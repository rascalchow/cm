"""
============================================================================
 Synthetic Farming-Unit Graph Generator
----------------------------------------------------------------------------
 Produces three CSV files under ./data/ :

     nodes.csv : id, lat, lon, county, province,
                 terrain_*, soil_*, area_*, crop_*, freq_*, owned_*,
                 label, split          (label = -1 if unlabeled)
     edges.csv : src, dst, distance_km, terrain_sim, soil_sim
                 (undirected -> symmetrically duplicated)
     meta.csv  : a few summary statistics

 Conforms to the assumptions of the paper :
    * 4,000 farming units
    * 13 provinces, 200 counties (~20 units / county)
    * Up to 10 geographic neighbours per unit (typically 5-6)
    * Selection of 30 % units per county (good / mid / bad economy buckets)
    * Selected nodes inside the same county are >=3 hops apart
============================================================================
"""

import os
import numpy as np
import pandas as pd
from collections import defaultdict, deque
from sklearn.neighbors import BallTree

RNG = np.random.default_rng(2026)
N_PROV, COUNTY_PER_PROV, UNITS_PER_COUNTY = 13, 200 // 13 + 1, 20  # 16 cnt/prov

TERRAIN  = ["plain", "hilly", "low_mountain"]
SOIL     = ["clay", "clay_silver", "sandy_silver", "sandy"]
CROPS    = ["paddy_rice", "corn", "wheat", "potato", "vegetable"]
SPRAYERS = ["knapsack", "boom_tractor", "drone", "self_propelled"]


# ---------------------------------------------------------------------------
def _onehot(value, choices):
    v = np.zeros(len(choices), dtype=np.float32)
    v[choices.index(value)] = 1.0
    return v


def _province_centers(n=N_PROV):
    """Place provinces randomly on a 10° x 10° lat-lon square (China-ish)."""
    lat = RNG.uniform(28, 42, n)
    lon = RNG.uniform(105, 122, n)
    return np.stack([lat, lon], axis=1)


def _county_centers(prov_xy, c_per_p=COUNTY_PER_PROV, sigma=0.4):
    out = []
    for c in prov_xy:
        out.append(c + RNG.normal(0, sigma, (c_per_p, 2)))
    return np.concatenate(out)              # [P*Cp, 2]


def _farm_locations(county_xy, u_per_c=UNITS_PER_COUNTY, sigma=0.07):
    out = []
    for c in county_xy:
        out.append(c + RNG.normal(0, sigma, (u_per_c, 2)))
    return np.concatenate(out)


# ---------------------------------------------------------------------------
def build_node_table(n_total: int = 4000) -> pd.DataFrame:
    prov_xy   = _province_centers()
    county_xy = _county_centers(prov_xy)
    farm_xy   = _farm_locations(county_xy)
    farm_xy   = farm_xy[:n_total]

    rows = []
    for i, (lat, lon) in enumerate(farm_xy):
        county_id   = i // UNITS_PER_COUNTY
        province_id = county_id // COUNTY_PER_PROV
        terrain     = RNG.choice(TERRAIN, p=[0.55, 0.30, 0.15])
        soil        = RNG.choice(SOIL,    p=[0.30, 0.25, 0.25, 0.20])

        # land areas (ha)
        paddy_field      = max(0, RNG.normal(8, 4))
        dry_field        = max(0, RNG.normal(5, 3))
        terraced_paddy   = max(0, RNG.normal(1, 1.2))
        terraced_dry     = max(0, RNG.normal(0.7, 0.8))

        # crop area split
        crop_share = RNG.dirichlet(np.ones(len(CROPS)) * 1.5)
        total_area = paddy_field + dry_field + terraced_paddy + terraced_dry
        crop_area  = crop_share * total_area

        # spraying frequencies (times / season)
        spray_freq = RNG.integers(low=2, high=12, size=len(CROPS))

        # current sprayer ownership (count per type)
        owned = RNG.integers(low=0, high=4, size=len(SPRAYERS))

        # ----- ground-truth label : new self-propelled sprayers needed -----
        # heuristic depending on size, terrain, ownership
        terrain_w = {"plain": 1.0, "hilly": 0.7, "low_mountain": 0.4}[terrain]
        soil_w    = {"clay": 0.9, "clay_silver": 1.0,
                     "sandy_silver": 1.0, "sandy": 0.85}[soil]
        demand_score = (
            0.18 * total_area * terrain_w * soil_w
            + 0.07 * spray_freq.mean()
            - 0.6  * owned[3]                # self-propelled already owned
            - 0.2  * owned[1]                # boom_tractor substitutes
            + RNG.normal(0, 0.7)
        )
        label = int(np.clip(np.round(demand_score / 1.5), 0, 5))

        rows.append({
            "id": i, "lat": lat, "lon": lon,
            "county":   county_id, "province": province_id,
            **{f"terrain_{t}": v for t, v in zip(TERRAIN,
                                                 _onehot(terrain, TERRAIN))},
            **{f"soil_{s}":    v for s, v in zip(SOIL,
                                                 _onehot(soil, SOIL))},
            "area_paddy": paddy_field, "area_dry": dry_field,
            "area_terraced_paddy": terraced_paddy,
            "area_terraced_dry":   terraced_dry,
            **{f"crop_area_{c}": a for c, a in zip(CROPS, crop_area)},
            **{f"freq_{c}":      f for c, f in zip(CROPS, spray_freq)},
            **{f"owned_{s}":     o for s, o in zip(SPRAYERS, owned)},
            "label": label,
        })
    df = pd.DataFrame(rows)
    return df


# ---------------------------------------------------------------------------
def build_edges(df: pd.DataFrame, k_max: int = 10,
                k_typ: int = 6) -> pd.DataFrame:
    """Geographic kNN with a small jitter so each unit gets between 4 and 10
    neighbours."""
    coords = np.deg2rad(df[["lat", "lon"]].values)
    tree   = BallTree(coords, metric="haversine")
    src, dst, dists = [], [], []
    for i in range(len(df)):
        k = RNG.integers(4, k_max + 1)        # variable per unit
        d, idx = tree.query(coords[[i]], k=k + 1)
        for j, dij in zip(idx[0][1:], d[0][1:]):
            src.append(i); dst.append(int(j))
            dists.append(float(dij) * 6371.0)         # km
    e = pd.DataFrame({"src": src, "dst": dst, "distance_km": dists})

    # similarity features
    terrain_cols = [c for c in df.columns if c.startswith("terrain_")]
    soil_cols    = [c for c in df.columns if c.startswith("soil_")]
    Tm = df[terrain_cols].values
    Sm = df[soil_cols].values
    e["terrain_sim"] = (Tm[e.src.values] * Tm[e.dst.values]).sum(1)
    e["soil_sim"]    = (Sm[e.src.values] * Sm[e.dst.values]).sum(1)
    # symmetrise
    e_rev = e.rename(columns={"src": "dst", "dst": "src"})
    e = pd.concat([e, e_rev], ignore_index=True).drop_duplicates(["src", "dst"])
    return e.reset_index(drop=True)


# ---------------------------------------------------------------------------
def _adj_dict(edges: pd.DataFrame, n: int):
    a = defaultdict(set)
    for s, d in zip(edges.src.values, edges.dst.values):
        a[int(s)].add(int(d))
    return a


def _hop_distance(adj, start, target, max_hop=3):
    if start == target:
        return 0
    seen = {start}
    front = deque([(start, 0)])
    while front:
        u, h = front.popleft()
        if h >= max_hop:
            continue
        for v in adj[u]:
            if v == target:
                return h + 1
            if v not in seen:
                seen.add(v)
                front.append((v, h + 1))
    return max_hop + 1


def stratified_3hop_split(df: pd.DataFrame, edges: pd.DataFrame,
                          ratio: float = 0.30,
                          val_frac: float = 0.10,
                          test_frac: float = 0.20) -> pd.Series:
    """For every county pick ~ratio*units_per_county nodes (good/mid/bad
    economy proxy = `total_area * (1+spray_freq.mean())`) such that selected
    members of the same county are >=3 hops apart."""
    adj = _adj_dict(edges, len(df))
    df["_econ"] = (
        df.area_paddy + df.area_dry +
        df.area_terraced_paddy + df.area_terraced_dry
    ) * (1 + df[[c for c in df.columns
                 if c.startswith("freq_")]].mean(axis=1))

    chosen = []
    for cid, sub in df.groupby("county"):
        # 3 strata
        thirds = np.array_split(sub.sort_values("_econ").index.values, 3)
        per_bucket = max(1, int(round(ratio * len(sub) / 3)))
        picks = []
        for bucket in thirds:
            random_order = RNG.permutation(bucket)
            for cand in random_order:
                if len(picks) >= per_bucket * 3:
                    break
                # 3-hop check
                if all(_hop_distance(adj, cand, p) > 3 for p in picks):
                    picks.append(int(cand))
        chosen.extend(picks)

    chosen = np.array(chosen)
    RNG.shuffle(chosen)
    n_val   = int(len(chosen) * val_frac / ratio)
    n_test  = int(len(chosen) * test_frac / ratio)
    n_train = len(chosen) - n_val - n_test

    split = pd.Series(["unlabeled"] * len(df), index=df.index)
    split.loc[chosen[:n_train]]                 = "train"
    split.loc[chosen[n_train:n_train + n_val]]  = "val"
    split.loc[chosen[n_train + n_val:]]         = "test"
    df.drop(columns=["_econ"], inplace=True)
    return split


# ---------------------------------------------------------------------------
def main(out_dir: str = "./data"):
    os.makedirs(out_dir, exist_ok=True)
    print("[1/3] generating nodes ...")
    nodes = build_node_table(4000)
    print("[2/3] generating edges ...")
    edges = build_edges(nodes)
    print("[3/3] selecting survey units (30%, 3-hop separated) ...")
    nodes["split"] = stratified_3hop_split(nodes, edges)

    nodes.to_csv(os.path.join(out_dir, "nodes.csv"), index=False)
    edges.to_csv(os.path.join(out_dir, "edges.csv"), index=False)

    meta = {
        "n_nodes":   len(nodes),
        "n_edges":   len(edges),
        "avg_deg":   round(len(edges) / len(nodes), 2),
        "n_train":   int((nodes.split == "train").sum()),
        "n_val":     int((nodes.split == "val").sum()),
        "n_test":    int((nodes.split == "test").sum()),
        "n_unlbl":   int((nodes.split == "unlabeled").sum()),
        "n_classes": int(nodes.label.max() + 1),
    }
    pd.Series(meta).to_csv(os.path.join(out_dir, "meta.csv"))
    print("done.\n", meta)


if __name__ == "__main__":
    main()

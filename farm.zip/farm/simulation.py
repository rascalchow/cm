"""
============================================================================
 Sprayer Demand Prediction via Semi-Supervised Node Classification on a
 Geographic Graph of Farming Units
----------------------------------------------------------------------------
 Environment : Python 3.11 / PyTorch 2.0.1 / PyG 2.3.1 / CUDA 11.8
 Data source : CSV files produced by `generate_data.py`
 Author      : (Your Name) - Precision Agriculture Submission
----------------------------------------------------------------------------
 The script:
   1. Loads node features, labels and the edge list from CSV.
   2. Builds a PyTorch-Geometric `Data` object.
   3. Reproduces 7 baselines and 4 GNN variants:
        - Baselines : Mean, LinearRegression, Kriging-OK, RandomForest,
                      XGBoost, MLP
        - GNNs      : GCN, GraphSAGE, GAT, ProposedGAT (multi-head GAT
                      with residual + edge weights + label propagation)
   4. Trains every model under the SAME train/val/test split, evaluates
      MAE / RMSE / Accuracy(±1) / Macro-F1, and prints a comparison table.
   5. Exports per-node predictions and a `results.csv` for later analysis.
============================================================================
"""

from __future__ import annotations

import argparse
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import f1_score, mean_absolute_error, mean_squared_error
from sklearn.neural_network import MLPRegressor
from torch_geometric.data import Data
from torch_geometric.nn import GATConv, GCNConv, SAGEConv

# Optional libraries - guarded import so that the script still runs
try:
    import xgboost as xgb
    HAS_XGB = True
except Exception:
    HAS_XGB = False

try:
    from pykrige.ok import OrdinaryKriging
    HAS_KRIGE = True
except Exception:
    HAS_KRIGE = False


# ----------------------------------------------------------------------
# 0. Reproducibility helpers
# ----------------------------------------------------------------------
def set_seed(seed: int = 42) -> None:
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ----------------------------------------------------------------------
# 1. Data loading
# ----------------------------------------------------------------------
@dataclass
class FarmGraph:
    x: torch.Tensor          # [N, F]
    y: torch.Tensor          # [N]   integer labels (0..C-1)
    edge_index: torch.Tensor # [2, E]
    edge_attr: torch.Tensor  # [E,  D]
    train_mask: torch.Tensor # [N]
    val_mask:   torch.Tensor # [N]
    test_mask:  torch.Tensor # [N]
    coords:     np.ndarray   # [N, 2]  (lat, lon) for kriging
    num_classes: int

    def to(self, device):
        self.x          = self.x.to(device)
        self.y          = self.y.to(device)
        self.edge_index = self.edge_index.to(device)
        self.edge_attr  = self.edge_attr.to(device)
        self.train_mask = self.train_mask.to(device)
        self.val_mask   = self.val_mask.to(device)
        self.test_mask  = self.test_mask.to(device)
        return self


def load_csv_dataset(data_dir: str = "./data") -> FarmGraph:
    """Reads:
       nodes.csv  : id, lat, lon, county, province, [features...], label, split
       edges.csv  : src, dst, distance_km, terrain_sim, soil_sim
    """
    nodes = pd.read_csv(os.path.join(data_dir, "nodes.csv"))
    edges = pd.read_csv(os.path.join(data_dir, "edges.csv"))

    feat_cols = [c for c in nodes.columns
                 if c not in ("id", "lat", "lon", "county", "province",
                              "label", "split")]

    x = torch.tensor(nodes[feat_cols].values, dtype=torch.float32)
    y = torch.tensor(nodes["label"].values, dtype=torch.long)

    src = torch.tensor(edges["src"].values, dtype=torch.long)
    dst = torch.tensor(edges["dst"].values, dtype=torch.long)
    edge_index = torch.stack([src, dst], dim=0)

    edge_attr = torch.tensor(
        edges[["distance_km", "terrain_sim", "soil_sim"]].values,
        dtype=torch.float32,
    )

    split = nodes["split"].values
    train_mask = torch.tensor(split == "train", dtype=torch.bool)
    val_mask   = torch.tensor(split == "val",   dtype=torch.bool)
    test_mask  = torch.tensor(split == "test",  dtype=torch.bool)

    return FarmGraph(
        x=x, y=y, edge_index=edge_index, edge_attr=edge_attr,
        train_mask=train_mask, val_mask=val_mask, test_mask=test_mask,
        coords=nodes[["lat", "lon"]].values,
        num_classes=int(y.max().item() + 1),
    )


# ----------------------------------------------------------------------
# 2. Metric helpers (regression + classification view)
# ----------------------------------------------------------------------
def evaluate(pred: np.ndarray, true: np.ndarray) -> Dict[str, float]:
    pred_int = np.clip(np.round(pred).astype(int), 0, true.max())
    return {
        "MAE":       float(mean_absolute_error(true, pred)),
        "RMSE":      float(np.sqrt(mean_squared_error(true, pred))),
        "Acc(±1)":   float(np.mean(np.abs(pred_int - true) <= 1)),
        "MacroF1":   float(f1_score(true, pred_int, average="macro",
                                    zero_division=0)),
    }


# ----------------------------------------------------------------------
# 3. Non-graph baselines
# ----------------------------------------------------------------------
def run_simple_mean(g: FarmGraph) -> Dict[str, float]:
    mean_val = g.y[g.train_mask].float().mean().item()
    pred = np.full(g.test_mask.sum().item(), mean_val)
    return evaluate(pred, g.y[g.test_mask].cpu().numpy())


def run_linear_regression(g: FarmGraph) -> Dict[str, float]:
    Xtr = g.x[g.train_mask].cpu().numpy()
    ytr = g.y[g.train_mask].cpu().numpy()
    Xte = g.x[g.test_mask].cpu().numpy()
    yte = g.y[g.test_mask].cpu().numpy()
    model = LinearRegression().fit(Xtr, ytr)
    return evaluate(model.predict(Xte), yte)


def run_random_forest(g: FarmGraph) -> Dict[str, float]:
    Xtr = g.x[g.train_mask].cpu().numpy()
    ytr = g.y[g.train_mask].cpu().numpy()
    Xte = g.x[g.test_mask].cpu().numpy()
    yte = g.y[g.test_mask].cpu().numpy()
    rf = RandomForestRegressor(n_estimators=300, max_depth=None,
                               n_jobs=-1, random_state=42).fit(Xtr, ytr)
    return evaluate(rf.predict(Xte), yte)


def run_xgboost(g: FarmGraph) -> Dict[str, float]:
    if not HAS_XGB:
        return {"MAE": float("nan"), "RMSE": float("nan"),
                "Acc(±1)": float("nan"), "MacroF1": float("nan")}
    Xtr = g.x[g.train_mask].cpu().numpy()
    ytr = g.y[g.train_mask].cpu().numpy()
    Xte = g.x[g.test_mask].cpu().numpy()
    yte = g.y[g.test_mask].cpu().numpy()
    model = xgb.XGBRegressor(n_estimators=400, max_depth=6,
                             learning_rate=0.05, n_jobs=-1,
                             random_state=42).fit(Xtr, ytr)
    return evaluate(model.predict(Xte), yte)


def run_mlp(g: FarmGraph) -> Dict[str, float]:
    Xtr = g.x[g.train_mask].cpu().numpy()
    ytr = g.y[g.train_mask].cpu().numpy()
    Xte = g.x[g.test_mask].cpu().numpy()
    yte = g.y[g.test_mask].cpu().numpy()
    mlp = MLPRegressor(hidden_layer_sizes=(128, 64),
                       activation="relu", max_iter=500,
                       random_state=42).fit(Xtr, ytr)
    return evaluate(mlp.predict(Xte), yte)


def run_kriging(g: FarmGraph) -> Dict[str, float]:
    if not HAS_KRIGE:
        return {"MAE": float("nan"), "RMSE": float("nan"),
                "Acc(±1)": float("nan"), "MacroF1": float("nan")}
    tr_idx = g.train_mask.cpu().numpy()
    te_idx = g.test_mask.cpu().numpy()
    coords = g.coords
    y_np   = g.y.cpu().numpy().astype(float)
    OK = OrdinaryKriging(
        coords[tr_idx, 1], coords[tr_idx, 0], y_np[tr_idx],
        variogram_model="spherical", verbose=False, enable_plotting=False,
    )
    pred, _ = OK.execute("points",
                         coords[te_idx, 1], coords[te_idx, 0])
    return evaluate(np.asarray(pred), y_np[te_idx])


# ----------------------------------------------------------------------
# 4. GNN models
# ----------------------------------------------------------------------
class GCN(nn.Module):
    def __init__(self, in_dim, hid, out_dim, dropout=0.5):
        super().__init__()
        self.c1 = GCNConv(in_dim, hid)
        self.c2 = GCNConv(hid, out_dim)
        self.drop = dropout

    def forward(self, x, edge_index, *_):
        h = F.relu(self.c1(x, edge_index))
        h = F.dropout(h, p=self.drop, training=self.training)
        return self.c2(h, edge_index)


class GraphSAGE(nn.Module):
    def __init__(self, in_dim, hid, out_dim, dropout=0.5):
        super().__init__()
        self.c1 = SAGEConv(in_dim, hid)
        self.c2 = SAGEConv(hid, out_dim)
        self.drop = dropout

    def forward(self, x, edge_index, *_):
        h = F.relu(self.c1(x, edge_index))
        h = F.dropout(h, p=self.drop, training=self.training)
        return self.c2(h, edge_index)


class GAT(nn.Module):
    def __init__(self, in_dim, hid, out_dim, heads=4, dropout=0.5):
        super().__init__()
        self.c1 = GATConv(in_dim, hid, heads=heads, dropout=dropout)
        self.c2 = GATConv(hid * heads, out_dim, heads=1,
                          concat=False, dropout=dropout)
        self.drop = dropout

    def forward(self, x, edge_index, *_):
        h = F.elu(self.c1(x, edge_index))
        h = F.dropout(h, p=self.drop, training=self.training)
        return self.c2(h, edge_index)


class ProposedGAT(nn.Module):
    """Multi-head GAT with:
       * residual / skip connection
       * edge-weight gating using geographic distance & terrain similarity
       * input + hidden batch-norm
       * label-smoothed cross-entropy is used at training time
    """
    def __init__(self, in_dim, hid, out_dim, heads=8, dropout=0.4):
        super().__init__()
        self.bn0 = nn.BatchNorm1d(in_dim)
        self.gat1 = GATConv(in_dim, hid, heads=heads,
                            dropout=dropout, edge_dim=3)
        self.bn1 = nn.BatchNorm1d(hid * heads)
        self.gat2 = GATConv(hid * heads, hid, heads=heads,
                            dropout=dropout, edge_dim=3)
        self.bn2 = nn.BatchNorm1d(hid * heads)
        self.skip = nn.Linear(in_dim, hid * heads)
        self.head = nn.Sequential(
            nn.Linear(hid * heads, hid),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hid, out_dim),
        )

    def forward(self, x, edge_index, edge_attr):
        x0 = self.bn0(x)
        h  = F.elu(self.gat1(x0, edge_index, edge_attr=edge_attr))
        h  = self.bn1(h)
        h  = h + self.skip(x0)                       # residual
        h  = F.elu(self.gat2(h, edge_index, edge_attr=edge_attr))
        h  = self.bn2(h)
        return self.head(h)


# ----------------------------------------------------------------------
# 5. GNN training loop
# ----------------------------------------------------------------------
def train_gnn(model: nn.Module, g: FarmGraph, *,
              epochs: int = 300, lr: float = 5e-3,
              weight_decay: float = 5e-4,
              label_smoothing: float = 0.05,
              patience: int = 40) -> Dict[str, float]:

    device = next(model.parameters()).device
    optim = torch.optim.AdamW(model.parameters(), lr=lr,
                              weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(optim, T_max=epochs)
    crit  = nn.CrossEntropyLoss(label_smoothing=label_smoothing)

    best_val, best_state, bad = float("inf"), None, 0
    for ep in range(1, epochs + 1):
        model.train()
        optim.zero_grad()
        out = model(g.x, g.edge_index, g.edge_attr)
        loss = crit(out[g.train_mask], g.y[g.train_mask])
        loss.backward()
        optim.step()
        sched.step()

        model.eval()
        with torch.no_grad():
            out = model(g.x, g.edge_index, g.edge_attr)
            v = crit(out[g.val_mask], g.y[g.val_mask]).item()
            if v < best_val - 1e-4:
                best_val, best_state, bad = v, {k: t.detach().clone()
                                                for k, t in
                                                model.state_dict().items()}, 0
            else:
                bad += 1
            if bad >= patience:
                break

    if best_state is not None:
        model.load_state_dict(best_state)

    model.eval()
    with torch.no_grad():
        logits = model(g.x, g.edge_index, g.edge_attr)
        pred   = logits.argmax(dim=-1)[g.test_mask].cpu().numpy()
        true   = g.y[g.test_mask].cpu().numpy()
    return evaluate(pred.astype(float), true)


# ----------------------------------------------------------------------
# 6. Orchestration
# ----------------------------------------------------------------------
def main(args):
    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"[INFO] device = {device}")

    g = load_csv_dataset(args.data_dir).to(device)
    print(f"[INFO] N={g.x.size(0)} F={g.x.size(1)} "
          f"E={g.edge_index.size(1)} C={g.num_classes}")

    results: Dict[str, Dict[str, float]] = {}

    # --- non-graph baselines ---
    results["MeanBaseline"]   = run_simple_mean(g)
    results["LinearReg"]      = run_linear_regression(g)
    results["Kriging"]        = run_kriging(g)
    results["RandomForest"]   = run_random_forest(g)
    results["XGBoost"]        = run_xgboost(g)
    results["MLP"]            = run_mlp(g)

    # --- GNNs ---
    in_dim  = g.x.size(1)
    nclass  = g.num_classes
    gnn_specs = {
        "GCN":         GCN(in_dim, 64, nclass),
        "GraphSAGE":   GraphSAGE(in_dim, 64, nclass),
        "GAT":         GAT(in_dim, 32, nclass, heads=4),
        "ProposedGAT": ProposedGAT(in_dim, 32, nclass, heads=8),
    }
    for name, m in gnn_specs.items():
        m = m.to(device)
        t0 = time.time()
        res = train_gnn(m, g, epochs=args.epochs)
        res["time_s"] = round(time.time() - t0, 1)
        results[name] = res
        print(f"[done] {name:<14s} -> {res}")

    df = pd.DataFrame(results).T.sort_values("MAE")
    print("\n=========== FINAL COMPARISON ===========")
    print(df.to_string())
    df.to_csv(os.path.join(args.data_dir, "results.csv"))


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", default="./data")
    p.add_argument("--epochs",   type=int, default=300)
    p.add_argument("--seed",     type=int, default=42)
    main(p.parse_args())

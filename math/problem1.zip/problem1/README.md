# A Study on the Mathematical Modeling of Automated Learning Path Generation Using Graph Neural Networks

Doctoral dissertation, with the code, synthetic data and computational experiments behind it.

| What | Where |
|---|---|
| Dissertation (PDF) | `Dissertation_LPG_GNN.pdf` (= `dissertation/main.pdf`) |
| Dissertation (Word) | `Dissertation_LPG_GNN.docx` (= `dissertation/main.docx`) |
| LaTeX sources | `dissertation/main.tex`, `dissertation/chapters/*.tex`, `dissertation/refs.bib` |
| Verified bibliography (per part) | `dissertation/bib/*.bib` |
| Python package | `code/lpg/` |
| Scripts | `code/scripts/` |
| Synthetic data | `data/` (JSON/NPZ for the code, CSV exports in `data/csv/`) |
| Results | `results/` (trained models, evaluation outputs, logs, `summary.json`) |

## Contents of the dissertation

1. Introduction: background, research questions RQ1–RQ5, contributions.
2. Literature review: remote education, pedagogy, learning objects, learner models, learning-path generation, GNNs and neural combinatorial optimisation.
3. Mathematical model: prerequisite partial order (knowledge space theory), Bloom levels, pedagogical rules, learning objects (IEEE LOM), learner traits, and stochastic learning dynamics (readiness, ZPD, forgetting, dropout). The chapter formulates the LPG problem and proves well-posedness, Lipschitz stability, a survival decomposition and down-set invariance. It shows LPG is NP-hard, and strongly NP-hard with prerequisites. It also proves submodularity without prerequisites and failure of myopic planning with them.
4. PA-HGNN: pedagogy-aware heterogeneous GNN with masked attention decoder, feasibility/equivariance/receptive-field results, and behaviour cloning plus policy gradient training with a Rao–Blackwellised reward.
5. Synthetic data: generator, ten dataset splits, validation against stylised facts.
6. Computational experiments: effectiveness, cost, Jensen gap, generalisation, robustness, equity, ablations, case study.
7. Discussion. 8. Conclusion. Appendices: proofs, parameters, data dictionary, reproducibility.

## Reproducing

Requirements: Python 3.12, PyTorch ≥ 2.1 (CPU suffices), NumPy, SciPy, pandas, NetworkX, Matplotlib; a TeX Live installation for the PDF.

```bash
python3 code/scripts/generate_data.py                 # synthetic data -> data/
python3 code/scripts/analyze_data.py                  # Chapter 5 statistics/figures
python3 code/scripts/theory_check.py                  # exact verification of the theory (Sec. 6.2)
python3 code/scripts/compute_experts.py --n 32 --procs 5 --threads 1 --pop 24 --gens 30
bash    code/scripts/train_all.sh 7                   # short-schedule runs + ablations -> results/models/
(cd code/scripts && python3 train_model.py --name full --variant full --init full_s1 --rl_iters 150 --threads 1 --seed 1 --crn)
(cd code/scripts && python3 train_model.py --name full_robust --variant full --init full_s1 --rl_iters 150 --threads 1 --seed 1 --crn --robust)
bash    results/commands.sh                           # all evaluations + Chapter 6 tables/figures
cd dissertation && pdflatex main && bibtex main && pdflatex main && pdflatex main && cd ..
python3 code/scripts/latex_to_docx.py                 # Word version (needs pandoc, LibreOffice, python-docx)
```

Use single-threaded processes (`--threads 1`) and parallelise over processes; on a CPU-only machine this is much faster than multi-threaded PyTorch for these small graphs.

## Title page

Candidate, advisor and institution are placeholders. Edit the macros at the top of `dissertation/main.tex` (`\dissAuthor`, `\dissAdvisor`, `\dissUniv`, ...).

## Word version

`code/scripts/latex_to_docx.py` converts the compiled LaTeX dissertation to Word. Equations become native Word equations. Numbering of chapters, theorems, figures, tables and equations, cross-references and the numeric citations match the PDF. Figures are embedded as PNG and the contents page is pre-filled. When the file is opened in Word you will be asked whether to update fields; answering *Yes* recomputes the contents page numbers for Word's layout. Intermediate files are written to `dissertation/docx_build/`.

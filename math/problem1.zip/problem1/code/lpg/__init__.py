"""lpg -- Learning Path Generation with pedagogy-aware graph neural networks.

Companion code for the dissertation "A Study on the Mathematical Modeling of Automated
Learning Path Generation Using Graph Neural Networks".

Modules
-------
synth      synthetic curricula, learning-object catalogues and learner populations
dynamics   batched learner-dynamics model (planner / mean-field and stochastic "true" learner)
baselines  classical path generators (random, static curriculum, rule-based KG, greedy, beam, GA)
model      pedagogy-aware heterogeneous GNN policy (PA-HGNN) and ablation variants
train      behaviour cloning and policy-gradient training
evaluate   execution of paths on simulated learners and outcome metrics
"""

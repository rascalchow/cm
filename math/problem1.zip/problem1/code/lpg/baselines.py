"""Classical learning-path generators used as baselines (all operate on the planner model).

random       uniformly random feasible LO
static       non-personalised syllabus: goal-relevant concepts in topological order, LOs by Bloom level
kg_rule      personalised rule-based knowledge-graph planner (topological traversal of unmastered
             goal ancestors, Bloom-level progression, modality preference, mastery-based advancement)
greedy       myopic model-based planner maximising survival-weighted relevance-shaped gain per minute
beam         beam search over the planner model with the same shaped heuristic
ga           random-key genetic algorithm optimising the planner objective J

Every generator returns a list of LO sequences (one per learner).
"""
from __future__ import annotations

import torch

from .dynamics import Dynamics, Learners, State, expected_objective


NEG = -1e9


def relevance_weights(dyn: Dynamics, L: Learners, gamma: float = 0.7) -> torch.Tensor:
    """(B, K) goal relevance: 1 for goals, gamma^d for ancestors at distance d of the nearest goal."""
    D = dyn.c.anc_dist
    Dm = torch.where(D > 0, D, torch.full_like(D, 99.0))           # Dm[i, j] = d(i, j)
    isg = (L.goals > 0)
    dist = torch.where(isg[:, None, :], Dm[None], torch.full_like(Dm[None], 99.0)).min(-1).values
    w = torch.where(isg, torch.ones_like(dist), gamma ** dist)
    return torch.where(dist < 99, w, torch.where(isg, w, torch.zeros_like(w)))


def _run(dyn: Dynamics, L: Learners, choose, max_steps: int = 400) -> list[list[int]]:
    s = dyn.init_state(L)
    paths = [[] for _ in range(L.B)]
    for _ in range(max_steps):
        mk = dyn.mask(s, L)
        has = mk.any(1)
        if not has.any():
            break
        a = choose(s, mk)
        a = torch.where(has, a, torch.full_like(a, -1))
        for i in torch.nonzero(a >= 0).flatten().tolist():
            paths[i].append(int(a[i]))
        s, _ = dyn.step(s, L, a)
    return paths


# ------------------------------------------------------------------------------ random
def random_paths(dyn: Dynamics, L: Learners, seed: int = 0) -> list[list[int]]:
    g = torch.Generator().manual_seed(seed)

    def choose(s, mk):
        return torch.multinomial(mk.float() + 1e-12, 1, generator=g).squeeze(1)
    return _run(dyn, L, choose)


# ------------------------------------------------------------------------------ static syllabus
def static_paths(dyn: Dynamics, L: Learners) -> list[list[int]]:
    """One-size-fits-all syllabus over goal-relevant concepts (ignores prior knowledge)."""
    c = dyn.c
    rel = relevance_weights(dyn, L) > 0
    # priority: earlier layer first, then concept id, then Bloom level, then LO id
    base = (c.layer[c.primary].float() * 1e6 + c.primary.float() * 1e2 + c.bloom.float() * 10
            + torch.arange(c.N).float() / c.N)
    pri = torch.where(rel[:, c.primary], -base[None, :], torch.full((L.B, c.N), NEG))

    def choose(s, mk):
        sc = torch.where(mk, pri, torch.full_like(pri, 2 * NEG))
        a = sc.argmax(1)
        return torch.where(sc.max(1).values > NEG, a, torch.full_like(a, -1))
    return _run(dyn, L, choose)


# ------------------------------------------------------------------------------ rule-based KG
def kg_rule_paths(dyn: Dynamics, L: Learners) -> list[list[int]]:
    """Personalised rule-based traversal of the knowledge graph."""
    c, pp = dyn.c, dyn.p
    rel = relevance_weights(dyn, L) > 0
    fit = dyn.fit(L)
    order = c.layer.float() * 1e3 + torch.arange(c.K).float()       # topological order of concepts

    def choose(s, mk):
        need = rel & (s.m < pp.tau_master)                          # unmastered relevant concepts
        # current focus: first needed concept (in topological order) that has a feasible LO
        has_lo = torch.zeros_like(need)
        has_lo.scatter_reduce_(1, c.primary.expand(L.B, -1), mk, reduce="amax")
        cand = need & has_lo
        focus = torch.where(cand, -order[None, :], torch.full((L.B, c.K), NEG)).argmax(1)
        ok_focus = cand.any(1)
        on_focus = c.primary[None, :] == focus[:, None]
        # LO choice: lowest Bloom level whose ceiling exceeds current mastery, then fit, then quality
        mprim = s.m[:, c.primary]
        useful = c.ceil[None, :] > mprim + 0.05
        score = -c.bloom.float()[None, :] * 10 + fit * 2 + c.rho[None, :]
        score = torch.where(useful, score, score - 100)
        score = torch.where(mk & on_focus, score, torch.full_like(score, 2 * NEG))
        a = score.argmax(1)
        return torch.where(ok_focus & (score.max(1).values > NEG), a, torch.full_like(a, -1))
    return _run(dyn, L, choose)


# ------------------------------------------------------------------------------ greedy
def shaped_gain_scores(dyn: Dynamics, s: State, L: Learners, w: torch.Tensor) -> torch.Tensor:
    """(B, N) survival-weighted relevance-shaped immediate gain."""
    dm, p, h = dyn.gains_all(s, L)
    return (dm * w[:, None, :]).sum(-1) * (1 - h)


def greedy_paths(dyn: Dynamics, L: Learners, gamma: float = 0.7, per_minute: bool = True) -> list[list[int]]:
    w = relevance_weights(dyn, L, gamma)
    state = {}

    def choose(s, mk):
        sc = shaped_gain_scores(dyn, s, L, w)
        if per_minute:
            sc = sc / dyn.c.dur[None, :]
        sc = torch.where(mk, sc, torch.full_like(sc, NEG))
        return sc.argmax(1)
    return _run(dyn, L, choose)


# ------------------------------------------------------------------------------ beam search
def beam_paths(dyn: Dynamics, L: Learners, width: int = 8, gamma: float = 0.7, kappa: float = 0.5,
               max_steps: int = 400) -> list[list[int]]:
    """Beam search on the planner model.

    Partial paths are ranked by  J_t + kappa * S_t * (Phi(m_t) - Phi(m_0)),  where Phi is the
    relevance-weighted mastery of non-goal (prerequisite) concepts; complete paths are compared
    by the exact planner objective J.
    """
    B, N = L.B, dyn.c.N
    W = width
    Lr = L.repeat(W)                                   # rows: learner-major, beam-minor
    wrel = relevance_weights(dyn, Lr, gamma) * (Lr.goals == 0).float()
    s = dyn.init_state(Lr)
    phi0 = (s.m * wrel).sum(1)
    # only the first beam slot is live at the start
    live = torch.zeros(B, W, dtype=torch.bool)
    live[:, 0] = True
    paths = [[] for _ in range(B * W)]
    best_J = torch.full((B,), NEG)
    best_path: list[list[int]] = [[] for _ in range(B)]
    for _ in range(max_steps):
        mk = dyn.mask(s, Lr) & live.reshape(-1)[:, None]
        has = mk.any(1)
        # finished beams: record complete paths
        done = live.reshape(-1) & ~has
        for r in torch.nonzero(done).flatten().tolist():
            b = r // W
            if s.J[r] > best_J[b]:
                best_J[b] = s.J[r]
                best_path[b] = list(paths[r])
        live = live & has.reshape(B, W)
        if not live.any():
            break
        # expand every live beam with every feasible LO (expected next state)
        dm, p, h = dyn.gains_all(s, Lr)
        S_next = s.S[:, None] * (1 - h)                               # (BW, N)
        m_next = (s.m[:, None, :] + dm).clamp(0, 1)                   # ignore forgetting in the score
        psi_next = (m_next * Lr.goals[:, None, :]).sum(-1)
        J_next = s.J[:, None] + S_next * (psi_next - (s.m * Lr.goals).sum(1)[:, None])
        phi_next = (m_next * wrel[:, None, :]).sum(-1)
        score = J_next + kappa * S_next * (phi_next - phi0[:, None])
        score = torch.where(mk, score, torch.full_like(score, NEG))
        score = score.reshape(B, W * N)
        top = score.topk(W, dim=1)
        new_live = top.values > NEG / 2
        src_beam = top.indices // N
        act = top.indices % N
        src_rows = (torch.arange(B)[:, None] * W + src_beam).reshape(-1)
        s = s.index(src_rows)
        a = torch.where(new_live.reshape(-1), act.reshape(-1), torch.full((B * W,), -1, dtype=torch.long))
        paths = [list(paths[r]) for r in src_rows.tolist()]
        for r in torch.nonzero(a >= 0).flatten().tolist():
            paths[r].append(int(a[r]))
        s, _ = dyn.step(s, Lr, a)
        live = new_live
        phi0 = phi0[src_rows]
    for r in range(B * W):                             # beams still alive at the step limit
        b = r // W
        if live.reshape(-1)[r] and s.J[r] > best_J[b]:
            best_J[b] = s.J[r]
            best_path[b] = list(paths[r])
    return best_path


# ------------------------------------------------------------------------------ genetic algorithm
def decode_priorities(dyn: Dynamics, L: Learners, pri: torch.Tensor, max_steps: int = 400):
    """Decode random-key chromosomes (B, N) into feasible paths; returns (paths, J)."""
    s = dyn.init_state(L)
    paths = [[] for _ in range(L.B)]
    for _ in range(max_steps):
        mk = dyn.mask(s, L) & (pri > NEG / 2)
        has = mk.any(1)
        if not has.any():
            break
        sc = torch.where(mk, pri, torch.full_like(pri, 2 * NEG))
        a = torch.where(has, sc.argmax(1), torch.full((L.B,), -1, dtype=torch.long))
        for i in torch.nonzero(a >= 0).flatten().tolist():
            paths[i].append(int(a[i]))
        s, _ = dyn.step(s, L, a)
    return paths, s.J


def ga_paths(dyn: Dynamics, L: Learners, pop: int = 32, gens: int = 40, elite: int = 4,
             p_mut: float = 0.1, seed: int = 0, mc_samples: int = 0, robust: bool = False,
             crn: bool = False) -> list[list[int]]:
    """Random-key GA (one population per learner, all learners evolved in parallel).

    With ``mc_samples > 0`` the fitness is the Monte Carlo expected objective under the planner's
    stochastic model (GA-MC; with ``robust=True`` the uncertainty-aware objective; with ``crn=True``
    the population of a learner is evaluated with common random numbers); otherwise the mean-field
    objective J is used.
    """
    g = torch.Generator().manual_seed(seed)
    B, N = L.B, dyn.c.N
    rel = relevance_weights(dyn, L) > 0
    relLO = rel[:, dyn.c.primary]                                       # (B, N)
    Lp = L.repeat(pop)
    relp = relLO.repeat_interleave(pop, 0)
    # initial population: random keys; slot 0 seeded with the static syllabus order
    keys = torch.rand(B * pop, N, generator=g)
    c = dyn.c
    syll = -(c.layer[c.primary].float() * 100 + c.bloom.float()) / 1000.0
    keys[::pop] = syll[None, :] - syll.min() + 1e-3
    best_J = torch.full((B,), NEG)
    best_path: list[list[int]] = [[] for _ in range(B)]
    for gen in range(gens):
        pri = torch.where(relp, keys, torch.full_like(keys, NEG))
        paths, J = decode_priorities(dyn, Lp, pri)
        if mc_samples > 0:
            J = expected_objective(dyn, Lp, paths, mc_samples, robust=robust, crn_group=pop if crn else 1)
        Jm = J.reshape(B, pop)
        jb, ib = Jm.max(1)
        for b in range(B):
            if jb[b] > best_J[b]:
                best_J[b] = jb[b]
                best_path[b] = paths[b * pop + int(ib[b])]
        if gen == gens - 1:
            break
        # selection (tournament of 2), uniform crossover biased to the fitter parent, mutation
        order = Jm.argsort(1, descending=True)
        K3 = keys.reshape(B, pop, N)
        elites = torch.gather(K3, 1, order[:, :elite, None].expand(-1, -1, N))
        n_child = pop - elite
        i1 = torch.randint(0, pop, (B, n_child, 2), generator=g)
        i2 = torch.randint(0, pop, (B, n_child, 2), generator=g)
        f = lambda idx: torch.where(torch.gather(Jm, 1, idx[..., 0]) >= torch.gather(Jm, 1, idx[..., 1]),
                                    idx[..., 0], idx[..., 1])
        pa, pb = f(i1), f(i2)
        A = torch.gather(K3, 1, pa[..., None].expand(-1, -1, N))
        Bk = torch.gather(K3, 1, pb[..., None].expand(-1, -1, N))
        cross = torch.rand(B, n_child, N, generator=g) < 0.7
        child = torch.where(cross, A, Bk)
        mut = torch.rand(B, n_child, N, generator=g) < p_mut
        child = torch.where(mut, torch.rand(B, n_child, N, generator=g), child)
        keys = torch.cat([elites, child], 1).reshape(B * pop, N)
    return best_path

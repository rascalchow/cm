"""Loading of the generated datasets."""
from __future__ import annotations

import json
from pathlib import Path

from .synth import load_curriculum, load_learners
from .train import Instance

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def manifest() -> dict:
    return json.loads((DATA / "manifest.json").read_text())


def load_split(split: str, params=None, limit_learners: int | None = None) -> list[Instance]:
    out = []
    for it in manifest()["splits"][split]:
        cur = load_curriculum(DATA / "curricula" / f"{it['curriculum']}.json")
        L = load_learners(DATA / it["file"])
        if limit_learners is not None:
            L = {k: v[:limit_learners] for k, v in L.items()}
        inst = Instance(cur, L, params)
        inst.split = split
        out.append(inst)
    return out

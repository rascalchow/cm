"""Batched learner-dynamics model.

State of learner u after t learning objects (LOs):  m_t in [0,1]^K (concept mastery),
n_t (exposure counts), elapsed study time tau_t, the set of visited LOs, the number of new
concepts introduced in the current session and the survival probability S_t.

Transition after studying LO l (Chapter 3 of the dissertation):

  success probability   p_l   = g + (1-g) * sigmoid(a_l (lambda_theta theta + lambda_m mbar_l - b_l))
  readiness             R_c   = prod_{i in Pre(c)} sigmoid(gamma (m_i - tau_R))^{w_ic}
  ZPD factor            Z_l   = exp(-(p_l - p*)^2 / (2 sigma_Z^2))
  learning gain         dm_c  = min(1, eta rho_l q_lc) * R_c * Z_l * (h_{beta_l} - m_c)_+   [* xi]
  dropout hazard        h_l   = h0 * exp(psi_fit (1-fit_l) + psi_fr (p_lo - p_l)_+ + psi_len (d_l/20 - 1)_+)
  forgetting at a session boundary (gap Delta days, k sessions crossed)
                        m_c  <- m0_c + (m_c - m0_c) * exp(-phi * Delta * k / (1 + kappa_s n_c))

``mode='planner'`` runs the deterministic mean-field model with the planner's *estimated*
learner parameters and tracks the survival probability; the objective is the
survival-weighted goal mastery  J = Psi(m_0) + sum_t S_t (Psi(m_t) - Psi(m_{t-1})).
``mode='mc'`` adds the multiplicative Gamma learning noise but keeps the expected survival, which
gives an unbiased, lower-variance Monte Carlo estimate of the planner's expected objective.
``mode='true'`` runs a stochastic learner with the *true* parameters (multiplicative Gamma
learning noise, Bernoulli dropout and Bernoulli assessment outcomes).
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np
import torch

from .synth import BLOOM_CEIL, MODALITIES, BANDWIDTH


@dataclass
class DynamicsParams:
    tau_pre: float = 0.50        # hard prerequisite threshold (mastery-learning rule)
    tau_ready: float = 0.50      # centre of the soft readiness sigmoid
    gamma_ready: float = 12.0    # steepness of readiness
    p_star: float = 0.70         # optimal success probability (zone of proximal development)
    sigma_z: float = 0.22
    guess: float = 0.10
    lambda_m: float = 3.0        # weight of current mastery in the success model
    lambda_theta: float = 0.5    # weight of general ability in the success model
    h0: float = 0.003            # baseline dropout hazard per LO
    psi_fit: float = 1.2
    psi_frustration: float = 3.0
    p_low: float = 0.50
    psi_length: float = 0.8
    stability_gain: float = 0.5  # kappa_s
    max_new_per_session: int = 2  # cognitive-load constraint
    tau_master: float = 0.75     # mastery threshold used for attainment
    new_threshold: float = 0.30  # a concept is "new" if never exposed and mastery below this
    gain_noise_shape: float = 8.0
    delayed_gap_days: float = 7.0


class Curriculum:
    """Tensor view of a curriculum dict produced by :func:`lpg.synth.generate_curriculum`."""

    def __init__(self, cur: dict, device: str = "cpu"):
        self.name = cur["name"]
        self.K = K = len(cur["concepts"])
        self.N = N = len(cur["los"])
        f = lambda x: torch.tensor(x, dtype=torch.float32, device=device)
        l_ = lambda x: torch.tensor(x, dtype=torch.long, device=device)
        los = cur["los"]
        self.primary = l_([o["primary"] for o in los])
        self.secondary = l_([o["secondary"] for o in los])
        Q = torch.zeros(N, K, device=device)
        Q[torch.arange(N), self.primary] = 1.0
        for o in los:
            if o["secondary"] >= 0:
                Q[o["lo"], o["secondary"]] = o["q_secondary"]
        self.Q = Q
        self.Qsum = Q.sum(1)
        self.bloom = l_([o["bloom"] for o in los])
        self.ceil = f(BLOOM_CEIL[np.array([o["bloom"] for o in los]) - 1])
        self.b = f([o["difficulty"] for o in los])
        self.a = f([o["discrimination"] for o in los])
        self.rho = f([o["quality"] for o in los])
        self.dur = f([o["duration"] for o in los])
        self.bw = l_([BANDWIDTH.index(o["bandwidth"]) for o in los])
        self.mod = l_([MODALITIES.index(o["modality"]) for o in los])
        self.layer = l_([c["layer"] for c in cur["concepts"]])
        self.topic = l_([c["topic"] for c in cur["concepts"]])
        W = torch.zeros(K, K, device=device)
        for e in cur["prerequisites"]:
            W[e["src"], e["dst"]] = e["weight"]
        self.W = W                                   # W[i, j] > 0  iff  i -> j
        self.P = (W > 0).float()
        D = torch.zeros(K, K, device=device)
        for e in cur["closure"]:
            D[e["src"], e["dst"]] = e["distance"]
        self.anc_dist = D                            # D[i, j] = d(i, j) if i < j, else 0
        self.n_layers = int(self.layer.max().item()) + 1
        # LO -> concept incidence for exposure counting
        self.cover = (Q > 0).float()
        self.cur = cur


@dataclass
class Learners:
    """A batch of learners as seen by a model (either the planner's estimates or the truth)."""
    theta: torch.Tensor
    eta: torch.Tensor
    phi: torch.Tensor
    pref: torch.Tensor     # (B, 4)
    bw: torch.Tensor       # (B,) long
    Ts: torch.Tensor       # session length (minutes)
    T: torch.Tensor        # total time budget (minutes)
    gap: torch.Tensor      # inter-session gap (days)
    m0: torch.Tensor       # (B, K)
    goals: torch.Tensor    # (B, K) goal weights, rows sum to 1

    @property
    def B(self):
        return self.theta.shape[0]

    def index(self, idx):
        return Learners(**{k: getattr(self, k)[idx] for k in self.__dataclass_fields__})

    def repeat(self, r: int):
        return Learners(**{k: getattr(self, k).repeat_interleave(r, 0) for k in self.__dataclass_fields__})


def learners_from_numpy(L: dict, view: str = "planner", device: str = "cpu") -> Learners:
    """``view='planner'`` uses the observed estimates, ``view='true'`` the latent truth."""
    f = lambda x: torch.tensor(np.asarray(x), dtype=torch.float32, device=device)
    goals = f(L["goals"].astype(float))
    goals = goals / goals.sum(1, keepdim=True).clamp_min(1.0)
    T = f(L["Ts"] * L["n_sess"])
    if view == "planner":
        return Learners(f(L["theta_hat"]), f(L["eta_hat"]), f(L["phi_hat"]), f(L["pref_hat"]),
                        torch.tensor(L["bw"], dtype=torch.long, device=device), f(L["Ts"]), T, f(L["gap"]),
                        f(L["m0_hat"]), goals)
    return Learners(f(L["theta"]), f(L["eta"]), f(L["phi"]), f(L["pref"]),
                    torch.tensor(L["bw"], dtype=torch.long, device=device), f(L["Ts"]), T, f(L["gap"]),
                    f(L["m0"]), goals)


@dataclass
class State:
    m: torch.Tensor          # (B, K)
    nexp: torch.Tensor       # (B, K)
    t: torch.Tensor          # (B,)
    visited: torch.Tensor    # (B, N) bool
    new_in_sess: torch.Tensor  # (B,)
    S: torch.Tensor          # survival probability (planner) or alive indicator (true)
    alive: torch.Tensor      # (B,) bool -- false after dropout (true mode) or termination
    J: torch.Tensor          # accumulated objective
    steps: torch.Tensor      # (B,)
    last: torch.Tensor       # (B,) last LO (-1 if none)

    def index(self, idx):
        return State(**{k: getattr(self, k)[idx] for k in self.__dataclass_fields__})

    def clone(self):
        return State(**{k: getattr(self, k).clone() for k in self.__dataclass_fields__})


class Dynamics:
    def __init__(self, cur: Curriculum, params: DynamicsParams | None = None):
        self.c = cur
        self.p = params or DynamicsParams()

    # ------------------------------------------------------------------ basic quantities
    def init_state(self, L: Learners) -> State:
        B, K, N = L.B, self.c.K, self.c.N
        dev = L.m0.device
        m = L.m0.clone()
        return State(m=m, nexp=torch.zeros(B, K, device=dev), t=torch.zeros(B, device=dev),
                     visited=torch.zeros(B, N, dtype=torch.bool, device=dev),
                     new_in_sess=torch.zeros(B, device=dev), S=torch.ones(B, device=dev),
                     alive=torch.ones(B, dtype=torch.bool, device=dev), J=self.psi(m, L),
                     steps=torch.zeros(B, dtype=torch.long, device=dev),
                     last=torch.full((B,), -1, dtype=torch.long, device=dev))

    @staticmethod
    def psi(m: torch.Tensor, L: Learners) -> torch.Tensor:
        """Goal-mastery functional Psi(m) = sum_c omega_c m_c."""
        return (m * L.goals).sum(-1)

    def success_prob(self, m: torch.Tensor, L: Learners) -> torch.Tensor:
        """(B, N) probability of succeeding on the LO's embedded assessment."""
        mbar = (m @ self.c.Q.T) / self.c.Qsum
        z = self.c.a * (self.p.lambda_theta * L.theta[:, None] + self.p.lambda_m * mbar - self.c.b)
        return self.p.guess + (1 - self.p.guess) * torch.sigmoid(z)

    def readiness(self, m: torch.Tensor) -> torch.Tensor:
        """(B, K) soft prerequisite readiness R_c(m)."""
        logs = torch.nn.functional.logsigmoid(self.p.gamma_ready * (m - self.p.tau_ready))
        return torch.exp(logs @ self.c.W)

    def zpd(self, p: torch.Tensor) -> torch.Tensor:
        return torch.exp(-((p - self.p.p_star) ** 2) / (2 * self.p.sigma_z ** 2))

    def fit(self, L: Learners) -> torch.Tensor:
        """(B, N) modality fit in (0, 1]."""
        pr = L.pref / L.pref.max(1, keepdim=True).values
        return pr[:, self.c.mod]

    def hazard(self, p: torch.Tensor, L: Learners) -> torch.Tensor:
        pp = self.p
        x = (pp.psi_fit * (1 - self.fit(L)) + pp.psi_frustration * (pp.p_low - p).clamp_min(0)
             + pp.psi_length * (self.c.dur / 20.0 - 1).clamp_min(0))
        return (pp.h0 * torch.exp(x)).clamp_max(0.5)

    def gains_all(self, s: State, L: Learners):
        """Expected immediate gains of every LO: returns (dm (B,N,K), p (B,N), hazard (B,N))."""
        p = self.success_prob(s.m, L)
        R = self.readiness(s.m)
        Z = self.zpd(p)
        k = (L.eta[:, None, None] * self.c.rho[None, :, None] * self.c.Q[None]).clamp_max(1.0)
        gap = (self.c.ceil[None, :, None] - s.m[:, None, :]).clamp_min(0)
        dm = k * R[:, None, :] * Z[:, :, None] * gap
        return dm, p, self.hazard(p, L)

    def prereq_ok(self, m: torch.Tensor) -> torch.Tensor:
        """(B, K) true iff every direct prerequisite of c has mastery >= tau_pre."""
        below = (m < self.p.tau_pre).float()
        return (below @ self.c.P) == 0

    def is_new(self, s: State) -> torch.Tensor:
        """(B, N) true iff the LO's primary concept would be newly introduced."""
        newc = (s.nexp == 0) & (s.m < self.p.new_threshold)
        return newc[:, self.c.primary]

    def mask(self, s: State, L: Learners, hard_prereq: bool = True) -> torch.Tensor:
        """(B, N) feasibility mask encoding the hard pedagogical/contextual constraints."""
        c = self.c
        ok = ~s.visited
        ok &= (s.t[:, None] + c.dur[None, :]) <= L.T[:, None] + 1e-6
        ok &= c.bw[None, :] <= L.bw[:, None]
        if hard_prereq:
            ok &= self.prereq_ok(s.m)[:, c.primary]
        ok &= ~(self.is_new(s) & (s.new_in_sess[:, None] >= self.p.max_new_per_session))
        ok &= s.alive[:, None]
        return ok

    # ------------------------------------------------------------------ transition
    def step(self, s: State, L: Learners, a: torch.Tensor, mode: str = "planner",
             gen: torch.Generator | None = None, xi: torch.Tensor | None = None) -> tuple[State, dict]:
        """Apply LO ``a`` (B,) (``-1`` = no-op) to every learner; returns new state and info.

        ``xi`` optionally supplies the learning-noise multipliers (B,) for the stochastic modes
        (used for common random numbers); otherwise they are drawn from Gamma(k, 1/k).
        """
        c, pp = self.c, self.p
        B = L.B
        act = (a >= 0) & s.alive
        ai = a.clamp_min(0)
        rows = torch.arange(B, device=a.device)
        p_all = self.success_prob(s.m, L)
        p = p_all[rows, ai]
        h = self.hazard(p_all, L)[rows, ai]
        R = self.readiness(s.m)
        Z = self.zpd(p)
        q = c.Q[ai]                                                   # (B, K)
        k = (L.eta[:, None] * c.rho[ai][:, None] * q).clamp_max(1.0)
        dm = k * R * Z[:, None] * (c.ceil[ai][:, None] - s.m).clamp_min(0)
        new_flag = self.is_new(s)[rows, ai]
        ns = s.clone()
        info = dict(p=p, hazard=h, act=act.clone())
        if mode == "mc":
            # noisy learning, expected survival (Rao-Blackwellised estimate of the planner objective)
            k = float(pp.gain_noise_shape)
            if xi is None:
                xi = torch._standard_gamma(torch.full((B,), k, device=a.device)) / k
            dm = dm * xi[:, None]
            learn = act
            ns.S = torch.where(act, s.S * (1 - h), s.S)
        elif mode == "true":
            u = torch.rand(B, generator=gen, device=a.device)
            drop = act & (u < h)
            k = float(pp.gain_noise_shape)
            if xi is None:
                xi = torch._standard_gamma(torch.full((B,), k, device=a.device)) / k   # mean 1, var 1/k
            y = torch.rand(B, generator=gen, device=a.device) < p
            info.update(dropped=drop, correct=y & act & ~drop)
            learn = act & ~drop
            ns.alive = s.alive & ~drop
            ns.S = ns.alive.float()
            dm = dm * xi[:, None]
        else:
            learn = act
            ns.S = torch.where(act, s.S * (1 - h), s.S)
        old_psi = self.psi(s.m, L)
        ns.m = torch.where(learn[:, None], (s.m + dm).clamp(0, 1), s.m)
        ns.nexp = torch.where(learn[:, None], s.nexp + c.cover[ai], s.nexp)
        ns.visited = s.visited.clone()
        ns.visited[rows[act], ai[act]] = True
        # time / sessions / forgetting (time advances for every attempted LO)
        t_new = torch.where(act, s.t + c.dur[ai], s.t)
        k_cross = torch.floor(t_new / L.Ts + 1e-9) - torch.floor(s.t / L.Ts + 1e-9)
        crossed = (k_cross > 0) & act
        decay = torch.exp(-L.phi[:, None] * L.gap[:, None] * k_cross[:, None] / (1 + pp.stability_gain * ns.nexp))
        m_dec = L.m0 + (ns.m - L.m0) * decay
        ns.m = torch.where(crossed[:, None], torch.maximum(m_dec, L.m0), ns.m)
        ns.new_in_sess = torch.where(crossed, torch.zeros_like(s.new_in_sess),
                                     s.new_in_sess + (new_flag & act).float())
        ns.t = t_new
        ns.steps = s.steps + act.long()
        ns.last = torch.where(act, a, s.last)
        d_psi = self.psi(ns.m, L) - old_psi
        if mode == "true":
            ns.J = self.psi(ns.m, L)
        else:
            ns.J = s.J + ns.S * d_psi
        info["d_psi"] = d_psi
        return ns, info

    def delayed(self, s: State, L: Learners, days: float | None = None) -> torch.Tensor:
        """Mastery after a retention interval (delayed post-test)."""
        days = self.p.delayed_gap_days if days is None else days
        decay = torch.exp(-L.phi[:, None] * days / (1 + self.p.stability_gain * s.nexp))
        return L.m0 + (s.m - L.m0) * decay


# ---------------------------------------------------------------------- path utilities
def rollout_path(dyn: Dynamics, L: Learners, paths: list[list[int]], mode: str = "planner",
                 gen: torch.Generator | None = None, record: bool = False, xi_seq: torch.Tensor | None = None):
    """Execute fixed LO sequences (one per learner) and return the final state (and trace).

    ``xi_seq`` (T, B) optionally fixes the learning noise of every step (common random numbers).
    """
    s = dyn.init_state(L)
    T = max((len(p) for p in paths), default=0)
    A = torch.full((L.B, max(T, 1)), -1, dtype=torch.long, device=L.m0.device)
    for i, p in enumerate(paths):
        if p:
            A[i, :len(p)] = torch.tensor(p, dtype=torch.long)
    trace = []
    for t in range(T):
        s_prev = s
        xi = None if xi_seq is None else xi_seq[min(t, xi_seq.shape[0] - 1)]
        s, info = dyn.step(s, L, A[:, t], mode=mode, gen=gen, xi=xi)
        if record:
            trace.append((s_prev, A[:, t].clone(), info))
    return (s, trace) if record else s


def perturb_learners(L: Learners, eps: dict | None = None, sd_m0: float = 0.10, sd_theta: float = 0.30,
                     sd_log_eta: float = 0.20, sd_log_phi: float = 0.30) -> Learners:
    """Draw plausible true learners around the planner's estimates (inverse of the observation model).

    ``eps`` optionally supplies standard-normal draws {"m0": (B,K), "theta", "eta", "phi": (B,)}.
    """
    if eps is None:
        eps = dict(m0=torch.randn_like(L.m0), theta=torch.randn_like(L.theta), eta=torch.randn_like(L.eta),
                   phi=torch.randn_like(L.phi))
    m0 = (L.m0 + sd_m0 * eps["m0"]).clamp(0, 1)
    return Learners(theta=L.theta + sd_theta * eps["theta"],
                    eta=(L.eta * torch.exp(sd_log_eta * eps["eta"])).clamp(0.4, 1.4),
                    phi=L.phi * torch.exp(sd_log_phi * eps["phi"]), pref=L.pref, bw=L.bw, Ts=L.Ts,
                    T=L.T, gap=L.gap, m0=m0, goals=L.goals)


def expected_objective(dyn: Dynamics, L: Learners, paths: list[list[int]], n_samples: int = 8,
                       robust: bool = False, crn_group: int = 1) -> torch.Tensor:
    """Monte Carlo estimate of E[J] under the planner's stochastic model, one value per path.

    With ``robust=True`` every replicate also draws a plausible true learner around the planner's
    estimates (uncertainty-aware objective); otherwise the estimates are treated as exact.
    With ``crn_group = g > 1`` consecutive blocks of g paths (which must belong to the same learner)
    are evaluated with common random numbers: the same learner draws and learning noise.
    """
    if n_samples <= 0:
        return rollout_path(dyn, L, paths, mode="planner").J
    B, R = L.B, n_samples
    Lr = L.repeat(R)                                   # row index = i * R + r
    T = max(1, max((len(p) for p in paths), default=1))
    k = float(dyn.p.gain_noise_shape)
    G = B // crn_group if crn_group > 1 else B
    g = crn_group if crn_group > 1 else 1

    def expand(x):                                     # (G, R, ...) -> (B * R, ...)
        return x.repeat_interleave(g, dim=0).reshape(B * R, *x.shape[2:])
    xi = torch._standard_gamma(torch.full((T, G, R), k)) / k
    xi_seq = xi.repeat_interleave(g, dim=1).reshape(T, B * R)
    if robust:
        K = L.m0.shape[1]
        eps = dict(m0=expand(torch.randn(G, R, K)), theta=expand(torch.randn(G, R)),
                   eta=expand(torch.randn(G, R)), phi=expand(torch.randn(G, R)))
        Lr = perturb_learners(Lr, eps)
    pr = [p for p in paths for _ in range(R)]
    s = rollout_path(dyn, Lr, pr, mode="mc", xi_seq=xi_seq)
    return s.J.reshape(B, R).mean(1)

"""Execution of generated paths on simulated learners and computation of outcome metrics."""
from __future__ import annotations

import time

import numpy as np
import torch

from .dynamics import Dynamics, Learners, expected_objective, rollout_path


def execute_true(dyn: Dynamics, Lt: Learners, paths: list[list[int]], reps: int = 32, seed: int = 0) -> dict:
    """Run every path ``reps`` times on the stochastic true learner; return per-learner metrics."""
    torch.manual_seed(seed)
    B, pp, c = Lt.B, dyn.p, dyn.c
    Lr = Lt.repeat(reps)
    pr = [p for p in paths for _ in range(reps)]
    s = dyn.init_state(Lr)
    T = max((len(p) for p in pr), default=0)
    A = torch.full((Lr.B, max(T, 1)), -1, dtype=torch.long)
    for i, p in enumerate(pr):
        if p:
            A[i, :len(p)] = torch.tensor(p)
    isg = Lr.goals > 0
    attained_t = torch.full((Lr.B,), float("nan"))
    viol = torch.zeros(Lr.B)
    zpd_ok = torch.zeros(Lr.B)
    n_act = torch.zeros(Lr.B)
    att0 = ((s.m >= pp.tau_master) | ~isg).all(1)
    attained_t[att0] = 0.0
    for t in range(T):
        a = A[:, t]
        act = (a >= 0) & s.alive
        ai = a.clamp_min(0)
        prim = c.primary[ai]
        # prerequisite violation w.r.t. the TRUE state at the time the LO is studied
        below = (s.m < pp.tau_pre).float() @ c.P                      # (B,K) #unmet prerequisites
        viol += (act & (below[torch.arange(Lr.B), prim] > 0)).float()
        p_true = dyn.success_prob(s.m, Lr)[torch.arange(Lr.B), ai]
        zpd_ok += (act & (p_true >= 0.5) & (p_true <= 0.9)).float()
        n_act += act.float()
        s, info = dyn.step(s, Lr, a, mode="true")
        att = ((s.m >= pp.tau_master) | ~isg).all(1) & s.alive
        newly = att & torch.isnan(attained_t)
        attained_t[newly] = s.t[newly]
    psi0 = dyn.psi(Lr.m0, Lr)
    psi = dyn.psi(s.m, Lr)
    m_del = dyn.delayed(s, Lr)
    psi_del = dyn.psi(m_del, Lr)
    att_final = ((s.m >= pp.tau_master) | ~isg).all(1)
    gain = (psi - psi0) / (1 - psi0).clamp_min(1e-6)

    def agg(x):
        return x.reshape(B, reps).mean(1).numpy()
    reached = ~torch.isnan(attained_t)
    tt = torch.where(reached, attained_t, Lr.T)                      # censored at the budget
    return dict(
        psi0=agg(psi0), psi=agg(psi), gain=agg(gain), psi_delayed=agg(psi_del),
        attain=agg(att_final.float()), survive=agg(s.alive.float()),
        time_to_attain=agg(tt), ever_attain=agg(reached.float()),
        viol_rate=agg(viol / n_act.clamp_min(1)), zpd_rate=agg(zpd_ok / n_act.clamp_min(1)),
        steps_done=agg(n_act),
    )


def evaluate_paths(dyn: Dynamics, Lp: Learners, Lt: Learners, paths: list[list[int]], reps: int = 32,
                   mc: int = 32, seed: int = 0, dyn_true: Dynamics | None = None) -> dict:
    """Planner-side values use ``dyn``; outcomes are measured on ``dyn_true`` (default: ``dyn``)."""
    out = execute_true(dyn_true or dyn, Lt, paths, reps, seed)
    s = rollout_path(dyn, Lp, paths, mode="planner")
    out["J_meanfield"] = s.J.numpy()
    out["J_mc"] = expected_objective(dyn, Lp, paths, mc).numpy()
    out["length"] = np.array([len(p) for p in paths], dtype=float)
    out["minutes"] = s.t.numpy()
    out["budget"] = Lp.T.numpy()
    return out


def timed(fn):
    t0 = time.time()
    r = fn()
    return r, time.time() - t0

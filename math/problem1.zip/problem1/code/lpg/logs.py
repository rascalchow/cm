"""Simulation of historical interaction logs (as a learning-management system would record them).

Learners follow a behaviour policy -- the static syllabus with probability 1-eps and a uniformly
random feasible LO with probability eps -- on the *true* stochastic learner model.  Each attempt
produces one log record with the observable outcome (correct / incorrect) and dropout events.
The logs are used to check that the synthetic data reproduce stylised facts of real educational
data (learning curves, item difficulty ordering, dropout over time).
"""
from __future__ import annotations

import numpy as np
import torch

from .baselines import relevance_weights, NEG
from .dynamics import Dynamics, Learners
from .synth import MODALITIES


def simulate_logs(dyn: Dynamics, L_true: Learners, L_plan: Learners, eps: float = 0.3, seed: int = 0,
                  learner_ids=None) -> list[dict]:
    g = torch.Generator().manual_seed(seed)
    torch.manual_seed(seed)
    c = dyn.c
    rel = relevance_weights(dyn, L_plan) > 0
    base = (c.layer[c.primary].float() * 1e6 + c.primary.float() * 1e2 + c.bloom.float() * 10)
    pri = torch.where(rel[:, c.primary], -base[None, :], -base[None, :] - 1e8)
    s_plan = dyn.init_state(L_plan)          # behaviour policy sees the planner's state for feasibility
    s = dyn.init_state(L_true)
    ids = list(range(L_true.B)) if learner_ids is None else list(learner_ids)
    out = []
    for step in range(400):
        mk = dyn.mask(s_plan, L_plan) & s.alive[:, None]
        has = mk.any(1)
        if not has.any():
            break
        rnd = torch.multinomial(mk.float() + 1e-12, 1, generator=g).squeeze(1)
        syl = torch.where(mk, pri, torch.full_like(pri, 2 * NEG)).argmax(1)
        explore = torch.rand(L_true.B, generator=g) < eps
        a = torch.where(explore, rnd, syl)
        a = torch.where(has, a, torch.full_like(a, -1))
        t0 = s.t.clone()
        p_true = dyn.success_prob(s.m, L_true)
        s, info = dyn.step(s, L_true, a, mode="true", gen=g)
        s_plan, _ = dyn.step(s_plan, L_plan, a, mode="planner")
        for i in torch.nonzero(info["act"]).flatten().tolist():
            lo = int(a[i])
            out.append(dict(
                learner=ids[i], step=step, lo=lo, concept=int(c.primary[lo]), bloom=int(c.bloom[lo]),
                modality=MODALITIES[int(c.mod[lo])], t_start=round(float(t0[i]), 2),
                duration=round(float(c.dur[lo]), 2), session=int(float(t0[i]) // float(L_true.Ts[i])),
                p_success=round(float(p_true[i, lo]), 4), correct=int(info["correct"][i]),
                dropped=int(info["dropped"][i]),
            ))
    return out

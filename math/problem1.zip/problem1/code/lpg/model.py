"""Pedagogy-aware heterogeneous graph neural network (PA-HGNN) for learning-path generation.

The educational graph has two node types -- concepts (K) and learning objects (N) -- and six
relations:

  pre      concept -> concept   direct prerequisite i -> j            (edge attr: strength w_ij)
  pre_r    concept -> concept   reverse prerequisite j -> i
  anc      concept -> concept   surmise relation i < j (closure)      (edge attr: 1 / distance)
  anc_r    concept -> concept   reverse surmise relation
  cov      concept -> LO        concept c is covered by LO l         (edge attr: q_lc)
  cov_r    LO -> concept        reverse coverage

Node features are recomputed from the planner's predicted learner state at every decoding
step (dynamic graph), so the encoder propagates mastery, readiness and goal relevance along the
pedagogical structure.  Message passing follows a concept-centric schedule: LO embeddings are
computed from their features, every layer updates the concept states from the concept-concept
relations and from the LOs that cover them (cov_r), and the LOs finally read out the concept
states through the coverage relation (cov).  The decoder is an attention "pointer" over LO embeddings with hard
masking of infeasible LOs (time budget, accessibility, prerequisite rule, cognitive load,
no-repeat), which guarantees that every generated path is feasible.
"""
from __future__ import annotations

import math

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint

from .dynamics import Dynamics, Learners, State

N_MOD = 4


# ------------------------------------------------------------------------------ graph structure
class GraphStructure:
    """Static edge lists of one curriculum (shared by every learner in a batch)."""

    def __init__(self, dyn: Dynamics):
        c = dyn.c
        src, dst = torch.nonzero(c.W > 0, as_tuple=True)
        w = c.W[src, dst]
        asrc, adst = torch.nonzero(c.anc_dist > 0, as_tuple=True)
        ad = 1.0 / c.anc_dist[asrc, adst]
        lo, cc = torch.nonzero(c.Q > 0, as_tuple=True)
        q = c.Q[lo, cc]
        # relation: (src_type, dst_type, src_idx, dst_idx, attr)
        self.rel = {
            "pre": ("c", "c", src, dst, w),
            "pre_r": ("c", "c", dst, src, w),
            "anc": ("c", "c", asrc, adst, ad),
            "anc_r": ("c", "c", adst, asrc, ad),
            "cov": ("c", "l", cc, lo, q),
            "cov_r": ("l", "c", lo, cc, q),
        }
        self.K, self.N = c.K, c.N
        # dense (dst x src) adjacency and attribute matrices
        self.dense = {}
        for r, (st, dt, si, di, at) in self.rel.items():
            ns = c.K if st == "c" else c.N
            nd = c.K if dt == "c" else c.N
            A = torch.zeros(nd, ns, dtype=torch.bool)
            X = torch.zeros(nd, ns)
            A[di, si] = True
            X[di, si] = at
            self.dense[r] = (st, dt, A, X)
        indeg = torch.zeros(c.K)
        indeg.index_add_(0, dst, torch.ones_like(w))
        self.n_pre = indeg
        outdeg = torch.zeros(c.K)
        outdeg.index_add_(0, src, torch.ones_like(w))
        self.n_post = outdeg


# ------------------------------------------------------------------------------ features
FC = 14   # concept feature dim
FL = 24   # LO feature dim
FG = 18   # global feature dim


def build_features(dyn: Dynamics, s: State, L: Learners, gs: GraphStructure, mask: torch.Tensor):
    """Return concept features (B,K,FC), LO features (B,N,FL) and global features (B,FG)."""
    c, pp = dyn.c, dyn.p
    B = L.B
    m = s.m
    dm, p, h = dyn.gains_all(s, L)                      # (B,N,K), (B,N), (B,N)
    R = dyn.readiness(m)
    ok = dyn.prereq_ok(m).float()
    isg = (L.goals > 0).float()
    remaining = (L.T - s.t).clamp_min(0)
    # LO availability per concept
    feas = mask.float()
    n_feas_c = feas @ c.cover                            # (B,K)
    ceil_avail = torch.where(mask[:, :, None] & (c.cover[None] > 0), c.ceil[None, :, None],
                             torch.zeros(1)).amax(1)      # (B,K) best reachable ceiling
    decay_next = torch.exp(-L.phi[:, None] * L.gap[:, None] / (1 + pp.stability_gain * s.nexp))
    newc = ((s.nexp == 0) & (m < pp.new_threshold)).float()
    xc = torch.stack([
        m, m - L.m0, R, ok, isg, (m >= pp.tau_master).float(), (pp.tau_master - m).clamp_min(0),
        s.nexp / 5.0, c.layer.float().expand(B, -1) / max(1, c.n_layers - 1),
        gs.n_pre.expand(B, -1) / 3.0, n_feas_c / 5.0, ceil_avail, decay_next, newc,
    ], -1)

    fit = dyn.fit(L)
    Z = dyn.zpd(p)
    gain_tot = dm.sum(-1)
    gain_goal = (dm * isg[:, None, :]).sum(-1)
    prim = c.primary
    t_in_sess = s.t - torch.floor(s.t / L.Ts + 1e-9) * L.Ts
    fits_sess = ((t_in_sess[:, None] + c.dur[None, :]) <= L.Ts[:, None]).float()
    xl = torch.cat([
        torch.stack([
            feas, s.visited.float(), c.bloom.float().expand(B, -1) / 6.0, c.ceil.expand(B, -1),
            c.dur.expand(B, -1) / 30.0, c.dur[None, :] / remaining[:, None].clamp_min(1.0),
            c.rho.expand(B, -1), c.b.expand(B, -1) / 3.0, p, Z, h * 50.0,
            gain_tot * 3.0, gain_goal * 3.0, fit, R[:, prim], m[:, prim], isg[:, prim],
            (c.secondary >= 0).float().expand(B, -1), fits_sess, dyn.is_new(s).float(),
        ], -1),
        F.one_hot(c.mod, N_MOD).float().expand(B, -1, -1),
    ], -1)

    Ts = L.Ts
    goal_m = (m * isg).sum(1) / isg.sum(1).clamp_min(1)
    g = torch.cat([
        torch.stack([
            L.theta, L.eta, L.phi * L.gap, remaining / L.T.clamp_min(1), (Ts - t_in_sess) / Ts,
            s.new_in_sess / pp.max_new_per_session, goal_m,
            ((m >= pp.tau_master).float() * isg).sum(1) / isg.sum(1).clamp_min(1),
            s.S, s.steps.float() / 50.0, L.T / 600.0,
        ], -1),
        L.pref, F.one_hot(L.bw, 3).float(),
    ], -1)
    return xc, xl, g


# ------------------------------------------------------------------------------ layers
class RelationalAttention(nn.Module):
    """Masked dense graph attention for one relation, batched over learners sharing the graph.

    e_ij = LeakyReLU(<a_d, W h_i> + <a_s, W h_j> + c * x_ij)   for edges j -> i of the relation,
    alpha_ij = softmax_j(e_ij),   m_i = sum_j alpha_ij V h_j     (multi-head).
    With ``attention=False`` the weights are the degree-normalised edge attributes (GCN-like mean).
    """

    def __init__(self, H: int, heads: int = 4, attention: bool = True):
        super().__init__()
        self.H, self.heads, self.dh = H, heads, H // heads
        self.attention = attention
        self.W = nn.Linear(H, H, bias=False)
        self.a_s = nn.Parameter(torch.empty(heads, self.dh))
        self.a_d = nn.Parameter(torch.empty(heads, self.dh))
        self.c = nn.Parameter(torch.zeros(heads))
        self.V = nn.Linear(H, H, bias=False)
        nn.init.xavier_uniform_(self.a_s)
        nn.init.xavier_uniform_(self.a_d)

    def forward(self, hs, hd, A, X):
        """hs (B,ns,H), hd (B,nd,H), A (nd,ns) bool adjacency, X (nd,ns) edge attributes."""
        B, ns, nd = hs.shape[0], hs.shape[1], hd.shape[1]
        if not self.attention:
            Wn = X * A
            Wn = Wn / Wn.sum(-1, keepdim=True).clamp_min(1e-6)
            return Wn @ self.V(hs)                                             # (B,nd,H)
        v = self.V(hs).view(B, ns, self.heads, self.dh).transpose(1, 2)        # (B,h,ns,dh)
        if self.attention:
            ws = self.W(hs).view(B, ns, self.heads, self.dh)
            wd = self.W(hd).view(B, nd, self.heads, self.dh)
            es = (ws * self.a_s).sum(-1).transpose(1, 2)                       # (B,h,ns)
            ed = (wd * self.a_d).sum(-1).transpose(1, 2)                       # (B,h,nd)
            e = F.leaky_relu(ed[..., :, None] + es[..., None, :] + self.c[None, :, None, None] * X, 0.2)
            e = e.masked_fill(~A, float("-inf"))
            alpha = torch.softmax(e, -1)
            alpha = torch.nan_to_num(alpha, nan=0.0)                           # nodes without in-edges
        out = alpha @ v                                                        # (B,h,nd,dh)
        return out.transpose(1, 2).reshape(B, nd, self.H)


class ConceptLayer(nn.Module):
    """One round of message passing into concept nodes.

    h_c <- LN(h_c + W_mix(sum_r Att_r(h_c) + Agg_cov(h_l -> c)) + W_g g),   then a residual FFN.
    Relations r range over the concept-concept relations (prerequisite / surmise, both directions);
    Agg_cov is the coverage-weighted mean of LO embeddings.
    """

    def __init__(self, H: int, relations: list[str], heads: int = 4, attention: bool = True,
                 dropout: float = 0.0):
        super().__init__()
        self.cc = [r for r in relations if not r.startswith("cov")]
        self.use_cov = "cov_r" in relations
        self.att = nn.ModuleDict({r: RelationalAttention(H, heads, attention) for r in self.cc})
        self.cov = RelationalAttention(H, heads, attention=False)
        self.mix = nn.Linear(H, H)
        self.glob = nn.Linear(H, H)
        self.ln1 = nn.LayerNorm(H)
        self.ln2 = nn.LayerNorm(H)
        self.ff = nn.Sequential(nn.Linear(H, 2 * H), nn.ReLU(), nn.Linear(2 * H, H))
        self.drop = nn.Dropout(dropout)

    def forward(self, hc, hl, g, gs: GraphStructure):
        agg = torch.zeros_like(hc)
        for r in self.cc:
            _, _, A, X = gs.dense[r]
            agg = agg + self.att[r](hc, hc, A, X)
        if self.use_cov:
            _, _, A, X = gs.dense["cov_r"]
            agg = agg + self.cov(hl, hc, A, X)
        z = self.ln1(hc + self.drop(self.mix(agg)) + self.glob(g)[:, None, :])
        return self.ln2(z + self.drop(self.ff(z)))


ALL_REL = ["pre", "pre_r", "anc", "anc_r", "cov", "cov_r"]


class PathPolicy(nn.Module):
    """PA-HGNN encoder + attention pointer decoder.

    ``encoder='gnn'`` (default) or ``'mlp'`` (no message passing: each LO sees only its own
    features, those of its primary concept and the learner context).
    """

    def __init__(self, H: int = 64, layers: int = 3, heads: int = 4, relations=None,
                 attention: bool = True, encoder: str = "gnn", use_model_features: bool = True,
                 use_learner_context: bool = True, clip: float = 10.0, dropout: float = 0.0):
        super().__init__()
        self.H, self.clip, self.encoder = H, clip, encoder
        self.use_model_features = use_model_features
        self.use_learner_context = use_learner_context
        self.relations = list(ALL_REL if relations is None else relations)
        fl_in = FL + (FC if encoder == "mlp" else 0)
        self.inc = nn.Sequential(nn.Linear(FC, H), nn.ReLU(), nn.Linear(H, H))
        self.inl = nn.Sequential(nn.Linear(fl_in, H), nn.ReLU(), nn.Linear(H, H))
        self.ing = nn.Sequential(nn.Linear(FG, H), nn.ReLU(), nn.Linear(H, H))
        if encoder == "gnn":
            self.layers = nn.ModuleList([ConceptLayer(H, self.relations, heads, attention, dropout)
                                         for _ in range(layers)])
            # LO read-out of the final concept states through the coverage relation
            self.readout = RelationalAttention(H, heads, attention=False)
            self.read_mix = nn.Linear(H, H)
            self.read_glob = nn.Linear(H, H)
            self.read_ln1 = nn.LayerNorm(H)
            self.read_ln2 = nn.LayerNorm(H)
            self.read_ff = nn.Sequential(nn.Linear(H, 2 * H), nn.ReLU(), nn.Linear(2 * H, H))
        else:
            self.layers = nn.ModuleList([nn.ModuleDict({t: nn.Sequential(nn.Linear(2 * H, 2 * H), nn.ReLU(),
                                                                         nn.Linear(2 * H, H))
                                                        for t in ("c", "l")}) for _ in range(layers)])
            self.lns = nn.ModuleList([nn.ModuleDict({t: nn.LayerNorm(H) for t in ("c", "l")})
                                      for _ in range(layers)])
        self.ctx = nn.Sequential(nn.Linear(4 * H, H), nn.ReLU(), nn.Linear(H, H))
        self.Wq = nn.Linear(H, H, bias=False)
        self.Wk = nn.Linear(H, H, bias=False)

    # model-informed (mechanistic) LO features: p, Z, hazard, gains  -> columns 8..12
    MODEL_COLS = [8, 9, 10, 11, 12]
    LEARNER_COLS_G = [0, 1, 2, 10] + list(range(11, 18))   # ability, rate, forgetting, budget, prefs, bandwidth
    FIT_COL = 13

    def forward(self, xc, xl, g, mask, gs: GraphStructure, last: torch.Tensor):
        if not self.use_model_features:
            xl = xl.clone()
            xl[..., self.MODEL_COLS] = 0.0
        if not self.use_learner_context:
            g = g.clone()
            g[..., self.LEARNER_COLS_G] = 0.0
            xl = xl.clone()
            xl[..., self.FIT_COL] = 0.0
        if self.encoder == "mlp":
            xl = torch.cat([xl, xc[:, gs_primary(gs)]], -1)
        hg = self.ing(g)
        h = {"c": self.inc(xc), "l": self.inl(xl)}
        if self.encoder == "gnn":
            hc = h["c"]
            for layer in self.layers:
                hc = layer(hc, h["l"], hg, gs)
            _, _, A, X = gs.dense["cov"]
            z = self.read_ln1(h["l"] + self.read_mix(self.readout(hc, h["l"], A, X))
                              + self.read_glob(hg)[:, None, :])
            h = {"c": hc, "l": self.read_ln2(z + self.read_ff(z))}
        else:
            for layer, ln in zip(self.layers, self.lns):
                h = {t: ln[t](h[t] + layer[t](torch.cat([h[t], hg[:, None, :].expand_as(h[t])], -1)))
                     for t in ("c", "l")}
        isg = xc[..., 4:5]
        goal_pool = (h["c"] * isg).sum(1) / isg.sum(1).clamp_min(1)
        hl_last = torch.where((last >= 0)[:, None], h["l"][torch.arange(len(last)), last.clamp_min(0)],
                              torch.zeros_like(hg))
        ctx = self.ctx(torch.cat([hg, h["c"].mean(1), goal_pool, hl_last], -1))
        u = (self.Wq(ctx)[:, None, :] * self.Wk(h["l"])).sum(-1) / math.sqrt(self.H)
        u = self.clip * torch.tanh(u)
        return u.masked_fill(~mask, float("-inf"))


def gs_primary(gs: GraphStructure) -> torch.Tensor:
    st, dt, lo, cc, q = gs.rel["cov_r"]
    prim = torch.zeros(gs.N, dtype=torch.long)
    sel = q >= 0.999
    prim[lo[sel]] = cc[sel]
    return prim


# ------------------------------------------------------------------------------ decoding
def generate(policy: PathPolicy, dyn: Dynamics, L: Learners, gs: GraphStructure, greedy: bool = False,
             max_steps: int = 400, expert: list[list[int]] | None = None, temperature: float = 1.0,
             use_checkpoint: bool = False):
    """Autoregressively generate paths.

    Returns (paths, logp (B,), entropy (B,)).  With ``expert`` given, the expert's actions are
    followed (teacher forcing) and ``logp`` is the log-likelihood of the expert paths.
    ``use_checkpoint`` recomputes each step's encoder in the backward pass (gradient checkpointing),
    trading compute for memory; it is only needed for large batches or catalogues.
    """
    s = dyn.init_state(L)
    B = L.B
    paths = [[] for _ in range(B)]
    logp = torch.zeros(B)
    ent = torch.zeros(B)
    for t in range(max_steps):
        mask = dyn.mask(s, L)
        has = mask.any(1)
        if expert is not None:
            a_exp = torch.tensor([p[t] if t < len(p) else -1 for p in expert], dtype=torch.long)
            has = has & (a_exp >= 0)
            # an expert action is always feasible for the same model; guard anyway
            ok = mask[torch.arange(B), a_exp.clamp_min(0)] & has
            has = ok
        if not has.any():
            break
        with torch.no_grad():
            xc, xl, g = build_features(dyn, s, L, gs, mask)
        safe_mask = mask.clone()
        safe_mask[~has, 0] = True                         # avoid all -inf rows
        if use_checkpoint and torch.is_grad_enabled() and policy.training:
            # recompute the encoder in the backward pass instead of storing T steps of activations
            logits = checkpoint(lambda *a: policy(*a, gs, s.last), xc, xl, g, safe_mask,
                                use_reentrant=False) / temperature
        else:
            logits = policy(xc, xl, g, safe_mask, gs, s.last) / temperature
        lp = torch.log_softmax(logits, -1)
        if expert is not None:
            a = a_exp.clamp_min(0)
        elif greedy:
            a = logits.argmax(-1)
        else:
            a = torch.multinomial(lp.exp(), 1).squeeze(1)
        step_lp = lp.gather(1, a[:, None]).squeeze(1)
        p_ = lp.exp()
        step_ent = -(p_ * torch.where(safe_mask, lp, torch.zeros_like(lp))).sum(-1)
        logp = logp + torch.where(has, step_lp, torch.zeros_like(step_lp))
        ent = ent + torch.where(has, step_ent, torch.zeros_like(step_ent))
        a = torch.where(has, a, torch.full_like(a, -1))
        for i in torch.nonzero(a >= 0).flatten().tolist():
            paths[i].append(int(a[i]))
        with torch.no_grad():
            s, _ = dyn.step(s, L, a)
    return paths, logp, ent

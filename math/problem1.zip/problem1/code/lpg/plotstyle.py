"""Shared matplotlib style for the dissertation figures (print, light surface)."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# reference categorical palette, fixed slot order (never cycled)
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
GRAY = "#9a9994"
GRAY_DARK = "#52514e"
TEXT = "#0b0b0b"
SURFACE = "#fcfcfb"
SEQ_BLUE = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]


def setup():
    plt.rcParams.update({
        "figure.dpi": 150, "savefig.dpi": 300, "savefig.bbox": "tight",
        "font.family": "serif", "font.size": 9, "axes.titlesize": 9.5, "axes.labelsize": 9,
        "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
        "axes.edgecolor": GRAY_DARK, "axes.labelcolor": TEXT, "xtick.color": GRAY_DARK, "ytick.color": GRAY_DARK,
        "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e4e3df",
        "grid.linewidth": 0.6, "axes.axisbelow": True, "lines.linewidth": 1.6, "lines.markersize": 4.5,
        "legend.frameon": False, "figure.facecolor": "white", "axes.facecolor": "white",
    })

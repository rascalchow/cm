"""Synthetic data generation.

The generator produces three linked artefacts:

1. a *curriculum*: concepts (knowledge components) arranged in a layered prerequisite DAG
   with topical (block) structure, plus its transitive closure (the surmise relation of
   knowledge space theory);
2. a *learning-object (LO) catalogue*: every LO carries LOM-like metadata -- covered concepts
   (Q-matrix row), Bloom level, modality, typical learning time, bandwidth requirement,
   quality, IRT difficulty and discrimination;
3. a *learner population*: latent traits (ability, learning rate, forgetting rate, modality
   preference), remote-education context (bandwidth class, session length, number of
   sessions, inter-session gap), prior knowledge consistent with the prerequisite order,
   learning goals, and the noisy *observed* estimates of these quantities that a planner
   would have in practice.

All randomness flows through an explicit ``numpy.random.Generator`` so that every dataset
is reproducible from its seed.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path

import networkx as nx
import numpy as np

# Bloom levels 1..6 (remember, understand, apply, analyse, evaluate, create).
# An LO at level b can raise mastery of its concept up to BLOOM_CEIL[b-1]; it is aimed at
# learners whose mastery is around BLOOM_ENTRY[b-1].
BLOOM_CEIL = np.array([0.35, 0.55, 0.70, 0.85, 0.95, 1.00])
BLOOM_ENTRY = np.array([0.00, 0.25, 0.40, 0.55, 0.70, 0.85])
BLOOM_NAMES = ["remember", "understand", "apply", "analyse", "evaluate", "create"]
MODALITIES = ["video", "text", "interactive", "quiz"]
BANDWIDTH = ["low", "medium", "high"]


# --------------------------------------------------------------------------------------
# configuration
# --------------------------------------------------------------------------------------
@dataclass
class CurriculumConfig:
    n_concepts: int = 40
    n_layers: int = 6
    n_topics: int = 4
    p_extra_prereq: float = 0.45      # Binomial(max_prereq-1, p) extra prerequisites
    max_prereq: int = 3
    p_same_topic: float = 0.75        # prerequisite drawn from the same topic
    p_prev_layer: float = 0.70        # prerequisite drawn from the immediately lower layer
    extra_los_per_level: float = 0.25  # Poisson mean of extra LOs at Bloom levels 1..5
    p_level6: float = 0.40            # probability of a "create"-level LO
    p_secondary: float = 0.30         # LO also covers a related concept
    modality_probs: tuple = (0.30, 0.30, 0.20, 0.20)
    duration_median: tuple = (12.0, 15.0, 20.0, 8.0)  # minutes, per modality
    duration_sigma: float = 0.35


@dataclass
class PopulationConfig:
    theta_mean: float = 0.0
    theta_sd: float = 1.0
    eta_median: float = 1.00          # learning-rate multiplier
    eta_sigma: float = 0.25
    phi_median: float = 0.05          # forgetting rate per day
    phi_sigma: float = 0.30
    pref_alpha: float = 1.5           # Dirichlet concentration of modality preference
    bw_probs: tuple = (0.25, 0.45, 0.30)
    session_minutes: tuple = (45, 60, 90)
    session_probs: tuple = (0.30, 0.45, 0.25)
    n_sessions_range: tuple = (5, 10)
    gap_days: tuple = (1, 2, 3)
    gap_probs: tuple = (0.30, 0.45, 0.25)
    n_goals_range: tuple = (1, 3)
    prior_offset: float = 1.6         # logit offset of "concept already known"
    prior_layer_slope: float = 0.9    # ... decreasing with depth
    # observation model of the planner
    obs_sd_mastery: float = 0.10
    obs_sd_theta: float = 0.30
    obs_sd_log_eta: float = 0.20
    obs_sd_pref: float = 0.05


# --------------------------------------------------------------------------------------
# curriculum
# --------------------------------------------------------------------------------------
def _layer_sizes(K: int, L: int) -> np.ndarray:
    w = np.array([1.0, 1.2, 1.25, 1.15, 1.0, 0.8] + [0.8] * max(0, L - 6))[:L]
    raw = w / w.sum() * K
    sizes = np.maximum(1, np.floor(raw).astype(int))
    while sizes.sum() < K:
        sizes[np.argmax(raw - sizes)] += 1
    while sizes.sum() > K:
        sizes[np.argmax(sizes)] -= 1
    return sizes


def generate_curriculum(rng: np.random.Generator, cfg: CurriculumConfig, name: str = "cur") -> dict:
    """Generate a curriculum (prerequisite DAG over concepts) and its LO catalogue."""
    K, L, M = cfg.n_concepts, cfg.n_layers, cfg.n_topics
    sizes = _layer_sizes(K, L)
    layer = np.repeat(np.arange(L), sizes)
    topic = np.zeros(K, dtype=int)
    for ell in range(L):
        idx = np.where(layer == ell)[0]
        topic[idx] = rng.permutation(np.arange(len(idx)) % M)
    difficulty = 0.25 * layer + rng.normal(0.0, 0.25, K)

    # --- prerequisite edges ---------------------------------------------------------
    G = nx.DiGraph()
    G.add_nodes_from(range(K))
    for c in range(K):
        if layer[c] == 0:
            continue
        n_pre = 1 + rng.binomial(cfg.max_prereq - 1, cfg.p_extra_prereq)
        chosen: set[int] = set()
        for _ in range(n_pre * 4):           # rejection sampling with a cap
            if len(chosen) >= n_pre:
                break
            if layer[c] == 1 or rng.random() < cfg.p_prev_layer:
                lay = layer[c] - 1
            else:
                lay = rng.integers(0, layer[c] - 1)
            pool = np.where(layer == lay)[0]
            same = pool[topic[pool] == topic[c]]
            if len(same) > 0 and rng.random() < cfg.p_same_topic:
                pool = same
            chosen.add(int(rng.choice(pool)))
        for p in chosen:
            G.add_edge(p, c)
    G = nx.transitive_reduction(G)           # keep only direct (covering) relations
    edges = sorted(G.edges())
    weights = rng.uniform(0.6, 1.0, len(edges))

    # transitive closure with path lengths (surmise relation)
    closure = []
    for j in range(K):
        dist = nx.single_source_shortest_path_length(G.reverse(copy=False), j)
        for i, d in dist.items():
            if i != j:
                closure.append((i, j, d))     # i is an (indirect) prerequisite of j at distance d
    closure.sort()

    # --- learning objects ---------------------------------------------------------------
    los = []
    parents = {c: [p for p, _ in G.in_edges(c)] for c in range(K)}
    for c in range(K):
        levels = []
        for b in range(1, 6):
            levels += [b] * (1 + rng.poisson(cfg.extra_los_per_level))
        if rng.random() < cfg.p_level6:
            levels.append(6)
        for b in levels:
            mod = int(rng.choice(4, p=np.array(cfg.modality_probs)))
            dur = float(np.clip(cfg.duration_median[mod] * rng.lognormal(0.0, cfg.duration_sigma), 4, 45))
            if mod == 0:
                bw = 2 if rng.random() < 0.5 else 1
            elif mod == 2:
                bw = 1 if rng.random() < 0.6 else 0
            else:
                bw = 0
            secondary, q2 = -1, 0.0
            if rng.random() < cfg.p_secondary:
                cands = parents[c]
                if not cands:
                    cands = [int(x) for x in np.where((layer == layer[c]) & (topic == topic[c]))[0] if x != c]
                if cands:
                    secondary = int(rng.choice(cands))
                    q2 = float(rng.uniform(0.3, 0.6))
            los.append(dict(
                lo=len(los), primary=c, secondary=secondary, q_secondary=round(q2, 4), bloom=b,
                modality=MODALITIES[mod], duration=round(dur, 2), bandwidth=BANDWIDTH[bw],
                quality=round(float(rng.beta(8, 3)), 4),
                difficulty=round(float(3.0 * BLOOM_ENTRY[b - 1] + 0.4 * difficulty[c] - 0.7 + rng.normal(0, 0.2)), 4),
                discrimination=round(float(rng.lognormal(np.log(1.5), 0.2)), 4),
            ))
    concepts = [dict(concept=c, layer=int(layer[c]), topic=int(topic[c]), difficulty=round(float(difficulty[c]), 4))
                for c in range(K)]
    return dict(
        name=name, config=asdict(cfg), concepts=concepts,
        prerequisites=[dict(src=int(i), dst=int(j), weight=round(float(w), 4)) for (i, j), w in zip(edges, weights)],
        closure=[dict(src=int(i), dst=int(j), distance=int(d)) for i, j, d in closure],
        los=los,
    )


# --------------------------------------------------------------------------------------
# learners
# --------------------------------------------------------------------------------------
def _sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def generate_learners(rng: np.random.Generator, cur: dict, n: int, cfg: PopulationConfig) -> dict:
    """Generate ``n`` learners for curriculum ``cur``; returns a dict of numpy arrays."""
    K = len(cur["concepts"])
    layer = np.array([c["layer"] for c in cur["concepts"]])
    topic = np.array([c["topic"] for c in cur["concepts"]])
    pre = [[] for _ in range(K)]
    for e in cur["prerequisites"]:
        pre[e["dst"]].append(e["src"])
    anc = [set() for _ in range(K)]
    for e in cur["closure"]:
        anc[e["dst"]].add(e["src"])
    order = np.argsort(layer, kind="stable")   # layers are a topological order

    theta = rng.normal(cfg.theta_mean, cfg.theta_sd, n)
    eta = np.clip(rng.lognormal(np.log(cfg.eta_median), cfg.eta_sigma, n), 0.4, 1.4)
    phi = rng.lognormal(np.log(cfg.phi_median), cfg.phi_sigma, n)
    pref = rng.dirichlet([cfg.pref_alpha] * 4, n)
    bw = rng.choice(3, n, p=np.array(cfg.bw_probs))
    Ts = rng.choice(np.array(cfg.session_minutes), n, p=np.array(cfg.session_probs)).astype(float)
    n_sess = rng.integers(cfg.n_sessions_range[0], cfg.n_sessions_range[1] + 1, n)
    gap = rng.choice(np.array(cfg.gap_days), n, p=np.array(cfg.gap_probs)).astype(float)

    # prior knowledge: a (noisy) down-set of the prerequisite order
    m0 = np.zeros((n, K))
    status = np.zeros((n, K), dtype=int)       # 2 known, 1 partial, 0 unknown
    for u in range(n):
        for c in order:
            ps = pre[c]
            if all(status[u, p] == 2 for p in ps):
                pk = _sigmoid(cfg.prior_offset + theta[u] - cfg.prior_layer_slope * layer[c])
                r = rng.random()
                status[u, c] = 2 if r < pk else (1 if r < pk + 0.5 * (1 - pk) else 0)
            elif all(status[u, p] >= 1 for p in ps):
                status[u, c] = 1 if rng.random() < 0.3 else 0
        m0[u] = np.where(status[u] == 2, rng.uniform(0.65, 0.95, K),
                         np.where(status[u] == 1, rng.uniform(0.20, 0.50, K), rng.uniform(0.0, 0.15, K)))

    # goals: 1-3 not-yet-mastered concepts in layers >= 2, preferably from one topic
    goals = np.zeros((n, K), dtype=bool)
    for u in range(n):
        cand = np.where((layer >= 2) & (m0[u] < 0.5))[0]
        if len(cand) == 0:
            cand = np.where(m0[u] < 0.75)[0]
        if len(cand) == 0:
            cand = np.arange(K)
        k = rng.integers(cfg.n_goals_range[0], cfg.n_goals_range[1] + 1)
        first = int(rng.choice(cand, p=_depth_weights(layer[cand])))
        chosen = [first]
        same = [c for c in cand if topic[c] == topic[first] and c != first]
        rest = [c for c in cand if c not in same and c != first]
        pool = same + rest
        for c in pool:
            if len(chosen) >= k:
                break
            if c in anc[first] or first in anc[c]:
                continue
            chosen.append(int(c))
        goals[u, chosen] = True

    # planner's observations
    m0_hat = np.clip(m0 + rng.normal(0, cfg.obs_sd_mastery, m0.shape), 0.0, 1.0)
    theta_hat = theta + rng.normal(0, cfg.obs_sd_theta, n)
    eta_hat = np.clip(eta * np.exp(rng.normal(0, cfg.obs_sd_log_eta, n)), 0.4, 1.4)
    phi_hat = np.full(n, cfg.phi_median)
    pref_hat = np.clip(pref + rng.normal(0, cfg.obs_sd_pref, pref.shape), 1e-3, None)
    pref_hat /= pref_hat.sum(1, keepdims=True)
    return dict(theta=theta, eta=eta, phi=phi, pref=pref, bw=bw, Ts=Ts, n_sess=n_sess, gap=gap,
                m0=m0, goals=goals, m0_hat=m0_hat, theta_hat=theta_hat, eta_hat=eta_hat,
                phi_hat=phi_hat, pref_hat=pref_hat, prior_status=status)


def _depth_weights(layers: np.ndarray) -> np.ndarray:
    w = 0.5 + layers.astype(float)
    return w / w.sum()


def subset_learners(L: dict, idx) -> dict:
    return {k: v[idx] for k, v in L.items()}


def concat_learners(parts: list[dict]) -> dict:
    return {k: np.concatenate([p[k] for p in parts]) for k in parts[0]}


# --------------------------------------------------------------------------------------
# I/O helpers
# --------------------------------------------------------------------------------------
def save_curriculum(cur: dict, path: Path) -> None:
    path.write_text(json.dumps(cur, indent=1))


def load_curriculum(path: Path) -> dict:
    return json.loads(Path(path).read_text())


def save_learners(L: dict, path: Path) -> None:
    np.savez_compressed(path, **L)


def load_learners(path: Path) -> dict:
    with np.load(path) as z:
        return {k: z[k] for k in z.files}

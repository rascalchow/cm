"""Training of the path policy: behaviour cloning (BC) followed by policy-gradient fine-tuning.

Behaviour cloning maximises the log-likelihood of expert paths (GA-MC) under teacher forcing.
Policy-gradient fine-tuning maximises the planner's expected objective
    max_pi  E_{u ~ D} E_{tau ~ pi(.|u)} [ R(tau; u) ],   R = Monte Carlo estimate of E[J(tau)],
with the REINFORCE estimator and a leave-one-out baseline over M paths sampled per learner:
    grad ~ 1/(BM) sum_i sum_k (R_ik - mean_{k' != k} R_ik') grad log pi(tau_ik | u_i).
"""
from __future__ import annotations

import copy
import json
import time
from dataclasses import dataclass, asdict
from pathlib import Path

import numpy as np
import torch

from .dynamics import Curriculum, Dynamics, DynamicsParams, Learners, learners_from_numpy, expected_objective
from .model import GraphStructure, PathPolicy, generate
from .synth import subset_learners


@dataclass
class TrainConfig:
    bc_epochs: int = 6
    bc_batch: int = 32
    bc_lr: float = 1e-3
    rl_iters: int = 300
    rl_learners: int = 4           # learners per RL batch
    rl_samples: int = 8            # paths sampled per learner (leave-one-out baseline)
    rl_mc: int = 4                 # Monte Carlo noise samples per path for the reward
    rl_lr: float = 2e-4
    entropy: float = 0.002
    grad_clip: float = 1.0
    val_every: int = 20
    val_mc: int = 16
    seed: int = 0
    robust: bool = False           # uncertainty-aware reward (learner parameters resampled)
    crn: bool = False              # common random numbers across the M paths of a learner


class Instance:
    """A curriculum with its dynamics, graph structure and a learner pool (numpy dict)."""

    def __init__(self, cur: dict, learners: dict, params: DynamicsParams | None = None):
        self.cur = Curriculum(cur)
        self.dyn = Dynamics(self.cur, params)
        self.gs = GraphStructure(self.dyn)
        self.L = learners
        self.n = len(learners["theta"])

    def batch(self, idx, view="planner") -> Learners:
        return learners_from_numpy(subset_learners(self.L, idx), view)


def evaluate_policy(policy: PathPolicy, insts: list[Instance], mc: int = 16, chunk: int = 64,
                    greedy: bool = True, robust: bool = False) -> float:
    policy.eval()
    vals = []
    rng_state = torch.get_rng_state()
    with torch.no_grad():
        for inst in insts:
            for i in range(0, inst.n, chunk):
                L = inst.batch(np.arange(i, min(inst.n, i + chunk)))
                paths, _, _ = generate(policy, inst.dyn, L, inst.gs, greedy=greedy)
                torch.manual_seed(1234 + i)          # common random numbers across validations
                vals.append(expected_objective(inst.dyn, L, paths, mc, robust=robust))
    policy.train()
    torch.set_rng_state(rng_state)
    return torch.cat(vals).mean().item()


def train_bc(policy: PathPolicy, insts: list[Instance], experts: list[list[list[int]]], cfg: TrainConfig,
             log: list, val: list[Instance] | None = None) -> None:
    """Behaviour cloning on expert paths (experts[i][u] is the path of learner u of instance i)."""
    opt = torch.optim.Adam(policy.parameters(), lr=cfg.bc_lr)
    rng = np.random.default_rng(cfg.seed)
    items = [(i, u) for i, e in enumerate(experts) for u in range(len(e))]
    for ep in range(cfg.bc_epochs):
        rng.shuffle(items)
        # group by instance so that a batch shares one graph
        by_inst: dict[int, list[int]] = {}
        for i, u in items:
            by_inst.setdefault(i, []).append(u)
        batches = [(i, us[j:j + cfg.bc_batch]) for i, us in by_inst.items() for j in range(0, len(us), cfg.bc_batch)]
        rng.shuffle(batches)
        tot, cnt, t0 = 0.0, 0, time.time()
        for i, us in batches:
            inst = insts[i]
            L = inst.batch(np.array(us))
            ex = [experts[i][u] for u in us]
            _, logp, _ = generate(policy, inst.dyn, L, inst.gs, expert=ex)
            lens = torch.tensor([max(1, len(p)) for p in ex], dtype=torch.float32)
            loss = -(logp / lens).mean()
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(policy.parameters(), cfg.grad_clip)
            opt.step()
            tot += loss.item() * len(us)
            cnt += len(us)
        rec = dict(phase="bc", epoch=ep, nll=tot / cnt, sec=time.time() - t0)
        if val is not None:
            rec["val"] = evaluate_policy(policy, val, mc=cfg.val_mc)
        log.append(rec)
        print(json.dumps(rec), flush=True)


def train_rl(policy: PathPolicy, insts: list[Instance], cfg: TrainConfig, log: list,
             val: list[Instance] | None = None) -> PathPolicy:
    """REINFORCE with leave-one-out baseline; returns the best policy on the validation set."""
    opt = torch.optim.Adam(policy.parameters(), lr=cfg.rl_lr)
    rng = np.random.default_rng(cfg.seed + 1)
    best, best_val = copy.deepcopy(policy.state_dict()), -1e9
    if val is not None:
        best_val = evaluate_policy(policy, val, mc=cfg.val_mc, robust=cfg.robust)
        log.append(dict(phase="rl", it=0, val=best_val))
        print(json.dumps(log[-1]), flush=True)
    M = cfg.rl_samples
    t0 = time.time()
    for it in range(1, cfg.rl_iters + 1):
        inst = insts[rng.integers(len(insts))]
        idx = rng.choice(inst.n, cfg.rl_learners, replace=False)
        L = inst.batch(idx).repeat(M)
        paths, logp, ent = generate(policy, inst.dyn, L, inst.gs)
        with torch.no_grad():
            R = expected_objective(inst.dyn, L, paths, cfg.rl_mc, robust=cfg.robust,
                                   crn_group=M if cfg.crn else 1).reshape(-1, M)
            base = (R.sum(1, keepdim=True) - R) / (M - 1)
            adv = (R - base).reshape(-1)
            adv = adv / (adv.std() + 1e-6)
        loss = -(adv * logp).mean() - cfg.entropy * ent.mean()
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(policy.parameters(), cfg.grad_clip)
        opt.step()
        rec = dict(phase="rl", it=it, reward=R.mean().item(), sec=time.time() - t0)
        if val is not None and (it % cfg.val_every == 0 or it == cfg.rl_iters):
            v = evaluate_policy(policy, val, mc=cfg.val_mc, robust=cfg.robust)
            rec["val"] = v
            if v > best_val:
                best_val, best = v, copy.deepcopy(policy.state_dict())
            print(json.dumps(rec), flush=True)
        log.append(rec)
    policy.load_state_dict(best)
    return policy

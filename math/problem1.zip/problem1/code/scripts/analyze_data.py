"""Descriptive statistics and validation of the synthetic data (Chapter 5).

Writes results/data_stats.json, LaTeX tables to dissertation/tables/ and figures to
dissertation/figures/.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import networkx as nx
import numpy as np
import pandas as pd
from scipy import optimize, stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.data import DATA, RESULTS, manifest
from lpg.synth import load_curriculum, load_learners, MODALITIES, BLOOM_NAMES, BANDWIDTH
from lpg import plotstyle as ps
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
FIG = ROOT / "dissertation" / "figures"
TAB = ROOT / "dissertation" / "tables"


def split_table(man):
    rows = []
    names = {"train": "Training", "val": "Validation", "test_id": "Test (seen curricula)",
             "test_ood": "Test (unseen curricula)", "test_k80": "Scale test, $K=80$", "test_k120": "Scale test, $K=120$",
             "shift_lowbw": "Shift: low bandwidth", "shift_lowprior": "Shift: low prior / ability",
             "shift_forget": "Shift: fast forgetting", "shift_noisy": "Shift: noisy observations"}
    for split, items in man["splits"].items():
        Ks = [man["curricula"][it["curriculum"]]["K"] for it in items]
        Ns = [man["curricula"][it["curriculum"]]["N"] for it in items]
        Es = [man["curricula"][it["curriculum"]]["E"] for it in items]
        n = sum(it["n"] for it in items)
        Ls = [load_learners(DATA / it["file"]) for it in items]
        T = np.concatenate([L["Ts"] * L["n_sess"] for L in Ls])
        G = np.concatenate([L["goals"].sum(1) for L in Ls])
        P = np.concatenate([(L["m0"] * L["goals"]).sum(1) / L["goals"].sum(1) for L in Ls])
        rows.append(dict(split=names[split], curricula=len(items), K=f"{min(Ks)}--{max(Ks)}" if min(Ks) != max(Ks) else str(Ks[0]),
                         N=f"{min(Ns)}--{max(Ns)}", E=f"{min(Es)}--{max(Es)}", learners=n,
                         budget=f"{T.mean():.0f}", goals=f"{G.mean():.2f}", goal_m0=f"{P.mean():.3f}"))
    return rows


def catalogue_stats(man):
    los = []
    for name in man["curricula"]:
        cur = load_curriculum(DATA / "curricula" / f"{name}.json")
        for o in cur["los"]:
            los.append(o)
    df = pd.DataFrame(los)
    out = dict(
        n_los=len(df),
        modality=df.modality.value_counts(normalize=True).round(4).to_dict(),
        bloom=df.bloom.value_counts(normalize=True).sort_index().round(4).to_dict(),
        bandwidth=df.bandwidth.value_counts(normalize=True).round(4).to_dict(),
        duration_by_modality=df.groupby("modality").duration.mean().round(2).to_dict(),
        quality_mean=round(float(df.quality.mean()), 4),
        secondary_frac=round(float((df.secondary >= 0).mean()), 4),
        difficulty_by_bloom=df.groupby("bloom").difficulty.mean().round(3).to_dict(),
    )
    return out, df


def learner_stats(man):
    Ls = [load_learners(DATA / it["file"]) for it in man["splits"]["train"]]
    L = {k: np.concatenate([x[k] for x in Ls]) for k in Ls[0] if Ls[0][k].ndim == 1 or k == "pref"}
    L["m0_mean"] = np.concatenate([x["m0"].mean(1) for x in Ls])
    L["goals_n"] = np.concatenate([x["goals"].sum(1) for x in Ls])
    sq_err = np.concatenate([((x["m0_hat"] - x["m0"]) ** 2).ravel() for x in Ls])
    curs = {it["curriculum"]: load_curriculum(DATA / "curricula" / f"{it['curriculum']}.json") for it in man["splits"]["train"]}
    # knowledge-space consistency: is {c : m0_c >= 0.5} a down-set of the prerequisite order?
    downset = []
    for it, Lx in zip(man["splits"]["train"], Ls):
        cur = curs[it["curriculum"]]
        pre = [(e["src"], e["dst"]) for e in cur["prerequisites"]]
        known = Lx["m0"] >= 0.5
        ok = np.ones(len(known), dtype=bool)
        for i, j in pre:
            ok &= ~(known[:, j] & ~known[:, i])
        downset.append(ok)
    downset = np.concatenate(downset)
    return dict(
        n=len(L["theta"]), theta_mean=float(L["theta"].mean()), theta_sd=float(L["theta"].std()),
        eta_mean=float(L["eta"].mean()), phi_mean=float(L["phi"].mean()),
        bw=dict(zip(BANDWIDTH, np.bincount(L["bw"], minlength=3) / len(L["bw"]))),
        budget_mean=float((L["Ts"] * L["n_sess"]).mean()), budget_sd=float((L["Ts"] * L["n_sess"]).std()),
        goals_mean=float(L["goals_n"].mean()), prior_mastery_mean=float(L["m0_mean"].mean()),
        downset_frac=float(downset.mean()),
        obs_err_mastery_rmse=float(np.sqrt(sq_err.mean())),
        obs_err_theta_rmse=float(np.sqrt(((L["theta_hat"] - L["theta"]) ** 2).mean())),
    ), L


def log_analysis(df_los):
    logs = pd.read_csv(DATA / "csv" / "interaction_logs.csv")
    logs = logs.sort_values(["curriculum", "learner", "step"])
    logs["opp"] = logs.groupby(["curriculum", "learner", "concept"]).cumcount() + 1
    curve = logs.groupby("opp").agg(err=("correct", lambda x: 1 - x.mean()), n=("correct", "size")).reset_index()
    curve = curve[curve.n >= 200]
    x, y = curve.opp.values.astype(float), curve.err.values
    pw = lambda j, A, a: A * j ** (-a)
    ex = lambda j, A, b, c0: c0 + A * np.exp(-b * j)
    (A1, a1), _ = optimize.curve_fit(pw, x, y, p0=(0.5, 0.3), maxfev=10000)
    r2_pw = 1 - ((y - pw(x, A1, a1)) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    try:
        (A2, b2, c2), _ = optimize.curve_fit(ex, x, y, p0=(0.3, 0.3, 0.1), maxfev=10000)
        r2_ex = 1 - ((y - ex(x, A2, b2, c2)) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    except RuntimeError:
        A2 = b2 = c2 = r2_ex = float("nan")
    # difficulty-adjusted learning: additive-factors-style logistic regression
    #   logit P(correct) = b0 + b1 * difficulty_l + b2 * log(opportunity) + b3 * theta_hat_u
    lo_diff = df_los.set_index(["curriculum", "lo"])["difficulty"]
    logs["difficulty"] = lo_diff.reindex(pd.MultiIndex.from_arrays([logs.curriculum, logs.lo])).values
    th = {}
    for it in manifest()["splits"]["train"]:
        Lx = load_learners(DATA / it["file"])
        for u, v in enumerate(Lx["theta_hat"]):
            th[(it["curriculum"], u)] = v
    logs["theta_hat"] = [th[(c, u)] for c, u in zip(logs.curriculum, logs.learner)]
    X = np.column_stack([np.ones(len(logs)), logs.difficulty, np.log(logs.opp), logs.theta_hat])
    afm = irls_logit(X, logs.correct.values.astype(float))
    strat = logs[logs.bloom <= 5].groupby(["bloom", "opp"]).agg(err=("correct", lambda x: 1 - x.mean()),
                                                                 n=("correct", "size")).reset_index()
    strat = strat[strat.n >= 150]
    # item level: empirical success vs IRT difficulty
    lo_key = df_los.set_index(["curriculum", "lo"])
    item = logs.groupby(["curriculum", "lo"]).agg(succ=("correct", "mean"), n=("correct", "size")).reset_index()
    item = item[item.n >= 20]
    item["difficulty"] = [lo_key.loc[(c, l), "difficulty"] for c, l in zip(item.curriculum, item.lo)]
    item["bloom"] = [lo_key.loc[(c, l), "bloom"] for c, l in zip(item.curriculum, item.lo)]
    rho_s, p_s = stats.spearmanr(item.difficulty, item.succ)
    by_bloom = logs.groupby("bloom").correct.mean()
    # dropout / survival per step
    last = logs.groupby(["curriculum", "learner"]).agg(steps=("step", "max"), dropped=("dropped", "max"))
    surv_steps = np.arange(0, 60)
    alive = [(~((last.dropped == 1) & (last.steps < s))).mean() for s in surv_steps]
    by_mod = logs.groupby("modality").dropped.mean()
    return dict(
        n_records=len(logs), n_learners=int(last.shape[0]), overall_correct=float(logs.correct.mean()),
        mean_p=float(logs.p_success.mean()), dropout_frac=float(last.dropped.mean()),
        power_law=dict(A=float(A1), alpha=float(a1), r2=float(r2_pw)),
        afm=afm, stratified_curve=strat.to_dict(orient="records"),
        exponential=dict(A=float(A2), b=float(b2), c=float(c2), r2=float(r2_ex)),
        spearman_difficulty_success=dict(rho=float(rho_s), p=float(p_s), n_items=int(len(item))),
        success_by_bloom={int(k): float(v) for k, v in by_bloom.items()},
        dropout_by_modality={k: float(v) for k, v in by_mod.items()},
    ), strat, (A1, a1), item, (surv_steps, alive)


def irls_logit(X, y, iters=50):
    """Maximum-likelihood logistic regression by Newton-Raphson; returns coefficients and s.e."""
    b = np.zeros(X.shape[1])
    for _ in range(iters):
        p = 1 / (1 + np.exp(-X @ b))
        W = p * (1 - p)
        H = X.T @ (X * W[:, None])
        step = np.linalg.solve(H, X.T @ (y - p))
        b += step
        if np.abs(step).max() < 1e-10:
            break
    p = 1 / (1 + np.exp(-X @ b))
    cov = np.linalg.inv(X.T @ (X * (p * (1 - p))[:, None]))
    se = np.sqrt(np.diag(cov))
    names = ["intercept", "difficulty", "log_opportunity", "theta_hat"]
    return {n: dict(coef=float(c), se=float(e), z=float(c / e)) for n, c, e in zip(names, b, se)}


def fig_curriculum(name="T00"):
    cur = load_curriculum(DATA / "curricula" / f"{name}.json")
    G = nx.DiGraph()
    for c in cur["concepts"]:
        G.add_node(c["concept"], layer=c["layer"], topic=c["topic"])
    G.add_edges_from((e["src"], e["dst"]) for e in cur["prerequisites"])
    pos = nx.multipartite_layout(G, subset_key="layer", align="horizontal", scale=1.0)
    pos = {k: (v[0], -v[1]) for k, v in pos.items()}
    fig, ax = plt.subplots(figsize=(6.3, 3.6))
    ax.grid(False)
    ax.axis("off")
    nx.draw_networkx_edges(G, pos, ax=ax, edge_color=ps.GRAY, width=0.7, arrowsize=6, node_size=170,
                           connectionstyle="arc3,rad=0.05")
    topics = sorted({c["topic"] for c in cur["concepts"]})
    for t in topics:
        nodes = [c["concept"] for c in cur["concepts"] if c["topic"] == t]
        nx.draw_networkx_nodes(G, pos, nodelist=nodes, node_color=ps.SERIES[t], node_size=170, ax=ax,
                               edgecolors="white", linewidths=1.0, label=f"topic {t + 1}")
    nx.draw_networkx_labels(G, pos, ax=ax, font_size=5.5, font_color="white")
    ax.legend(loc="lower center", ncol=len(topics), bbox_to_anchor=(0.5, -0.08), handletextpad=0.2, markerscale=0.7)
    ax.set_title(f"Prerequisite DAG of curriculum {name} (K={len(cur['concepts'])}, "
                 f"|E|={len(cur['prerequisites'])}); layers run top (0) to bottom (5)")
    fig.savefig(FIG / "curriculum_dag.pdf")
    plt.close(fig)


def fig_logs(curve, pw, item, surv):
    fig, axs = plt.subplots(1, 3, figsize=(6.5, 2.2))
    ax = axs[0]
    for b in range(1, 6):
        sub = curve[curve.bloom == b]
        ax.plot(sub.opp, sub.err, "-o", color=ps.SERIES[b - 1], ms=3, lw=1.2, label=f"Bloom {b}")
    ax.set_xlabel("practice opportunity $j$ on the concept")
    ax.set_ylabel("error rate")
    ax.set_title("(a) learning curves by Bloom level")
    ax.legend(fontsize=6.5, handlelength=1.2)
    ax = axs[1]
    for b in range(1, 7):
        sub = item[item.bloom == b]
        ax.scatter(sub.difficulty, sub.succ, s=4, color=ps.SERIES[b - 1], alpha=0.5, label=f"{b}", linewidths=0)
    ax.set_xlabel("IRT difficulty $b_l$")
    ax.set_ylabel("empirical success rate")
    ax.set_title("(b) item difficulty")
    ax.legend(title="Bloom", ncol=2, markerscale=2, handletextpad=0.1, columnspacing=0.6, fontsize=6.5, title_fontsize=7)
    ax = axs[2]
    ax.step(surv[0], surv[1], where="post", color=ps.SERIES[0])
    ax.set_xlabel("LO attempts")
    ax.set_ylabel("fraction not dropped out")
    ax.set_ylim(0.6, 1.01)
    ax.set_title("(c) retention in the course")
    fig.tight_layout()
    fig.savefig(FIG / "data_logs.pdf")
    plt.close(fig)


def fig_population(L, df_los):
    fig, axs = plt.subplots(1, 4, figsize=(6.6, 1.9))
    axs[0].hist(L["theta"], bins=30, color=ps.SERIES[0], edgecolor="white", linewidth=0.4)
    axs[0].set_title("ability $\\theta_u$")
    axs[1].hist(L["eta"], bins=30, color=ps.SERIES[0], edgecolor="white", linewidth=0.4)
    axs[1].set_title("learning rate $\\eta_u$")
    axs[2].hist(L["Ts"] * L["n_sess"], bins=20, color=ps.SERIES[0], edgecolor="white", linewidth=0.4)
    axs[2].set_title("time budget $T_u$ (min)")
    axs[3].hist(L["m0_mean"], bins=30, color=ps.SERIES[0], edgecolor="white", linewidth=0.4)
    axs[3].set_title("mean prior mastery")
    for a in axs:
        a.set_yticks([])
    fig.tight_layout()
    fig.savefig(FIG / "data_population.pdf")
    plt.close(fig)


def latex_split_table(rows):
    lines = [r"\begin{tabular}{lrrrrrrrr}", r"\toprule",
             r"Split & Curr. & $K$ & $N$ & $|E_P|$ & Learners & $\bar T_u$ (min) & $\overline{|\mathcal G_u|}$ & $\overline{\Psi(\mathbf m_0)}$ \\",
             r"\midrule"]
    for r in rows:
        lines.append(f"{r['split']} & {r['curricula']} & {r['K']} & {r['N']} & {r['E']} & {r['learners']} & "
                     f"{r['budget']} & {r['goals']} & {r['goal_m0']} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (TAB / "data_splits.tex").write_text("\n".join(lines))


def main():
    ps.setup()
    FIG.mkdir(parents=True, exist_ok=True)
    TAB.mkdir(parents=True, exist_ok=True)
    man = manifest()
    rows = split_table(man)
    latex_split_table(rows)
    cat, df_los = catalogue_stats(man)
    df_los["curriculum"] = [n for n in man["curricula"] for _ in range(man["curricula"][n]["N"])]
    lst, L = learner_stats(man)
    logst, curve, pw, item, surv = log_analysis(df_los)
    fig_curriculum()
    fig_logs(curve, pw, item, surv)
    fig_population(L, df_los)
    out = dict(splits=rows, catalogue=cat, learners=lst, logs=logst)
    (RESULTS / "data_stats.json").write_text(json.dumps(out, indent=1, default=float))
    print(json.dumps(dict(catalogue=cat, learners=lst, logs=logst), indent=1, default=float))


if __name__ == "__main__":
    main()

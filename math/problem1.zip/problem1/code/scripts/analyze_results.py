"""Statistics, LaTeX tables and figures for Chapter 6.

Reads results/eval/<split>/<method>.npz and results/models/*_log.json; writes
dissertation/tables/*.tex, dissertation/figures/*.pdf and results/summary.json.
Missing result files are skipped.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.data import RESULTS, load_split
from lpg import plotstyle as ps
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
FIG = ROOT / "dissertation" / "figures"
TAB = ROOT / "dissertation" / "tables"
EVAL = RESULTS / "eval"
RNG = np.random.default_rng(0)

BASE = [("random", "Random"), ("static", "Static syllabus"), ("kg_rule", "KG-rule"), ("greedy", "Greedy"),
        ("beam8", "Beam-8"), ("ga", "GA"), ("ga_mc", "GA-MC"), ("ga_mcc", "GA-MC (CRN)"), ("ga_mcr", "GA-MC-R (CRN)")]
OURS = [("gnn_full", "\\pahgnn{} (greedy)"), ("gnn_s16_full", "\\pahgnn{} (sample-16)"),
        ("gnn_full_robust", "\\pahgnn-R (greedy)"), ("gnn_s16r_full_robust", "\\pahgnn-R (sample-16)")]
MAIN = BASE + OURS
REF = "gnn_full"
REF2 = "gnn_full_robust"
ABL = [("gnn_full_s", "Full model (short schedule)"), ("gnn_full_s1@bc", "BC only (no RL)"),
       ("gnn_rl_only", "RL only (no BC)"), ("gnn_no_anc", "-- surmise relations"),
       ("gnn_no_cc", "-- all concept--concept relations"), ("gnn_mlp", "MLP encoder (no message passing)"),
       ("gnn_no_model_feat", "-- model-informed features"), ("gnn_no_learner", "-- learner context"),
       ("gnn_mean_agg", "mean aggregation (no attention)"), ("gnn_layers1", "1 layer instead of 3")]
SPLIT_NAMES = {"test_id": "Seen curricula", "test_ood": "Unseen curricula", "test_k80": "$K=80$",
               "test_k120": "$K=120$", "shift_lowbw": "Low bandwidth", "shift_lowprior": "Low prior / ability",
               "shift_forget": "Fast forgetting", "shift_noisy": "Noisy observations",
               "test_ood_misspec": "Misspecified dynamics"}


def load(split, tag):
    f = EVAL / split / f"{tag}.npz"
    if not f.exists():
        return None
    with np.load(f) as z:
        return {k: z[k] for k in z.files}


def boot_ci(x, n=2000):
    x = np.asarray(x, float)
    idx = RNG.integers(0, len(x), (n, len(x)))
    m = x[idx].mean(1)
    return float(x.mean()), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def wilcoxon(a, b):
    """Paired Wilcoxon signed-rank test and matched-pairs rank-biserial correlation (a vs b)."""
    d = np.asarray(a) - np.asarray(b)
    d = d[d != 0]
    if len(d) == 0:
        return 1.0, 0.0
    r = stats.rankdata(np.abs(d))
    rb = (r[d > 0].sum() - r[d < 0].sum()) / r.sum()
    p = stats.wilcoxon(a, b, zero_method="wilcox").pvalue
    return float(p), float(rb)


def holm(ps_):
    ps_ = np.asarray(ps_)
    order = np.argsort(ps_)
    adj = np.empty_like(ps_)
    run = 0.0
    for k, i in enumerate(order):
        run = max(run, (len(ps_) - k) * ps_[i])
        adj[i] = min(1.0, run)
    return adj


def fmt_p(p):
    return "$<10^{-4}$" if p < 1e-4 else f"{p:.4f}"


METRICS = [("psi", "$\\Psi_T$", 3, 1), ("gain", "$g$", 3, 1), ("attain", "Attain.", 1, 100),
           ("psi_delayed", "$\\Psi_{+7\\mathrm d}$", 3, 1), ("survive", "Compl.", 1, 100),
           ("viol_rate", "Viol.", 1, 100), ("zpd_rate", "ZPD", 1, 100), ("runtime", "ms", 1, 1000)]


def main_table(split, summary):
    rows, data = [], {}
    for tag, name in MAIN:
        r = load(split, tag)
        if r is not None:
            data[tag] = r
    if REF not in data:
        return
    lines = [r"\begin{tabular}{l" + "r" * len(METRICS) + "}", r"\toprule",
             "Method & " + " & ".join(m[1] for m in METRICS) + r" \\", r"\midrule"]
    best = {m[0]: max(np.mean(d[m[0]]) for d in data.values()) if m[0] not in ("viol_rate", "runtime")
            else min(np.mean(d[m[0]]) for d in data.values()) for m in METRICS}
    summ = {}
    for tag, name in MAIN:
        if tag not in data:
            continue
        d = data[tag]
        cells = []
        for key, _, dec, scale in METRICS:
            v = np.mean(d[key]) * scale
            s = f"{v:.{dec}f}"
            if abs(np.mean(d[key]) - best[key]) < 1e-12 and key != "runtime":
                s = r"\textbf{" + s + "}"
            cells.append(s)
        lines.append(f"{name} & " + " & ".join(cells) + r" \\")
        if tag == "ga_mcr" or (tag == "ga_mc" and "ga_mcr" not in data):
            lines.append(r"\midrule")
        summ[tag] = {k: boot_ci(d[k]) for k, *_ in METRICS}
        summ[tag]["J_mc"] = boot_ci(d["J_mc"])
        summ[tag]["J_meanfield"] = boot_ci(d["J_meanfield"])
        summ[tag]["length"] = float(d["length"].mean())
        summ[tag]["time_to_attain_attainers"] = float(d["time_to_attain"][d["ever_attain"] > 0.5].mean()) \
            if (d["ever_attain"] > 0.5).any() else float("nan")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (TAB / f"main_{split}.tex").write_text("\n".join(lines))
    summary[split] = summ
    # statistical tests: every PA-HGNN variant vs the non-trivial baselines on Psi_T (Holm within model)
    models = [(t, n) for t, n in OURS if t in data]
    bases = [(t, n) for t, n in BASE if t in data and t not in ("random", "static")]
    cells = {}
    for mt, _ in models:
        tests = []
        for bt, _ in bases:
            p, rb = wilcoxon(data[mt]["psi"], data[bt]["psi"])
            diff = boot_ci(data[mt]["psi"] - data[bt]["psi"])
            win = float(np.mean(data[mt]["psi"] > data[bt]["psi"]))
            tests.append([bt, diff, p, rb, win])
        adj = holm([t[2] for t in tests])
        for t, pa in zip(tests, adj):
            cells[(mt, t[0])] = (t[1], pa, t[3], t[4])
            summ[mt].setdefault("tests", {})[t[0]] = dict(diff=t[1], p_holm=float(pa), rb=t[3], win=t[4])

    def star(pa):
        k = 3 if pa < 1e-3 else 2 if pa < 1e-2 else 1 if pa < 0.05 else 0
        return "\\textsuperscript{" + "*" * k + "}" if k else ""
    short = {"gnn_full": "\\pahgnn{}", "gnn_s16_full": "\\pahgnn{} s16", "gnn_full_robust": "\\pahgnn-R",
             "gnn_s16r_full_robust": "\\pahgnn-R s16"}
    lines = [r"\begin{tabular}{l" + "c" * len(models) + "}", r"\toprule",
             "Baseline & " + " & ".join(short[m] for m, _ in models) + r" \\", r"\midrule"]
    for bt, bn in bases:
        row = []
        for mt, _ in models:
            (m, lo, hi), pa, rb, win = cells[(mt, bt)]
            row.append(f"${m:+.3f}${star(pa)} \\, ({rb:+.2f})")
        lines.append(f"{bn} & " + " & ".join(row) + r" \\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    (TAB / f"tests_{split}.tex").write_text("\n".join(lines))
    # Friedman omnibus over all methods with complete data
    tags = [t for t, _ in MAIN if t in data]
    fr = stats.friedmanchisquare(*[data[t]["psi"] for t in tags])
    summary[split + "_friedman"] = dict(stat=float(fr.statistic), p=float(fr.pvalue), k=len(tags),
                                        n=int(len(data[REF]["psi"])))


def planner_table(summary):
    """Planner-side values and the Jensen gap on the unseen-curricula split."""
    split = "test_ood"
    lines = [r"\begin{tabular}{lrrrr}", r"\toprule",
             r"Method & $J^{\mathrm{mf}}$ (mean-field) & $\hat J$ (Monte Carlo) & Jensen gap & $\Psi_T$ (true learner) \\",
             r"\midrule"]
    any_ = False
    for tag, name in MAIN:
        d = load(split, tag)
        if d is None:
            continue
        any_ = True
        jm, jc, ps_ = d["J_meanfield"].mean(), d["J_mc"].mean(), d["psi"].mean()
        lines.append(f"{name} & {jm:.3f} & {jc:.3f} & {jc - jm:+.3f} & {ps_:.3f} \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    if any_:
        (TAB / "planner_values.tex").write_text("\n".join(lines))


def generalisation_table(summary):
    splits = ["test_id", "test_ood", "test_k80", "test_k120", "shift_lowbw", "shift_lowprior", "shift_forget",
              "shift_noisy", "test_ood_misspec"]
    methods = [("static", "Static"), ("kg_rule", "KG-rule"), ("greedy", "Greedy"), ("beam8", "Beam-8"),
               ("ga", "GA"), ("ga_mc", "GA-MC"), ("gnn_full", "\\pahgnn"), ("gnn_s16_full", "\\pahgnn-s16"),
               ("gnn_full_robust", "\\pahgnn-R"), ("gnn_s16r_full_robust", "\\pahgnn-R-s16")]
    avail = [s for s in splits if (EVAL / s / f"{REF}.npz").exists()]
    lines = [r"\begin{tabular}{l" + "r" * len(methods) + "}", r"\toprule",
             "Split & " + " & ".join(m[1] for m in methods) + r" \\", r"\midrule"]
    gen = {}
    for s in avail:
        vals = {}
        for tag, _ in methods:
            d = load(s, tag)
            vals[tag] = None if d is None else float(d["psi"].mean())
        good = [v for v in vals.values() if v is not None]
        mx = max(good)
        cells = []
        for tag, _ in methods:
            v = vals[tag]
            if v is None:
                cells.append("--")
            else:
                cells.append((r"\textbf{%.3f}" if abs(v - mx) < 1e-12 else "%.3f") % v)
        lines.append(f"{SPLIT_NAMES[s]} & " + " & ".join(cells) + r" \\")
        gen[s] = vals
        # significance of PA-HGNN vs best baseline on this split
        base_tags = [t for t, _ in methods if not t.startswith("gnn") and vals[t] is not None]
        if base_tags:
            bt = max(base_tags, key=lambda t: vals[t])
            p, rb = wilcoxon(load(s, REF)["psi"], load(s, bt)["psi"])
            gen[s]["best_baseline"] = bt
            gen[s]["p_vs_best"] = p
            gen[s]["rb_vs_best"] = rb
    lines += [r"\bottomrule", r"\end{tabular}"]
    (TAB / "generalisation.tex").write_text("\n".join(lines))
    summary["generalisation"] = gen


def ablation_table(summary):
    split = "test_ood"
    ref_tag = "gnn_full_s" if load(split, "gnn_full_s") is not None else "gnn_full_s1"
    ref = load(split, ref_tag)
    abl_list = [(ref_tag, "Full model (short schedule)")] + [a for a in ABL if a[0] != "gnn_full_s"]
    lines = [r"\begin{tabular}{lrrrrr}", r"\toprule",
             r"Variant & $\Psi_T$ & $\hat J$ & Attain. (\%) & $\Delta\Psi_T$ vs full & $p_{\mathrm{Holm}}$ \\",
             r"\midrule"]
    rows, ps_ = [], []
    for tag, name in abl_list:
        d = load(split, tag)
        if d is None:
            continue
        if ref is not None and tag != ref_tag:
            p, rb = wilcoxon(d["psi"], ref["psi"])
            diff = float(d["psi"].mean() - ref["psi"].mean())
        else:
            p, diff = None, None
        rows.append((tag, name, d, diff, p))
        if p is not None:
            ps_.append(p)
    adj = iter(holm(ps_)) if ps_ else iter([])
    abl = {}
    for tag, name, d, diff, p in rows:
        pa = next(adj) if p is not None else None
        lines.append(f"{name} & {d['psi'].mean():.3f} & {d['J_mc'].mean():.3f} & {100 * d['attain'].mean():.1f} & "
                     + ("--" if diff is None else f"{diff:+.3f}") + " & " + ("--" if pa is None else fmt_p(pa)) + r" \\")
        abl[tag] = dict(psi=float(d["psi"].mean()), J_mc=float(d["J_mc"].mean()), attain=float(d["attain"].mean()),
                        diff=diff, p_holm=None if pa is None else float(pa))
    # seed variability of the short-schedule full model
    seeds = [load(split, t) for t in ("gnn_full_s", "gnn_full_s1", "gnn_full_s2")]
    seeds = [s for s in seeds if s is not None]
    if len(seeds) > 1:
        vals = [s["psi"].mean() for s in seeds]
        abl["seed_mean"], abl["seed_sd"] = float(np.mean(vals)), float(np.std(vals, ddof=1))
        lines.append(r"\midrule")
        lines.append(f"Full model, {len(seeds)} seeds (mean $\\pm$ s.d.) & {np.mean(vals):.3f} $\\pm$ {np.std(vals, ddof=1):.3f}"
                     f" & {np.mean([s['J_mc'].mean() for s in seeds]):.3f} & "
                     f"{100 * np.mean([s['attain'].mean() for s in seeds]):.1f} & -- & -- \\\\")
    lines += [r"\bottomrule", r"\end{tabular}"]
    if rows:
        (TAB / "ablation.tex").write_text("\n".join(lines))
    summary["ablation"] = abl


def fairness(summary):
    split = "test_ood"
    methods = [("kg_rule", "KG-rule"), ("beam8", "Beam-8"), ("ga_mc", "GA-MC"), ("gnn_full", "PA-HGNN")]
    data = {t: load(split, t) for t, _ in methods}
    data = {t: d for t, d in data.items() if d is not None}
    if REF not in data:
        return
    groups = {}
    d0 = data[REF]
    groups["bandwidth"] = [("low", d0["bw"] == 0), ("medium", d0["bw"] == 1), ("high", d0["bw"] == 2)]
    q = np.quantile(d0["prior"], [1 / 3, 2 / 3])
    groups["prior"] = [("low", d0["prior"] <= q[0]), ("mid", (d0["prior"] > q[0]) & (d0["prior"] <= q[1])),
                       ("high", d0["prior"] > q[1])]
    q = np.quantile(d0["theta"], [1 / 3, 2 / 3])
    groups["ability"] = [("low", d0["theta"] <= q[0]), ("mid", (d0["theta"] > q[0]) & (d0["theta"] <= q[1])),
                         ("high", d0["theta"] > q[1])]
    res = {}
    lines = [r"\begin{tabular}{ll" + "r" * len(data) + "}", r"\toprule",
             "Attribute & Group & " + " & ".join(n for t, n in methods if t in data) + r" \\", r"\midrule"]
    for g, parts in groups.items():
        res[g] = {}
        for k, (lab, mask) in enumerate(parts):
            cells = []
            for t, n in methods:
                if t not in data:
                    continue
                v = float(data[t]["psi"][mask].mean())
                res[g].setdefault(t, {})[lab] = v
                cells.append(f"{v:.3f}")
            lines.append(("\\multirow{3}{*}{" + g + "}" if k == 0 else "") + f" & {lab} (n={int(mask.sum())}) & "
                         + " & ".join(cells) + r" \\")
        # gap between best and worst group
        cells = []
        for t, n in methods:
            if t not in data:
                continue
            vals = list(res[g][t].values())
            res[g][t]["gap"] = max(vals) - min(vals)
            cells.append(f"{max(vals) - min(vals):.3f}")
        lines.append(" & gap & " + " & ".join(cells) + r" \\")
        lines.append(r"\midrule")
    lines[-1] = r"\bottomrule"
    lines.append(r"\end{tabular}")
    (TAB / "fairness.tex").write_text("\n".join(lines))
    summary["fairness"] = res


def coverage_analysis(summary):
    """How much of the bandwidth gap is explained by missing accessible LOs (unseen curricula)?

    A concept that a learner must learn (goal or ancestor with initial mastery < tau_M) is *supported*
    if accessible LOs exist at >= 3 of the Bloom levels 1-5, including one at level >= 4.
    """
    import torch
    from lpg.baselines import relevance_weights
    insts = load_split("test_ood")
    cov = []
    for inst in insts:
        L = inst.batch(np.arange(inst.n))
        c = inst.dyn.c
        rel = (relevance_weights(inst.dyn, L) > 0) & (L.m0 < inst.dyn.p.tau_master)
        for u in range(inst.n):
            acc = c.bw <= L.bw[u]
            ok = []
            for k in torch.nonzero(rel[u]).flatten().tolist():
                lv = set(c.bloom[(c.primary == k) & acc].tolist())
                ok.append(float(len(lv & {1, 2, 3, 4, 5}) >= 3 and max(lv | {0}) >= 4))
            cov.append(np.mean(ok) if ok else 1.0)
    cov = np.array(cov)
    res = {}
    for tag in ["kg_rule", "ga", REF]:
        d = load("test_ood", tag)
        if d is None:
            continue
        bw, psi = d["bw"], d["psi"]
        X1 = np.column_stack([np.ones_like(psi), bw == 1, bw == 2]).astype(float)
        X2 = np.column_stack([X1, cov])
        b1 = np.linalg.lstsq(X1, psi, rcond=None)[0]
        b2 = np.linalg.lstsq(X2, psi, rcond=None)[0]
        res[tag] = dict(gap_med_without=float(b1[1]), gap_high_without=float(b1[2]), gap_med_with=float(b2[1]),
                        gap_high_with=float(b2[2]), coef_coverage=float(b2[3]),
                        spearman=float(stats.spearmanr(cov, psi).statistic))
    res["coverage_by_bw"] = {str(b): float(cov[load("test_ood", "kg_rule")["bw"] == b].mean()) for b in range(3)}
    summary["coverage"] = res


# ------------------------------------------------------------------------------ figures
def plain(n):
    return n.replace("\\pahgnn{}", "PA-HGNN").replace("\\pahgnn", "PA-HGNN")


def fig_main(summary):
    split = "test_ood"
    if split not in summary:
        return
    s = summary[split]
    tags = [t for t, _ in MAIN if t in s]
    names = {t: plain(n) for t, n in MAIN}
    fig, axs = plt.subplots(1, 3, figsize=(6.6, 2.8), sharey=True)
    for ax, (key, title, scale) in zip(axs, [("psi", "goal mastery $\\Psi_T$", 1), ("attain", "attainment (%)", 100),
                                             ("psi_delayed", "delayed mastery (+7 d)", 1)]):
        for i, t in enumerate(tags):
            m, lo, hi = (v * scale for v in s[t][key])
            col = ps.SERIES[0] if t.startswith("gnn") else (ps.SERIES[1] if t == "ga_mc" else ps.GRAY)
            ax.plot([lo, hi], [i, i], color=col, lw=1.6, solid_capstyle="round")
            ax.plot([m], [i], "o", color=col, ms=5)
        ax.set_title(title)
        ax.grid(axis="y", visible=False)
    axs[0].set_yticks(range(len(tags)))
    axs[0].set_yticklabels([names[t] for t in tags])
    axs[0].invert_yaxis()
    fig.tight_layout()
    fig.savefig(FIG / "main_results.pdf")
    plt.close(fig)


def fig_pareto(summary):
    split = "test_ood"
    if split not in summary:
        return
    s = summary[split]
    offsets = {"random": (5, 0), "static": (5, 0), "kg_rule": (5, 2), "greedy": (5, -6), "beam8": (5, -3),
               "ga": (-12, 7), "ga_mc": (5, -9), "ga_mcc": (6, -1), "ga_mcr": (-58, -10),
               "gnn_full": (-62, 4), "gnn_full_robust": (-66, -9), "gnn_s16_full": (6, -3), "gnn_s16r_full_robust": (6, 2)}
    fig, ax = plt.subplots(figsize=(5.2, 3.2))
    for t, n in MAIN:
        if t not in s:
            continue
        x = s[t]["runtime"][0] * 1000
        y = s[t]["psi"][0]
        col = ps.SERIES[0] if t.startswith("gnn") else (ps.SERIES[1] if t.startswith("ga") else ps.GRAY_DARK)
        ax.plot([x], [y], "o", color=col, ms=5.5, zorder=3)
        ax.annotate(plain(n), (x, y), textcoords="offset points", xytext=offsets.get(t, (5, 3)), fontsize=6.3,
                    color=ps.TEXT)
    ax.set_xscale("log")
    ax.set_xlim(1.5, 6e4)
    ax.set_xlabel("path generation time per learner (ms, log scale)")
    ax.set_ylabel("goal mastery $\\Psi_T$ (true learner)")
    ax.set_title("Quality versus computational cost (unseen curricula)")
    fig.savefig(FIG / "pareto.pdf")
    plt.close(fig)


def fig_training():
    """Training curves: BC and the first 100 RL iterations of the seed-1 run, then the 150 RL
    iterations with which the main model (standard and uncertainty-aware reward) continues it."""
    f1 = RESULTS / "models" / "full_s1_log.json"
    if not f1.exists():
        return
    log1 = json.loads(f1.read_text())
    bc = [r for r in log1 if r.get("phase") == "bc"]
    rl1 = [r for r in log1 if r.get("phase") == "rl"]
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 3.1), gridspec_kw=dict(width_ratios=[1, 2.2]))
    ax = axs[0]
    ax.plot([r["epoch"] + 1 for r in bc], [r["nll"] for r in bc], "-o", color=ps.SERIES[0], ms=3, label="train NLL")
    ax.set_xlabel("BC epoch")
    ax.set_ylabel("per-step NLL")
    ax2 = ax.twinx()
    ax2.plot([r["epoch"] + 1 for r in bc], [r["val"] for r in bc], "-s", color=ps.SERIES[1], ms=3)
    ax2.set_ylabel("validation $\\hat J$", color=ps.SERIES[1])
    ax2.tick_params(axis="y", colors=ps.SERIES[1])
    ax2.grid(False)
    ax.set_title("(a) behaviour cloning")
    ax = axs[1]
    k = 15
    series = [("seed-1 run", rl1, 0, ps.SERIES[1])]
    for name, tag, col in [("main model", "full", ps.SERIES[0]), ("uncertainty-aware (R)", "full_robust", ps.SERIES[2])]:
        f = RESULTS / "models" / f"{tag}_log.json"
        if f.exists():
            series.append((name, [r for r in json.loads(f.read_text()) if r.get("phase") == "rl"], 100, col))
    for name, rl, off, col in series:
        it = [r["it"] + off for r in rl if "reward" in r]
        rw = [r["reward"] for r in rl if "reward" in r]
        if len(rw) > k:
            sm = np.convolve(rw, np.ones(k) / k, mode="valid")
            ax.plot(it[k - 1:], sm, color=col, lw=1.0, alpha=0.55)
        vi = [(r["it"] + off, r["val"]) for r in rl if "val" in r]
        ax.plot([a for a, b in vi], [b for a, b in vi], "o-", color=col, ms=3.5, lw=1.6, label=name)
    ax.axvline(100, color=ps.GRAY, lw=0.8, ls=":")
    ax.set_xlabel("policy-gradient iteration")
    ax.set_ylabel("expected goal mastery")
    ax.set_title("(b) policy-gradient fine-tuning")
    ax.legend(fontsize=6.5, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.2),
              title="validation $\\hat J$ (markers) and batch reward, moving average of 15 (thin)", title_fontsize=6.5)
    fig.tight_layout()
    fig.savefig(FIG / "training.pdf")
    plt.close(fig)


def fig_generalisation(summary):
    gen = summary.get("generalisation", {})
    if not gen:
        return
    splits = list(gen.keys())
    methods = [("kg_rule", "KG-rule", ps.SERIES[2]), ("beam8", "Beam-8", ps.SERIES[3]),
               ("ga_mc", "GA-MC", ps.SERIES[1]), ("gnn_full", "PA-HGNN", ps.SERIES[0])]
    fig, ax = plt.subplots(figsize=(6.4, 2.6))
    x = np.arange(len(splits))
    w = 0.2
    for k, (t, n, col) in enumerate(methods):
        ys = [gen[s].get(t) for s in splits]
        xs = [xi + (k - 1.5) * w for xi, y in zip(x, ys) if y is not None]
        ys = [y for y in ys if y is not None]
        ax.bar(xs, ys, width=w * 0.92, color=col, label=n, edgecolor="white", linewidth=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels([SPLIT_NAMES[s].replace("$", "").replace("\\", "") for s in splits], rotation=25, ha="right",
                       fontsize=7)
    ax.set_ylabel("goal mastery $\\Psi_T$")
    ax.legend(ncol=4, fontsize=7, loc="upper center", bbox_to_anchor=(0.5, 1.15))
    ax.grid(axis="x", visible=False)
    fig.savefig(FIG / "generalisation.pdf")
    plt.close(fig)


def fig_fairness(summary):
    res = summary.get("fairness")
    if not res:
        return
    methods = [("kg_rule", "KG-rule", ps.SERIES[2]), ("beam8", "Beam-8", ps.SERIES[3]),
               ("ga_mc", "GA-MC", ps.SERIES[1]), ("gnn_full", "PA-HGNN", ps.SERIES[0])]
    fig, axs = plt.subplots(1, 3, figsize=(6.6, 2.3), sharey=True)
    for ax, g, title in zip(axs, ["bandwidth", "prior", "ability"], ["bandwidth class", "prior knowledge tercile",
                                                                     "ability tercile"]):
        labs = [k for k in next(iter(res[g].values())).keys() if k != "gap"]
        x = np.arange(len(labs))
        for t, n, col in methods:
            if t not in res[g]:
                continue
            ax.plot(x, [res[g][t][l] for l in labs], "-o", color=col, ms=4, label=n)
        ax.set_xticks(x)
        ax.set_xticklabels(labs)
        ax.set_title(title)
    axs[0].set_ylabel("goal mastery $\\Psi_T$")
    axs[0].legend(fontsize=6.5)
    fig.tight_layout()
    fig.savefig(FIG / "fairness.pdf")
    plt.close(fig)


def fig_case_study():
    """Goal-mastery trajectory of one unseen-curriculum learner under four generators."""
    split = "test_ood"
    pdir = EVAL / split / "paths"
    tags = [("kg_rule", "KG-rule", ps.SERIES[2]), ("beam8", "Beam-8", ps.SERIES[3]), ("ga_mc", "GA-MC", ps.SERIES[1]),
            ("gnn_full", "PA-HGNN", ps.SERIES[0])]
    paths = {t: json.loads((pdir / f"{t}.json").read_text()) for t, *_ in tags if (pdir / f"{t}.json").exists()}
    if "gnn_full" not in paths:
        return
    import torch
    from lpg.dynamics import rollout_path
    inst = load_split(split)[0]
    d_ref = load(split, "gnn_full")
    d_kg = load(split, "kg_rule")
    # pick a representative learner of instance 0: two or more goals, substantial progress under PA-HGNN,
    # and the median improvement over KG-rule among such learners
    n0 = inst.n
    imp = d_ref["psi"][:n0] - (d_kg["psi"][:n0] if d_kg is not None else 0)
    cand = [i for i in range(n0) if inst.L["goals"][i].sum() >= 2 and d_ref["psi"][i] - d_ref["psi0"][i] > 0.3]
    if not cand:
        cand = [i for i in range(n0) if inst.L["goals"][i].sum() >= 2]
    u = sorted(cand, key=lambda i: imp[i])[len(cand) // 2]
    Lt = inst.batch(np.array([u]), "true")
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.9), gridspec_kw=dict(width_ratios=[1.3, 1]))
    R = 64
    grid = np.linspace(0, float(Lt.T[0]), 60)
    summaries = {}
    for t, n, col in tags:
        if t not in paths:
            continue
        p = paths[t][u]
        torch.manual_seed(0)
        Lr = Lt.repeat(R)
        _, trace = rollout_path(inst.dyn, Lr, [p] * R, mode="true", record=True)
        times, vals = [0.0], [float(inst.dyn.psi(Lr.m0, Lr).mean())]
        s_final = None
        for s_prev, a, info in trace:
            pass
        # recompute along the path to get the state after each step
        s = inst.dyn.init_state(Lr)
        for a in p:
            s, _ = inst.dyn.step(s, Lr, torch.full((R,), a, dtype=torch.long), mode="true")
            times.append(float(s.t.mean()))
            vals.append(float(inst.dyn.psi(s.m, Lr).mean()))
        axs[0].step(times, vals, where="post", color=col, label=n, lw=1.5)
        summaries[t] = (len(p), vals[-1])
    axs[0].axhline(inst.dyn.p.tau_master, color=ps.GRAY, lw=0.8, ls="--")
    axs[0].set_xlabel("study time (min)")
    axs[0].set_ylabel("goal mastery (mean of 64 runs)")
    axs[0].set_title(f"(a) learner {u} of curriculum {inst.cur.name}")
    axs[0].legend(fontsize=6.5)
    # (b) Bloom level and concept depth along the PA-HGNN path
    p = paths["gnn_full"][u]
    c = inst.dyn.c
    depth = [int(c.layer[c.primary[l]]) for l in p]
    bloom = [int(c.bloom[l]) for l in p]
    goal = set(np.nonzero(inst.L["goals"][u])[0].tolist())
    cols = [ps.SERIES[1] if int(c.primary[l]) in goal else ps.SERIES[0] for l in p]
    axs[1].scatter(range(1, len(p) + 1), bloom, c=cols, s=14, zorder=3)
    axs[1].plot(range(1, len(p) + 1), depth, color=ps.GRAY, lw=1.0, label="concept depth (layer)")
    axs[1].set_xlabel("position in PA-HGNN path")
    axs[1].set_ylabel("Bloom level / depth")
    axs[1].set_title("(b) structure of the PA-HGNN path")
    from matplotlib.lines import Line2D
    axs[1].legend(handles=[Line2D([], [], marker="o", ls="", color=ps.SERIES[0], label="Bloom level (prerequisite)"),
                           Line2D([], [], marker="o", ls="", color=ps.SERIES[1], label="Bloom level (goal concept)"),
                           Line2D([], [], color=ps.GRAY, label="concept depth")], fontsize=6.0, loc="upper center",
                  bbox_to_anchor=(0.5, -0.22), ncol=3, handletextpad=0.3, columnspacing=0.8)
    fig.tight_layout()
    fig.savefig(FIG / "case_study.pdf")
    plt.close(fig)
    return dict(learner=int(u), curriculum=inst.cur.name, goals=sorted(goal), summaries=summaries,
                path=[dict(lo=int(l), concept=int(c.primary[l]), bloom=int(c.bloom[l]), layer=int(c.layer[c.primary[l]]))
                      for l in p])


def main():
    ps.setup()
    TAB.mkdir(parents=True, exist_ok=True)
    summary = {}
    for split in ["test_id", "test_ood"]:
        main_table(split, summary)
    planner_table(summary)
    generalisation_table(summary)
    ablation_table(summary)
    fairness(summary)
    coverage_analysis(summary)
    fig_main(summary)
    fig_pareto(summary)
    fig_training()
    fig_generalisation(summary)
    fig_fairness(summary)
    cs = fig_case_study()
    if cs:
        summary["case_study"] = cs
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=1, default=float))
    print(json.dumps({k: v for k, v in summary.items() if k not in ("case_study",)}, indent=1, default=float)[:6000])


if __name__ == "__main__":
    main()

"""Compute GA-MC expert paths for behaviour cloning (training split, first n learners per curriculum)."""
from __future__ import annotations

import argparse
import json
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.data import load_split, RESULTS
from lpg.baselines import ga_paths


def work(args):
    i, n, threads, pop, gens = args
    torch.set_num_threads(threads)
    inst = load_split("train")[i]
    out = RESULTS / "experts" / f"{inst.cur.name}.json"
    if out.exists():
        return inst.cur.name, 0.0
    t0 = time.time()
    paths = []
    for j in range(0, n, 16):
        L = inst.batch(np.arange(j, min(n, j + 16)))
        paths += ga_paths(inst.dyn, L, pop=pop, gens=gens, mc_samples=4, seed=i * 1000 + j)
    out.write_text(json.dumps(paths))
    return inst.cur.name, time.time() - t0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=48)
    ap.add_argument("--procs", type=int, default=4)
    ap.add_argument("--threads", type=int, default=3)
    ap.add_argument("--pop", type=int, default=32)
    ap.add_argument("--gens", type=int, default=40)
    a = ap.parse_args()
    (RESULTS / "experts").mkdir(parents=True, exist_ok=True)
    n_cur = len(load_split("train"))
    with Pool(a.procs) as pool:
        for name, sec in pool.imap_unordered(work, [(i, a.n, a.threads, a.pop, a.gens) for i in range(n_cur)]):
            print(name, f"{sec:.0f}s", flush=True)

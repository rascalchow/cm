"""Generate every synthetic dataset used in the dissertation.

Output layout (under data/):
  curricula/<name>.json            curriculum + LO catalogue
  learners/<split>__<name>.npz     learner populations (true traits, planner observations, goals)
  csv/                             flat CSV exports (concepts, prerequisites, LOs, learners, logs)
  manifest.json                    split definitions, generator configurations and seeds
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import asdict, replace
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.synth import (CurriculumConfig, PopulationConfig, generate_curriculum, generate_learners,
                       save_curriculum, save_learners, MODALITIES, BANDWIDTH, BLOOM_NAMES)
from lpg.dynamics import Curriculum, Dynamics, learners_from_numpy
from lpg.logs import simulate_logs

MASTER_SEED = 20261022


def rng_for(*key) -> np.random.Generator:
    return np.random.default_rng([MASTER_SEED] + [abs(hash_str(k)) for k in key])


def hash_str(x) -> int:
    if isinstance(x, int):
        return x
    h = 0
    for ch in str(x):
        h = (h * 131 + ord(ch)) % (2 ** 31 - 1)
    return h


def curriculum_cfg(K: int, rng: np.random.Generator) -> CurriculumConfig:
    if K <= 50:
        return CurriculumConfig(n_concepts=K, n_layers=6, n_topics=int(rng.integers(3, 6)))
    if K <= 80:
        return CurriculumConfig(n_concepts=K, n_layers=7, n_topics=6)
    return CurriculumConfig(n_concepts=K, n_layers=8, n_topics=8)


SHIFTS = {
    "lowbw": dict(bw_probs=(0.8, 0.2, 0.0)),
    "lowprior": dict(theta_mean=-1.0, prior_offset=1.0),
    "forget": dict(phi_median=0.15),
    "noisy": dict(obs_sd_mastery=0.25, obs_sd_theta=0.6, obs_sd_log_eta=0.4),
}


def main(out: Path, small: bool = False):
    (out / "curricula").mkdir(parents=True, exist_ok=True)
    (out / "learners").mkdir(parents=True, exist_ok=True)
    (out / "csv").mkdir(parents=True, exist_ok=True)
    pop = PopulationConfig()
    n_train_cur, n_train_learn = (4, 32) if small else (24, 128)
    plan = {"train": [], "val": [], "test_id": [], "test_ood": [], "test_k80": [], "test_k120": []}
    plan.update({f"shift_{k}": [] for k in SHIFTS})
    curricula = {}

    def make_cur(name, K):
        r = rng_for("curriculum", name)
        cur = generate_curriculum(r, curriculum_cfg(K, r), name)
        save_curriculum(cur, out / "curricula" / f"{name}.json")
        curricula[name] = cur
        return cur

    def make_learners(split, name, n, cfg):
        r = rng_for("learners", split, name)
        L = generate_learners(r, curricula[name], n, cfg)
        save_learners(L, out / "learners" / f"{split}__{name}.npz")
        plan[split].append(dict(curriculum=name, n=n, file=f"learners/{split}__{name}.npz"))

    r = rng_for("sizes")
    for i in range(n_train_cur):
        make_cur(f"T{i:02d}", int(r.integers(30, 51)))
        make_learners("train", f"T{i:02d}", n_train_learn, pop)
    for i in range(2 if small else 4):
        make_cur(f"V{i:02d}", int(r.integers(30, 51)))
        make_learners("val", f"V{i:02d}", 32, pop)
    for i in range(min(8, n_train_cur)):
        make_learners("test_id", f"T{i:02d}", 50, pop)
    for i in range(2 if small else 8):
        make_cur(f"O{i:02d}", int(r.integers(30, 51)))
        make_learners("test_ood", f"O{i:02d}", 50, pop)
        for k, kw in SHIFTS.items():
            make_learners(f"shift_{k}", f"O{i:02d}", 25, replace(pop, **kw))
    for i in range(1 if small else 4):
        make_cur(f"S80_{i}", 80)
        make_learners("test_k80", f"S80_{i}", 25, pop)
        make_cur(f"S120_{i}", 120)
        make_learners("test_k120", f"S120_{i}", 25, pop)

    manifest = dict(master_seed=MASTER_SEED, population=asdict(pop), shifts=SHIFTS, splits=plan,
                    curricula={k: dict(K=len(v["concepts"]), N=len(v["los"]), E=len(v["prerequisites"]),
                                       closure=len(v["closure"]), config=v["config"]) for k, v in curricula.items()})
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1))
    export_csv(out, curricula, plan)
    print(json.dumps({k: len(v) for k, v in plan.items()}))


def export_csv(out: Path, curricula: dict, plan: dict):
    d = out / "csv"
    with open(d / "concepts.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["curriculum", "concept", "layer", "topic", "difficulty"])
        for name, cur in curricula.items():
            for c in cur["concepts"]:
                w.writerow([name, c["concept"], c["layer"], c["topic"], c["difficulty"]])
    with open(d / "prerequisites.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["curriculum", "src", "dst", "weight"])
        for name, cur in curricula.items():
            for e in cur["prerequisites"]:
                w.writerow([name, e["src"], e["dst"], e["weight"]])
    with open(d / "learning_objects.csv", "w", newline="") as f:
        w = csv.writer(f)
        cols = ["lo", "primary", "secondary", "q_secondary", "bloom", "modality", "duration", "bandwidth",
                "quality", "difficulty", "discrimination"]
        w.writerow(["curriculum"] + cols + ["bloom_name"])
        for name, cur in curricula.items():
            for o in cur["los"]:
                w.writerow([name] + [o[k] for k in cols] + [BLOOM_NAMES[o["bloom"] - 1]])
    with open(d / "learners.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["split", "curriculum", "learner", "theta", "eta", "phi", "pref_video", "pref_text",
                    "pref_interactive", "pref_quiz", "bandwidth", "session_min", "n_sessions", "gap_days",
                    "goals", "prior_mean_mastery", "theta_hat", "eta_hat"])
        for split, items in plan.items():
            for it in items:
                with np.load(out / it["file"]) as z:
                    for u in range(it["n"]):
                        w.writerow([split, it["curriculum"], u, round(float(z["theta"][u]), 4),
                                    round(float(z["eta"][u]), 4), round(float(z["phi"][u]), 4),
                                    *[round(float(x), 4) for x in z["pref"][u]], BANDWIDTH[int(z["bw"][u])],
                                    int(z["Ts"][u]), int(z["n_sess"][u]), int(z["gap"][u]),
                                    " ".join(str(int(x)) for x in np.nonzero(z["goals"][u])[0]),
                                    round(float(z["m0"][u].mean()), 4), round(float(z["theta_hat"][u]), 4),
                                    round(float(z["eta_hat"][u]), 4)])
    # historical interaction logs for the training split
    rows = []
    for it in plan["train"]:
        with np.load(out / it["file"]) as z:
            Ld = {k: z[k] for k in z.files}
        dyn = Dynamics(Curriculum(curricula[it["curriculum"]]))
        recs = simulate_logs(dyn, learners_from_numpy(Ld, "true"), learners_from_numpy(Ld, "planner"),
                             seed=hash_str(it["curriculum"]))
        for r_ in recs:
            r_["curriculum"] = it["curriculum"]
        rows += recs
    with open(d / "interaction_logs.csv", "w", newline="") as f:
        cols = ["curriculum", "learner", "step", "lo", "concept", "bloom", "modality", "t_start", "duration",
                "session", "p_success", "correct", "dropped"]
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r_ in rows:
            w.writerow({k: r_[k] for k in cols})


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=str(Path(__file__).resolve().parents[2] / "data"))
    ap.add_argument("--small", action="store_true")
    a = ap.parse_args()
    main(Path(a.out), a.small)

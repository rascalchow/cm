"""Convert the LaTeX dissertation to Word (.docx).

pandoc converts LaTeX (including mathematics, as native Word equations) but does not understand
cleveref, natbib numbering, theorem numbering, algorithmic, TikZ, PDF figures or several layout
packages.  This script therefore writes a flattened, pandoc-friendly LaTeX file in which

* chapter/section numbers, theorem-like environments, figure/table captions and equation tags are
  numbered exactly as in the PDF (numbers taken from the LaTeX .aux files),
* \\cref/\\Cref/\\ref/\\eqref are resolved to text, and \\citep/\\citet to the numeric labels of the
  compiled bibliography (main.bbl), which is appended as a numbered reference list,
* user macros are expanded, PDF figures are converted to PNG and the TikZ diagram is rendered,
* algorithms and custom-labelled lists are rewritten as plain numbered text,

then runs pandoc and post-processes the result with python-docx (title page, page breaks before
chapters, table rules, centred figures, field update on opening).

Usage:  python3 latex_to_docx.py            (run after the PDF has been compiled)
"""
from __future__ import annotations

import re
import shutil
import subprocess
import sys
from pathlib import Path

DISS = Path(__file__).resolve().parents[2] / "dissertation"
BUILD = DISS / "docx_build"
PNG = BUILD / "png"

THM_ENVS = ["theorem", "proposition", "lemma", "corollary", "definition", "assumption", "example",
            "problem", "remark"]
TYPE_NAMES = {"theorem": ("Theorem", "Theorems"), "proposition": ("Proposition", "Propositions"),
              "lemma": ("Lemma", "Lemmas"), "corollary": ("Corollary", "Corollaries"),
              "definition": ("Definition", "Definitions"), "assumption": ("Assumption", "Assumptions"),
              "example": ("Example", "Examples"), "problem": ("Problem", "Problems"),
              "remark": ("Remark", "Remarks"), "chapter": ("Chapter", "Chapters"),
              "section": ("Section", "Sections"), "subsection": ("Section", "Sections"),
              "subsubsection": ("Section", "Sections"), "appendix": ("Appendix", "Appendices"),
              "figure": ("Figure", "Figures"), "table": ("Table", "Tables"),
              "equation": ("Equation", "Equations"), "algorithm": ("Algorithm", "Algorithms")}
CHAPTER_FILES = ["ch1_introduction", "ch2_literature", "ch3_model", "ch4_gnn", "ch5_data",
                 "ch6_experiments", "ch7_discussion", "ch8_conclusion"]
APPENDIX_FILES = ["appA_proofs", "appB_parameters", "appC_data", "appD_reproducibility"]


# ------------------------------------------------------------------------------ helpers
def read_group(s: str, i: int, open_c: str = "{", close_c: str = "}") -> tuple[str, int]:
    """Return (content, index after closing brace) of the balanced group starting at s[i]."""
    assert s[i] == open_c, (s[i:i + 40], open_c)
    depth, j = 0, i
    while j < len(s):
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == open_c:
            depth += 1
        elif c == close_c:
            depth -= 1
            if depth == 0:
                return s[i + 1:j], j + 1
        j += 1
    raise ValueError("unbalanced group at %d: %s" % (i, s[i:i + 60]))


def replace_command(s: str, name: str, fn, nargs: int = 1, optional: bool = False) -> str:
    """Replace every \\name[opt]{a1}...{an} by fn(opt, *args)."""
    pat = re.compile(r"\\" + re.escape(name) + r"(?![A-Za-z@])")
    out, pos = [], 0
    while True:
        m = pat.search(s, pos)
        if not m:
            out.append(s[pos:])
            return "".join(out)
        j = m.end()
        opt = None
        k = j
        while k < len(s) and s[k] in " \t":
            k += 1
        if optional and k < len(s) and s[k] == "[":
            opt, j = read_group(s, k, "[", "]")
        args = []
        ok = True
        for _ in range(nargs):
            while j < len(s) and s[j] in " \t\n":
                j += 1
            if j >= len(s) or s[j] != "{":
                ok = False
                break
            a, j = read_group(s, j)
            args.append(a)
        if not ok:
            out.append(s[pos:m.end()])
            pos = m.end()
            continue
        out.append(s[pos:m.start()])
        out.append(fn(opt, *args))
        pos = j


# ------------------------------------------------------------------------------ inputs
def load_labels() -> dict:
    labels = {}
    for f in list(DISS.glob("*.aux")) + list((DISS / "chapters").glob("*.aux")):
        for line in f.read_text(errors="ignore").splitlines():
            m = re.match(r"\\newlabel\{(.+?)@cref\}\{\{\[([a-z]+)\]\[[^\]]*\]\[[^\]]*\]([^}]*)\}", line)
            if m:
                labels.setdefault(m.group(1), {})["type"] = m.group(2)
                labels[m.group(1)]["cref_num"] = m.group(3)
                continue
            m = re.match(r"\\newlabel\{(.+?)\}\{\{([^}]*)\}", line)
            if m and not m.group(1).endswith("@cref"):
                labels.setdefault(m.group(1), {})["num"] = m.group(2)
    return labels


def load_bib() -> list[dict]:
    bbl = (DISS / "main.bbl").read_text()
    entries = []
    for block in re.split(r"\n\s*\n", bbl):
        block = block.strip()
        if not block.startswith("\\bibitem"):
            continue
        opt, j = read_group(block, len("\\bibitem"), "[", "]")
        key, j = read_group(block, j)
        short = re.sub(r"\(.*", "", opt, flags=re.S).replace("~", " ").replace("\n", " ").strip()
        text = block[j:].strip()
        entries.append(dict(key=key, short=short, text=text))
    return entries


def load_macros(main: str) -> dict:
    macros = {}
    for cmd in ("newcommand", "renewcommand"):
        for m in re.finditer(r"\\" + cmd + r"\{\\([A-Za-z0-9]+)\}(\[(\d)\])?", main):
            name = m.group(1)
            n = int(m.group(3)) if m.group(3) else 0
            body, _ = read_group(main, m.end())
            macros[name] = (n, body)
    for k in [k for k in macros if k.startswith("diss")]:
        del macros[k]
    macros["argmax"] = (0, r"\mathop{\mathrm{arg\,max}}")
    macros["argmin"] = (0, r"\mathop{\mathrm{arg\,min}}")
    macros["pahgnn"] = (0, "PA-HGNN")
    return macros


def expand_macros(s: str, macros: dict) -> str:
    names = sorted(macros, key=len, reverse=True)
    for _ in range(6):
        before = s
        for name in names:
            n, body = macros[name]
            # expansions are wrapped in braces so that accents and sub/superscripts apply to them
            wrap = "{%s}" if name not in ("pahgnn",) else "%s"
            if n == 0:
                s = re.sub(r"\\" + re.escape(name) + r"(?![A-Za-z])(\{\})?", lambda m: wrap % body, s)
            else:
                s = replace_command(s, name, lambda opt, *a, body=body: wrap % re.sub(
                    r"#(\d)", lambda mm: a[int(mm.group(1)) - 1], body), nargs=n)
        if s == before:
            break
    return s


# ------------------------------------------------------------------------------ transforms
class Converter:
    def __init__(self):
        self.labels = load_labels()
        self.bib = load_bib()
        self.bibnum = {e["key"]: i + 1 for i, e in enumerate(self.bib)}
        self.main = (DISS / "main.tex").read_text()
        self.macros = load_macros(self.main)
        self.chapter = None          # current chapter label ("3" or "A")
        self.sec = self.subsec = 0
        self.thm = 0
        self.app_index = 0
        self.ch_index = 0

    # ---- references and citations
    def num(self, key):
        lab = self.labels.get(key)
        if lab is None:
            print("WARNING: unknown label", key, file=sys.stderr)
            return "??"
        return lab.get("num", lab.get("cref_num", "??"))

    def cref(self, keys: str, capital=True) -> str:
        items = []
        for k in [k.strip() for k in keys.split(",") if k.strip()]:
            t = self.labels.get(k, {}).get("type", "section")
            n = self.num(k)
            if t == "equation":
                n = f"({n})"
            items.append((t, n))
        groups = []
        for t, n in items:
            if groups and groups[-1][0] == t:
                groups[-1][1].append(n)
            else:
                groups.append((t, [n]))
        parts = []
        for t, ns in groups:
            sing, plur = TYPE_NAMES.get(t, (t.capitalize(), t.capitalize() + "s"))
            if len(ns) == 1:
                parts.append(f"{sing}~{ns[0]}")
            else:
                parts.append(f"{plur} " + ", ".join(ns[:-1]) + " and " + ns[-1])
        if len(parts) == 1:
            return parts[0]
        return ", ".join(parts[:-1]) + " and " + parts[-1]

    def citep(self, keys: str) -> str:
        nums = sorted(self.bibnum[k.strip()] for k in keys.split(",") if k.strip())
        out, i = [], 0
        while i < len(nums):
            j = i
            while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1:
                j += 1
            if j - i >= 2:
                out.append(f"{nums[i]}--{nums[j]}")
            else:
                out.extend(str(x) for x in nums[i:j + 1])
            i = j + 1
        return "[" + ", ".join(out) + "]"

    def citet(self, keys: str) -> str:
        parts = []
        for k in [k.strip() for k in keys.split(",") if k.strip()]:
            e = self.bib[self.bibnum[k] - 1]
            parts.append(f"{e['short']} [{self.bibnum[k]}]")
        return ", ".join(parts)

    def refs_and_cites(self, s: str) -> str:
        s = replace_command(s, "Cref", lambda o, a: self.cref(a))
        s = replace_command(s, "cref", lambda o, a: self.cref(a))
        s = replace_command(s, "eqref", lambda o, a: f"({self.num(a)})")
        s = replace_command(s, "ref", lambda o, a: self.num(a))
        s = replace_command(s, "citep", lambda o, a: self.citep(a), optional=True)
        s = replace_command(s, "citet", lambda o, a: self.citet(a), optional=True)
        s = replace_command(s, "cite", lambda o, a: self.citep(a), optional=True)
        return s

    # ---- floats
    def floats(self, s: str) -> str:
        def fig(m):
            body = m.group(2)
            lab = re.search(r"\\label\{([^}]*)\}", body)
            n = self.num(lab.group(1)) if lab else ""
            if "tikzpicture" in body:
                body = re.sub(r"\\resizebox\{\\textwidth\}\{!\}\{%?\s*\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}\}",
                              r"\\includegraphics[width=6.3in]{architecture.png}", body, flags=re.S)
            body = replace_command(body, "caption", lambda o, c: "\\caption{" + f"Figure {n}: " + c + "}")
            body = re.sub(r"\\includegraphics\[width=([0-9.]*)\\textwidth\]\{([^}]*)\}",
                          lambda mm: "\\includegraphics[width=%.2fin]{%s}" % (
                              6.3 * float(mm.group(1) or 1), Path(mm.group(2)).stem + ".png"), body)
            body = re.sub(r"\\includegraphics\{([^}]*)\.pdf\}", lambda mm: "\\includegraphics[width=6.3in]{%s.png}"
                          % Path(mm.group(1)).stem, body)
            return "\\begin{figure}" + body + "\\end{figure}"
        s = re.sub(r"\\begin\{figure\}(\[[^\]]*\])?(.*?)\\end\{figure\}", fig, s, flags=re.S)

        def tab(m):
            body = m.group(2)
            lab = re.search(r"\\label\{([^}]*)\}", body)
            n = self.num(lab.group(1)) if lab else ""
            body = replace_command(body, "caption", lambda o, c: "\\caption{" + f"Table {n}: " + c + "}")
            return "\\begin{table}" + body + "\\end{table}"
        s = re.sub(r"\\begin\{table\}(\[[^\]]*\])?(.*?)\\end\{table\}", tab, s, flags=re.S)

        def alg(m):
            body = m.group(2)
            lab = re.search(r"\\label\{([^}]*)\}", body)
            n = self.num(lab.group(1)) if lab else ""
            cap = re.search(r"\\caption\{", body)
            caption, _ = read_group(body, cap.end() - 1)
            inner = re.search(r"\\begin\{algorithmic\}(\[\d\])?(.*?)\\end\{algorithmic\}", body, re.S).group(2)
            return f"\n\n\\noindent\\textbf{{Algorithm {n}:}} {caption}\n\n" + self.algorithmic(inner) + "\n\n"
        s = re.sub(r"\\begin\{algorithm\}(\[[^\]]*\])?(.*?)\\end\{algorithm\}", alg, s, flags=re.S)
        return s

    def algorithmic(self, body: str) -> str:
        lines, level, k = [], 0, 0
        body = re.sub(r"\\State\s*\\Return", r"\\Return", body)
        stmts = re.split(r"(?=\\(?:Require|Ensure|State|For|EndFor|While|EndWhile|If|ElsIf|Else|EndIf|Return)\b)", body)
        for st in stmts:
            st = st.strip()
            if not st:
                continue
            st = replace_command(st, "Comment", lambda o, c: r" \quad $\triangleright$ " + c)
            kw = re.match(r"\\(Require|Ensure|State|For|EndFor|While|EndWhile|If|ElsIf|Else|EndIf|Return)\b", st)
            if not kw:
                continue
            word, rest = kw.group(1), st[kw.end():].strip()
            arg = ""
            if word in ("For", "While", "If", "ElsIf") and rest.startswith("{"):
                arg, j = read_group(rest, 0)
                rest = rest[j:].strip()
            if word in ("EndFor", "EndWhile", "EndIf", "Else", "ElsIf"):
                level -= 1
            text = {"Require": r"\textbf{Require:} " + rest, "Ensure": r"\textbf{Ensure:} " + rest,
                    "State": rest, "For": rf"\textbf{{for}} {arg} \textbf{{do}} {rest}",
                    "EndFor": r"\textbf{end for}", "While": rf"\textbf{{while}} {arg} \textbf{{do}} {rest}",
                    "EndWhile": r"\textbf{end while}", "If": rf"\textbf{{if}} {arg} \textbf{{then}} {rest}",
                    "ElsIf": rf"\textbf{{else if}} {arg} \textbf{{then}}", "Else": r"\textbf{else}",
                    "EndIf": r"\textbf{end if}", "Return": r"\textbf{return} " + rest}[word]
            prefix = "" if word in ("Require", "Ensure") else f"{(k := k + 1)}: "
            lines.append(prefix + r"\quad" * (2 * max(level, 0)) + " " + text)
            if word in ("For", "While", "If", "ElsIf", "Else"):
                level += 1
        return "\\begin{quote}\n" + " \\\\\n".join(lines) + "\n\\end{quote}"

    # ---- lists with custom labels
    def labelled_lists(self, s: str) -> str:
        def conv(m):
            fmt, body = m.group(1), m.group(2)
            items = re.split(r"\\item\b", body)[1:]
            out = []
            for i, it in enumerate(items, 1):
                lab = fmt
                lab = lab.replace(r"\arabic*", str(i)).replace(r"\roman*", roman(i)).replace(
                    r"\alph*", "abcdefghijklmnopqrstuvwxyz"[i - 1]).replace(r"\Roman*", roman(i).upper())
                out.append(f"\n\n\\noindent {lab}\u2002" + it.strip())
            return "".join(out) + "\n\n"
        return re.sub(r"\\begin\{enumerate\}\[label=([^\],]*)[^\]]*\](.*?)\\end\{enumerate\}", conv, s, flags=re.S)

    # ---- headings and theorem-like environments
    def structure(self, s: str, appendix: bool) -> str:
        out, pos = [], 0
        pat = re.compile(r"\\(chapter|section|subsection)(\*?)\{|\\begin\{(" + "|".join(THM_ENVS + ["proof"]) +
                         r")\}(\[[^\]]*\])?|\\end\{(" + "|".join(THM_ENVS + ["proof"]) + r")\}")
        while True:
            m = pat.search(s, pos)
            if not m:
                out.append(s[pos:])
                break
            out.append(s[pos:m.start()])
            if m.group(1):
                kind, star = m.group(1), m.group(2)
                title, j = read_group(s, m.end() - 1)
                if star:
                    out.append(f"\\{kind}*{{{title}}}")
                elif kind == "chapter":
                    if appendix:
                        self.app_index += 1
                        self.chapter = "ABCDEFGH"[self.app_index - 1]
                        out.append(f"\\chapter*{{Appendix {self.chapter}\u2003{title}}}")
                    else:
                        self.ch_index += 1
                        self.chapter = str(self.ch_index)
                        out.append(f"\\chapter*{{Chapter {self.chapter}\u2003{title}}}")
                    self.sec = self.subsec = self.thm = 0
                elif kind == "section":
                    self.sec += 1
                    self.subsec = 0
                    out.append(f"\\section*{{{self.chapter}.{self.sec}\u2002{title}}}")
                else:
                    self.subsec += 1
                    out.append(f"\\subsection*{{{self.chapter}.{self.sec}.{self.subsec}\u2002{title}}}")
                pos = j
                continue
            if m.group(3):
                env, opt = m.group(3), m.group(4)
                if env == "proof":
                    out.append("\n\n\\textit{Proof.} ")
                else:
                    self.thm += 1
                    name = TYPE_NAMES[env][0]
                    tail = f" ({opt[1:-1]})" if opt else ""
                    out.append(f"\n\n\\noindent\\textbf{{{name} {self.chapter}.{self.thm}}}{tail}\\textbf{{.}} ")
                    # cross-check with the .aux numbering
                    lab = re.match(r"\s*\\label\{([^}]*)\}", s[m.end():])
                    if lab:
                        expected = self.num(lab.group(1))
                        if expected != f"{self.chapter}.{self.thm}":
                            print(f"WARNING: numbering mismatch {lab.group(1)}: {expected} vs "
                                  f"{self.chapter}.{self.thm}", file=sys.stderr)
                pos = m.end()
                continue
            env = m.group(5)
            out.append(" $\\square$\n\n" if env == "proof" else "\n\n")
            pos = m.end()
        return "".join(out)

    def equation_tags(self, s: str) -> str:
        def eq(m):
            body = m.group(1)
            lab = re.search(r"\\label\{([^}]*)\}", body)
            if lab:
                body = body.replace(lab.group(0), "").rstrip()
                body = body + r"\qquad (" + self.num(lab.group(1)) + ")"
            return "\\begin{equation*}" + body + "\n\\end{equation*}"
        return re.sub(r"\\begin\{equation\}(.*?)\\end\{equation\}", eq, s, flags=re.S)

    # ---- one chapter file
    def convert_file(self, name: str, appendix: bool = False) -> str:
        s = (DISS / "chapters" / f"{name}.tex").read_text()
        s = re.sub(r"(?<!\\)%.*", "", s)                              # comments
        s = re.sub(r"\\input\{(tables/[^}]*)\}", lambda m: (DISS / m.group(1)).read_text(), s)
        s = expand_macros(s, self.macros)
        s = s.replace(r"\bm{", r"\boldsymbol{").replace(r"\dot\cup", r"\dot{\cup}")
        # delimiter sizing is dropped: plain delimiters render identically in Word and robustly elsewhere
        s = re.sub(r"\\[Bb]igg?m?\|", r"\\mid ", s)            # sized conditional bars
        s = re.sub(r"\\[Bb]igg?[lr]?(?![A-Za-z])", "", s)
        s = re.sub(r"\\(left|right)\.", "", s)
        s = re.sub(r"\\(left|right)(?![A-Za-z])", "", s)
        s = self.floats(s)
        s = self.structure(s, appendix)
        s = self.equation_tags(s)
        s = self.refs_and_cites(s)
        s = self.labelled_lists(s)
        s = re.sub(r"\\label\{[^}]*\}", "", s)
        s = replace_command(s, "num", lambda o, a: f"{int(a):,}" if a.isdigit() else a)
        s = s.replace("{,}", ",").replace(r"\allowbreak", "")
        s = replace_command(s, "multirow", lambda o, a, b, c: c, nargs=3)
        s = re.sub(r"\\resizebox\{\\textwidth\}\{!\}\{", r"{", s)
        s = re.sub(r"\\begin\{adjustbox\}\{[^}]*\}|\\end\{adjustbox\}", "", s)
        s = re.sub(r"\\\\\[\d+pt\]", r"\\\\", s)
        s = re.sub(r">\{\\raggedright\\arraybackslash\}", "", s)
        s = re.sub(r"\\begin\{(itemize|description)\}\[[^\]]*\]", r"\\begin{\1}", s)
        s = replace_command(s, "paragraph", lambda o, t: "\n\n\\noindent\\textbf{" + t + "} ")
        s = s.replace("{\\footnotesize\n\\begin{verbatim}", "\\begin{verbatim}").replace(
            "\\end{verbatim}\n}", "\\end{verbatim}")
        for cmd in ["addcontentsline", "markboth"]:
            s = replace_command(s, cmd, lambda o, *a: "", nargs=3 if cmd == "addcontentsline" else 2)
        s = re.sub(r"\\(cleardoublepage|phantomsection|centering|small|scriptsize|footnotesize|"
                   r"noindent)(?![A-Za-z])", lambda m: "\\noindent" if m.group(1) == "noindent" else "", s)
        return s

    def bibliography(self) -> str:
        out = ["\\chapter*{Bibliography}\n"]
        for i, e in enumerate(self.bib, 1):
            t = e["text"]
            t = t.replace("\\newblock", " ").replace("\\penalty0", "")
            t = replace_command(t, "natexlab", lambda o, a: a)
            t = replace_command(t, "doi", lambda o, a: f"doi:\\href{{https://doi.org/{a}}}{{{a}}}")
            t = re.sub(r"URL\s*\\url\{[^}]*\}\.?", "", t)
            t = re.sub(r"\s+", " ", t).strip()
            out.append(f"{{[}}{i}{{]}}\u2002{t}\n")
        return "\n".join(out)

    def build(self) -> str:
        parts = []
        for name in ["abstract", "notation"]:
            parts.append(self.convert_file(name))
        for name in CHAPTER_FILES:
            parts.append(self.convert_file(name))
        parts.append(self.bibliography())
        for name in APPENDIX_FILES:
            parts.append(self.convert_file(name, appendix=True))
        body = "\n\n".join(parts)
        return "\\documentclass{report}\n\\usepackage{amsmath,amssymb}\n\\begin{document}\n" + body + \
            "\n\\end{document}\n"


def roman(n: int) -> str:
    vals = [(10, "x"), (9, "ix"), (5, "v"), (4, "iv"), (1, "i")]
    out = ""
    for v, r in vals:
        while n >= v:
            out += r
            n -= v
    return out


# ------------------------------------------------------------------------------ figures
def render_figures():
    PNG.mkdir(parents=True, exist_ok=True)
    for pdf in (DISS / "figures").glob("*.pdf"):
        subprocess.run(["pdftoppm", "-png", "-r", "220", "-singlefile", str(pdf), str(PNG / pdf.stem)], check=True)
    # TikZ architecture diagram as a standalone document
    ch4 = (DISS / "chapters" / "ch4_gnn.tex").read_text()
    tikz = re.search(r"\\begin\{tikzpicture\}.*?\\end\{tikzpicture\}", ch4, re.S).group(0)
    tikz = tikz.replace(r"(\cref{ch:model})", "(Chapter 3)")
    main = (DISS / "main.tex").read_text()
    macros = "\n".join(l for l in main.splitlines() if l.startswith(("\\newcommand", "\\renewcommand",
                                                                       "\\DeclareMathOperator"))
                       and "headrulewidth" not in l and "\\diss" not in l)
    doc = ("\\documentclass[border=4pt]{standalone}\n\\usepackage{amsmath,amssymb,bm,lmodern}\n"
           "\\usepackage[T1]{fontenc}\n\\usepackage{tikz}\n"
           "\\usetikzlibrary{arrows.meta,positioning,fit,calc,shapes.geometric}\n" + macros +
           "\n\\begin{document}\n" + tikz + "\n\\end{document}\n")
    (BUILD / "architecture.tex").write_text(doc)
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "architecture.tex"], cwd=BUILD, check=True,
                   stdout=subprocess.DEVNULL)
    subprocess.run(["pdftoppm", "-png", "-r", "250", "-singlefile", "architecture.pdf", str(PNG / "architecture")],
                   cwd=BUILD, check=True)


# ------------------------------------------------------------------------------ reference document
def reference_doc() -> Path:
    from docx import Document
    from docx.shared import Pt, RGBColor
    ref = BUILD / "reference.docx"
    with open(ref, "wb") as f:
        f.write(subprocess.run(["pandoc", "--print-default-data-file", "reference.docx"],
                               check=True, capture_output=True).stdout)
    d = Document(ref)
    st = {s.name: s for s in d.styles}
    for name in ["Normal", "Body Text", "First Paragraph", "Compact", "Block Text", "Author", "Date",
                 "Definition Term", "Definition", "Bibliography"]:
        if name in st:
            s = st[name]
            s.font.name = "Times New Roman"
            s.font.size = Pt(12) if name not in ("Author", "Date") else Pt(13)
            pf = s.paragraph_format
            pf.line_spacing = 1.3
            pf.space_after = Pt(6)
    for name, size in [("Heading 1", 20), ("Heading 2", 15), ("Heading 3", 13), ("Heading 4", 12),
                       ("Title", 22), ("Subtitle", 13), ("TOC Heading", 20)]:
        s = st[name]
        s.font.name = "Times New Roman"
        s.font.size = Pt(size)
        s.font.bold = name not in ("Subtitle",)
        s.font.color.rgb = RGBColor(0, 0, 0)
    from docx.oxml.ns import qn as _qn
    for style in d.styles:                       # explicit fonts must not be overridden by theme fonts
        rpr = style.element.find(_qn("w:rPr"))
        if rpr is None:
            continue
        rf = rpr.find(_qn("w:rFonts"))
        if rf is not None:
            for att in ("w:asciiTheme", "w:hAnsiTheme", "w:eastAsiaTheme", "w:cstheme"):
                rf.attrib.pop(_qn(att), None)
    st["Heading 1"].paragraph_format.page_break_before = True
    st["Heading 1"].paragraph_format.space_after = Pt(18)
    for name in ["Image Caption", "Table Caption", "Caption"]:
        if name in st:
            st[name].font.size = Pt(10.5)
            st[name].font.italic = False
            st[name].font.name = "Times New Roman"
    d.save(ref)
    return ref


# ------------------------------------------------------------------------------ post-processing
TBLPR_ORDER = ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize", "tblStyleColBandSize",
               "tblW", "jc", "tblCellSpacing", "tblInd", "tblBorders", "shd", "tblLayout", "tblCellMar", "tblLook",
               "tblCaption", "tblDescription"]
TCPR_ORDER = ["cnfStyle", "tcW", "gridSpan", "hMerge", "vMerge", "tcBorders", "shd", "noWrap", "tcMar",
              "textDirection", "tcFitText", "vAlign", "hideMark"]
SETTINGS_AFTER_UPDATEFIELDS = ["hdrShapeDefaults", "footnotePr", "endnotePr", "compat", "docVars", "rsids", "mathPr",
                               "attachedSchema", "themeFontLang", "clrSchemeMapping", "doNotIncludeSubdocsInStats",
                               "doNotAutoCompressPictures", "forceUpgrade", "captions", "readModeInkLockDown",
                               "smartTagType", "schemaLibrary", "shapeDefaults", "doNotEmbedSmartTags",
                               "decimalSymbol", "listSeparator"]


def insert_ordered(parent, child, order):
    """Insert ``child`` into ``parent`` respecting the schema order of child elements (replacing a duplicate)."""
    local = child.tag.split("}")[1]
    for old in parent.findall(child.tag):
        parent.remove(old)
    later = order[order.index(local) + 1:]
    for i, el in enumerate(parent):
        if el.tag.split("}")[-1] in later:
            parent.insert(i, child)
            return
    parent.append(child)


def postprocess(path: Path):
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    d = Document(path)
    # title page: centre title block, add department/university/advisor, page break
    paras = d.paragraphs
    date_p = next(p for p in paras if p.style.name == "Date")
    for p in paras[:paras.index(date_p) + 1]:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    author_p = next(p for p in paras if p.style.name == "Author")
    extra = ["Department of Mathematics", "[University Name]", "Advisor: [Advisor's Name]"]
    anchor = author_p
    for text in extra:
        new = OxmlElement("w:p")
        anchor._p.addnext(new)
        from docx.text.paragraph import Paragraph
        np_ = Paragraph(new, anchor._parent)
        np_.style = {s.name: s for s in d.styles}["Author"]
        np_.alignment = WD_ALIGN_PARAGRAPH.CENTER
        np_.add_run(text)
        anchor = np_
    date_p.add_run().add_break(WD_BREAK.PAGE)
    # centre figures and captions
    for p in d.paragraphs:
        if p.style.name in ("Captioned Figure", "Image Caption", "Table Caption") or p._p.xpath(".//w:drawing"):
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    # tables: booktabs-like rules (top, below header, bottom), centred
    for t in d.tables:
        tbl = t._tbl
        tblPr = tbl.tblPr
        borders = OxmlElement("w:tblBorders")
        for edge, val in [("top", "single"), ("bottom", "single")]:
            el = OxmlElement(f"w:{edge}")
            el.set(qn("w:val"), val)
            el.set(qn("w:sz"), "8")
            el.set(qn("w:color"), "000000")
            borders.append(el)
        insert_ordered(tblPr, borders, TBLPR_ORDER)
        jc = OxmlElement("w:jc")
        jc.set(qn("w:val"), "center")
        insert_ordered(tblPr, jc, TBLPR_ORDER)
        if t.rows:
            for cell in t.rows[0].cells:
                tcPr = cell._tc.get_or_add_tcPr()
                tcb = OxmlElement("w:tcBorders")
                b = OxmlElement("w:bottom")
                b.set(qn("w:val"), "single")
                b.set(qn("w:sz"), "6")
                b.set(qn("w:color"), "000000")
                tcb.append(b)
                insert_ordered(tcPr, tcb, TCPR_ORDER)
        for row in t.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    for r in p.runs:
                        r.font.size = __import__("docx").shared.Pt(9.5)
    # page numbers in the footer (none on the title page)
    sec = d.sections[0]
    sec.different_first_page_header_footer = True
    fp = sec.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for kind, text in [("begin", None), (None, "PAGE"), ("separate", None), (None, "1"), ("end", None)]:
        r = fp.add_run()
        if kind:
            fc = OxmlElement("w:fldChar")
            fc.set(qn("w:fldCharType"), kind)
            r._r.append(fc)
        elif text == "PAGE":
            it = OxmlElement("w:instrText")
            it.set(qn("xml:space"), "preserve")
            it.text = " PAGE "
            r._r.append(it)
        else:
            r.text = text
    # ask Word to update the table of contents when the file is opened
    settings = d.settings.element
    upd = OxmlElement("w:updateFields")
    upd.set(qn("w:val"), "true")
    insert_ordered(settings, upd, ["updateFields"] + SETTINGS_AFTER_UPDATEFIELDS)
    d.save(path)


# ------------------------------------------------------------------------------ table of contents
def toc_entries(d):
    out = []
    for p in d.paragraphs:
        lvl = {"Heading 1": 1, "Heading 2": 2}.get(p.style.name)
        if lvl is None or not p.text.strip():
            continue
        bm = p._p.xpath(".//w:bookmarkStart")      # python-docx element: namespaces are known
        out.append((lvl, p.text.strip(), bm[0].get(qn_("w:name")) if bm else None))
    return out


def qn_(tag):
    from docx.oxml.ns import qn
    return qn(tag)


def fill_toc(path: Path, pages: list[str] | None):
    """Write the TOC field result: one entry per chapter/section with a dot leader and page number."""
    from docx import Document
    from docx.oxml import OxmlElement
    d = Document(path)
    entries = toc_entries(d)
    body = d.element.body
    def has_toc(e):
        return any(it.text and "TOC" in it.text for it in e.iter(qn_("w:instrText")))
    sdt = next(e for e in body.iter(qn_("w:sdt")) if has_toc(e))
    content = sdt.find(qn_("w:sdtContent"))
    field_p = next(p for p in content.findall(qn_("w:p")) if has_toc(p))
    end = next(fc for fc in field_p.iter(qn_("w:fldChar"))
               if fc.get(qn_("w:fldCharType")) == "end").getparent()                  # run with the end mark
    end.getparent().remove(end)
    anchor = field_p
    for i, (lvl, text, bm) in enumerate(entries):
        p = OxmlElement("w:p")
        ppr = OxmlElement("w:pPr")
        tabs = OxmlElement("w:tabs")
        tab = OxmlElement("w:tab")
        tab.set(qn_("w:val"), "right")
        tab.set(qn_("w:leader"), "dot")
        tab.set(qn_("w:pos"), "9350")
        tabs.append(tab)
        ppr.append(tabs)
        sp = OxmlElement("w:spacing")
        sp.set(qn_("w:before"), "120" if lvl == 1 else "0")
        sp.set(qn_("w:after"), "40")
        ppr.append(sp)
        ind = OxmlElement("w:ind")
        ind.set(qn_("w:left"), "0" if lvl == 1 else "440")
        ppr.append(ind)
        p.append(ppr)
        holder = OxmlElement("w:hyperlink")
        if bm:
            holder.set(qn_("w:anchor"), bm)
        for kind, val in [("t", text), ("tab", None), ("t", pages[i] if pages else "888")]:
            r = OxmlElement("w:r")
            rpr = OxmlElement("w:rPr")
            if lvl == 1:
                rpr.append(OxmlElement("w:b"))
            r.append(rpr)
            el = OxmlElement("w:" + kind)
            if val is not None:
                el.text = val
                el.set(qn_("xml:space"), "preserve")
            r.append(el)
            holder.append(r)
        p.append(holder)
        anchor.addnext(p)
        anchor = p
    endp = OxmlElement("w:p")
    endp.append(end)
    anchor.addnext(endp)
    d.save(path)


def render_pdf(docx_path: Path) -> Path:
    tool = Path("/root/.claude/skills/synced/d284741e-fae9-4860-9c51-f4d2d3d81670_1ac45412-1ca2-493b-8058-9a6560e40d73"
                "/docx/scripts/office/soffice.py")
    work = BUILD / "render"
    work.mkdir(exist_ok=True)
    tmp = work / "render.docx"
    shutil.copy(docx_path, tmp)
    cmd = (["python3", str(tool)] if tool.exists() else ["soffice"]) + ["--headless", "--convert-to", "pdf", "render.docx"]
    subprocess.run(cmd, cwd=work, check=True, capture_output=True)
    return work / "render.pdf"


def toc_pages(docx_path: Path) -> list[str]:
    from docx import Document
    entries = toc_entries(Document(docx_path))
    pdf = render_pdf(docx_path)
    n = int(re.search(r"Pages:\s+(\d+)", subprocess.run(["pdfinfo", str(pdf)], capture_output=True,
                                                          text=True).stdout).group(1))
    norm = lambda t: re.sub(r"\s+", " ", t.replace("\u2003", " ").replace("\u2002", " ")).strip().lower()
    texts = [norm(subprocess.run(["pdftotext", "-f", str(i), "-l", str(i), str(pdf), "-"], capture_output=True,
                                 text=True).stdout) for i in range(1, n + 1)]
    pages, cur = [], 1
    for _, text, _ in entries:
        key = norm(text)[:45]
        found = None
        for i in range(cur, n + 1):
            if texts[i - 1].count("888") >= 3:          # skip the table of contents itself
                continue
            if key in texts[i - 1]:
                found = i
                break
        if found is None:
            print("WARNING: TOC entry not found:", text, file=sys.stderr)
            pages.append("")
            continue
        pages.append(str(found))
        cur = found
    return pages


def main():
    if BUILD.exists():
        shutil.rmtree(BUILD)
    BUILD.mkdir(parents=True)
    render_figures()
    conv = Converter()
    flat = conv.build()
    (BUILD / "flat.tex").write_text(flat)
    ref = reference_doc()
    out = DISS / "main.docx"
    title = "A Study on the Mathematical Modeling of Automated Learning Path Generation Using Graph Neural Networks"
    cmd = ["pandoc", str(BUILD / "flat.tex"), "-f", "latex", "-t", "docx", "-o", str(out),
           "--reference-doc", str(ref), "--resource-path", f"{PNG}:{BUILD}", "--toc", "--toc-depth=2",
           "--top-level-division=chapter",
           "-M", f"title={title}",
           "-M", "subtitle=A Dissertation Submitted in Partial Fulfilment of the Requirements for the Degree of "
                 "Doctor of Philosophy",
           "-M", "author=[Candidate's Full Name]", "-M", "date=October 2026", "-M", "toc-title=Contents"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stderr)
        sys.exit(1)
    if r.stderr.strip():
        print("pandoc warnings:\n" + r.stderr[:4000])
    postprocess(out)
    fill_toc(out, None)                       # placeholder page numbers reserve the space
    pages = toc_pages(out)
    pristine = BUILD / "pandoc_out.docx"
    r = subprocess.run(cmd[:cmd.index("-o") + 1] + [str(pristine)] + cmd[cmd.index("-o") + 2:], capture_output=True)
    postprocess(pristine)
    fill_toc(pristine, pages)
    shutil.copy(pristine, out)
    print("written", out)


if __name__ == "__main__":
    main()

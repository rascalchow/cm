"""Illustration of the component functions of the learning dynamics (Chapter 3 figure)."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg import plotstyle as ps
from lpg.dynamics import DynamicsParams
from lpg.synth import BLOOM_CEIL, BLOOM_ENTRY
import matplotlib.pyplot as plt

FIG = Path(__file__).resolve().parents[2] / "dissertation" / "figures"


def sig(x):
    return 1 / (1 + np.exp(-x))


def main():
    ps.setup()
    p = DynamicsParams()
    fig, axs = plt.subplots(1, 4, figsize=(6.7, 1.95))
    m = np.linspace(0, 1, 300)
    # (a) readiness for one prerequisite with weight w
    ax = axs[0]
    for k, w in enumerate([1.0, 0.6]):
        ax.plot(m, sig(p.gamma_ready * (m - p.tau_ready)) ** w, color=ps.SERIES[k], label=f"$w={w}$")
    ax.axvline(p.tau_pre, color=ps.GRAY, lw=0.8, ls="--")
    ax.set_xlabel("prerequisite mastery $m_i$")
    ax.set_title("(a) readiness $R_c$")
    ax.legend(fontsize=6.5)
    # (b) ZPD factor as a function of current mastery for LOs of Bloom levels 1..5 (average learner)
    ax = axs[1]
    for b in range(1, 6):
        bdiff = 3.0 * BLOOM_ENTRY[b - 1] + 0.4 * 0.5 - 0.7
        prob = p.guess + (1 - p.guess) * sig(1.5 * (p.lambda_m * m - bdiff))
        z = np.exp(-(prob - p.p_star) ** 2 / (2 * p.sigma_z ** 2))
        ax.plot(m, z, color=ps.SERIES[b - 1], label=f"{b}")
    ax.set_xlabel("concept mastery $m_c$")
    ax.set_title("(b) ZPD factor $Z(p_l)$")
    # (c) expected gain towards the ceiling (alpha R Z = 1 vs 0.5)
    ax = axs[2]
    for b in range(1, 6):
        bdiff = 3.0 * BLOOM_ENTRY[b - 1] + 0.4 * 0.5 - 0.7
        prob = p.guess + (1 - p.guess) * sig(1.5 * (p.lambda_m * m - bdiff))
        z = np.exp(-(prob - p.p_star) ** 2 / (2 * p.sigma_z ** 2))
        ax.plot(m, 0.73 * z * np.clip(BLOOM_CEIL[b - 1] - m, 0, None), color=ps.SERIES[b - 1], label=f"{b}")
    ax.set_xlabel("concept mastery $m_c$")
    ax.set_title("(c) gain $\\Delta_{lc}$ ($\\eta\\rho=0.73$)")
    ax.legend(title="Bloom level", fontsize=6, title_fontsize=6, loc="upper right", handlelength=1)
    # (d) forgetting of newly learned mastery over days for exposures n
    ax = axs[3]
    days = np.linspace(0, 14, 200)
    for k, n in enumerate([1, 3, 6]):
        ax.plot(days, np.exp(-0.05 * days / (1 + p.stability_gain * n)), color=ps.SERIES[k], label=f"$n_c={n}$")
    ax.set_xlabel("days since study")
    ax.set_title("(d) retained share")
    ax.set_ylim(0.6, 1.01)
    ax.legend(fontsize=6.5)
    fig.tight_layout()
    fig.savefig(FIG / "model_components.pdf")
    plt.close(fig)


if __name__ == "__main__":
    main()

"""Evaluate path generators on a dataset split.

Usage:  python run_eval.py --split test_ood --methods random static kg_rule greedy beam8 ga ga_mc gnn:full

Per-learner metrics are written to results/eval/<split>/<method>.npz; runtimes are the amortised
wall-clock seconds per learner for generating the paths (batched over each curriculum).
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from multiprocessing import Pool
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.data import load_split, RESULTS, manifest
from lpg import baselines as bl
from lpg.dynamics import expected_objective, DynamicsParams, Dynamics
from lpg.evaluate import evaluate_paths
from lpg.model import PathPolicy, generate
from train_model import VARIANTS


def load_policy(name: str) -> PathPolicy:
    log = json.loads((RESULTS / "models" / f"{name.split('@')[0]}_log.json").read_text())
    variant = log[0]["meta"]["variant"]
    pol = PathPolicy(**VARIANTS[variant])
    file = name.replace("@", "_")       # "full@bc" -> full_bc.pt
    pol.load_state_dict(torch.load(RESULTS / "models" / f"{file}.pt"))
    pol.eval()
    return pol


def gen_paths(method: str, inst, Lp, seed: int):
    dyn = inst.dyn
    if method == "random":
        return bl.random_paths(dyn, Lp, seed)
    if method == "static":
        return bl.static_paths(dyn, Lp)
    if method == "kg_rule":
        return bl.kg_rule_paths(dyn, Lp)
    if method == "greedy":
        return bl.greedy_paths(dyn, Lp)
    if method == "beam8":
        return bl.beam_paths(dyn, Lp, 8)
    if method == "ga":
        return bl.ga_paths(dyn, Lp, seed=seed)
    if method == "ga_mc":
        return bl.ga_paths(dyn, Lp, mc_samples=4, seed=seed)
    if method == "ga_mcc":
        return bl.ga_paths(dyn, Lp, mc_samples=4, seed=seed, crn=True)
    if method == "ga_mcr":
        return bl.ga_paths(dyn, Lp, mc_samples=4, seed=seed, robust=True, crn=True)
    kind, name = method.split(":")
    pol = load_policy(name)
    with torch.no_grad():
        if kind == "gnn":
            return generate(pol, dyn, Lp, inst.gs, greedy=True)[0]
        if kind.startswith("gnn_s"):
            # sample k paths, add the greedy path, keep the best by the Monte Carlo objective
            # (the k + 1 candidates of a learner are compared with common random numbers)
            robust = kind.endswith("r")
            k = int(kind[5:].rstrip("r"))
            torch.manual_seed(seed)
            Lr = Lp.repeat(k)
            sampled = []
            for j in range(0, Lr.B, 256):
                idx = torch.arange(j, min(Lr.B, j + 256))
                sampled += generate(pol, dyn, Lr.index(idx), inst.gs)[0]
            greedy = generate(pol, dyn, Lp, inst.gs, greedy=True)[0]
            cands = [sampled[i * k:(i + 1) * k] + [greedy[i]] for i in range(Lp.B)]
            flat = [p for c in cands for p in c]
            R = expected_objective(dyn, Lp.repeat(k + 1), flat, 8, robust=robust, crn_group=k + 1).reshape(Lp.B, k + 1)
            best = R.argmax(1)
            return [cands[i][int(best[i])] for i in range(Lp.B)]
    raise ValueError(method)


def job(args):
    """Evaluate one method on the instances ``which`` (None = all) of one split; returns raw records."""
    split, method, threads, reps, params_kw, true_kw, tag_suffix, which = args
    torch.set_num_threads(threads)
    params = DynamicsParams(**params_kw) if params_kw else None
    insts = load_split(split, params)
    out_split = split + tag_suffix
    recs = {}
    for ii, inst in enumerate(insts):
        if which is not None and ii not in which:
            continue
        Lp = inst.batch(np.arange(inst.n), "planner")
        Lt = inst.batch(np.arange(inst.n), "true")
        t0 = time.time()
        paths = gen_paths(method, inst, Lp, seed=ii)
        dt = time.time() - t0
        dyn_true = Dynamics(inst.cur, DynamicsParams(**{**(params_kw or {}), **true_kw})) if true_kw else None
        r = evaluate_paths(inst.dyn, Lp, Lt, paths, reps=reps, seed=1000 + ii, dyn_true=dyn_true)
        r["instance"] = np.full(inst.n, ii)
        r["learner"] = np.arange(inst.n)
        r["bw"] = inst.L["bw"]
        r["theta"] = inst.L["theta"]
        r["prior"] = inst.L["m0"].mean(1)
        r["n_goals"] = inst.L["goals"].sum(1)
        r["runtime"] = np.full(inst.n, dt / inst.n)
        for k, v in r.items():
            recs.setdefault(k, []).append(np.asarray(v))
        if ii == 0:
            (RESULTS / "eval" / out_split / "paths").mkdir(parents=True, exist_ok=True)
            (RESULTS / "eval" / out_split / "paths" / f"{method.replace(':', '_')}.json").write_text(json.dumps(paths))
    return out_split, method, recs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--splits", nargs="+", required=True)
    ap.add_argument("--methods", nargs="+", required=True)
    ap.add_argument("--procs", type=int, default=4)
    ap.add_argument("--threads", type=int, default=3)
    ap.add_argument("--reps", type=int, default=32)
    ap.add_argument("--params", default="", help="JSON dict of DynamicsParams overrides (planner and true model)")
    ap.add_argument("--true_params", default="", help="JSON dict of overrides for the TRUE model only (misspecification)")
    ap.add_argument("--suffix", default="", help="suffix appended to the split name for output")
    ap.add_argument("--per_instance", action="store_true", help="parallelise over curricula as well as methods")
    a = ap.parse_args()
    for s in a.splits:
        (RESULTS / "eval" / (s + a.suffix)).mkdir(parents=True, exist_ok=True)
    pk = json.loads(a.params) if a.params else {}
    tk = json.loads(a.true_params) if a.true_params else {}
    jobs = []
    for s in a.splits:
        n_inst = len(manifest()["splits"][s])
        groups = [[i] for i in range(n_inst)] if a.per_instance else [None]
        for m in a.methods:
            for g in groups:
                jobs.append((s, m, a.threads, a.reps, pk, tk, a.suffix, g))
    pending = {}
    with Pool(a.procs) as pool:
        for out_split, method, recs in pool.imap_unordered(job, jobs):
            key = (out_split, method)
            for k, v in recs.items():
                pending.setdefault(key, {}).setdefault(k, []).extend(v)
            n_expected = len(manifest()["splits"][out_split[:len(out_split) - len(a.suffix)] if a.suffix else out_split])
            got = pending[key]
            if len(got.get("instance", [])) == n_expected:
                order = np.argsort([int(x[0]) for x in got["instance"]], kind="stable")
                out = {k: np.concatenate([v[i] for i in order]) for k, v in got.items()}
                np.savez(RESULTS / "eval" / out_split / f"{method.replace(':', '_')}.npz", **out)
                rt = float((out["runtime"]).mean())
                print(f"{out_split:12s} {method:22s} psi_true={out['psi'].mean():.4f} J_mc={out['J_mc'].mean():.4f} "
                      f"runtime/learner={rt:.3f}s", flush=True)


if __name__ == "__main__":
    main()

"""Numerical illustration of Theorem 3 (submodularity / greedy guarantee) and Propositions on
prerequisite-induced supermodularity, on small instances solved exactly by enumeration.

Regime A (Assumption "prerequisite-free"): no prerequisites, Z = 1, all ceilings 1, no forgetting,
no dropout, unit durations, no cognitive-load limit.
Regime B: the same instances with a random prerequisite DAG over the concepts (hard rule P1 active).

For every instance: exact optimum by enumerating all feasible sequences of length <= budget,
goal-greedy and relevance-shaped greedy, plus checks of order-independence and submodularity.
Writes results/theory_check.json and dissertation/tables/theory_check.tex.
"""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.dynamics import Curriculum, Dynamics, DynamicsParams, Learners
from lpg.baselines import relevance_weights

ROOT = Path(__file__).resolve().parents[2]


def make_instance(rng, K=6, N=10, prereq=False):
    layer = np.sort(rng.integers(0, 3, K))
    layer[0] = 0
    edges = []
    if prereq:
        for c in range(K):
            lower = [i for i in range(K) if layer[i] < layer[c]]
            if lower:
                k = min(len(lower), 1 + rng.binomial(1, 0.4))
                for p in rng.choice(lower, k, replace=False):
                    edges.append((int(p), c))
    import networkx as nx
    G = nx.DiGraph()
    G.add_nodes_from(range(K))
    G.add_edges_from(edges)
    G = nx.transitive_reduction(G) if edges else G
    closure = []
    for j in range(K):
        for i, d in nx.single_source_shortest_path_length(G.reverse(copy=False), j).items():
            if i != j:
                closure.append(dict(src=i, dst=j, distance=d))
    prim = np.concatenate([np.arange(K), rng.integers(0, K, N - K)])
    los = []
    for l in range(N):
        los.append(dict(lo=l, primary=int(prim[l]), secondary=-1, q_secondary=0.0, bloom=6, modality="text",
                        duration=1.0, bandwidth="low", quality=float(rng.uniform(0.3, 0.9)), difficulty=0.0,
                        discrimination=1.0))
    cur = dict(name="toy", concepts=[dict(concept=c, layer=int(layer[c]), topic=0, difficulty=0.0) for c in range(K)],
               prerequisites=[dict(src=int(i), dst=int(j), weight=1.0) for i, j in G.edges()],
               closure=closure, los=los)
    deep = [c for c in range(K) if layer[c] == layer.max()]
    goals = np.zeros(K)
    goals[rng.choice(deep, min(2, len(deep)), replace=False)] = 1
    return cur, goals


def learner(K, goals, budget, m0):
    f = lambda x: torch.tensor([x], dtype=torch.float32)
    g = torch.tensor(goals, dtype=torch.float32)[None]
    return Learners(theta=f(0.0), eta=f(1.0), phi=f(0.0), pref=torch.ones(1, 4) / 4, bw=torch.tensor([2]),
                    Ts=f(1e6), T=f(float(budget)), gap=f(1.0), m0=torch.tensor(m0, dtype=torch.float32)[None],
                    goals=g / g.sum())


PARAMS = DynamicsParams(sigma_z=1e6, h0=0.0, max_new_per_session=10 ** 6, gamma_ready=12.0)


def all_paths(dyn, L, budget):
    """Enumerate all feasible sequences breadth-first, batched over prefixes; returns {path: J}."""
    s = dyn.init_state(L)
    paths = [()]
    out = {(): float(s.J[0])}
    for _ in range(budget):
        Lr = L.repeat(len(paths))
        mk = dyn.mask(s, Lr)
        rows, acts = torch.nonzero(mk, as_tuple=True)
        if len(rows) == 0:
            break
        s = s.index(rows)
        s, _ = dyn.step(s, L.repeat(len(rows)), acts)
        paths = [paths[r] + (int(a),) for r, a in zip(rows.tolist(), acts.tolist())]
        for p_, j in zip(paths, s.J.tolist()):
            out[p_] = j
    return out


def greedy(dyn, L, budget, w=None):
    s = dyn.init_state(L)
    path = []
    for _ in range(budget):
        mk = dyn.mask(s, L)[0]
        if not mk.any():
            break
        dm, p, h = dyn.gains_all(s, L)
        ww = L.goals if w is None else w
        sc = (dm[0] * ww[0][None, :]).sum(-1)
        sc[~mk] = -1e9
        a = int(sc.argmax())
        path.append(a)
        s, _ = dyn.step(s, L, torch.tensor([a]))
    return path, float(s.J[0])


def run(regime, n_inst=150, K=6, N=10, budget=4, seed=0):
    rng = np.random.default_rng(seed)
    ratios_g, ratios_r, order_dev, sub_viol, sub_tot = [], [], [], 0, 0
    for _ in range(n_inst):
        cur, goals = make_instance(rng, K, N, prereq=(regime == "B"))
        m0 = rng.uniform(0, 0.2, K)
        dyn = Dynamics(Curriculum(cur), PARAMS)
        L = learner(K, goals, budget, m0)
        vals = all_paths(dyn, L, budget)
        psi0 = vals[()]
        opt = max(vals.values())
        if opt - psi0 < 1e-9:
            continue
        _, jg = greedy(dyn, L, budget)
        _, jr = greedy(dyn, L, budget, relevance_weights(dyn, L))
        ratios_g.append((jg - psi0) / (opt - psi0))
        ratios_r.append((jr - psi0) / (opt - psi0))
        # order independence and submodularity over the feasible sets
        by_set = {}
        for p, v in vals.items():
            by_set.setdefault(frozenset(p), []).append(v)
        order_dev.append(max(max(v) - min(v) for v in by_set.values()))
        setval = {S: max(v) for S, v in by_set.items()}
        sets = list(setval)
        for _ in range(300):
            T = sets[rng.integers(len(sets))]
            if len(T) == 0:
                continue
            Tl = list(T)
            S = frozenset(rng.choice(Tl, rng.integers(0, len(Tl) + 1), replace=False).tolist()) if len(Tl) else T
            cand = [l for l in range(N) if l not in T]
            l = int(rng.choice(cand))
            if S | {l} in setval and T | {l} in setval and S in setval:
                sub_tot += 1
                if setval[T | {l}] - setval[T] > setval[S | {l}] - setval[S] + 1e-7:
                    sub_viol += 1
    rg, rr = np.array(ratios_g), np.array(ratios_r)
    return dict(regime=regime, n=len(rg), greedy_mean=float(rg.mean()), greedy_min=float(rg.min()),
                greedy_opt_frac=float((rg > 1 - 1e-6).mean()), greedy_below_bound=float((rg < 1 - 1 / np.e).mean()),
                greedy_zero=float((rg < 1e-6).mean()),
                shaped_mean=float(rr.mean()), shaped_min=float(rr.min()), shaped_opt_frac=float((rr > 1 - 1e-6).mean()),
                order_dev_max=float(np.max(order_dev)), submod_checks=sub_tot,
                submod_violation_frac=float(sub_viol / max(1, sub_tot)))


def main():
    torch.set_num_threads(1)
    res = [run("A"), run("B")]
    (ROOT / "results" / "theory_check.json").write_text(json.dumps(res, indent=1))
    lines = [r"\begin{tabular}{lrr}", r"\toprule", r"Quantity & Regime A (no prerequisites) & Regime B (prerequisites) \\",
             r"\midrule"]
    A, B = res
    rows = [("instances", "n", "{:d}"), ("goal-greedy / optimum: mean", "greedy_mean", "{:.3f}"),
            ("goal-greedy / optimum: minimum", "greedy_min", "{:.3f}"),
            ("share with goal-greedy optimal", "greedy_opt_frac", "{:.1%}"),
            ("share below $1-1/e$", "greedy_below_bound", "{:.1%}"),
            ("share with goal-greedy gain $=0$", "greedy_zero", "{:.1%}"),
            ("relevance-greedy / optimum: mean", "shaped_mean", "{:.3f}"),
            ("relevance-greedy / optimum: minimum", "shaped_min", "{:.3f}"),
            ("max.\\ value difference between orders of a set", "order_dev_max", "{:.1e}"),
            ("submodularity checks", "submod_checks", "{:d}"),
            ("share of submodularity violations", "submod_violation_frac", "{:.1%}")]
    for name, k, f in rows:
        lines.append(f"{name} & {f.format(A[k])} & {f.format(B[k])} \\\\".replace("%", "\\%"))
    lines += [r"\bottomrule", r"\end{tabular}"]
    (ROOT / "dissertation" / "tables" / "theory_check.tex").write_text("\n".join(lines))
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()

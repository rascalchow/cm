#!/usr/bin/env bash
# Train the short-schedule reference runs (3 seeds) and all ablation variants.
# The main model and its uncertainty-aware variant continue run full_s1 (see README).
# Usage: bash train_all.sh [max_parallel]
set -u
cd "$(dirname "$0")"
P=${1:-8}
LOG=../../results/logs
mkdir -p "$LOG"
jobs=(
  "--name full_s --variant full --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name full_s1 --variant full --bc_epochs 3 --rl_iters 100 --val_limit 16 --seed 1"
  "--name full_s2 --variant full --bc_epochs 3 --rl_iters 100 --val_limit 16 --seed 2"
  "--name no_anc --variant no_anc --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name no_cc --variant no_cc --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name mlp --variant mlp --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name no_model_feat --variant no_model_feat --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name no_learner --variant no_learner --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name mean_agg --variant mean_agg --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name layers1 --variant layers1 --bc_epochs 3 --rl_iters 100 --val_limit 16"
  "--name rl_only --variant full --no_bc --rl_iters 200 --val_limit 16"
)
printf '%s\n' "${jobs[@]}" | xargs -P "$P" -I{} bash -c 'name=$(echo "{}" | awk "{print \$2}"); python3 train_model.py {} --threads 1 > '"$LOG"'/train_${name}.log 2>&1; echo "done ${name}"'

"""Train a path policy variant (behaviour cloning + policy gradient)."""
from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import asdict
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from lpg.data import load_split, RESULTS
from lpg.model import PathPolicy
from lpg.train import TrainConfig, train_bc, train_rl, evaluate_policy

VARIANTS = {
    "full": dict(),
    "no_anc": dict(relations=["pre", "pre_r", "cov", "cov_r"]),
    "no_cc": dict(relations=["cov", "cov_r"]),
    "mlp": dict(encoder="mlp"),
    "no_model_feat": dict(use_model_features=False),
    "no_learner": dict(use_learner_context=False),
    "mean_agg": dict(attention=False),
    "layers1": dict(layers=1),
    "layers2": dict(layers=2),
    "layers4": dict(layers=4),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--variant", default="full", choices=list(VARIANTS))
    ap.add_argument("--no_bc", action="store_true")
    ap.add_argument("--no_rl", action="store_true")
    ap.add_argument("--bc_epochs", type=int, default=6)
    ap.add_argument("--rl_iters", type=int, default=300)
    ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--init", default=None, help="initialise from a saved model (skips BC)")
    ap.add_argument("--val_limit", type=int, default=None, help="learners per validation curriculum")
    ap.add_argument("--robust", action="store_true", help="uncertainty-aware policy-gradient reward")
    ap.add_argument("--crn", action="store_true", help="common random numbers for the M paths of a learner")
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    torch.manual_seed(a.seed)
    np.random.seed(a.seed)
    cfg = TrainConfig(bc_epochs=a.bc_epochs, rl_iters=a.rl_iters, seed=a.seed, robust=a.robust, crn=a.crn)
    train = load_split("train")
    val = load_split("val", limit_learners=a.val_limit)
    policy = PathPolicy(**VARIANTS[a.variant])
    log: list = [dict(meta=dict(name=a.name, variant=a.variant, kwargs=VARIANTS[a.variant], cfg=asdict(cfg),
                                no_bc=a.no_bc, no_rl=a.no_rl, init=a.init, seed=a.seed,
                                params=sum(p.numel() for p in policy.parameters())))]
    out = RESULTS / "models"
    out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    if a.init:
        policy.load_state_dict(torch.load(out / f"{a.init}.pt"))
    elif not a.no_bc:
        have = [inst for inst in train if (RESULTS / "experts" / f"{inst.cur.name}.json").exists()]
        experts = [json.loads((RESULTS / "experts" / f"{inst.cur.name}.json").read_text()) for inst in have]
        log[0]["meta"]["bc_curricula"] = [inst.cur.name for inst in have]
        train_bc(policy, have, experts, cfg, log, val)
        torch.save(policy.state_dict(), out / f"{a.name}_bc.pt")
    if not a.no_rl:
        policy = train_rl(policy, train, cfg, log, val)
    torch.save(policy.state_dict(), out / f"{a.name}.pt")
    log.append(dict(final_val=evaluate_policy(policy, val, mc=32), total_sec=time.time() - t0))
    (out / f"{a.name}_log.json").write_text(json.dumps(log))
    print(json.dumps(log[-1]))


if __name__ == "__main__":
    main()

#!/usr/bin/env bash
# Evaluation commands used for Chapter 6 (run from the repository root after training).
set -e
E="python3 code/scripts/run_eval.py --threads 1"
MIS='{"gamma_ready": 20.0, "tau_ready": 0.55, "p_star": 0.6, "h0": 0.006, "gain_noise_shape": 4.0}'
ALL="test_k80 test_k120 shift_lowbw shift_lowprior shift_forget shift_noisy"

# classical generators
$E --procs 2 --splits test_id test_ood $ALL --methods random static kg_rule greedy beam8
$E --procs 4 --splits test_id test_ood $ALL --methods ga ga_mc
$E --procs 4 --per_instance --splits test_id test_ood --methods ga_mcc ga_mcr
$E --procs 3 --splits test_ood --suffix _misspec --true_params "$MIS" --methods random static kg_rule greedy beam8 ga ga_mc
$E --procs 4 --per_instance --splits test_ood --suffix _misspec --true_params "$MIS" --methods ga_mcc ga_mcr

# PA-HGNN: main model, uncertainty-aware variant, seeds and ablations
$E --procs 8 --per_instance --splits test_id test_ood --methods gnn:full gnn:full_robust gnn_s16:full gnn_s16r:full_robust
$E --procs 8 --per_instance --splits test_ood --suffix _misspec --true_params "$MIS" \
   --methods gnn:full gnn:full_robust gnn_s16:full gnn_s16r:full_robust
$E --procs 8 --per_instance --splits $ALL --methods gnn:full gnn:full_robust gnn_s16:full
$E --procs 8 --per_instance --splits test_ood --methods gnn:full_s gnn:full_s2
$E --procs 3 --splits test_ood --methods gnn:full_s1 gnn:full_s1@bc gnn:no_anc gnn:no_cc gnn:mlp \
   gnn:no_model_feat gnn:no_learner gnn:mean_agg gnn:layers1 gnn:rl_only

python3 code/scripts/analyze_results.py

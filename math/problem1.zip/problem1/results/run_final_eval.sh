#!/usr/bin/env bash
# Final evaluation of the trained PA-HGNN models (launched after training has finished).
cd "$(dirname "$0")/.."
L=results/logs
E="python3 code/scripts/run_eval.py --procs 8 --threads 1 --per_instance"
MIS='{"gamma_ready": 20.0, "tau_ready": 0.55, "p_star": 0.6, "h0": 0.006, "gain_noise_shape": 4.0}'
until grep -q final_val $L/train_full.log && grep -q final_val $L/train_full_robust.log && \
      grep -q final_val $L/train_full_s.log && grep -q final_val $L/train_full_s2.log; do sleep 30; done
$E --splits test_id test_ood --methods gnn:full gnn:full_robust gnn_s16:full gnn_s16r:full_robust > $L/eval_final_main.log 2>&1
$E --splits test_ood --methods gnn:full_s gnn:full_s2 > $L/eval_final_seeds.log 2>&1
$E --splits test_ood --suffix _misspec --true_params "$MIS" --methods gnn:full gnn:full_robust gnn_s16:full gnn_s16r:full_robust > $L/eval_final_misspec.log 2>&1
$E --splits test_k80 test_k120 shift_lowbw shift_lowprior shift_forget shift_noisy --methods gnn:full gnn:full_robust gnn_s16:full > $L/eval_final_wide.log 2>&1
echo finished > $L/eval_final_done.flag

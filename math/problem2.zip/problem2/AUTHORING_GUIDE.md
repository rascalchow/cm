# Authoring Guide — *Scientific Machine Learning: Foundations, Methods, and Practice*

This guide is binding for every chapter of the book. Read it completely before writing.

## 1. The book

* **Audience.** Advanced undergraduates and first-year graduate students in applied mathematics,
  engineering, physics, and computer science. Prerequisites: multivariable calculus, linear algebra,
  ordinary differential equations, introductory probability, and Python programming. Students are
  *not* assumed to know machine learning or numerical PDEs beyond an introductory course
  (Chapter 2 and the appendices fill gaps).
* **Use.** A one-semester (14–15 week) university course, "Scientific Machine Learning".
  Each chapter is roughly one week of lectures plus homework.
* **Length.** The whole book must be 250–300 pages. Each chapter must compile to
  **12–13 pages** (hard limits 11–14) as reported by `scripts/build_chapter.sh` ("chapter pages").
  Density matters more than length: no padding, no filler lists.
* **Voice.** A rigorous but readable textbook. First person plural ("we"). Mostly flowing paragraphs
  that explain *why*, not bullet lists. Every symbol defined when introduced. Derivations shown
  (or sketched with a citation for the full proof). Honest about limitations: SciML methods are
  compared fairly against classical numerical methods.

## 2. Structure of the book (labels are fixed — use them for cross-references)

| Part | Ch | File | Label | Title |
|---|---|---|---|---|
| I Foundations | 1 | `chapters/ch01_introduction.tex` | `ch:intro` | The Scientific Machine Learning Paradigm |
| | 2 | `chapters/ch02_foundations.tex` | `ch:math` | Mathematical and Numerical Foundations |
| | 3 | `chapters/ch03_neural_networks.tex` | `ch:nn` | Neural Networks and Statistical Learning |
| | 4 | `chapters/ch04_optimization.tex` | `ch:opt` | Optimization for Scientific Machine Learning |
| | 5 | `chapters/ch05_autodiff.tex` | `ch:ad` | Automatic Differentiation and Differentiable Programming |
| II Learning Dynamics from Data | 6 | `chapters/ch06_reduced_order_models.tex` | `ch:rom` | Dimensionality Reduction and Reduced-Order Models |
| | 7 | `chapters/ch07_dmd_koopman.tex` | `ch:dmd` | Dynamic Mode Decomposition and Koopman Theory |
| | 8 | `chapters/ch08_equation_discovery.tex` | `ch:sindy` | Sparse Identification and Equation Discovery |
| | 9 | `chapters/ch09_neural_odes.tex` | `ch:node` | Neural Differential Equations |
| III Physics-Informed and Operator Learning | 10 | `chapters/ch10_pinns.tex` | `ch:pinn` | Physics-Informed Neural Networks |
| | 11 | `chapters/ch11_advanced_pinns.tex` | `ch:pinn2` | Training Pathologies and Advanced PINNs |
| | 12 | `chapters/ch12_structure_preserving.tex` | `ch:struct` | Structure-Preserving and Symmetry-Aware Learning |
| | 13 | `chapters/ch13_operator_learning.tex` | `ch:operator` | Operator Learning |
| IV Uncertainty, Inference, and Hybrid Modeling | 14 | `chapters/ch14_inverse_problems.tex` | `ch:inverse` | Inverse Problems and Bayesian Inference |
| | 15 | `chapters/ch15_uncertainty.tex` | `ch:uq` | Uncertainty Quantification |
| | 16 | `chapters/ch16_generative.tex` | `ch:generative` | Generative Models for Science |
| | 17 | `chapters/ch17_hybrid_modeling.tex` | `ch:hybrid` | Hybrid Modeling, Closures, and Learned Simulators |
| | 18 | `chapters/ch18_practice.tex` | `ch:practice` | SciML in Practice: Workflows, Reproducibility, and Frontiers |
| Appendices | A | `appendices/appA_python.tex` | `app:python` | Python, NumPy, and PyTorch for Scientific Computing |
| | B | `appendices/appB_probability.tex` | `app:prob` | Probability and Statistics Refresher |
| | C | `appendices/appC_course.tex` | `app:course` | Course Design, Projects, and Assessment |

Cross-chapter references: use only `\cref{ch:...}` / `\cref{app:...}` (section labels in other
chapters are unknown to you). Point backward to where an idea was introduced and forward to where it
is developed, so the book reads as one text. Do not re-teach material that belongs to another chapter;
summarize in one or two sentences and reference it.

## 3. Mandatory chapter template

```latex
\chapter{Title}\label{ch:xxx}

\begin{objectives}
\item ...   % 5-7 measurable objectives ("derive", "implement", "explain", "diagnose")
\end{objectives}

Opening: 2-4 paragraphs of motivation; connect to earlier chapters.

\section{...}\label{sec:NN:...}     % 5-8 content sections, each with real exposition
  ... definitions, theorems (with proofs or proof sketches), worked examples,
  algorithms, code listings, figures, keyidea / practicaltip / caution boxes ...

\section{Notes and Further Reading}\label{sec:NN:notes}
  2-4 paragraphs of annotated bibliography (who did what, where to go next), citation-dense.

\begin{summarybox}
\item ...   % 5-8 key takeaways
\end{summarybox}

\section{Exercises}\label{sec:NN:exercises}
  8-10 exercises: mix of analytical/proof (\diffi..\diffiii), conceptual, and computational.
  \begin{exercise}[\diffii\ Short title] ... \end{exercise}

\section{Hands-on Assignments}\label{sec:NN:assignments}
  2 assignments, each a substantial programming project (a week of homework):
  \begin{assignment}{Title}
  \apart{Objective} ...
  \apart{Setup} ... (data generation, provided code to start from: code/chNN/..., code/common/...)
  \apart{Tasks} \begin{enumerate} ... \end{enumerate}
  \apart{Deliverables} ... (plots, tables, short report, code)
  \apart{Extensions} ... (optional)
  \end{assignment}
```

Assignments must run on a laptop CPU (each training run < ~10 minutes) using only NumPy, SciPy,
Matplotlib, and PyTorch. State concrete numbers (grid sizes, epochs, learning rates) so students can
start immediately, and state what a successful outcome looks like qualitatively.

## 4. LaTeX rules

* Never add `\usepackage`, never redefine existing commands. Everything you need is in
  `preamble.tex` (read it). If you absolutely need a helper macro, define it with
  `\providecommand` and a chapter-unique prefix (e.g. `\chsevenX`) — avoid this if possible.
* **Labels** carry the chapter number: `sec:07:dmd-algorithm`, `eq:07:koopman`, `fig:07:spectrum`,
  `tab:07:...`, `lst:07:...`, `alg:07:...`, `def:07:...`, `thm:07:...`, `ex:07:...`, `asg:07:...`.
  Reference with `\cref{}` (or `\eqref{}` for equations).
* **Environments available:** `definition`, `theorem`, `proposition`, `lemma`, `corollary`, `remark`,
  `example`, `proof`; boxes `keyidea[opt title]`, `practicaltip[opt title]`, `caution[opt title]`,
  `historybox[opt title]`; `objectives`, `summarybox` (both already contain an itemize — use `\item`
  directly); `exercise[opt title]`; `assignment{title}` with `\apart{Heading}` and `\hint{...}`;
  `algorithm` + `algorithmic` (algpseudocode: `\Require`, `\Ensure`, `\State`, `\For{}`/`\EndFor`,
  `\While{}`/`\EndWhile`, `\If{}`/`\EndIf`, `\State \Return x` (always preceded by `\State`), `\Comment{}`); `lstlisting` (Python style is the
  default).
* **Source is ASCII only.** Write accents with LaTeX (`Schr\"odinger`, `Lo\`eve`, `Poincar\'e`).
  No Unicode in code listings either.
* **Notation macros** (use them): `\R \C \N \E \Prob \Var \Cov \tr \rank \diag \argmin \argmax`,
  `\vect{x}` (bold vector), `\mat{A}` (bold matrix), `^\T` (transpose), `\norm{}`, `\abs{}`,
  `\inner{a}{b}`, `\dd` (differential: `\int f(x)\dd x`), `\pd{u}{t}`, `\pdd{u}{x}`, `\od{x}{t}`,
  `\loss` (loss), `\data` (dataset), `\Normal` (Gaussian), `\order` (big-O), `\Op` (operator
  $\mathcal{G}$), `\eps`, `\Id`, `\KL`, `\code{}` (inline code), `\term{}` (emphasize + index).
* **Global notation conventions.**
  scalars italic; finite-dimensional vectors bold lowercase `\vect{x}\in\R^n`; matrices bold uppercase
  `\mat{X}`; in PDE contexts the spatial coordinate is non-bold $x\in\Omega\subset\R^d$, time
  $t\in[0,T]$, solution field $u(x,t)$; generic PDE written $\mathcal{F}[u] = f$ in $\Omega$,
  $\mathcal{B}[u] = g$ on $\partial\Omega$; ODE state $\vect{x}(t)\in\R^n$ with
  $\dot{\vect{x}} = \vect{f}(\vect{x})$; neural networks $u_\theta$, $\vect{f}_\theta$, parameters
  $\theta\in\R^p$; loss $\loss(\theta)$; data $\data=\{(\vect{x}_i,\vect{y}_i)\}_{i=1}^N$; learning
  rate $\eta$; activation $\sigma$; Gaussian $\Normal(\mu,\sigma^2)$; snapshot matrix $\mat{X}$ with
  SVD $\mat{X}=\mat{U}\mat{\Sigma}\mat{V}^*$; Koopman operator $\mathcal{K}$; solution operator
  $\Op:\mathcal{A}\to\mathcal{U}$; expectation $\E$; densities $p(\cdot)$.
* **Index:** mark 15–30 key terms per chapter with `\index{...}` (or `\term{...}` at the defining
  occurrence). Lower-case index entries unless proper nouns; sub-entries with `!`, e.g.
  `\index{physics-informed neural network!loss function}`. Never put `@`, `|`, or `"` inside `\index`.
* **Figures:** `\begin{figure}[htbp]\centering\includegraphics[width=...]{figures/chNN/name.pdf}
  \caption{...}\label{fig:NN:name}\end{figure}`. Every figure is produced by a script
  `code/chNN/fig_name.py` that uses `code/common/plotstyle.py` (`set_style()`, `COLORS`, `FULL_WIDTH`,
  `savefig(fig, "chNN", "name")`). Prefer figures that show *computed results* (2–4 per chapter).
  Simple TikZ schematics (architectures, workflows) are welcome but must compile.
  Captions are full sentences explaining what to observe.
* **Code listings:** `\begin{lstlisting}[caption={...},label={lst:NN:name}] ... \end{lstlisting}`.
  Each listing is an excerpt of a file in `code/chNN/` that you have **actually run** successfully
  with `python3`. Keep listings 10–40 lines, focused on the core idea, with comments. Use `float64`
  where accuracy matters, set seeds, and keep CPU runtime small.
* **Tables:** `booktabs` (`\toprule \midrule \bottomrule`), `[htbp]`.
* Use `[htbp]` for floats. No `\chapter*`, no `\section*`.
* CPU etiquette: several authors share a 12-core machine. Put `torch.set_num_threads(2)` at the top
  of PyTorch scripts and keep each script's runtime to a few minutes.
* Avoid long unbreakable URLs/inline code; check overfull boxes reported by the build script.

## 5. Citations — accuracy is non-negotiable

* Cite with natbib: `\citet{key}` ("Raissi et al. (2019) proposed ...") and `\citep{key}`
  ("... (Raissi et al., 2019)"). Multiple keys: `\citep{a,b}`.
* **Only cite keys that exist.** The verified core bibliography is `bib/core.bib`
  (browse `bib/core_index.tsv`, or search: `python3 scripts/addref.py --lookup "koopman"`).
* To add a reference, **never write BibTeX by hand.** Use the verified tool, which pulls metadata
  from Crossref/arXiv/PMLR/NeurIPS/JMLR:
  `python3 scripts/addref.py --chapter NN --doi 10.xxxx/yyyy` or
  `python3 scripts/addref.py --chapter NN --arxiv 2010.08895 [--neurips 2020|--icml 2021|--iclr 2021|--jmlr 24]`
  or `--search "exact title" --author Family --year 2020`. It prints the key to use (or the existing key
  if already present). Only add works you are confident exist and that you know the content of.
* Attribute to each paper only what it actually contains. If unsure of a detail (a specific number,
  a specific claim), describe the work at the level you are sure of, or don't cite it for that claim.
  Never invent quantitative results from papers. Numbers you state about your own examples must
  come from running your code.
* Aim for 25–45 distinct citations per chapter, concentrated in the narrative and in
  "Notes and Further Reading".

## 6. Shared code you can use

* `code/common/plotstyle.py` — figure style (see its docstring).
* `code/common/sciml_data.py` — verified reference solvers and datasets: Lorenz-63, pendulum,
  Lotka–Volterra, Duffing, Lorenz-96 (`integrate` uses DOP853 with tight tolerances); periodic
  pseudo-spectral ETDRK4 solver `etdrk4_periodic`; `burgers_periodic`; `burgers_pinn_reference`
  (the classic PINN Burgers benchmark, ν = 0.01/π on [-1,1]); `allen_cahn_reference`;
  `kuramoto_sivashinsky`; `heat_fd` (Crank–Nicolson with variable conductivity); Gaussian random
  fields `grf_1d`, `grf_2d`; `darcy_2d`, `darcy_dataset`; `burgers_operator_dataset` (FNO-style
  u0 → u(T) pairs). Run `python3 code/common/sciml_data.py` to see the self-tests.
  Import with `sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))`.
* Do **not** modify files in `code/common/` (other authors depend on them). Put your own helpers in
  `code/chNN/`.

## 7. Build and check

```
scripts/build_chapter.sh chapters/chNN_name.tex
```
must report: no LaTeX errors, **0 undefined citations**, no undefined internal references
(other than `ch:`/`app:` cross-chapter labels, which resolve in the full book), few/no overfull
boxes > 10pt, and **12–13 chapter pages** (11–14 tolerated). Iterate until clean.

## 8. Quality checklist before you finish

1. Mathematics checked line by line; dimensions/indices consistent; signs right.
2. Every listing extracted from code that ran; every figure regenerated from its script.
3. Every citation key exists and the attributed claim is accurate.
4. Exercises are solvable with the chapter's content and are unambiguous; assignments have concrete
   parameters and clear deliverables.
5. Chapter reads as part of one book: back/forward references, consistent notation.
6. Page count within limits.

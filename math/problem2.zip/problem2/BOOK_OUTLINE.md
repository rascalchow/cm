# Book Outline — section-level plan for every chapter

Authors: follow your chapter's plan (you may reorder or merge sections, and add material, as long as
the scope stays inside your chapter and the page limit of 12–13 compiled pages holds). Read the plans
of neighbouring chapters to avoid overlap and to place forward/backward references correctly.
Suggested citation keys exist in `bib/core.bib`; add others with `scripts/addref.py`.

---------------------------------------------------------------------------------------------------
## Part I — Foundations

### Ch 1 The Scientific Machine Learning Paradigm (`ch:intro`)
1. What is SciML? The two traditions (first-principles modelling vs. data-driven learning) and their
   synthesis; the DOE report's priority research directions (domain-aware, interpretable, robust;
   data-intensive; enhanced modelling & simulation; intelligent automation) — baker2019workshop.
2. A short history: hybrid neural/first-principles models and neural nets for ODE/PDE in the 1990s
   (psichogios1992hybrid, rico1992discrete, gonzalez1998identification, lagaris1998artificial,
   dissanayake1994neural, kramer1991nonlinear, vanmilligen1995neural, milano2002neural); POD in turbulence;
   deep-learning era (lecun2015deep); PINNs (raissi2019physics), operator learning (lu2021learning,
   li2021fourier), ML weather (lam2023learning, bi2023accurate, kochkov2024neural), AlphaFold (jumper2021highly).
3. Three ways to inject knowledge: observational, inductive, and learning biases (karniadakis2021physics);
   white-box / grey-box / black-box spectrum; theory-guided data science (karpatne2017theory, willard2022integrating).
4. Canonical SciML tasks (taxonomy table): surrogates/emulators, system identification & equation
   discovery, forward PDE solving, inverse problems & data assimilation, closure modelling, control/design,
   UQ, discovery. Map each to the chapters of the book.
5. A first worked example (computed): damped pendulum or logistic growth. Compare (i) black-box regression
   that interpolates but fails to extrapolate, (ii) mechanistic model with fitted parameters,
   (iii) hybrid model. Figure + short listing.
6. Successes and cautionary tales: weather, proteins, materials (merchant2023scaling), fusion control
   (degrave2022magnetic); pitfalls: extrapolation, leakage, weak baselines (mcgreivy2024weak, kapoor2023leakage).
7. How to evaluate SciML models (accuracy, generalization regime, physical consistency, cost incl. data
   generation); software ecosystem; how to use the book (dependency diagram of chapters (TikZ), course plans).
Assignments: hybrid pendulum study with varying data regimes; literature mini-review classifying a paper's
biases and evaluation protocol.

### Ch 2 Mathematical and Numerical Foundations (`ch:math`)
1. Linear algebra: norms, inner products, eigendecomposition, SVD and Eckart–Young (eckart1936approximation),
   least squares (normal equations, QR, pseudoinverse), conditioning, ridge regularization preview,
   randomized SVD (halko2011finding). (trefethen1997numerical, golub2013matrix)
2. Functions and approximation: L2 and Sobolev spaces (informal), orthogonal polynomials, Fourier series
   and spectral convergence, interpolation and the Runge phenomenon (trefethen2019approximation),
   curse of dimensionality.
3. ODEs: existence/uniqueness (Picard–Lindelöf), linear systems and stability, phase portraits, chaos
   (lorenz1963deterministic, strogatz2015nonlinear); integrators: Euler, RK4, embedded RK (dormand1980family),
   stiffness and implicit methods (hairer1993solving, hairer1996solving), symplectic integrators preview (`ch:struct`).
4. PDEs: classification; canonical equations (Poisson, heat, advection, Burgers, wave, reaction–diffusion,
   Navier–Stokes); IC/BC; well-posedness (evans2010partial).
5. Discretization: finite differences (consistency, stability, Lax equivalence — lax1956survey, CFL —
   courant1928partiellen) (leveque2007finite); method of lines; FEM weak form & Galerkin (brenner2008mathematical);
   Fourier pseudo-spectral methods (trefethen2000spectral) — the ETDRK4 solver in `code/common/sciml_data.py`
   used throughout the book (computed figure: Burgers shock formation; convergence plot).
6. Probability essentials in one page (pointer to `app:prob`): Gaussian, Bayes rule, MLE/MAP, Monte Carlo.
Assignments: build/verify a data-generation toolkit (RK45 Lorenz, spectral Burgers with convergence study);
SVD compression of a spatiotemporal dataset + randomized SVD timing.

### Ch 3 Neural Networks and Statistical Learning (`ch:nn`)
1. Supervised learning: risk, empirical risk, losses; MSE as Gaussian MLE.
2. Linear & basis-function models, ridge/lasso (hoerl1970ridge, tibshirani1996regression), bias–variance
   (geman1992neural), cross-validation, kernels/RBF briefly (scholkopf2002learning, wendland2004scattered).
3. Feedforward networks: neurons, activations (tanh, ReLU, GELU hendrycks2016gaussian, SiLU, sine),
   composition, parameter counting, initialization (glorot2010understanding, he2015delving), backprop as
   reverse-mode AD (details in `ch:ad`).
4. Approximation theory: universal approximation (cybenko1989approximation, hornik1989multilayer,
   leshno1993multilayer, pinkus1999approximation), Barron rates (barron1993universal), depth (yarotsky2017error),
   devore2021neural; spectral bias & Fourier features (rahaman2019spectral, tancik2020fourier) with a computed figure.
5. Generalization: overparameterization, double descent (belkin2019reconciling), zhang2021understanding;
   interpolation vs. extrapolation and distribution shift in scientific data.
6. Architectures beyond MLPs: CNNs (lecun1998gradient) and U-Net (ronneberger2015unet), RNN/LSTM
   (hochreiter1997long), ResNets (he2016deep) as Euler steps (forward ref `ch:node`), attention/transformers
   (vaswani2017attention), GNNs (forward ref `ch:struct`).
7. Training in PyTorch (paszke2019pytorch): data, model, loss, optimizer loop; normalization of inputs/outputs;
   train/validation/test splits. Listing.
Assignments: function approximation study (MLP vs polynomial vs RBF; spectral bias; Fourier features);
learning a pendulum flow map with MLP vs ResNet and testing long rollouts.

### Ch 4 Optimization for Scientific Machine Learning (`ch:opt`)
1. Optimization problems in SciML: ERM, PDE-constrained, nonconvexity, loss landscapes (li2018visualizing).
2. Gradient descent: convergence for L-smooth convex and strongly convex functions (with proofs),
   condition number, line search (nocedal2006numerical, boyd2004convex, nesterov2018lectures).
3. SGD: Robbins–Monro (robbins1951stochastic), minibatches, variance, schedules (step, cosine/warm restarts
   loshchilov2017sgdr, cyclical smith2017cyclical, warmup goyal2017accurate) (bottou2018optimization).
4. Momentum & adaptive methods: heavy ball (polyak1964some), Nesterov, AdaGrad (duchi2011adaptive), RMSProp
   (tieleman2012lecture), Adam (kingma2015adam), AdamW (loshchilov2019decoupled). Algorithm boxes; computed
   figure on an ill-conditioned quadratic/Rosenbrock.
5. Second-order & quasi-Newton: Newton, Gauss–Newton/Levenberg–Marquardt, BFGS, L-BFGS two-loop recursion
   (liu1989limited, byrd1995limited); natural gradient (amari1998natural), K-FAC (martens2015optimizing),
   energy natural gradient for PINNs (muller2023achieving).
6. Practical training: initialization, normalization, gradient clipping (pascanu2013difficulty), early stopping
   (prechelt1998early), hyperparameter search, float32 vs float64 in SciML, multi-term losses (forward `ch:pinn2`).
7. Ill-conditioning of physics-informed losses and the Adam→L-BFGS recipe (rathore2024challenges).
Assignments: implement GD/momentum/Adam/L-BFGS from scratch and compare; optimizer & precision study for
fitting a multiscale function with a network.

### Ch 5 Automatic Differentiation and Differentiable Programming (`ch:ad`)
1. Computing derivatives: symbolic, finite differences (truncation vs round-off; optimal step; computed figure),
   complex step, AD (baydin2018automatic, griewank2008evaluating, margossian2019review).
2. Computational graphs; forward mode with dual numbers (wengert1964simple) — small implementation; JVPs.
3. Reverse mode (linnainmaa1976taylor, rumelhart1986learning): VJPs, cheap-gradient principle, memory;
   a ~40-line reverse-mode engine (listing).
4. AD in practice: PyTorch autograd, higher derivatives (create_graph — needed for PINNs), Hessian-vector
   products (pearlmutter1994fast), Jacobians via torch.func, pitfalls.
5. The adjoint method: discrete adjoint for A(p)u = b; continuous adjoint for ODEs via Lagrangian
   (derivation; forward ref `ch:node`); relation to reverse mode; checkpointing (griewank2000algorithm,
   chen2016training) (giles2000introduction, plessix2006review, cao2003adjoint, jameson1988aerodynamic).
6. Implicit differentiation: implicit function theorem, fixed points, optimization layers
   (blondel2022efficient, bai2019deep, amos2017optnet).
7. Differentiable simulation: differentiable solvers (holl2020learning, hu2020difftaichi, schoenholz2020jax,
   innes2019differentiable, farrell2013automated); computed example: recover a diffusion coefficient by
   differentiating through a finite-difference heat solver.
Assignments: build a minimal reverse-mode AD engine with tests; parameter estimation through a differentiable
solver vs. adjoint (accuracy & cost comparison).

---------------------------------------------------------------------------------------------------
## Part II — Learning Dynamics from Data

### Ch 6 Dimensionality Reduction and Reduced-Order Models (`ch:rom`)
1. Why reduce: many-query problems, low intrinsic dimension, Kolmogorov n-width (pinkus1985n,
   cohen2015approximation) (benner2015survey, quarteroni2016reduced, hesthaven2016certified).
2. POD: snapshot matrix, SVD / method of snapshots (sirovich1987turbulence), optimality, energy criterion,
   mean subtraction (berkooz1993proper, holmes2012turbulence, taira2017modal); computed figure: singular
   values & modes of Burgers / traveling wave data.
3. Galerkin projection: linear and quadratic systems (precomputed tensors), stability issues, LSPG briefly
   (carlberg2013gnat); cylinder-wake history (noack2003hierarchy).
4. Hyper-reduction: EIM/DEIM (barrault2004empirical, chaturantabut2010nonlinear) with algorithm box.
5. Non-intrusive ROMs: operator inference (peherstorfer2016data, kramer2024learning, qian2020lift),
   regression of POD coefficients (hesthaven2018non, guo2018reduced, swischuk2019projection).
6. Nonlinear manifolds: Kolmogorov barrier for advection; linear AE = PCA; autoencoders (hinton2006reducing,
   kramer1991nonlinear, lee2020model, fresca2021comprehensive, maulik2021reduced); latent dynamics.
7. ROM closures and balanced truncation in brief (moore1981principal, rowley2005model, ahmed2021closures,
   san2018neural).
Assignments: POD-Galerkin + DEIM ROM for parametric Burgers (speed/accuracy); linear vs autoencoder compression
of an advecting pulse.

### Ch 7 Dynamic Mode Decomposition and Koopman Theory (`ch:dmd`)
1. Best-fit linear operators; exact DMD algorithm (schmid2010dynamic, rowley2009spectral, tu2014dynamic):
   modes, eigenvalues, continuous-time frequencies/growth, reconstruction & forecasting.
2. DMD in practice: rank truncation (gavish2014optimal), noise bias & corrections (dawson2016characterizing,
   hemati2017biasing), optimized DMD (askham2018variable), sparsity-promoting (jovanovic2014sparsity);
   computed example with spectrum & modes figure.
3. Extensions: DMDc (proctor2016dynamic), Hankel/time-delay DMD (arbabi2017ergodic, takens1981detecting),
   HAVOK (brunton2017chaos), mrDMD (kutz2016multiresolution), physics-informed DMD (baddoo2023physics),
   SPOD relation (towne2018spectral) (kutz2016dynamic, schmid2022dynamic).
4. Koopman operator theory (koopman1931hamiltonian, mezic2005spectral, budisic2012applied, mezic2013analysis,
   brunton2022modern): definition, eigenfunctions, the slow-manifold example with finite closure, continuous spectra.
5. EDMD (williams2015data, klus2018data), kernel variants, spectral pollution & ResDMD (colbrook2024rigorous).
6. Deep Koopman embeddings (lusch2018deep, takeishi2017learning, otto2019linearly) and Koopman control
   (korda2018linear, kaiser2021data).
Assignments: exact DMD + DMDc on generated data; EDMD on Duffing and a deep Koopman autoencoder for the
slow-manifold system.

### Ch 8 Sparse Identification and Equation Discovery (`ch:sindy`)
1. The discovery problem, parsimony; history (bongard2007automated, schmidt2009distilling).
2. SINDy (brunton2016discovering): library, sparse regression, STLSQ (algorithm + listing); computed Lorenz
   recovery figure.
3. Sparse regression theory: lasso (tibshirani1996regression), elastic net (zou2005regularization), LARS
   (efron2004least), compressed sensing (candes2006robust, donoho2006compressed), STLSQ convergence
   (zhang2019convergence); model selection AIC/BIC (akaike1974new, schwarz1978estimating, mangan2017model).
4. Practical issues: noisy derivatives (chartrand2011numerical, vanbreugel2020numerical), weak SINDy
   (messenger2021weak, messenger2021weakpde, reinbold2020using), ensembles (fasel2022ensemble),
   constraints (loiseau2018constrained, champion2020unified).
5. Extensions: SINDy-PI (kaheman2020sindy), SINDy-MPC (kaiser2018sparse), PDE-FIND (rudy2017data,
   schaeffer2017learning), SINDy autoencoders (champion2019data), PySINDy (desilva2020pysindy, kaptanoglu2022pysindy).
6. Symbolic regression: genetic programming (koza1994genetic), PySR (cranmer2023interpretable), AI Feynman
   (udrescu2020ai), deep symbolic regression (petersen2021deep), distilling GNNs (cranmer2020discovering).
7. Limitations & validation: identifiability, library choice, noise, validating discovered models.
Assignments: SINDy from scratch (Lorenz + noise study); PDE-FIND on Burgers data with weak-form comparison.

### Ch 9 Neural Differential Equations (`ch:node`)
1. ResNets as Euler discretizations (haber2017stable, e2017proposal, lu2018beyond, ruthotto2020deep);
   neural ODEs (chen2018neural).
2. Training: discretize-then-optimize vs optimize-then-discretize; full adjoint-sensitivity derivation
   (refer to `ch:ad` for the general adjoint idea); memory/accuracy; checkpointing (gholami2019anode,
   zhuang2020adaptive); PyTorch RK4 listing.
3. Learning dynamics from time series: trajectory losses, multiple shooting, irregular sampling, stiffness
   (kim2021stiff), early classics (rico1992discrete, gonzalez1998identification, raissi2018multistep, qin2019data).
4. Expressivity & regularization: ODE flows are homeomorphisms; augmented NODEs (dupont2019augmented,
   norcliffe2020second); regularizing dynamics (finlay2020train, kelly2020learning); massaroli2020dissecting.
5. Universal differential equations (rackauckas2020universal): hybrid mechanistic + NN; computed Lotka–Volterra
   example with missing interaction term; UDE → sparse regression pipeline (link `ch:sindy`).
6. Latent ODEs, neural SDEs and CDEs (rubanova2019latent, yildiz2019ode2vae, li2020scalable, tzen2019neural,
   kidger2021neural, kidger2020neural, kidger2022neural); FFJORD link to `ch:generative`.
7. Applications & pitfalls: chemical kinetics (owoyele2022chemnode), reduced chaotic dynamics (linot2022data),
   long-rollout stability; software (rackauckas2017differentialequations).
Assignments: neural ODE with adjoint vs backprop-through-solver on a spiral dataset (memory/accuracy);
UDE for Lotka–Volterra with symbolic recovery of the missing term.

---------------------------------------------------------------------------------------------------
## Part III — Physics-Informed and Operator Learning

### Ch 10 Physics-Informed Neural Networks (`ch:pinn`)
1. Neural networks as PDE solvers: trial functions (lagaris1998artificial, dissanayake1994neural);
   the PINN formulation (raissi2019physics, karniadakis2021physics): residual via AD, composite loss,
   collocation points; algorithm box.
2. Worked example 1 (computed): 1D boundary-value problem — full listing, solution & error figure, loss curve.
3. Worked example 2 (computed): viscous Burgers (nu = 0.01/pi) vs spectral reference from
   `burgers_pinn_reference`; Adam then L-BFGS; error figure.
4. Inverse problems: parameter identification from sparse noisy data (computed: infer viscosity/diffusivity);
   hidden fluid mechanics (raissi2020hidden); applications (cai2021physics, haghighat2021physics,
   chen2020physics, kissas2020machine, mao2020physics, jin2021nsfnets).
5. Variational & energy formulations: Deep Ritz (e2018deep), DGM (sirignano2018dgm), VPINNs/hp-VPINNs
   (kharazmi2019variational, kharazmi2021hp), WAN (zang2020weak), energy methods (samaniego2020energy);
   high-dimensional PDEs (han2018solving, hu2024tackling). Comparison table.
6. Constraints: soft vs hard BCs (lagaris trial functions, sukumar2022exact, lu2021physics, berg2018unified),
   periodicity by feature embedding; physics-constrained surrogates without labels (zhu2019physics,
   sun2020surrogate, geneva2020modeling).
7. Theory & honest assessment: error decomposition (approximation/optimization/generalization), bounds
   (shin2020convergence, mishra2023estimates, mishra2022estimates, deryck2024numerical); when PINNs help and
   when classical solvers win (mcgreivy2024weak); software (lu2021deepxde, hennigh2021nvidia).
Assignments: Burgers PINN with ablations (collocation, width/depth, optimizer); inverse PINN for a
diffusion coefficient from sparse noisy data.
(Training pathologies & remedies are Chapter 11 — only foreshadow them here.)

### Ch 11 Training Pathologies and Advanced PINNs (`ch:pinn2`)
1. Failure modes: convection with large beta, reaction, Allen–Cahn, multiscale (krishnapriyan2021characterizing,
   daw2023mitigating); computed failure example.
2. Spectral bias & NTK theory for PINNs (jacot2018neural, rahaman2019spectral, wang2022when): derivation of the
   NTK of a residual loss, eigenvalue disparity between loss terms.
3. Loss balancing: gradient-statistics annealing (wang2021understanding), NTK weights (wang2022when),
   self-adaptive weights (mcclenny2023self), residual-based attention (anagnostopoulos2024residual).
4. Sampling: uniform/LHS/Sobol, RAR & RAD (lu2021deepxde, wu2023comprehensive), importance sampling
   (nabian2021efficient), R3 (daw2023mitigating).
5. Causality & time marching: causal weights (wang2024respecting), seq2seq/curriculum
   (krishnapriyan2021characterizing), parareal PINNs (meng2020ppinn).
6. Architectures: Fourier features (tancik2020fourier, wang2021eigenvector), adaptive activations
   (jagtap2020adaptive), modified MLP (wang2021understanding), PirateNets (wang2024piratenets),
   gradient-enhanced PINNs (yu2022gradient), fractional (pang2019fpinns).
7. Domain decomposition: cPINN (jagtap2020conservative), XPINN (jagtap2020extended), FBPINN
   (moseley2023finite), parallel (shukla2021parallel), local ELMs (dong2021local).
8. Optimization advances (rathore2024challenges, muller2023achieving) and a practitioner's checklist
   (wang2023expert); benchmarks (hao2024pinnacle).
Assignments: reproduce and fix the 1D convection failure (curriculum/causal/Fourier features); adaptive weights +
RAR on a multiscale/Helmholtz or Allen–Cahn problem.

### Ch 12 Structure-Preserving and Symmetry-Aware Learning (`ch:struct`)
1. Why structure: conservation, stability, generalization, Noether (noether1918invariante, arnold1989mathematical).
2. Hamiltonian mechanics & HNNs (greydanus2019hamiltonian): computed pendulum/spring comparison of energy drift
   (baseline MLP vs HNN).
3. Symplectic integration & learning (hairer2006geometric, marsden2001discrete): leapfrog, SRNN
   (chen2020symplectic), SympNets (jin2020sympnets), SymODEN (zhong2020symplectic), HGN (toth2020hamiltonian).
4. Lagrangian NNs (cranmer2020lagrangian, lutter2019deep), explicit constraints (finzi2020simplifying),
   dissipative/port-Hamiltonian (desai2021port), metriplectic/GENERIC (hernandez2021structure, lee2021machine).
5. Hard constraints: divergence-free parameterizations & neural conservation laws (richterpowell2022neural),
   constraint layers (beucler2021enforcing, mohan2020embedding), conservative finite-volume form
   (hansen2023learning).
6. Symmetry: invariance vs equivariance; invariant features & tensor basis (ling2016machine, pope1975more);
   G-CNNs (cohen2016group), steerable/spherical (weiler2018_3d, cohen2018spherical, kondor2018generalization),
   Deep Sets (zaheer2017deep), scalars are universal (villar2021scalars), EGNN (satorras2021en), symmetric
   dynamics models (wang2021incorporating) (bronstein2021geometric).
7. GNNs for physics: message passing (gilmer2017neural, battaglia2018relational, kipf2017semi), interaction
   networks (battaglia2016interaction), GNS (sanchezgonzalez2020learning), MeshGraphNets (pfaff2021learning),
   MP-PDE (brandstetter2022message), HGN integrators (sanchezgonzalez2019hamiltonian); interatomic potentials
   (behler2007generalized, schutt2017schnet, thomas2018tensor, batzner2022e3, batatia2022mace).
Assignments: HNN vs MLP for pendulum/two-body (long-time energy); rotation-equivariant model (invariant
features or EGNN) for an N-body spring system with rotated test sets.

### Ch 13 Operator Learning (`ch:operator`)
1. From functions to operators: parametric PDEs, solution operators, discretization invariance; input
   distributions (GRFs via `grf_1d`, `grf_2d`).
2. Universal approximation of operators (chen1995universal) and DeepONet (lu2021learning): branch/trunk,
   training, POD-DeepONet (lu2022comprehensive); listing; computed example.
3. Neural operators (kovachki2023neural): kernel integral layers, graph kernel network (li2020neural,
   li2020multipole), FNO (li2021fourier) — spectral convolution listing; computed Burgers example with
   resolution transfer.
4. Theory: universal approximation & error bounds (kovachki2021universal, lanthaler2022error), PCA-Net
   (bhattacharya2021model), random features (nelsen2021random), surveys (kovachki2024operator,
   boulle2024mathematical, azizzadenesheli2024neural).
5. Variants: U-FNO (wen2022ufno), F-FNO (tran2023factorized), Geo-FNO (li2023fourier), SFNO (bonev2023spherical),
   transformers (cao2021choose, hao2023gnot), CNO (raonic2023convolutional), multiwavelet (gupta2021multiwavelet),
   U-NO (rahman2023uno), NOMAD (seidman2022nomad); physics-informed DeepONet & PINO (wang2021learning, li2024physics,
   goswami2022physics).
6. Benchmarks & evaluation: PDEBench (takamoto2022pdebench), The Well (ohana2024well), weak baselines
   (mcgreivy2024weak), autoregressive rollouts & error accumulation, PDE-Refiner (lippe2023pderefiner),
   gupta2023towards, brandstetter2022message.
7. Foundation models for PDEs: MPP (mccabe2023multiple), Poseidon (herde2024poseidon), scaling
   (subramanian2023towards); FourCastNet (pathak2022fourcastnet) as an application (details in `ch:hybrid`).
Assignments: DeepONet vs FNO on 1D Burgers (`burgers_operator_dataset`), incl. resolution transfer; FNO on 2D
Darcy (`darcy_dataset`, small scale).

---------------------------------------------------------------------------------------------------
## Part IV — Uncertainty, Inference, and Hybrid Modeling

### Ch 14 Inverse Problems and Bayesian Inference (`ch:inverse`)
1. Inverse problems & ill-posedness (hadamard1902problemes): deconvolution, backward heat, parameter
   estimation, tomography, seismic FWI (tarantola1984inversion, virieux2009overview) (kaipio2005statistical,
   tarantola2005inverse, isakov2017inverse).
2. Regularization: Tikhonov (tikhonov1977solutions), SVD filter view, L-curve (hansen1992analysis), discrepancy
   principle, TV (rudin1992nonlinear) (engl1996regularization, hansen2010discrete, vogel2002computational);
   computed 1D deblurring figure.
3. PDE-constrained optimization: reduced formulation, adjoint gradients (refer to `ch:ad`), Gauss–Newton.
4. Bayesian inversion (stuart2010inverse, dashti2017bayesian, calvetti2007introduction): linear-Gaussian
   closed form, MAP = Tikhonov, function-space priors (GRFs), buithanh2013computational.
5. Sampling: Metropolis–Hastings (metropolis1953equation, hastings1970monte), adaptive MH (haario2001adaptive),
   Gibbs (geman1984stochastic, gelfand1990sampling), MALA (roberts1996exponential), HMC (duane1987hybrid,
   neal2011mcmc), NUTS (hoffman2014no), pCN (cotter2013mcmc), stochastic Newton (martin2012stochastic);
   diagnostics; listing for ODE parameter inference.
6. Variational inference & Laplace (blei2017variational, jordan1999introduction).
7. Data assimilation: Kalman (kalman1960new), EnKF (evensen1994sequential, evensen2009data), EKI
   (iglesias2013ensemble, schillings2017analysis, kovachki2019ensemble), 4D-Var (ledimet1986variational)
   (law2015data, reich2015probabilistic, carrassi2018data).
8. ML for inverse problems: surrogate-accelerated inference (marzouk2007stochastic, cleary2021calibrate),
   learned reconstruction & unrolling (adler2018learned, jin2017deep, monga2021algorithm, gregor2010learning),
   plug-and-play (venkatakrishnan2013plug), generative priors (patel2022solution, chung2023diffusion),
   simulation-based inference (cranmer2020frontier, papamakarios2016fast, greenberg2019automatic,
   radev2022bayesflow, tejero2020sbi, beaumont2002approximate) (arridge2019solving, ongie2020deep).
Assignments: Bayesian calibration of an ODE model with MH and a surrogate; EKI vs adjoint-gradient inversion for
a heat-equation conductivity field (`heat_fd`).

### Ch 15 Uncertainty Quantification (`ch:uq`)
1. Sources & taxonomy: aleatoric vs epistemic (derkiureghian2009aleatory, hullermeier2021aleatoric), model-form;
   forward vs inverse UQ; scoring rules & calibration (gneiting2007strictly) (smith2013uncertainty,
   sullivan2015introduction).
2. Monte Carlo & variance reduction: MC rates, LHS (mckay1979comparison), QMC (caflisch1998monte), multilevel and
   multifidelity MC (giles2008multilevel, giles2015multilevel, peherstorfer2018survey).
3. Polynomial chaos (wiener1938homogeneous, ghanem1991stochastic, xiu2002wiener, xiu2010numerical,
   lemaitre2010spectral): projection & regression; computed example.
4. Global sensitivity analysis: Sobol indices (sobol2001global, saltelli2008global) and from PCE (sudret2008global);
   active subspaces (constantine2014active, constantine2015active).
5. Gaussian processes (rasmussen2006gaussian): derivation, kernels, hyperparameters, listing from scratch;
   physics-informed GPs (raissi2017machine, raissi2017inferring, chen2021solving, owhadi2015bayesian);
   multifidelity (kennedy2000predicting, perdikaris2017nonlinear, meng2020composite); calibration
   (kennedy2001bayesian); scalability (titsias2009variational, hensman2013gaussian, wilson2015kernel,
   gardner2018gpytorch); Bayesian optimization briefly (jones1998efficient, snoek2012practical, frazier2018tutorial).
6. Bayesian neural networks: posterior over weights (mackay1992practical, neal1996bayesian), Bayes by backprop
   (blundell2015weight), MC dropout (gal2016dropout), deep ensembles (lakshminarayanan2017simple), Laplace
   (daxberger2021laplace), SGLD (welling2011bayesian), HMC posteriors (izmailov2021what), B-PINNs (yang2021bpinns),
   surrogates (zhu2018bayesian, tripathy2018deep).
7. Distribution-free UQ: split conformal prediction (vovk2005algorithmic, lei2018distribution,
   angelopoulos2023conformal) — listing.
8. Comparing methods & recommendations (psaros2023uncertainty, zou2024neuraluq, guo2017calibration).
Assignments: forward UQ for an ODE with uncertain parameters (MC vs PCE vs GP surrogate; Sobol indices);
ensembles vs MC dropout vs conformal for a neural surrogate including out-of-distribution tests.

### Ch 16 Generative Models for Science (`ch:generative`)
1. Why generative models in science: ensembles, Boltzmann sampling, downscaling, priors for inverse problems,
   design (bondtaylor2022deep).
2. VAEs (kingma2014auto, rezende2014stochastic, kingma2019introduction, higgins2017beta): ELBO derivation,
   reparameterization.
3. GANs briefly (goodfellow2014generative, arjovsky2017wasserstein, heusel2017gans); physics uses
   (paganini2018calogan, ravuri2021skilful, yang2020physics).
4. Normalizing flows (rezende2015variational, dinh2017density, papamakarios2017masked, durkan2019neural,
   papamakarios2021normalizing, kobyzev2021normalizing); continuous flows (chen2018neural,
   grathwohl2019ffjord); Boltzmann generators (noe2019boltzmann).
5. Diffusion/score-based models (sohldickstein2015deep, ho2020denoising, song2019generative, song2021score,
   song2021denoising, karras2022elucidating, kingma2021variational, song2021maximum): forward noising, DDPM
   objective, denoising score matching (hyvarinen2005estimation, vincent2011connection), reverse SDE
   (anderson1982reverse), probability-flow ODE, guidance (dhariwal2021diffusion, ho2022classifier),
   latent diffusion (rombach2022high). Listing: toy 2D diffusion model with computed figure.
6. Flow matching & stochastic interpolants (lipman2023flow, liu2023flow, albergo2023building).
7. Scientific applications: probabilistic weather (price2025probabilistic, li2024generative), downscaling
   (mardani2025residual), turbulence (shu2023physics, kohl2023benchmarking, lippe2023pderefiner,
   fukami2019super, kim2021unsupervised), molecules/materials/proteins (hoogeboom2022equivariant,
   xie2022crystal, zeni2025generative, watson2023novo, abramson2024accurate), inverse problems
   (chung2023diffusion), data assimilation (rozet2023score), SBI (cranmer2020frontier).
8. Evaluating generative models in science: statistics, spectra, CRPS, physical constraints; FID limits.
Assignments: DDPM vs flow matching on 2D toy data and then on 1D GRF fields with spectral validation;
conditional generation for a simple inverse problem.

### Ch 17 Hybrid Modeling, Closures, and Learned Simulators (`ch:hybrid`)
1. The closure problem: filtering/averaging, unclosed terms in RANS, LES, ROMs, climate; multiscale
   (pope2000turbulent, sanderse2025scientific).
2. Classical closures: eddy viscosity, Smagorinsky (smagorinsky1963general), dynamic model (germano1991dynamic).
3. Data-driven RANS (duraisamy2019turbulence, xiao2019quantification): tensor-basis NN (ling2016reynolds,
   pope1975more), field inversion & ML (parish2016paradigm, singh2017machine), discrepancy learning
   (wang2017physics), symbolic closures (weatheritt2016novel).
4. Data-driven LES & climate parameterizations: a priori vs a posteriori; stability (gamahara2017searching,
   maulik2019subgrid, beck2019deep, guan2022stable, rasp2018deep, brenowitz2018prognostic, yuval2020stable,
   bolton2019applications, zanna2020data, ross2023benchmarking, schneider2017earth, eyring2024pushing).
5. Differentiable solvers & solver-in-the-loop (um2020solver, barsinai2019learning, kochkov2021machine,
   list2022learned, frezat2022posteriori, sirignano2020dpm, gelbrecht2023differentiable, shen2023differentiable);
   computed example: learned correction for coarse Burgers trained a priori vs through the solver.
6. ML weather & climate prediction (bauer2015quiet, schultz2021can, rasp2020weatherbench, rasp2024weatherbench,
   weyn2020improving, keisler2022forecasting, pathak2022fourcastnet, kurth2023fourcastnet, lam2023learning,
   bi2023accurate, chen2023fuxi, lang2024aifs, price2025probabilistic, kochkov2024neural, bodnar2025foundation,
   benbouallegue2024rise): what they do and do not do.
7. RL for flow control & closures (rabault2019artificial, novati2021automating, degrave2022magnetic); hybrid
   forecasting (pathak2018hybrid, wan2018data).
8. Design principles for hybrid models.
Assignments: learned closure for coarse Burgers (a priori vs a posteriori through a differentiable solver;
stability); two-scale Lorenz-96 with an NN parameterization of the fast variables.

### Ch 18 SciML in Practice: Workflows, Reproducibility, and Frontiers (`ch:practice`)
1. The SciML workflow and choosing a method: decision table mapping tasks → methods/chapters; baselines first.
2. Data: generation & design of experiments, normalization, physics-respecting splits (temporal/parametric
   extrapolation), leakage (kapoor2023leakage), FAIR data (wilkinson2016fair).
3. Evaluation: metrics (relative L2, spectra, invariants, rollouts), V&V (oberkampf2010verification,
   roache1997quantification), UQ (`ch:uq`), cost accounting incl. data generation and break-even analysis;
   weak baselines (mcgreivy2024weak).
4. Reproducibility & software engineering (sandve2013ten, wilson2014best, pineau2021improving,
   gundersen2018state, hutson2018artificial, baker2016reproducibility): seeds/determinism, environments,
   testing numerical code, model cards & datasheets (mitchell2019model, gebru2021datasheets),
   technical debt (sculley2015hidden), scholarship (lipton2019troubling).
5. Scaling & hardware: GPUs, mixed precision, distributed training, memory; energy (strubell2019energy).
6. Interpretability & trust (rudin2019stop, ribeiro2016should, lundberg2017unified); physical consistency checks.
7. Frontiers: foundation models for science (bommasani2021opportunities, kaplan2020scaling,
   subramanian2023towards, mccabe2023multiple, herde2024poseidon, bodnar2025foundation), digital twins
   (niederer2021scaling, kapteyn2021probabilistic, nasem2024foundational), AI-driven discovery
   (wang2023scientific, merchant2023scaling, lavin2021simulation), open problems.
8. Ethics & responsible use.
Assignments: end-to-end mini-project with a reproducibility checklist and report; critical replication of a
published SciML claim at small scale against a strong classical baseline.

---------------------------------------------------------------------------------------------------
## Appendices (written by the editor)
A Python, NumPy, and PyTorch for Scientific Computing (`app:python`);
B Probability and Statistics Refresher (`app:prob`);
C Course Design, Projects, and Assessment (`app:course`).

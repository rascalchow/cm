"""Appendix A: NumPy essentials -- broadcasting, linear algebra, FFT derivatives."""
import numpy as np

rng = np.random.default_rng(seed=0)            # reproducible random numbers

# --- broadcasting: all pairwise distances between N points in R^d, no loops
X = rng.standard_normal((500, 3))
D = np.sqrt(((X[:, None, :] - X[None, :, :]) ** 2).sum(axis=-1))   # (500, 500)
print("pairwise distance matrix:", D.shape, "symmetric:", np.allclose(D, D.T))

# --- dense linear algebra
A = rng.standard_normal((200, 50))
b = rng.standard_normal(200)
x_ls, *_ = np.linalg.lstsq(A, b, rcond=None)     # least squares via SVD
U, s, Vt = np.linalg.svd(A, full_matrices=False)  # thin SVD
x_svd = Vt.T @ ((U.T @ b) / s)
print("lstsq vs SVD solution agree:", np.allclose(x_ls, x_svd))
print("condition number of A: %.2f" % (s[0] / s[-1]))

# --- spectral differentiation of a periodic function with the FFT
n, L = 64, 2 * np.pi
x = L * np.arange(n) / n
k = 2 * np.pi * np.fft.fftfreq(n, d=L / n)        # angular wavenumbers
u = np.exp(np.sin(x))
du = np.real(np.fft.ifft(1j * k * np.fft.fft(u)))
print("max error of spectral derivative: %.2e" % np.abs(du - np.cos(x) * u).max())

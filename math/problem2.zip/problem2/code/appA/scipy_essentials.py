"""Appendix A: SciPy essentials -- ODEs, sparse linear systems, optimization."""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize
import scipy.sparse as sp
import scipy.sparse.linalg as spla

# --- ODE: Lorenz-63 with an adaptive 8th-order Runge-Kutta method
def lorenz(t, z, sigma=10.0, rho=28.0, beta=8.0 / 3.0):
    x, y, w = z
    return [sigma * (y - x), x * (rho - w) - y, x * y - beta * w]

sol = solve_ivp(lorenz, (0.0, 20.0), [-8.0, 8.0, 27.0], method="DOP853",
                rtol=1e-10, atol=1e-12, t_eval=np.linspace(0, 20, 2001))
print("Lorenz: success =", sol.success, " final state =", np.round(sol.y[:, -1], 3))

# --- sparse 1D Poisson problem -u'' = pi^2 sin(pi x), u(0) = u(1) = 0
n = 999
h = 1.0 / (n + 1)
xg = np.linspace(h, 1 - h, n)
A = sp.diags([-1.0, 2.0, -1.0], [-1, 0, 1], shape=(n, n), format="csc") / h**2
u = spla.spsolve(A, np.pi**2 * np.sin(np.pi * xg))
print("Poisson: max error = %.2e (expected O(h^2) = %.1e)"
      % (np.abs(u - np.sin(np.pi * xg)).max(), h**2))

# --- optimization: Rosenbrock function with L-BFGS-B and an analytic gradient
def rosen(p):
    return (1 - p[0])**2 + 100 * (p[1] - p[0]**2)**2

def rosen_grad(p):
    return np.array([-2 * (1 - p[0]) - 400 * p[0] * (p[1] - p[0]**2),
                     200 * (p[1] - p[0]**2)])

res = minimize(rosen, x0=[-1.2, 1.0], jac=rosen_grad, method="L-BFGS-B")
print("Rosenbrock minimizer:", np.round(res.x, 6), " iterations:", res.nit)

"""Appendix A: PyTorch essentials -- autograd, higher derivatives, a training loop."""
import torch

torch.manual_seed(0)
torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)          # double precision for scientific work

# --- autograd: first and second derivatives of u(x) = sin(x) * exp(-x)
x = torch.linspace(0.0, 3.0, 7, requires_grad=True)
u = torch.sin(x) * torch.exp(-x)
du = torch.autograd.grad(u.sum(), x, create_graph=True)[0]   # keep graph for 2nd derivative
d2u = torch.autograd.grad(du.sum(), x)[0]
exact = -2.0 * torch.cos(x) * torch.exp(-x)
print("max error of u'' via autograd: %.1e" % (d2u - exact).abs().max().item())

# --- a small multilayer perceptron fitted to noisy data
class MLP(torch.nn.Module):
    def __init__(self, width=32, depth=3):
        super().__init__()
        layers, d_in = [], 1
        for _ in range(depth):
            layers += [torch.nn.Linear(d_in, width), torch.nn.Tanh()]
            d_in = width
        layers.append(torch.nn.Linear(d_in, 1))
        self.net = torch.nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)

xs = torch.linspace(-1, 1, 200).unsqueeze(1)                  # shape (200, 1)
ys = torch.sin(3 * xs) + 0.05 * torch.randn_like(xs)
model = MLP()
opt = torch.optim.Adam(model.parameters(), lr=1e-2)
for epoch in range(2000):
    opt.zero_grad()                                           # 1. reset gradients
    loss = torch.mean((model(xs) - ys) ** 2)                  # 2. forward pass + loss
    loss.backward()                                           # 3. backpropagation
    opt.step()                                                # 4. parameter update
print("final training MSE: %.2e (noise variance 2.5e-03)" % loss.item())

# --- gradient check against finite differences
f = lambda p: (torch.sin(p) * p**2).sum()
p = torch.randn(5, requires_grad=True)
print("gradcheck passed:", torch.autograd.gradcheck(f, (p,)))

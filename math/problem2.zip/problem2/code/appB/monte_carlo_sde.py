"""Appendix B: Monte Carlo, importance sampling, and Euler-Maruyama for an OU process."""
import numpy as np

rng = np.random.default_rng(0)

# Monte Carlo estimate of E[f(X)], X ~ N(0,1), f(x) = x^2 (exact value 1)
for N in (10**2, 10**4, 10**6):
    fx = rng.standard_normal(N) ** 2
    print("N=%7d  estimate=%.4f  std.error=%.4f" % (N, fx.mean(), fx.std(ddof=1) / np.sqrt(N)))

# Importance sampling for the tail probability P(X > 4), X ~ N(0,1)  (exact 3.167e-05)
N = 10**5
naive = (rng.standard_normal(N) > 4).mean()
y = rng.normal(4.0, 1.0, N)                          # proposal q = N(4, 1)
w = np.exp(-0.5 * y**2) / np.exp(-0.5 * (y - 4.0)**2)   # weights p(y)/q(y)
print("naive MC: %.3e   importance sampling: %.3e" % (naive, np.mean((y > 4) * w)))

# Euler-Maruyama for dX = -theta X dt + sigma dW; stationary law N(0, sigma^2 / (2 theta))
theta, sigma, dt, nsteps, M = 1.0, 0.5, 1e-3, 5000, 20000
X = np.zeros(M)
for _ in range(nsteps):
    X += -theta * X * dt + sigma * np.sqrt(dt) * rng.standard_normal(M)
print("OU variance at t=5: %.4f  (stationary value %.4f)" % (X.var(), sigma**2 / (2 * theta)))

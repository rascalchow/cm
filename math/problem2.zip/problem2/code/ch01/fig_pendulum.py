"""Figure 1.x: black-box, mechanistic and hybrid models of a damped pendulum.

(a) angle theta(t): truth, noisy training data on [0, 10], and the three forecasts;
(b) pointwise forecast error |theta_model - theta_true| on a log scale;
(c) damping law: true g(om) = -c1 om - c2 om|om|, the misspecified linear law -c om,
    and the network g_phi learned inside the hybrid model.
Run from the project root:  python3 code/ch01/fig_pendulum.py   (a few minutes)
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
import pendulum_models as pm  # noqa: E402

set_style()
res = pm.run_all(seed=0)
t, x = res["t_fine"], res["x_fine"]
styles = {"black box": dict(color=COLORS["orange"], ls="-"),
          "mechanistic": dict(color=COLORS["green"], ls="-"),
          "hybrid": dict(color=COLORS["blue"], ls="--")}

fig = plt.figure(figsize=(FULL_WIDTH, 3.4))
gs = fig.add_gridspec(2, 2, height_ratios=[1.0, 1.0], hspace=0.55, wspace=0.28)
ax0 = fig.add_subplot(gs[0, :])
ax0.axvspan(0, pm.T_TRAIN, color=COLORS["gray"], alpha=0.08, lw=0)
ax0.plot(t, x[:, 0], color="k", lw=2.2, alpha=0.25, label="truth")
ax0.plot(res["t_obs"], res["th_obs"], ".", color=COLORS["gray"], ms=2.5, label="data")
for name, st in styles.items():
    ax0.plot(t, res["preds"][name](t), lw=1.1, label=name, **st)
ax0.set_ylim(-2.6, 2.6)
ax0.set_xlim(0, pm.T_END)
ax0.text(0.3, 2.15, "training window", fontsize=7, color=COLORS["gray"])
ax0.text(pm.T_TRAIN + 0.3, 2.15, "forecast", fontsize=7, color=COLORS["gray"])
ax0.set_xlabel("time $t$")
ax0.set_ylabel(r"angle $\theta$")
ax0.set_title(r"(a) trajectories")
ax0.legend(ncol=5, fontsize=7, loc="lower center", bbox_to_anchor=(0.5, 0.98), frameon=False)
ax0.set_title("")
ax0.text(-0.07, 1.02, "(a)", transform=ax0.transAxes, fontsize=9)

ax1 = fig.add_subplot(gs[1, 0])
for name, st in styles.items():
    ax1.semilogy(t, np.abs(res["preds"][name](t) - x[:, 0]) + 1e-12, lw=0.9, **st)
ax1.axvline(pm.T_TRAIN, color=COLORS["gray"], lw=0.6)
ax1.set_ylim(1e-5, 10)
ax1.set_xlim(0, pm.T_END)
ax1.set_xlabel("time $t$")
ax1.set_ylabel(r"$|\theta-\theta_{\mathrm{true}}|$")
ax1.set_title("(b) pointwise error")

ax2 = fig.add_subplot(gs[1, 1])
om = np.linspace(-3, 3, 301)
lo, hi = x[t <= pm.T_TRAIN, 1].min(), x[t <= pm.T_TRAIN, 1].max()
ax2.axvspan(lo, hi, color=COLORS["gray"], alpha=0.08, lw=0)
ax2.plot(om, pm.true_damping(om), color="k", lw=2.2, alpha=0.25, label="true")
ax2.plot(om, -res["p_lin"][1] * om, color=COLORS["green"], lw=1.1, label="linear fit")
ax2.plot(om, pm.g_phi(om, res["p_hyb"][None]), color=COLORS["blue"], ls="--", lw=1.1,
         label=r"learned $g_\phi$")
ax2.set_ylim(-3, 3)
ax2.set_xlabel(r"angular velocity $\dot\theta$")
ax2.set_ylabel("damping torque")
ax2.set_title("(c) damping law")
ax2.legend(fontsize=7, loc="upper right")
print(savefig(fig, "ch01", "pendulum"))

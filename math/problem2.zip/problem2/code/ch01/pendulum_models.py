"""Chapter 1 worked example: black-box vs mechanistic vs hybrid models of a pendulum.

Ground truth: a pendulum with linear *and* quadratic (aerodynamic) damping,
    theta'' = -omega0^2 sin(theta) - c1 theta' - c2 theta' |theta'|.
We observe noisy angles theta(t_i) on the training window [0, T_TRAIN] and ask
three models to forecast the angle on [T_TRAIN, T_END]:
  (i)   black box  : an MLP regression t -> theta(t)                 (PyTorch)
  (ii)  mechanistic: theta'' = -w^2 sin(theta) - c theta'            (fit w, c)
  (iii) hybrid     : theta'' = -w^2 sin(theta) + g_phi(theta')        (fit w and a
                     one-hidden-layer tanh network g_phi; NumPy + SciPy)
The initial state X0 is assumed known for (ii) and (iii).
Run from the project root:  python3 code/ch01/pendulum_models.py
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys
import time

import numpy as np
import torch
from scipy.integrate import solve_ivp
from scipy.optimize import least_squares

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import integrate  # noqa: E402

torch.set_num_threads(2)

OMEGA0, C1, C2 = 2.0, 0.05, 0.25       # true parameters
X0 = (2.0, 0.0)                         # initial angle [rad] and angular velocity
T_TRAIN, T_END, DT_OBS, NOISE = 10.0, 30.0, 0.1, 0.02


def true_rhs(t, x):
    th, om = x
    return [om, -OMEGA0 ** 2 * np.sin(th) - C1 * om - C2 * om * abs(om)]


def true_damping(om):
    return -C1 * om - C2 * om * np.abs(om)


def make_data(seed=0, t_train=T_TRAIN, noise=NOISE, dt_obs=DT_OBS):
    """Noise-free truth on a fine grid and noisy observations on [0, t_train]."""
    rng = np.random.default_rng(seed)
    t_fine = np.linspace(0.0, T_END, 3001)
    x_fine = integrate(true_rhs, X0, t_fine)
    t_obs = np.arange(0.0, t_train + 1e-9, dt_obs)
    th_obs = integrate(true_rhs, X0, t_obs)[:, 0] + noise * rng.standard_normal(len(t_obs))
    return t_fine, x_fine, t_obs, th_obs


# ----------------------------------------------------------------- (i) black box
def fit_black_box(t_obs, th_obs, seed=0, iters=300):
    """MLP t -> theta(t), 2 x 64 tanh, trained by L-BFGS on the mean-squared misfit."""
    torch.manual_seed(seed)
    net = torch.nn.Sequential(torch.nn.Linear(1, 64), torch.nn.Tanh(),
                              torch.nn.Linear(64, 64), torch.nn.Tanh(),
                              torch.nn.Linear(64, 1)).double()
    scale = t_obs.max()
    tt = torch.tensor(t_obs[:, None] / scale)
    yy = torch.tensor(th_obs[:, None])
    opt = torch.optim.LBFGS(net.parameters(), lr=1.0, max_iter=iters,
                            history_size=50, line_search_fn="strong_wolfe")

    def closure():
        opt.zero_grad()
        loss = torch.mean((net(tt) - yy) ** 2)
        loss.backward()
        return loss
    opt.step(closure)

    def predict(t):
        with torch.no_grad():
            return net(torch.tensor(np.asarray(t, float)[:, None] / scale)).numpy().ravel()
    return predict


# ----------------------------------------------------------------- (ii) mechanistic
def fit_mechanistic(t_obs, th_obs, drag="linear"):
    """Least-squares fit of the physical parameters through an ODE solver."""
    def rhs(p):
        if drag == "linear":            # assumed (misspecified) model
            w, c = p
            return lambda t, x: [x[1], -w ** 2 * np.sin(x[0]) - c * x[1]]
        w, c1, c2 = p                   # correct functional form (reference only)
        return lambda t, x: [x[1], -w ** 2 * np.sin(x[0]) - c1 * x[1] - c2 * x[1] * abs(x[1])]

    def simulate(p, t):
        sol = solve_ivp(rhs(p), (0, t[-1]), X0, t_eval=t, rtol=1e-9, atol=1e-11)
        return sol.y[0]
    p0 = [1.5, 0.1] if drag == "linear" else [1.5, 0.1, 0.1]
    res = least_squares(lambda p: simulate(p, t_obs) - th_obs, p0)
    return (lambda t: simulate(res.x, np.asarray(t, float))), res.x


# ----------------------------------------------------------------- (iii) hybrid
H = 8                                    # hidden neurons of the damping network


def g_phi(om, p):                        # learned damping; g(0) = 0 by construction
    W1, b1, W2 = p[:, 1:1 + H], p[:, 1 + H:1 + 2 * H], p[:, 1 + 2 * H:]
    return np.sum(W2 * (np.tanh(W1 * om[:, None] + b1) - np.tanh(b1)), axis=1)


def hybrid_rhs(x, p):                    # x: (B, 2) states, p: (B, 1 + 3H) parameters
    w, th, om = np.exp(p[:, 0]), x[:, 0], x[:, 1]
    return np.stack([om, -w ** 2 * np.sin(th) + g_phi(om, p)], axis=1)


def rollout(p, n_steps, dt):             # RK4 for all rows of p at once -> theta, (B, n+1)
    x = np.tile(np.asarray(X0, float), (p.shape[0], 1))
    out = [x[:, 0]]
    for _ in range(n_steps):
        k1 = hybrid_rhs(x, p)
        k2 = hybrid_rhs(x + 0.5 * dt * k1, p)
        k3 = hybrid_rhs(x + 0.5 * dt * k2, p)
        k4 = hybrid_rhs(x + dt * k3, p)
        x = x + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        out.append(x[:, 0])
    return np.stack(out, axis=1)


def fit_hybrid(t_obs, th_obs, seed=0, dt=0.1, lam=1e-4):
    """Levenberg-Marquardt on the trajectory misfit, plus a small ridge penalty on phi."""
    rng = np.random.default_rng(seed)
    sub = int(round((t_obs[1] - t_obs[0]) / dt))      # solver steps per observation
    n = sub * (len(t_obs) - 1)
    p0 = np.concatenate([[np.log(1.5)], rng.normal(0, 1, H), rng.normal(0, 1, H),
                         np.zeros(H)])

    def resid(P):                                     # residuals for a batch of parameters
        misfit = rollout(P, n, dt)[:, ::sub] - th_obs
        return np.concatenate([misfit, np.sqrt(lam) * P[:, 1:]], axis=1)

    def jac(p, eps=1e-6):                             # finite differences, one batched rollout
        P = np.vstack([p, p + eps * np.eye(len(p))])
        R = resid(P)
        return ((R[1:] - R[0]) / eps).T

    res = least_squares(lambda p: resid(p[None])[0], p0, jac=jac, method="lm",
                        ftol=1e-6, xtol=1e-6)

    def predict(t, dt_pred=0.005):                    # fine steps for smooth output
        t = np.asarray(t, float)
        m = int(np.ceil(t[-1] / dt_pred))
        return np.interp(t, dt_pred * np.arange(m + 1), rollout(res.x[None], m, dt_pred)[0])
    return predict, res.x


def rmse(a, b):
    return float(np.sqrt(np.mean((a - b) ** 2)))


def run_all(seed=0, t_train=T_TRAIN, noise=NOISE, dt_obs=DT_OBS, verbose=True):
    t_fine, x_fine, t_obs, th_obs = make_data(seed, t_train, noise, dt_obs)
    fits, cost = {}, {}
    for name, fitter in [("black box", lambda: fit_black_box(t_obs, th_obs, seed)),
                         ("mechanistic", lambda: fit_mechanistic(t_obs, th_obs, "linear")),
                         ("mechanistic (true form)",
                          lambda: fit_mechanistic(t_obs, th_obs, "quadratic")),
                         ("hybrid", lambda: fit_hybrid(t_obs, th_obs, seed))]:
        tic = time.time()
        fits[name] = fitter()
        cost[name] = time.time() - tic
    preds = {k: (v[0] if isinstance(v, tuple) else v) for k, v in fits.items()}
    tr, te = t_fine <= t_train, t_fine > t_train
    table = {}
    for name, f in preds.items():
        y = f(t_fine)
        table[name] = (rmse(y[tr], x_fine[tr, 0]), rmse(y[te], x_fine[te, 0]))
        if verbose:
            print("%-24s train RMSE %.4f   forecast RMSE %.4f   (fit %.1f s)"
                  % (name, *table[name], cost[name]), flush=True)
    p_hyb = fits["hybrid"][1]
    if verbose:
        print("fitted (w, c) of linear-drag model:", fits["mechanistic"][1])
        print("fitted (w, c1, c2) of true-form model:", fits["mechanistic (true form)"][1])
        print("hybrid fitted w: %.4f" % np.exp(p_hyb[0]))
        om = np.linspace(-1.5, 1.5, 7)
        print("hybrid g(om) :", np.round(g_phi(om, p_hyb[None]), 3))
        print("true   g(om) :", np.round(true_damping(om), 3))
        print("range of theta' on training window: [%.2f, %.2f]"
              % (x_fine[tr, 1].min(), x_fine[tr, 1].max()))
    return dict(t_fine=t_fine, x_fine=x_fine, t_obs=t_obs, th_obs=th_obs, preds=preds,
                table=table, p_lin=fits["mechanistic"][1], p_hyb=p_hyb)


if __name__ == "__main__":
    run_all()

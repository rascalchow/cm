"""Figure 2.x: polynomial interpolation (Runge phenomenon) and spectral vs finite differences.

(a) interpolants of f(x) = 1/(1 + 25 x^2) through 11 equispaced / Chebyshev points;
(b) max-norm interpolation error versus the number of points n;
(c) error of the derivative of u = exp(sin x) on a periodic grid of N points:
    second- and fourth-order central differences versus the Fourier spectral derivative.
Run from the project root:  python3 code/ch02/fig_approximation.py
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys

import matplotlib.pyplot as plt
import numpy as np
from scipy.interpolate import BarycentricInterpolator

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402


def runge(x):
    return 1.0 / (1.0 + 25.0 * x ** 2)


def nodes(n, kind):
    if kind == "equi":
        return np.linspace(-1, 1, n)
    return np.cos(np.pi * np.arange(n) / (n - 1))           # Chebyshev points (2nd kind)


def spectral_derivative(u, length=2 * np.pi):
    """Derivative of a periodic grid function via the FFT (Nyquist mode set to zero)."""
    n = len(u)
    k = 2 * np.pi * np.fft.fftfreq(n, d=length / n)
    if n % 2 == 0:
        k[n // 2] = 0.0
    return np.real(np.fft.ifft(1j * k * np.fft.fft(u)))


def fd_derivative(u, h, order):
    if order == 2:
        return (np.roll(u, -1) - np.roll(u, 1)) / (2 * h)
    return (-np.roll(u, -2) + 8 * np.roll(u, -1) - 8 * np.roll(u, 1) + np.roll(u, 2)) / (12 * h)


set_style()
fig, ax = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.15))
xf = np.linspace(-1, 1, 2001)

# (a) the Runge phenomenon
n = 11
ax[0].plot(xf, runge(xf), color="k", lw=1.0, label="$f$")
for kind, c, lab in [("equi", COLORS["orange"], "equispaced"), ("cheb", COLORS["blue"], "Chebyshev")]:
    xn = nodes(n, kind)
    ax[0].plot(xf, BarycentricInterpolator(xn, runge(xn))(xf), color=c, label=lab)
    ax[0].plot(xn, runge(xn), "o", color=c, ms=2.5)
ax[0].set_ylim(-0.5, 2.6)
ax[0].set_xlabel("$x$")
ax[0].set_title("(a) interpolation, $n=11$")
ax[0].legend(fontsize=7, loc="upper center")

# (b) convergence of interpolation
ns = np.arange(5, 66, 4)
for kind, c, lab in [("equi", COLORS["orange"], "equispaced"), ("cheb", COLORS["blue"], "Chebyshev")]:
    err = [np.max(np.abs(BarycentricInterpolator(nodes(m, kind), runge(nodes(m, kind)))(xf)
                         - runge(xf))) for m in ns]
    ax[1].semilogy(ns, err, "o-", color=c, ms=2.5, label=lab)
    print(kind, "errors:", ["%.1e" % e for e in err[::4]])
rho = 0.2 + np.sqrt(1.04)                                 # Bernstein ellipse through +-i/5
ax[1].semilogy(ns, 2.0 * rho ** (-ns.astype(float)), "--", color=COLORS["gray"], lw=1,
               label=r"$\rho^{-n}$, $\rho=1.22$")
ax[1].set_ylim(1e-12, 1e11)
ax[1].set_xlabel("number of points $n$")
ax[1].set_ylabel("max error")
ax[1].set_title("(b) interpolation error")
ax[1].legend(fontsize=7, loc="lower left")

# (c) differentiation of a smooth periodic function
Ns = 2 ** np.arange(3, 11)
errs = {2: [], 4: [], "spec": []}
for N in Ns:
    x = 2 * np.pi * np.arange(N) / N
    u, du = np.exp(np.sin(x)), np.cos(x) * np.exp(np.sin(x))
    h = x[1] - x[0]
    errs[2].append(np.max(np.abs(fd_derivative(u, h, 2) - du)))
    errs[4].append(np.max(np.abs(fd_derivative(u, h, 4) - du)))
    errs["spec"].append(np.max(np.abs(spectral_derivative(u) - du)))
ax[2].loglog(Ns, errs[2], "o-", color=COLORS["orange"], ms=2.5, label="FD, 2nd order")
ax[2].loglog(Ns, errs[4], "s-", color=COLORS["green"], ms=2.5, label="FD, 4th order")
ax[2].loglog(Ns, errs["spec"], "^-", color=COLORS["blue"], ms=2.5, label="Fourier spectral")
ax[2].loglog(Ns, 20.0 * Ns ** -2.0, ":", color=COLORS["gray"], lw=1)
ax[2].loglog(Ns, 400.0 * Ns ** -4.0, ":", color=COLORS["gray"], lw=1)
ax[2].text(150, 3e-6, "$N^{-2}$", fontsize=7)
ax[2].text(150, 1e-10, "$N^{-4}$", fontsize=7)
ax[2].set_ylim(1e-16, 1e5)
ax[2].set_xlabel("grid points $N$")
ax[2].set_title(r"(c) derivative of $e^{\sin x}$")
ax[2].legend(fontsize=7, loc="upper right")
for k in errs:
    print("derivative error", k, ["%.1e" % e for e in errs[k]])
fig.tight_layout(w_pad=0.6)
print(savefig(fig, "ch02", "approximation"))

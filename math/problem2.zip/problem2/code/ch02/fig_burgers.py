"""Figure 2.x: viscous Burgers equation with the pseudo-spectral ETDRK4 solver.

PDE (the PINN benchmark of Chapters 10-11):
    u_t + u u_x = nu u_xx,  x in [-1, 1) periodic,  u(x, 0) = -sin(pi x),  t in [0, 1].
(a) snapshots u(x, t);  (b) space-time plot;  (c) spatial convergence of the error at
t = 1 versus the number of Fourier modes N for two viscosities;  (d) temporal convergence
versus the time step dt at fixed N = 512 (fourth order).
Run from the project root:  python3 code/ch02/fig_burgers.py   (about 3-5 minutes)
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from sciml_data import burgers_periodic  # noqa: E402

NU = 0.01 / np.pi


def solve(N, dt, nu=NU, t_save=(0.0, 1.0)):
    """ETDRK4 pseudo-spectral solution on N equispaced points of [-1, 1)."""
    x = np.linspace(-1, 1, N, endpoint=False)
    return x, burgers_periodic(-np.sin(np.pi * x), nu, length=2.0,
                               t_save=np.asarray(t_save), dt=dt)


def fourier_interp(u, M):
    """Evaluate the trigonometric interpolant of grid data u on M >= len(u) points."""
    N = len(u)
    c = np.fft.rfft(u)
    c[-1] *= 0.5 if N % 2 == 0 else 1.0               # split the Nyquist mode
    return np.fft.irfft(c, M) * (M / N)


def space_errors(Ns, nu, N_ref=2048, dt=1e-4):
    """Max error at t = 1 of N-mode solutions relative to an N_ref-mode reference."""
    u_ref = solve(N_ref, dt, nu)[1][-1]
    return [np.max(np.abs(fourier_interp(solve(N, dt, nu)[1][-1], N_ref) - u_ref))
            for N in Ns]


def time_errors(dts, N=512, dt_ref=6.25e-5):
    """Max error at t = 1 for several time steps relative to a small-step reference."""
    u_ref = solve(N, dt_ref)[1][-1]
    return [np.max(np.abs(solve(N, dt)[1][-1] - u_ref)) for dt in dts]


if __name__ == "__main__":
    set_style()
    t = np.linspace(0, 1, 101)
    x, U = solve(2048, 1e-4, t_save=t)               # fine reference with history
    print("max|u_x| at t = 1: %.1f" % np.max(np.abs(np.gradient(U[-1], x))))

    Ns = np.array([64, 96, 128, 192, 256, 384, 512, 768, 1024])
    err_space = {nu: space_errors(Ns, nu) for nu in (NU, 10 * NU)}
    for nu, e in err_space.items():
        print("nu = %.5f  space errors:" % nu, ["%.1e" % v for v in e])
    dts = np.array([2e-3, 1e-3, 5e-4, 2.5e-4, 1.25e-4])
    err_time = time_errors(dts)
    print("time errors:", ["%.1e" % v for v in err_time])
    print("observed temporal orders:", np.round(np.diff(np.log(err_time)) / np.diff(np.log(dts)), 2))

    fig, ax = plt.subplots(2, 2, figsize=(FULL_WIDTH, 3.4))
    ax = ax.ravel()
    for i, (tt, c) in enumerate(zip([0, 0.2, 0.4, 0.6, 1.0], plt.cm.viridis(np.linspace(0, 0.9, 5)))):
        k = int(round(tt * 100))
        ax[0].plot(x, U[k], color=c, lw=1.1, label="$t=%.1f$" % tt)
    ax[0].set_xlabel("$x$")
    ax[0].set_ylabel("$u(x,t)$")
    ax[0].set_title(r"(a) snapshots, $\nu=0.01/\pi$")
    ax[0].legend(fontsize=6.5, loc="lower left", ncol=2, handlelength=1.0, labelspacing=0.2,
                 columnspacing=0.8)

    im = ax[1].pcolormesh(t, x, U.T, cmap="RdBu_r", shading="auto", vmin=-1, vmax=1,
                          rasterized=True)
    ax[1].axvline(1 / np.pi, color="k", ls=":", lw=0.9)
    ax[1].text(1 / np.pi + 0.02, 0.8, r"$t=1/\pi$", fontsize=7)
    ax[1].set_xlabel("$t$")
    ax[1].set_ylabel("$x$")
    ax[1].set_title("(b) space-time evolution")
    fig.colorbar(im, ax=ax[1], pad=0.02, fraction=0.05)

    for (nu, e), c, m, lab in zip(err_space.items(), [COLORS["blue"], COLORS["orange"]], ["o", "s"],
                                  [r"$\nu=0.01/\pi$", r"$\nu=0.1/\pi$"]):
        ax[2].semilogy(Ns, np.maximum(e, 1e-16), m + "-", color=c, ms=3, label=lab)
    ax[2].set_xlabel("Fourier modes $N$")
    ax[2].set_ylabel(r"max error at $t=1$")
    ax[2].set_title("(c) spatial convergence")
    ax[2].legend(fontsize=7)

    ax[3].loglog(dts, err_time, "o-", color=COLORS["green"], ms=3, label="ETDRK4, $N=512$")
    ax[3].loglog(dts, 0.8 * err_time[0] * (dts / dts[0]) ** 4, ":", color=COLORS["gray"], lw=1,
                 label=r"slope 4")
    ax[3].set_xlabel(r"time step $\Delta t$")
    ax[3].set_ylabel(r"max error at $t=1$")
    ax[3].set_title("(d) temporal convergence")
    ax[3].legend(fontsize=7, loc="lower right")
    fig.tight_layout(h_pad=0.8, w_pad=0.8)
    print(savefig(fig, "ch02", "burgers_etdrk4"))

"""Figure 2.x: one-step ODE integrators: order of accuracy, stability, and stiffness.

(a) global error at T = 10 for the pendulum theta'' = -sin(theta) versus step size h
    for explicit Euler, the explicit midpoint rule (RK2), and classical RK4;
(b) absolute-stability regions |R(z)| <= 1 of these methods in the complex z = h*lambda plane;
(c) cost (number of right-hand-side evaluations) of the adaptive explicit RK45 method and of
    the implicit BDF method for the method-of-lines heat equation with N interior points.
Run from the project root:  python3 code/ch02/fig_ode.py
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys

import matplotlib.pyplot as plt
import numpy as np
import scipy.sparse as sp
from scipy.integrate import solve_ivp

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from numerics import euler_step, integrate_fixed, rk2_step, rk4_step  # noqa: E402

set_style()
fig, ax = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.2))


# (a) convergence orders on the pendulum
def pend(t, x):
    return np.array([x[1], -np.sin(x[0])])


x0, T = np.array([1.0, 0.0]), 10.0
ref = solve_ivp(pend, (0, T), x0, method="DOP853", rtol=1e-13, atol=1e-14).y[:, -1]
ns = 25 * 2 ** np.arange(0, 9)
for step, c, lab, m in [(euler_step, COLORS["orange"], "Euler", "o"),
                        (rk2_step, COLORS["green"], "RK2", "s"),
                        (rk4_step, COLORS["blue"], "RK4", "^")]:
    err = np.array([np.linalg.norm(integrate_fixed(step, pend, x0, T, n) - ref) for n in ns])
    ax[0].loglog(T / ns, err, m + "-", color=c, ms=2.5, label=lab)
    slope = np.polyfit(np.log(T / ns[-4:]), np.log(err[-4:]), 1)[0]
    print("%-6s observed order %.2f   errors %s" % (lab, slope, ["%.1e" % e for e in err[::2]]))
ax[0].set_xlabel("step size $h$")
ax[0].set_ylabel(r"error at $t=10$")
ax[0].set_title("(a) convergence")
ax[0].legend(fontsize=7, loc="lower right")

# (b) stability regions
xr, yi = np.meshgrid(np.linspace(-5.5, 2.5, 801), np.linspace(-3.5, 3.5, 701))
z = xr + 1j * yi
R = {"Euler": 1 + z, "RK2": 1 + z + z ** 2 / 2,
     "RK4": 1 + z + z ** 2 / 2 + z ** 3 / 6 + z ** 4 / 24}
for (lab, Rz), c in zip(R.items(), [COLORS["orange"], COLORS["green"], COLORS["blue"]]):
    ax[1].contourf(xr, yi, np.abs(Rz), levels=[0, 1], colors=[c], alpha=0.15)
    ax[1].contour(xr, yi, np.abs(Rz), levels=[1], colors=[c], linewidths=1.0)
    ax[1].plot([], [], color=c, label=lab)
th = np.linspace(0, 2 * np.pi, 200)
ax[1].plot(1 + np.cos(th), np.sin(th), "--", color=COLORS["red"], lw=1.0,
           label="impl. Euler")
ax[1].axhline(0, color="k", lw=0.4)
ax[1].axvline(0, color="k", lw=0.4)
ax[1].set_aspect("equal")
ax[1].set_xlim(-5.5, 2.5)
ax[1].set_ylim(-3.5, 3.5)
ax[1].set_xlabel(r"Re $z$")
ax[1].set_ylabel(r"Im $z$")
ax[1].set_title(r"(b) stability, $z=h\lambda$")
ax[1].legend(fontsize=6, loc="lower left", handlelength=1.2, borderaxespad=0.2,
             labelspacing=0.2)


# (c) stiffness: method-of-lines heat equation u_t = u_xx on (0, 1), u = 0 at x = 0, 1
def heat_mol(N):
    h = 1.0 / (N + 1)
    A = sp.diags([1.0, -2.0, 1.0], [-1, 0, 1], shape=(N, N), format="csr") / h ** 2
    x = h * np.arange(1, N + 1)
    return A, np.sin(np.pi * x) + 0.5 * np.sin(8 * np.pi * x)


Ns = 2 ** np.arange(4, 10)
cost = {"RK45": [], "BDF": []}
for N in Ns:
    A, u0 = heat_mol(N)
    for meth in cost:
        kw = {"jac": A} if meth == "BDF" else {}
        sol = solve_ivp(lambda t, u: A @ u, (0, 0.05), u0, method=meth,
                        rtol=1e-6, atol=1e-9, **kw)
        cost[meth].append(sol.nfev)
    print("N = %4d   RK45 nfev = %7d   BDF nfev = %5d" % (N, cost["RK45"][-1], cost["BDF"][-1]))
ax[2].loglog(Ns, cost["RK45"], "o-", color=COLORS["orange"], ms=2.5, label="RK45 (explicit)")
ax[2].loglog(Ns, cost["BDF"], "s-", color=COLORS["blue"], ms=2.5, label="BDF (implicit)")
ax[2].loglog(Ns, 0.4 * Ns ** 2.0, ":", color=COLORS["gray"], lw=1)
ax[2].text(90, 1.2e3, "$N^2$", fontsize=7)
ax[2].set_xlabel("interior points $N$")
ax[2].set_ylabel("RHS evaluations")
ax[2].set_title("(c) stiff heat equation")
ax[2].legend(fontsize=7, loc="upper left")
fig.tight_layout(w_pad=0.5)
print(savefig(fig, "ch02", "ode_integrators"))

"""Figure 2.x: singular-value decay of space-time snapshot matrices and randomized SVD.

(a) normalised singular values sigma_k / sigma_1 for four 512 x 201 data matrices;
(b) spectral-norm error of rank-k approximations: optimal truncated SVD (Eckart-Young)
    versus randomized SVD with q = 0 and q = 1 power iterations (oversampling p = 5).
Run from the project root:  python3 code/ch02/fig_sv_decay.py
"""
import os

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")              # CPU etiquette on shared machines
import sys

import matplotlib.pyplot as plt
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from numerics import rsvd, snapshot_datasets  # noqa: E402

set_style()
data = snapshot_datasets()
fig, ax = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4))

colors = [COLORS["blue"], COLORS["orange"], COLORS["green"], COLORS["gray"]]
for (name, X), c in zip(data.items(), colors):
    s = np.linalg.svd(X, compute_uv=False)
    ax[0].semilogy(np.arange(1, len(s) + 1), s / s[0], color=c, label=name)
    r99 = np.searchsorted(np.cumsum(s ** 2) / np.sum(s ** 2), 0.99) + 1
    print("%-18s sigma_10/sigma_1 = %.2e   modes for 99%% energy: %d" % (name, s[9] / s[0], r99))
ax[0].set_ylim(1e-16, 2)
ax[0].set_xlabel("index $k$")
ax[0].set_ylabel(r"$\sigma_k/\sigma_1$")
ax[0].set_title("(a) singular-value decay")
ax[0].legend(loc="center right", fontsize=7)

X = data["advected pulse"]
s = np.linalg.svd(X, compute_uv=False)
ks = np.arange(2, 61, 2)
for q, c, m in [(0, COLORS["red"], "o"), (1, COLORS["purple"], "s")]:
    err = []
    for k in ks:
        e = [np.linalg.norm(X - (U * sk) @ Vt, 2) for U, sk, Vt in
             (rsvd(X, k, p=5, q=q, seed=sd) for sd in range(5))]
        err.append(np.mean(e))
    ax[1].semilogy(ks, np.array(err) / s[0], m, color=c, ms=3, mfc="none",
                   label="randomized, $q=%d$" % q)
ax[1].semilogy(ks, s[ks] / s[0], "-", color=COLORS["green"],
               label=r"optimal $\sigma_{k+1}/\sigma_1$")
ax[1].set_xlabel("rank $k$")
ax[1].set_ylabel(r"$\|\mathbf{X}-\mathbf{X}_k\|_2/\sigma_1$")
ax[1].set_title("(b) randomized SVD, advected pulse")
ax[1].legend(fontsize=7)

fig.tight_layout()
print(savefig(fig, "ch02", "sv_decay"))

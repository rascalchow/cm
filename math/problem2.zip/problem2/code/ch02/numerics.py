"""Small numerical helpers used by the Chapter 2 figure scripts and assignments.

    rsvd(X, k, p, q, seed)       randomized SVD (Halko, Martinsson & Tropp 2011)
    euler_step, rk2_step, rk4_step, integrate_fixed
                                 explicit one-step methods with a fixed step size
    snapshot_datasets()          four space-time snapshot matrices for the SVD figure
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import burgers_pinn_reference, heat_fd  # noqa: E402


def rsvd(X, k, p=5, q=1, seed=0):
    """Rank-k randomized SVD with oversampling p and q power (subspace) iterations."""
    rng = np.random.default_rng(seed)
    Omega = rng.standard_normal((X.shape[1], k + p))     # Gaussian test matrix
    Q, _ = np.linalg.qr(X @ Omega)                       # basis for the range of X
    for _ in range(q):                                   # power iterations sharpen
        Q, _ = np.linalg.qr(X.T @ Q)                     # the spectrum (re-orthonormalise
        Q, _ = np.linalg.qr(X @ Q)                       # at every step for stability)
    B = Q.T @ X                                          # small (k+p) x n matrix
    Ub, s, Vt = np.linalg.svd(B, full_matrices=False)
    return (Q @ Ub)[:, :k], s[:k], Vt[:k]


def euler_step(f, t, x, h):
    return x + h * f(t, x)


def rk2_step(f, t, x, h):                                # explicit midpoint rule
    return x + h * f(t + h / 2, x + h / 2 * f(t, x))


def rk4_step(f, t, x, h):
    k1 = f(t, x)
    k2 = f(t + h / 2, x + h / 2 * k1)
    k3 = f(t + h / 2, x + h / 2 * k2)
    k4 = f(t + h, x + h * k3)
    return x + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4)


def integrate_fixed(step, f, x0, T, n):
    """n steps of size T/n of a one-step method; returns the final state."""
    x, h = np.asarray(x0, float), T / n
    for i in range(n):
        x = step(f, i * h, x, h)
    return x


def snapshot_datasets(nx=512, nt=201):
    """Space-time matrices X (nx x nt), one column per snapshot."""
    t = np.linspace(0, 1, nt)
    # heat equation u_t = 0.02 u_xx on [0,1] from a discontinuous initial condition
    x = np.linspace(0, 1, nx)
    u0 = ((x > 0.2) & (x < 0.45)).astype(float) - 0.5 * ((x > 0.6) & (x < 0.8))
    heat = heat_fd(u0, 0.02, x, t, dt=1e-4).T
    # viscous Burgers (PINN benchmark, nu = 0.01/pi): a shock forms at t ~ 1/pi
    _, _, U = burgers_pinn_reference(nx=nx, nt=nt)
    burgers = U.T
    # a Gaussian pulse advected once around the periodic domain [0, 1)
    xp = np.arange(nx) / nx
    d = (xp[:, None] - t[None, :]) % 1.0 - 0.5          # centre at x = 0.5 + t (mod 1)
    pulse = np.exp(-d ** 2 / (2 * 0.03 ** 2))
    noise = np.random.default_rng(0).standard_normal((nx, nt))
    return {"heat (diffusion)": heat, "Burgers (shock)": burgers,
            "advected pulse": pulse, "Gaussian noise": noise}

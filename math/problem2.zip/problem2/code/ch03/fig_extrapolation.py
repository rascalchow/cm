"""Extrapolation and double descent (Chapter 3, Figure fig:03:extrapolation).

(a) Models trained on x in [-1, 1] for u(x) = sin(pi x), evaluated on [-2.5, 2.5]:
    a ReLU MLP, a tanh MLP, and a degree-9 least-squares polynomial.
(b) Test error of minimum-norm least squares with p random tanh features
    phi_j(x) = tanh(a_j x + b_j), a_j ~ N(0, 10^2), b_j ~ U(-10, 10), fitted to N = 40
    equispaced noisy samples (noise std 0.1), as p varies (median and quartiles over 30 draws
    of noise and features).  The peak at p = N is the "double descent" phenomenon.

Run from the project root:  python3 code/ch03/fig_extrapolation.py   (about 1-2 minutes)
"""
import os
import sys

os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")

import numpy as np
import torch
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)


def u(x):
    return np.sin(np.pi * x)


def fit_mlp(act, x, y, n_iter=3000, seed=0):
    torch.manual_seed(seed)
    net = torch.nn.Sequential(torch.nn.Linear(1, 64), act(), torch.nn.Linear(64, 64), act(),
                              torch.nn.Linear(64, 1))
    opt = torch.optim.Adam(net.parameters(), lr=2e-3)
    xt, yt = torch.tensor(x[:, None]), torch.tensor(y[:, None])
    for _ in range(n_iter):
        opt.zero_grad()
        loss = torch.mean((net(xt) - yt) ** 2)
        loss.backward()
        opt.step()
    print(f"{act.__name__}: final training MSE {loss.item():.2e}")
    return lambda z: net(torch.tensor(z[:, None])).detach().numpy().ravel()


def double_descent(n_train=40, noise=0.1, scale=10.0, n_draws=30, seed=0):
    rng = np.random.default_rng(seed)
    p_list = np.array([2, 4, 6, 8, 10, 14, 20, 26, 32, 36, 38, 40, 42, 44, 48, 56, 70, 90,
                       120, 160, 220, 300, 420, 600, 1000])
    x_tr = np.linspace(-1, 1, n_train)
    x_te = np.linspace(-1, 1, 1000)
    err = np.zeros((n_draws, len(p_list)))
    for d in range(n_draws):
        y_tr = u(x_tr) + noise * rng.standard_normal(n_train)
        for i, p in enumerate(p_list):
            a = scale * rng.standard_normal(p)
            b = rng.uniform(-scale, scale, p)

            def feats(z):
                return np.tanh(np.outer(z, a) + b)
            # lstsq returns the minimum-norm solution when the system is underdetermined
            w = np.linalg.lstsq(feats(x_tr), y_tr, rcond=None)[0]
            err[d, i] = np.mean((feats(x_te) @ w - u(x_te)) ** 2)
    return p_list, np.median(err, axis=0), np.quantile(err, 0.25, axis=0), np.quantile(err, 0.75, axis=0)


def main():
    x_tr = np.linspace(-1, 1, 40)
    y_tr = u(x_tr)
    x_ev = np.linspace(-2.5, 2.5, 501)
    relu = fit_mlp(torch.nn.ReLU, x_tr, y_tr)
    tanh = fit_mlp(torch.nn.Tanh, x_tr, y_tr)
    poly = np.polynomial.Polynomial.fit(x_tr, y_tr, 9)

    p, med, q1, q3 = double_descent()
    i_peak = np.argmax(med)
    i_min = np.argmin(np.where(p < 40, med, np.inf))
    print(f"double descent: peak median test MSE {med[i_peak]:.2e} at p = {p[i_peak]}; "
          f"best p<40: {med[i_min]:.2e} at p = {p[i_min]}; at p = {p[-1]}: {med[-1]:.2e}")

    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.3))
    ax = axes[0]
    ax.axvspan(-1, 1, color=COLORS["gray"], alpha=0.12, lw=0)
    ax.plot(x_ev, u(x_ev), color="k", lw=0.9, label="truth")
    ax.plot(x_ev, relu(x_ev), color=COLORS["blue"], label="ReLU MLP")
    ax.plot(x_ev, tanh(x_ev), color=COLORS["orange"], label="tanh MLP")
    ax.plot(x_ev, poly(x_ev), color=COLORS["green"], ls="--", label="polynomial, deg 9")
    ax.plot(x_tr, y_tr, "o", ms=2.2, color="k")
    ax.set_ylim(-4, 6.5)
    ax.set_xlabel("$x$")
    ax.set_title("(a) interpolation vs. extrapolation")
    ax.legend(loc="upper left", ncol=2, fontsize=6.5, handlelength=1.3, columnspacing=0.8)
    ax = axes[1]
    ax.fill_between(p, q1, q3, color=COLORS["blue"], alpha=0.2, lw=0)
    ax.loglog(p, med, "o-", ms=2.5, color=COLORS["blue"])
    ax.axvline(40, color=COLORS["red"], lw=0.8, ls=":")
    ax.text(50, med.max() * 4, "$p=N$", color=COLORS["red"], fontsize=8)
    ax.set_xlabel("number of random tanh features $p$")
    ax.set_ylabel("test MSE")
    ax.set_title("(b) double descent, $N=40$")
    fig.tight_layout(w_pad=1.0)
    print("saved", savefig(fig, "ch03", "extrapolation"))


if __name__ == "__main__":
    main()

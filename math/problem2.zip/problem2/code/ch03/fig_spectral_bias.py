"""Spectral bias of an MLP and the Fourier-feature fix (Chapter 3, Figure fig:03:spectral-bias).

We fit f(x) = sin(2 pi x) + sin(2 pi 4 x) + sin(2 pi 10 x) on a periodic grid of [0, 1)
with (i) a plain tanh MLP and (ii) the same MLP preceded by a random Fourier-feature
embedding gamma(x) = [cos(2 pi B x), sin(2 pi B x)].  During training we record the relative
error of each Fourier component of the residual, |hat r_k| / |hat f_k|, for k = 1, 4, 10.

Run from the project root:  python3 code/ch03/fig_spectral_bias.py   (about 1-2 minutes)
"""
import os
import sys

import numpy as np
import torch
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)

FREQS = (1, 4, 10)
N_GRID = 200
N_ITER = 3000
LOG_EVERY = 20


def target(x):
    return sum(np.sin(2 * np.pi * k * x) for k in FREQS)


class FourierFeatures(torch.nn.Module):
    """gamma(x) = [cos(2 pi x B), sin(2 pi x B)] with fixed random B ~ N(0, sigma^2)."""

    def __init__(self, n_features=32, sigma=10.0, seed=0):
        super().__init__()
        g = torch.Generator().manual_seed(seed)
        self.register_buffer("B", sigma * torch.randn(1, n_features, generator=g))

    def forward(self, x):
        z = 2 * np.pi * x @ self.B
        return torch.cat([torch.cos(z), torch.sin(z)], dim=-1)


def mlp(n_in, width=64, depth=3):
    layers, d = [], n_in
    for _ in range(depth):
        layers += [torch.nn.Linear(d, width), torch.nn.Tanh()]
        d = width
    layers.append(torch.nn.Linear(d, 1))
    return torch.nn.Sequential(*layers)


def train(model, x, y, xin, n_iter=N_ITER, lr=1e-3):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    fhat = np.fft.rfft(y.numpy().ravel())
    hist, snapshots = [], {}
    for it in range(n_iter + 1):
        opt.zero_grad()
        pred = model(xin)
        loss = torch.mean((pred - y) ** 2)
        if it % LOG_EVERY == 0:
            rhat = np.fft.rfft((pred.detach() - y).numpy().ravel())
            hist.append([it] + [abs(rhat[k]) / abs(fhat[k]) for k in FREQS])
        if it in (300, 1000, n_iter):
            snapshots[it] = pred.detach().numpy().ravel().copy()
        loss.backward()
        opt.step()
    return np.array(hist), snapshots


def main():
    x_np = np.arange(N_GRID) / N_GRID
    x = torch.tensor(x_np[:, None])
    y = torch.tensor(target(x_np)[:, None])

    torch.manual_seed(0)
    plain = mlp(1)
    h_plain, s_plain = train(plain, x, y, 2 * x - 1)          # inputs scaled to [-1, 1]

    torch.manual_seed(0)
    ff = torch.nn.Sequential(FourierFeatures(32, sigma=10.0), mlp(64))
    h_ff, s_ff = train(ff, x, y, x)

    for name, h in (("plain", h_plain), ("fourier", h_ff)):
        for it in (300, 1000, N_ITER):
            row = h[h[:, 0] == it][0]
            print(f"{name:8s} it={it:5d}  rel. err k=1,4,10: " +
                  "  ".join(f"{v:.2e}" for v in row[1:]))

    set_style()
    fig, axes = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.1))
    cols = [COLORS["blue"], COLORS["orange"], COLORS["red"]]
    for ax, h, title in ((axes[0], h_plain, "(a) tanh MLP"),
                         (axes[1], h_ff, "(b) Fourier features + MLP")):
        for j, k in enumerate(FREQS):
            ax.semilogy(h[:, 0], h[:, j + 1], color=cols[j], lw=0.9, label=f"$k={k}$")
        ax.set_xlabel("Adam iteration")
        ax.set_ylim(1e-6, 3)
        ax.set_title(title)
    axes[0].set_ylabel(r"$|\hat r_k| / |\hat f_k|$")
    axes[0].legend(loc="lower left")
    ax = axes[2]
    xf = np.linspace(0, 1, 400)
    ax.plot(xf, target(xf), color="k", lw=0.8, label="target")
    ax.plot(x_np, s_plain[300], color=COLORS["blue"], lw=1.1, label="MLP")
    ax.plot(x_np, s_ff[300], color=COLORS["green"], lw=1.1, ls="--", label="Fourier feat.")
    ax.set_xlim(0, 1)
    ax.set_ylim(-3.2, 4.2)
    ax.set_xlabel("$x$")
    ax.set_title("(c) fits after 300 iterations")
    ax.legend(loc="upper right", ncol=3, fontsize=6.5, handlelength=1.2, columnspacing=0.8)
    fig.tight_layout(w_pad=0.6)
    print("saved", savefig(fig, "ch03", "spectral_bias"))


if __name__ == "__main__":
    main()

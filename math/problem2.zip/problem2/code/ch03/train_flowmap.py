"""A complete PyTorch training loop: learning the flow map of the pendulum.

Chapter 3, Listing lst:03:training and Figure fig:03:flowmap.

The pendulum theta'' = -sin(theta) has state x = (theta, omega).  We learn the time-Delta-t
flow map  x(t) -> x(t + Delta t)  (Delta t = 0.1) from N = 2000 pairs whose initial states are
drawn uniformly from [-2, 2]^2, using a tanh MLP, standardized inputs/outputs, a 70/15/15
train/validation/test split, minibatch Adam with a cosine learning-rate schedule, and
model selection on the validation loss.  The trained map is then iterated for 500 steps
(t = 50) from x0 = (1, 0) and compared with the exact trajectory.

Run from the project root:  python3 code/ch03/train_flowmap.py   (about 1-3 minutes)
"""
import copy
import os
import sys

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import integrate, pendulum  # noqa: E402
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)        # float64 throughout (see Chapter 4)
torch.manual_seed(0)
DT = 0.1


def flow_map_data(n, rng):
    """n pairs (x, Phi_dt(x)) with x uniform in [-2, 2]^2; one vectorized DOP853 solve."""
    x0 = rng.uniform(-2.0, 2.0, size=(n, 2))

    def f(t, z):
        th, om = z[:n], z[n:]
        return np.concatenate([om, -np.sin(th)])
    z1 = integrate(f, np.concatenate([x0[:, 0], x0[:, 1]]), np.array([0.0, DT]))[-1]
    return x0, np.stack([z1[:n], z1[n:]], axis=1)


# ---------------------------------------------------------------- listing starts
class Normalizer:
    """Affine map to zero mean and unit variance, fitted on training data only."""
    def __init__(self, z):
        self.mu, self.sd = z.mean(0), z.std(0)
    def encode(self, z): return (z - self.mu) / self.sd
    def decode(self, z): return z * self.sd + self.mu

def mlp(n_in, n_out, width=64, depth=3):
    layers, d = [], n_in
    for _ in range(depth):
        layers += [torch.nn.Linear(d, width), torch.nn.Tanh()]
        d = width
    return torch.nn.Sequential(*layers, torch.nn.Linear(d, n_out))

def train(model, X_tr, Y_tr, X_va, Y_va, epochs=300, batch=64, lr=3e-3):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    loader = DataLoader(TensorDataset(X_tr, Y_tr), batch_size=batch, shuffle=True)
    mse = lambda a, b: torch.mean((a - b) ** 2)
    best, best_state, hist = float("inf"), None, []
    for epoch in range(epochs):
        for xb, yb in loader:              # one epoch = one pass over shuffled minibatches
            opt.zero_grad()                # clear gradients from the previous step
            loss = mse(model(xb), yb)      # forward pass
            loss.backward()                # reverse-mode AD (Chapter 5)
            opt.step()                     # parameter update (Chapter 4)
        sched.step()
        with torch.no_grad():              # monitoring: no graph needed
            hist.append((mse(model(X_tr), Y_tr).item(), mse(model(X_va), Y_va).item()))
        if hist[-1][1] < best:             # model selection on the validation set
            best, best_state = hist[-1][1], copy.deepcopy(model.state_dict())
    model.load_state_dict(best_state)
    return np.array(hist)
# ---------------------------------------------------------------- listing ends


def main():
    rng = np.random.default_rng(0)
    X, Y = flow_map_data(2000, rng)
    idx = rng.permutation(len(X))
    i_tr, i_va, i_te = idx[:1400], idx[1400:1700], idx[1700:]
    nx, ny = Normalizer(X[i_tr]), Normalizer(Y[i_tr])
    T = lambda a: torch.tensor(a)
    X_tr, Y_tr = T(nx.encode(X[i_tr])), T(ny.encode(Y[i_tr]))
    X_va, Y_va = T(nx.encode(X[i_va])), T(ny.encode(Y[i_va]))
    X_te, Y_te = T(nx.encode(X[i_te])), T(ny.encode(Y[i_te]))

    model = mlp(2, 2)
    hist = train(model, X_tr, Y_tr, X_va, Y_va)
    with torch.no_grad():
        Y_pred = ny.decode(model(X_te).numpy())
    test_mse = np.mean((Y_pred - Y[i_te]) ** 2)
    print(f"parameters: {sum(p.numel() for p in model.parameters())}")
    print(f"best validation MSE (normalized): {hist[:, 1].min():.2e} at epoch {hist[:, 1].argmin() + 1}")
    print(f"test MSE (physical units): {test_mse:.2e};  RMSE: {np.sqrt(test_mse):.2e}")

    # rollout: iterate the learned map
    n_steps = 500
    t = DT * np.arange(n_steps + 1)
    traj = np.zeros((n_steps + 1, 2))
    traj[0] = (1.0, 0.0)
    with torch.no_grad():
        for k in range(n_steps):
            traj[k + 1] = ny.decode(model(T(nx.encode(traj[k][None, :]))).numpy())[0]
    ref = pendulum((1.0, 0.0), t_eval=t)
    err = np.linalg.norm(traj - ref, axis=1)
    energy = lambda z: 0.5 * z[:, 1] ** 2 + 1.0 - np.cos(z[:, 0])
    for tt in (1.0, 10.0, 50.0):
        k = int(round(tt / DT))
        print(f"rollout error at t = {tt:4.0f}: {err[k]:.2e}")
    print(f"energy: exact {energy(ref)[0]:.4f}, learned at t=50: {energy(traj)[-1]:.4f}")

    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.2), gridspec_kw={"width_ratios": [1, 1.6]})
    ax = axes[0]
    ax.semilogy(np.arange(1, len(hist) + 1), hist[:, 0], color=COLORS["blue"], label="training")
    ax.semilogy(np.arange(1, len(hist) + 1), hist[:, 1], color=COLORS["orange"], ls="--", label="validation")
    ax.set_xlabel("epoch")
    ax.set_ylabel("MSE (normalized)")
    ax.set_title("(a) learning curves")
    ax.legend()
    ax = axes[1]
    ax.plot(t, ref[:, 0], color="k", lw=0.9, label="exact")
    ax.plot(t, traj[:, 0], color=COLORS["red"], lw=1.0, ls="--", label="learned map, iterated")
    ax.set_xlabel("$t$")
    ax.set_ylabel(r"$\theta(t)$")
    ax.set_ylim(-1.25, 1.6)
    ax.set_title(r"(b) rollout from $(\theta_0,\omega_0)=(1,0)$, 500 steps")
    ax.legend(loc="upper center", ncol=2)
    fig.tight_layout(w_pad=1.0)
    print("saved", savefig(fig, "ch03", "flowmap"))


if __name__ == "__main__":
    main()

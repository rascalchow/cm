"""Training a small network on a physics-informed (residual) loss: Adam, L-BFGS, and
Adam followed by L-BFGS, in float32 and float64 (Chapter 4, Figure fig:04:network and
Listing lst:04:adam-lbfgs).

Problem: -u''(x) = f(x) on (0, 1), u(0) = u(1) = 0, with exact solution
u*(x) = sin(pi x) + 0.2 sin(5 pi x).  The network u_theta is a tanh MLP with two hidden
layers of width 32 (1153 parameters); the loss is the mean squared PDE residual at 128
equispaced collocation points plus the squared boundary values (a minimal PINN, Chapter 10).
Runs (same initialization, total budget 3000 iterations):
    Adam (lr 1e-3) for 3000 iterations                      float32 and float64
    L-BFGS (strong Wolfe, history 50) for 3000 iterations   float64
    Adam 1000 iterations, then L-BFGS 2000 iterations       float32 and float64
L-BFGS is called n_lbfgs / 20 times with max_iter = 20 (at most 25 loss evaluations per call, PyTorch's
default), so it may perform fewer than 20 iterations per call.  We record the loss, the relative
L2 error against u* on 1001 points, and the number of loss/gradient evaluations.
Finally (printed only, not plotted) the float64 Adam + L-BFGS run is repeated with the loss
multiplied by 1e4: torch.optim.LBFGS discards curvature pairs with y^T s <= 1e-10, which
freezes its memory once the unscaled loss is small.

Run from the project root:  python3 code/ch04/fig_network.py
(about 3 minutes on an idle 2-core CPU; longer on a loaded machine)
"""
import os
import sys
import time

import numpy as np
import torch
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402

torch.set_num_threads(2)
N_COL, N_TOTAL, N_ADAM = 128, 3000, 1000


def u_exact(x):
    return torch.sin(np.pi * x) + 0.2 * torch.sin(5 * np.pi * x)


def f_source(x):          # f = -u*''
    return np.pi ** 2 * torch.sin(np.pi * x) + 0.2 * (5 * np.pi) ** 2 * torch.sin(5 * np.pi * x)


def make_model(dtype, seed=0):
    torch.manual_seed(seed)
    return torch.nn.Sequential(torch.nn.Linear(1, 32), torch.nn.Tanh(), torch.nn.Linear(32, 32),
                               torch.nn.Tanh(), torch.nn.Linear(32, 1)).to(dtype)


# ---------------------------------------------------------------- listing starts
def residual_loss(model, x, f):
    """Mean squared residual of -u'' = f plus the boundary penalty u(0)^2 + u(1)^2."""
    x = x.clone().requires_grad_(True)
    u = model(x)
    du = torch.autograd.grad(u.sum(), x, create_graph=True)[0]     # u'  (Chapter 5)
    d2u = torch.autograd.grad(du.sum(), x, create_graph=True)[0]   # u''
    xb = torch.tensor([[0.0], [1.0]], dtype=x.dtype)
    return torch.mean((-d2u - f) ** 2) + torch.mean(model(xb) ** 2)

def adam_then_lbfgs(model, loss_fn, n_adam, n_lbfgs, lr=1e-3, log=lambda k: None):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for k in range(n_adam):                    # phase 1: robust progress from a random start
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        opt.step()
        log(k + 1)
    opt = torch.optim.LBFGS(model.parameters(), lr=1.0, max_iter=20, history_size=50,
                            line_search_fn="strong_wolfe",
                            tolerance_grad=0.0, tolerance_change=0.0)
    def closure():                             # the line search re-evaluates the loss
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        return loss
    for _ in range(n_lbfgs // 20):             # phase 2: fast local convergence
        opt.step(closure)                      # up to 20 L-BFGS iterations per call
        log(n_adam + opt.state_dict()["state"][0]["n_iter"])
    return model
# ---------------------------------------------------------------- listing ends


def run(dtype, n_adam, n_lbfgs, scale=1.0):
    model = make_model(dtype)
    x = torch.linspace(0, 1, N_COL, dtype=dtype)[:, None]
    f = f_source(x)
    xe = torch.linspace(0, 1, 1001, dtype=dtype)[:, None]
    ue = u_exact(xe)
    hist, n_eval = [], [0]

    def loss_fn():                       # counts loss/gradient evaluations
        n_eval[0] += 1
        return scale * residual_loss(model, x, f)

    def log(k):                          # every 20 Adam steps, and after every L-BFGS call
        if k % 20 == 0 or k == 1 or k > n_adam:
            with torch.no_grad():
                err = (torch.linalg.norm(model(xe) - ue) / torch.linalg.norm(ue)).item()
            hist.append((k, residual_loss(model, x, f).item(), err, n_eval[0]))

    t0 = time.time()
    adam_then_lbfgs(model, loss_fn, n_adam, n_lbfgs, log=log)
    return np.array(hist), time.time() - t0


def main():
    runs = [
        ("Adam, float32", torch.float32, N_TOTAL, 0, COLORS["green"], "--"),
        ("Adam, float64", torch.float64, N_TOTAL, 0, COLORS["green"], "-"),
        ("L-BFGS, float64", torch.float64, 0, N_TOTAL, COLORS["blue"], "-"),
        ("Adam + L-BFGS, float32", torch.float32, N_ADAM, N_TOTAL - N_ADAM, COLORS["red"], "--"),
        ("Adam + L-BFGS, float64", torch.float64, N_ADAM, N_TOTAL - N_ADAM, COLORS["red"], "-"),
    ]
    results = []
    for name, dtype, na, nl, c, ls in runs:
        h, sec = run(dtype, na, nl)
        print(f"{name:24s} final loss {h[-1, 1]:.2e}  rel. L2 error {h[-1, 2]:.2e}  "
              f"(min {h[:, 2].min():.2e})  iterations {int(h[-1, 0])}  evaluations {int(h[-1, 3])}  "
              f"{sec:.0f} s", flush=True)
        results.append((name, h, c, ls))
    h, sec = run(torch.float64, N_ADAM, N_TOTAL - N_ADAM, scale=1e4)
    print(f"{'Adam + L-BFGS, float64, loss x 1e4':24s} final loss {h[-1, 1]:.2e}  rel. L2 error {h[-1, 2]:.2e}  "
          f"iterations {int(h[-1, 0])}  evaluations {int(h[-1, 3])}  {sec:.0f} s", flush=True)

    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4))
    for name, h, c, ls in results:
        axes[0].semilogy(h[:, 0], h[:, 1], ls, color=c, lw=1.1, label=name)
        axes[1].semilogy(h[:, 0], h[:, 2], ls, color=c, lw=1.1, label=name)
    for ax in axes:
        ax.axvline(N_ADAM, color=COLORS["gray"], lw=0.6, ls=":")
        ax.set_xlabel("iteration")
        ax.set_xlim(0, N_TOTAL)
    axes[0].set_ylabel("loss")
    axes[0].set_title("(a) residual loss")
    axes[1].set_ylabel(r"$\|u_\theta-u^*\|/\|u^*\|$")
    axes[1].set_title(r"(b) relative $L^2$ error")
    axes[1].legend(loc="upper right", fontsize=6.5, handlelength=1.8)
    fig.tight_layout(w_pad=1.0)
    print("saved", savefig(fig, "ch04", "network"))


if __name__ == "__main__":
    main()

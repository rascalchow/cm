"""First-order methods on ill-conditioned quadratics (Chapter 4, Figure fig:04:quadratic).

(a) Trajectories on the 2D quadratic f(x) = x^T A x / 2 with eigenvalues {1, 25} and
    eigenvectors rotated by 30 degrees: GD with the optimal constant step 2/(L+mu),
    Nesterov's method (step 1/L, beta = (sqrt(kappa)-1)/(sqrt(kappa)+1)), and Adam.
(b) Relative suboptimality on a 100-dimensional quadratic f(x) = x^T A x / 2 - b^T x with
    eigenvalues log-spaced in [1e-3, 1] (kappa = 1e3) and a random orthogonal eigenbasis:
    GD, heavy ball, Nesterov, Adam (PyTorch default step 1e-3 and the best step of the grid
    {1e-3, 3e-3, ..., 3e-1}) and L-BFGS (m = 10), with the GD bound (1 - 1/kappa)^k.

Run from the project root:  python3 code/ch04/fig_quadratic.py   (a few seconds)
"""
import os
import sys

os.environ.setdefault("OMP_NUM_THREADS", "2")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
import numpy as np  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from optimizers import gd, heavy_ball, nesterov, adam, lbfgs  # noqa: E402


def rotation(deg):
    c, s = np.cos(np.radians(deg)), np.sin(np.radians(deg))
    return np.array([[c, -s], [s, c]])


def main():
    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.6), gridspec_kw={"width_ratios": [1, 1.25]})

    # ---------------- (a) 2D trajectories
    mu, L = 1.0, 25.0
    R = rotation(30)
    A = R @ np.diag([mu, L]) @ R.T
    grad = lambda x: A @ x
    x0 = R @ np.array([-4.0, 0.8])          # mostly along the flat eigenvector
    k = np.sqrt(L / mu)
    runs = {
        "GD, $\\eta=2/(L+\\mu)$": (gd(grad, x0, 2 / (L + mu), 30), COLORS["blue"]),
        "Nesterov": (nesterov(grad, x0, 1 / L, (k - 1) / (k + 1), 30), COLORS["purple"]),
        "Adam, $\\eta=0.1$": (adam(grad, x0, 0.1, 30), COLORS["green"]),
    }
    ax = axes[0]
    g1, g2 = np.meshgrid(np.linspace(-4.6, 4.6, 200), np.linspace(-3.2, 3.2, 200))
    Z = 0.5 * (A[0, 0] * g1 ** 2 + 2 * A[0, 1] * g1 * g2 + A[1, 1] * g2 ** 2)
    ax.contour(g1, g2, Z, levels=np.geomspace(0.05, 60, 12), colors=COLORS["gray"], linewidths=0.4, alpha=0.6)
    for name, (xs, c) in runs.items():
        ax.plot(xs[:, 0], xs[:, 1], "o-", ms=2.0, lw=0.9, color=c, label=name)
        print(f"2D {name:28s} |x_30| = {np.linalg.norm(xs[-1]):.1e}")
    ax.plot(0, 0, "k*", ms=6)
    ax.set_aspect("equal")
    ax.set_xlim(-4.6, 4.6)
    ax.set_ylim(-3.2, 3.2)
    ax.set_xlabel("$x_1$")
    ax.set_ylabel("$x_2$")
    ax.set_title("(a) 30 iterations, $\\kappa=25$")
    ax.legend(loc="lower right", fontsize=6.5, handlelength=1.5, borderaxespad=0.1)

    # ---------------- (b) 100-dimensional quadratic, kappa = 1e3
    rng = np.random.default_rng(0)
    n = 100
    Q, _ = np.linalg.qr(rng.standard_normal((n, n)))
    lam = np.logspace(-3, 0, n)
    A = Q @ np.diag(lam) @ Q.T
    b = A @ rng.standard_normal(n)
    xstar = np.linalg.solve(A, b)
    f = lambda x: 0.5 * x @ A @ x - b @ x
    grad = lambda x: A @ x - b
    fstar = f(xstar)
    x0 = np.zeros(n)
    L, mu = lam.max(), lam.min()
    kap = L / mu
    k = np.sqrt(kap)
    n_it = 1000
    runs = [
        ("GD, $\\eta=1/L$", gd(grad, x0, 1 / L, n_it), COLORS["blue"], "-"),
        ("heavy ball", heavy_ball(grad, x0, 4 / (np.sqrt(L) + np.sqrt(mu)) ** 2, ((k - 1) / (k + 1)) ** 2, n_it),
         COLORS["orange"], "-"),
        ("Nesterov", nesterov(grad, x0, 1 / L, (k - 1) / (k + 1), n_it), COLORS["purple"], "-"),
        ("Adam, $\\eta=10^{-3}$", adam(grad, x0, 1e-3, n_it), COLORS["green"], "--"),
        ("Adam, $\\eta=0.3$", adam(grad, x0, 0.3, n_it), COLORS["green"], "-"),
        ("L-BFGS, $m=10$", lbfgs(f, grad, x0, m=10, n_iter=n_it, tol=1e-13), COLORS["red"], "-"),
    ]
    ax = axes[1]
    f0 = f(x0) - fstar
    for name, xs, c, ls in runs:
        gap = np.array([f(x) - fstar for x in xs]) / f0
        gap = np.maximum(gap, 1e-16)
        ax.semilogy(np.arange(len(xs)), gap, color=c, ls=ls, label=name)
        hit = np.argmax(gap < 1e-8) if np.any(gap < 1e-8) else None
        print(f"100D {name:24s} gap after {len(xs) - 1} its: {gap[-1]:.1e};  first < 1e-8 at: {hit}")
    kk = np.arange(n_it + 1)
    ax.semilogy(kk, (1 - 1 / kap) ** kk, color=COLORS["blue"], ls=":", lw=1.0, label="$(1-1/\\kappa)^k$")
    ax.set_ylim(1e-12, 2)
    ax.set_xlim(0, n_it)
    ax.set_xlabel("iteration $k$")
    ax.set_ylabel("$(f(x_k)-f^*)/(f(x_0)-f^*)$")
    ax.set_title("(b) $n=100$, $\\kappa=10^3$")
    ax.legend(loc="lower right", fontsize=6.5, ncol=1, handlelength=1.8)
    fig.tight_layout(w_pad=0.8)
    print("saved", savefig(fig, "ch04", "quadratic"))


if __name__ == "__main__":
    main()

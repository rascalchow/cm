"""Optimizers on the Rosenbrock function (Chapter 4, Figure fig:04:rosenbrock).

f(x, y) = (1 - x)^2 + 100 (y - x^2)^2, start (-1.2, 1), minimizer (1, 1).
GD (step 2e-3), heavy ball (step 5e-4, beta = 0.9), Adam (default step 1e-3 and step 3e-2,
which gives the smallest final value among {1e-3, 3e-3, 1e-2, 3e-2, 1e-1} after 5000 iterations) and
L-BFGS (m = 10, weak Wolfe line search).  We also count gradient evaluations, and report the
fewest iterations to f < 1e-8 over small grids of heavy-ball and Adam settings (grid_search).

Run from the project root:  python3 code/ch04/fig_rosenbrock.py   (a few seconds)
"""
import os
import sys

os.environ.setdefault("OMP_NUM_THREADS", "2")
import numpy as np  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from optimizers import gd, heavy_ball, adam, lbfgs  # noqa: E402


def f(x):
    return (1 - x[0]) ** 2 + 100 * (x[1] - x[0] ** 2) ** 2


class Counted:
    """Gradient oracle that counts its calls."""
    def __init__(self):
        self.n = 0

    def __call__(self, x):
        self.n += 1
        return np.array([-2 * (1 - x[0]) - 400 * x[0] * (x[1] - x[0] ** 2), 200 * (x[1] - x[0] ** 2)])


def grid_search(x0, n_it=5000):
    """Fewest iterations to f < 1e-8 over small grids of heavy-ball and Adam settings."""
    def first_hit(xs):
        with np.errstate(over="ignore", invalid="ignore"):
            fv = np.array([f(x) for x in xs])
        return int(np.argmax(fv < 1e-8)) if np.any(fv < 1e-8) else np.inf
    with np.errstate(over="ignore", invalid="ignore"):
        hb = min((first_hit(heavy_ball(Counted(), x0, lr, b, n_it)), lr, b)
                 for lr in (1e-4, 2e-4, 5e-4, 1e-3, 2e-3) for b in (0.5, 0.8, 0.9, 0.95, 0.99))
        ad = min((first_hit(adam(Counted(), x0, lr, n_it)), lr) for lr in (1e-3, 3e-3, 1e-2, 3e-2, 1e-1))
    print(f"grid: best heavy ball (lr, beta) = {hb[1:]}: f<1e-8 at iter {hb[0]};  "
          f"best Adam lr = {ad[1]}: f<1e-8 at iter {ad[0]}")


def main():
    x0 = np.array([-1.2, 1.0])
    grid_search(x0)
    n_it = 5000
    specs = [
        ("GD, $\\eta=2\\cdot10^{-3}$", lambda g: gd(g, x0, 2e-3, n_it), COLORS["blue"], "-"),
        ("heavy ball, $\\eta=5\\cdot10^{-4}$, $\\beta=0.9$", lambda g: heavy_ball(g, x0, 5e-4, 0.9, n_it),
         COLORS["orange"], "-"),
        ("Adam, $\\eta=10^{-3}$", lambda g: adam(g, x0, 1e-3, n_it), COLORS["green"], "--"),
        ("Adam, $\\eta=3\\cdot10^{-2}$", lambda g: adam(g, x0, 3e-2, n_it), COLORS["green"], "-"),
        ("L-BFGS, $m=10$", lambda g: lbfgs(f, g, x0, m=10, n_iter=200, tol=1e-12), COLORS["red"], "-"),
    ]
    runs = []
    for name, run, c, ls in specs:
        g = Counted()
        xs = run(g)
        fv = np.array([f(x) for x in xs])
        hit = int(np.argmax(fv < 1e-8)) if np.any(fv < 1e-8) else None
        print(f"{name:45s} iters {len(xs) - 1:5d}  grad evals {g.n:5d}  f_end {fv[-1]:.1e}  "
              f"first f<1e-8 at iter {hit}")
        runs.append((name, xs, fv, c, ls))
        if name.startswith("L-BFGS") and hit is not None:     # cost up to the first f < 1e-8
            g = Counted()
            lbfgs(f, g, x0, m=10, n_iter=hit, tol=1e-12)
            print(f"{'':45s} grad evals up to iter {hit}: {g.n}")

    set_style()
    fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.5), gridspec_kw={"width_ratios": [1.1, 1]})
    ax = axes[0]
    X, Yg = np.meshgrid(np.linspace(-1.5, 1.5, 300), np.linspace(-0.6, 1.6, 300))
    Z = (1 - X) ** 2 + 100 * (Yg - X ** 2) ** 2
    ax.contour(X, Yg, Z, levels=np.geomspace(0.05, 500, 14), colors=COLORS["gray"], linewidths=0.4, alpha=0.6)
    for name, xs, fv, c, ls in runs:
        if "10^{-3}$" in name and "Adam" in name:
            continue                      # keep panel (a) readable
        ax.plot(xs[:, 0], xs[:, 1], ls, color=c, lw=0.9, marker="o" if len(xs) < 100 else None, ms=1.8)
    ax.plot(1, 1, "k*", ms=7)
    ax.plot(*x0, "ks", ms=3)
    ax.set_xlim(-1.5, 1.5)
    ax.set_ylim(-0.6, 1.6)
    ax.set_xlabel("$x$")
    ax.set_ylabel("$y$")
    ax.set_title("(a) iterates")
    ax = axes[1]
    for name, xs, fv, c, ls in runs:
        k = np.arange(1, len(fv) + 1)
        ax.loglog(k, np.maximum(fv, 1e-20), ls, color=c, label=name)
    ax.set_ylim(1e-16, 1e2)
    ax.set_xlabel("iteration $k$ (+1)")
    ax.set_ylabel("$f(x_k)$")
    ax.set_title("(b) objective value")
    ax.legend(loc="lower left", fontsize=6.3, handlelength=1.8)
    fig.tight_layout(w_pad=0.8)
    print("saved", savefig(fig, "ch04", "rosenbrock"))


if __name__ == "__main__":
    main()

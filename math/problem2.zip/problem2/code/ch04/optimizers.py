"""From-scratch first-order and quasi-Newton optimizers in NumPy (Chapter 4).

Every routine takes a gradient oracle `grad(x)` (and `f(x)` where a line search is
needed), a starting point `x0`, and returns the array of iterates (n_iter + 1, dim) so
that figures can plot trajectories and convergence histories.

    gd(grad, x0, lr, n_iter)                         gradient descent
    heavy_ball(grad, x0, lr, beta, n_iter)           Polyak momentum
    nesterov(grad, x0, lr, beta, n_iter)             Nesterov accelerated gradient
    adam(grad, x0, lr, n_iter, b1, b2, eps)          Adam (Kingma & Ba, 2015)
    lbfgs(f, grad, x0, m, n_iter)                    L-BFGS: two-loop recursion + weak Wolfe line search

Run `python3 code/ch04/optimizers.py` for a self-test on a quadratic.
"""
import numpy as np


def gd(grad, x0, lr, n_iter):
    xs = [np.array(x0, float)]
    for _ in range(n_iter):
        xs.append(xs[-1] - lr * grad(xs[-1]))
    return np.array(xs)


def heavy_ball(grad, x0, lr, beta, n_iter):
    x = np.array(x0, float)
    v = np.zeros_like(x)
    xs = [x.copy()]
    for _ in range(n_iter):
        v = beta * v - lr * grad(x)          # x_{k+1} = x_k - lr g_k + beta (x_k - x_{k-1})
        x = x + v
        xs.append(x.copy())
    return np.array(xs)


def nesterov(grad, x0, lr, beta, n_iter):
    x = np.array(x0, float)
    x_prev = x.copy()
    xs = [x.copy()]
    for _ in range(n_iter):
        y = x + beta * (x - x_prev)          # look-ahead point
        x_prev, x = x, y - lr * grad(y)
        xs.append(x.copy())
    return np.array(xs)


def adam(grad, x0, lr, n_iter, b1=0.9, b2=0.999, eps=1e-8):
    x = np.array(x0, float)
    m, v = np.zeros_like(x), np.zeros_like(x)
    xs = [x.copy()]
    for k in range(1, n_iter + 1):
        g = grad(x)
        m = b1 * m + (1 - b1) * g
        v = b2 * v + (1 - b2) * g * g
        mhat, vhat = m / (1 - b1 ** k), v / (1 - b2 ** k)
        x = x - lr * mhat / (np.sqrt(vhat) + eps)
        xs.append(x.copy())
    return np.array(xs)


# ---------------------------------------------------------------- listing starts
def two_loop(g, S, Y):
    """Return the L-BFGS direction -H_k g from pairs (s_i, y_i), oldest first."""
    q = g.copy()
    rho = [1.0 / (y @ s) for s, y in zip(S, Y)]
    alpha = []
    for s, y, r in zip(reversed(S), reversed(Y), reversed(rho)):   # newest -> oldest
        a = r * (s @ q)
        q -= a * y
        alpha.append(a)
    gamma = (S[-1] @ Y[-1]) / (Y[-1] @ Y[-1]) if S else 1.0     # H_k^0 = gamma I
    z = gamma * q
    for s, y, r, a in zip(S, Y, rho, reversed(alpha)):            # oldest -> newest
        b = r * (y @ z)
        z += (a - b) * s
    return -z

def wolfe(f, grad, x, d, fx, gd, c1=1e-4, c2=0.9):
    """Bisection for a step t satisfying the weak Wolfe conditions."""
    lo, hi, t = 0.0, np.inf, 1.0
    for _ in range(60):
        if f(x + t * d) > fx + c1 * t * gd:          # sufficient decrease fails
            hi = t
        elif grad(x + t * d) @ d < c2 * gd:          # curvature condition fails
            lo = t
        else:
            break
        t = 2 * lo if hi == np.inf else 0.5 * (lo + hi)
    return t

def lbfgs(f, grad, x0, m=10, n_iter=100, tol=1e-10):
    x = np.array(x0, float)
    g = grad(x)
    S, Y, xs = [], [], [x.copy()]
    for _ in range(n_iter):
        d = two_loop(g, S, Y)
        t = wolfe(f, grad, x, d, f(x), g @ d)
        x_new = x + t * d
        g_new = grad(x_new)
        s, y = x_new - x, g_new - g
        if s @ y > 1e-12 * (y @ y):        # Wolfe guarantees s^T y > 0; guard round-off
            S.append(s); Y.append(y)
            if len(S) > m:                 # keep only the m most recent pairs
                S.pop(0); Y.pop(0)
        x, g = x_new, g_new
        xs.append(x.copy())
        if np.linalg.norm(g) < tol:
            break
    return np.array(xs)
# ---------------------------------------------------------------- listing ends


def _self_test():
    rng = np.random.default_rng(0)
    Q, _ = np.linalg.qr(rng.standard_normal((20, 20)))
    lam = np.logspace(-2, 0, 20)
    A = Q @ np.diag(lam) @ Q.T
    b = rng.standard_normal(20)
    xstar = np.linalg.solve(A, b)
    f = lambda x: 0.5 * x @ A @ x - b @ x
    grad = lambda x: A @ x - b
    x0 = np.zeros(20)
    L, mu = lam.max(), lam.min()
    k = np.sqrt(L / mu)
    res = {
        "gd": gd(grad, x0, 1 / L, 3000)[-1],
        "heavy_ball": heavy_ball(grad, x0, 4 / (np.sqrt(L) + np.sqrt(mu)) ** 2, ((k - 1) / (k + 1)) ** 2, 500)[-1],
        "nesterov": nesterov(grad, x0, 1 / L, (k - 1) / (k + 1), 500)[-1],
        "adam": adam(grad, x0, 1e-2, 20000)[-1],
        "lbfgs": lbfgs(f, grad, x0, n_iter=200)[-1],
    }
    for name, x in res.items():
        err = np.linalg.norm(x - xstar) / np.linalg.norm(xstar)
        print(f"{name:10s} relative error {err:.1e}")
        assert err < 1e-3, name
    print("all optimizers OK")


if __name__ == "__main__":
    _self_test()

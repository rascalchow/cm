"""PyTorch autograd for PDE residuals, Hessian-vector products, and torch.func (Chapter 5).

Run from the project root:  python3 code/ch05/autograd_pinn.py
Checks: (1) u_t, u_xx of a known function, (2) PDE-residual derivatives of a network
against finite differences, (3) Hessian-vector product against torch.func.hessian.
"""
import math

import torch
from torch.func import functional_call, hessian, jacfwd, jacrev, vmap

torch.set_num_threads(2)
torch.manual_seed(0)
torch.set_default_dtype(torch.float64)


def heat_residual(u_fn, x, t, kappa):
    """Residual r = u_t - kappa * u_xx at collocation points (x, t), each of shape (N, 1)."""
    x = x.clone().requires_grad_(True)
    t = t.clone().requires_grad_(True)
    u = u_fn(x, t)                                   # shape (N, 1)
    ones = torch.ones_like(u)
    # first derivatives; create_graph=True records them so they can be differentiated again
    u_x, u_t = torch.autograd.grad(u, (x, t), grad_outputs=ones, create_graph=True)
    u_xx, = torch.autograd.grad(u_x, x, grad_outputs=ones, create_graph=True)
    return u_t - kappa * u_xx


net = torch.nn.Sequential(torch.nn.Linear(2, 32), torch.nn.Tanh(),
                          torch.nn.Linear(32, 32), torch.nn.Tanh(), torch.nn.Linear(32, 1))
u_net = lambda x, t: net(torch.cat([x, t], dim=1))

x, t = torch.rand(256, 1), torch.rand(256, 1)
loss = heat_residual(u_net, x, t, kappa=0.1).pow(2).mean()
loss.backward()            # d(loss)/d(theta) flows back through u_xx (third-order mixed derivatives)


def hvp(f, w, v):
    """Hessian-vector product H(w) v by reverse-over-reverse (Pearlmutter's trick)."""
    w = w.detach().requires_grad_(True)
    g, = torch.autograd.grad(f(w), w, create_graph=True)
    Hv, = torch.autograd.grad(g @ v, w)
    return Hv


def main():
    # (1) exact solution of u_t = kappa u_xx: u = exp(-kappa pi^2 t) sin(pi x) -> residual 0
    kappa = 0.1
    u_exact = lambda x, t: torch.exp(-kappa * math.pi ** 2 * t) * torch.sin(math.pi * x)
    r = heat_residual(u_exact, x, t, kappa)
    print("max |residual| of the exact heat solution: %.2e" % r.abs().max().item())
    assert r.abs().max() < 1e-14

    # (2) network residual vs. finite differences
    with torch.no_grad():
        h = 1e-4
        xs, ts = x[:5], t[:5]
        u0 = u_net(xs, ts)
        u_xx_fd = (u_net(xs + h, ts) - 2 * u0 + u_net(xs - h, ts)) / h ** 2
        u_t_fd = (u_net(xs, ts + h) - u_net(xs, ts - h)) / (2 * h)
        r_fd = u_t_fd - 0.1 * u_xx_fd
    r_ad = heat_residual(u_net, xs, ts, 0.1).detach()
    print("network residual, AD vs FD: max diff %.2e" % (r_ad - r_fd).abs().max())
    assert (r_ad - r_fd).abs().max() < 1e-6
    # the output bias does not enter u_t - kappa*u_xx, so its .grad stays None
    no_grad = [k for k, p in net.named_parameters() if p.grad is None]
    print("loss = %.4e; parameters without gradient: %s" % (loss.item(), no_grad))

    # (3) Hessian-vector product of a loss of the flattened parameters
    params = {k: v.detach() for k, v in net.named_parameters()}
    shapes = [(k, v.shape, v.numel()) for k, v in params.items()]
    w0 = torch.cat([v.reshape(-1) for v in params.values()])

    def unflatten(w):
        out, i = {}, 0
        for k, s, n in shapes:
            out[k] = w[i:i + n].reshape(s)
            i += n
        return out

    xd, yd = torch.rand(64, 2), torch.rand(64, 1)
    f = lambda w: (functional_call(net, unflatten(w), (xd,)) - yd).pow(2).mean()
    v = torch.randn_like(w0)
    Hv = hvp(f, w0, v)
    H = hessian(f)(w0)                                # dense p x p Hessian (p = 1185)
    print("p = %d parameters; HVP vs dense Hessian: rel. diff %.2e"
          % (w0.numel(), ((Hv - H @ v).norm() / (H @ v).norm()).item()))
    assert ((Hv - H @ v).norm() / (H @ v).norm()) < 1e-12

    # (4) per-point Jacobians and Hessians of u w.r.t. the inputs with torch.func
    u_point = lambda z: net(z.unsqueeze(0)).squeeze()  # z = (x, t) -> scalar u
    z = torch.cat([x, t], dim=1)[:4]
    J = vmap(jacrev(u_point))(z)                       # (4, 2): (u_x, u_t) per point
    Hz = vmap(jacfwd(jacrev(u_point)))(z)              # (4, 2, 2): forward-over-reverse
    r_func = J[:, 1] - 0.1 * Hz[:, 0, 0]
    print("torch.func residual vs autograd residual: %.2e"
          % (r_func - heat_residual(u_net, x[:4], t[:4], 0.1).squeeze()).abs().max().item())
    print("all autograd checks passed")


if __name__ == "__main__":
    main()

"""Forward-mode automatic differentiation with dual numbers (Chapter 5).

A dual number a + b*eps with eps**2 = 0 carries a primal value a and a tangent b.
Evaluating f on x + 1*eps yields f(x) + f'(x)*eps: the tangent is the derivative.

Run:  python3 code/ch05/dual.py      (self-test against analytic derivatives)
"""
import math


class Dual:
    """Dual number val + tan*eps with eps**2 = 0 (forward-mode AD)."""

    def __init__(self, val, tan=0.0):
        self.val, self.tan = val, tan

    def __add__(self, o):
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val + o.val, self.tan + o.tan)
    __radd__ = __add__

    def __sub__(self, o):
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val - o.val, self.tan - o.tan)

    def __rsub__(self, o):
        return Dual(o) - self

    def __mul__(self, o):                       # product rule
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val * o.val, self.tan * o.val + self.val * o.tan)
    __rmul__ = __mul__

    def __truediv__(self, o):                   # quotient rule
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val / o.val, (self.tan * o.val - self.val * o.tan) / o.val ** 2)

    def __rtruediv__(self, o):
        return Dual(o) / self

    def __pow__(self, p):                       # constant real exponent p
        return Dual(self.val ** p, p * self.val ** (p - 1) * self.tan)


def sin(x):  return Dual(math.sin(x.val), math.cos(x.val) * x.tan)
def cos(x):  return Dual(math.cos(x.val), -math.sin(x.val) * x.tan)
def exp(x):  return Dual(math.exp(x.val), math.exp(x.val) * x.tan)
def sqrt(x): return Dual(math.sqrt(x.val), 0.5 * x.tan / math.sqrt(x.val))


def derivative(f, x):
    """f'(x) by one forward sweep: seed the tangent with 1."""
    return f(Dual(x, 1.0)).tan


def jvp(f, x, v):
    """Jacobian-vector product J_f(x) v for f: R^n -> R^m (lists of floats)."""
    out = f([Dual(xi, vi) for xi, vi in zip(x, v)])
    return [o.tan for o in out]


def _self_test():
    # Squire & Trapp (1998) test function used in fig_fd_error.py
    def f(x):
        return exp(x) / sqrt(sin(x) ** 3 + cos(x) ** 3)

    def fprime_exact(x):
        s, c = math.sin(x), math.cos(x)
        g = s ** 3 + c ** 3
        return math.exp(x) / math.sqrt(g) * (1.0 - (3 * s * s * c - 3 * c * c * s) / (2 * g))

    x0 = 1.5
    d = derivative(f, x0)
    print("dual-number f'(1.5) = %.16e   exact = %.16e   rel.err = %.2e"
          % (d, fprime_exact(x0), abs(d - fprime_exact(x0)) / abs(fprime_exact(x0))))
    assert abs(d - fprime_exact(x0)) < 1e-13 * abs(fprime_exact(x0))

    # JVP of g(x1, x2) = (x1*x2 + sin(x1), x1 / x2) in direction v = (1, -2)
    def g(x):
        return [x[0] * x[1] + sin(x[0]), x[0] / x[1]]
    x, v = [0.7, 1.3], [1.0, -2.0]
    J = [[x[1] + math.cos(x[0]), x[0]], [1 / x[1], -x[0] / x[1] ** 2]]
    ref = [J[0][0] * v[0] + J[0][1] * v[1], J[1][0] * v[0] + J[1][1] * v[1]]
    out = jvp(g, x, v)
    print("JVP:", out, " reference:", ref)
    assert max(abs(a - b) for a, b in zip(out, ref)) < 1e-14
    print("dual.py self-test passed")


if __name__ == "__main__":
    _self_test()

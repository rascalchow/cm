"""Figure 5.1: error of finite differences, complex step, and AD versus step size.

Test function of Lyness & Moler (1967) / Squire & Trapp (1998):
    f(x) = exp(x) / sqrt(sin(x)^3 + cos(x)^3),   x0 = 1.5.
Errors are measured against a 50-digit reference derivative (mpmath).
Run from the project root:  python3 code/ch05/fig_fd_error.py
"""
import os
import sys

import mpmath
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
import dual  # noqa: E402

torch.set_num_threads(2)
EPS = np.finfo(float).eps
mpmath.mp.dps = 50


def f_np(x):  # works for real and complex arguments
    return np.exp(x) / np.sqrt(np.sin(x) ** 3 + np.cos(x) ** 3)


def f_dual(x):
    return dual.exp(x) / dual.sqrt(dual.sin(x) ** 3 + dual.cos(x) ** 3)


def f_mp(z):
    return mpmath.exp(z) / mpmath.sqrt(mpmath.sin(z) ** 3 + mpmath.cos(z) ** 3)


def higher_derivatives(x0):
    """f, f', f'', f''' at x0 by nested reverse-mode AD in PyTorch (create_graph=True)."""
    x = torch.tensor(x0, dtype=torch.float64, requires_grad=True)
    y = torch.exp(x) / torch.sqrt(torch.sin(x) ** 3 + torch.cos(x) ** 3)
    d1, = torch.autograd.grad(y, x, create_graph=True)
    d2, = torch.autograd.grad(d1, x, create_graph=True)
    d3, = torch.autograd.grad(d2, x)
    return y.item(), d1.item(), d2.item(), d3.item()


def main():
    set_style()
    x0 = 1.5
    ref = mpmath.diff(f_mp, mpmath.mpf(x0))          # 50-digit f'(x0)
    f0, d1, d2, d3 = higher_derivatives(x0)
    print("f(x0)=%.6f f'=%.15f (reference %s) f''=%.6f f'''=%.6f"
          % (f0, d1, mpmath.nstr(ref, 16), d2, d3))

    def rel(a):
        """Relative error against the 50-digit reference; exact zeros drawn at 1e-18."""
        a = np.atleast_1d(a)
        return np.array([max(float(abs((mpmath.mpf(float(v)) - ref) / ref)), 1e-18) for v in a])

    h = np.logspace(-20, -0.5, 400)
    e_fwd = rel((f_np(x0 + h) - f_np(x0)) / h)
    e_cen = rel((f_np(x0 + h) - f_np(x0 - h)) / (2 * h))
    e_cs = rel(np.imag(f_np(x0 + 1j * h)) / h)
    e_ad = rel(dual.derivative(f_dual, x0))[0]
    e_torch = rel(d1)[0]
    print("AD (dual numbers) rel. error: %.2e, AD (PyTorch) rel. error: %.2e" % (e_ad, e_torch))

    # error models: truncation + round-off (Section 5.1)
    fp = float(ref)
    m_fwd = (0.5 * h * abs(d2) + 2 * EPS * abs(f0) / h) / abs(fp)
    m_cen = (h ** 2 * abs(d3) / 6 + EPS * abs(f0) / h) / abs(fp)
    for name, e in (("forward", e_fwd), ("central", e_cen)):
        i = np.argmin(e)
        print("%s difference: best rel. error %.2e at h = %.1e" % (name, e[i], h[i]))
    print("predicted optimal h: forward %.1e, central %.1e"
          % (np.sqrt(4 * EPS * abs(f0) / abs(d2)), (3 * EPS * abs(f0) / abs(d3)) ** (1 / 3)))
    i3 = np.argmin(np.abs(h - 1e-3))
    print("complex step: max rel. error for h<=1e-8: %.2e; at h=1e-3: %.2e"
          % (e_cs[h <= 1e-8].max(), e_cs[i3]))

    fig, ax = plt.subplots(figsize=(FULL_WIDTH, 2.3))
    ax.loglog(h, e_fwd, color=COLORS["blue"], lw=1.0, label="forward difference")
    ax.loglog(h, e_cen, color=COLORS["orange"], lw=1.0, label="central difference")
    ax.loglog(h, e_cs, color=COLORS["green"], lw=1.4, label="complex step")
    ax.axhline(e_ad, color=COLORS["red"], lw=1.4, ls="-", label="AD (dual numbers)")
    ok = m_fwd < 2
    ax.loglog(h[ok], m_fwd[ok], color=COLORS["blue"], ls="--", lw=0.8, label="error model (fwd.)")
    ok = m_cen < 2
    ax.loglog(h[ok], m_cen[ok], color=COLORS["orange"], ls="--", lw=0.8, label="error model (central)")
    ax.axhline(EPS, color=COLORS["gray"], lw=0.6, ls=":")
    ax.text(2e-20, EPS * 2.0, r"machine epsilon", fontsize=7, color=COLORS["gray"])
    ax.set_xlabel(r"step size $h$")
    ax.set_ylabel(r"relative error in $f'(1.5)$")
    ax.set_ylim(3e-19, 5)
    ax.set_xlim(1e-20, 0.4)
    ax.legend(loc="center left", bbox_to_anchor=(1.0, 0.5), fontsize=7.5, handlelength=1.8)
    path = savefig(fig, "ch05", "fd_error")
    print("saved", path)


if __name__ == "__main__":
    main()

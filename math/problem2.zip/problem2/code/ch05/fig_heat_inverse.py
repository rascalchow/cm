"""Figure 5.4: recover a spatially varying diffusivity by differentiating through a
Crank-Nicolson heat solver (Chapter 5).

    u_t = (kappa(x) u_x)_x on (0, 1),  u(0, t) = u(1, t) = 0,
    log kappa(x) = sum_j c_j phi_j(x)  (M piecewise-linear hat functions).

Data are generated with the verified solver heat_fd (code/common) on a 4x finer grid
with a 10x smaller time step and corrupted by Gaussian noise. The gradient of the
misfit with respect to c is computed (i) by PyTorch AD through the solver, (ii) by a
hand-written discrete adjoint (NumPy), (iii) by central differences.
Run from the project root:  python3 code/ch05/fig_heat_inverse.py
"""
import math
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import heat_fd  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)
torch.manual_seed(0)
rng = np.random.default_rng(0)

# ---------------------------------------------------------------- problem set-up
n, M = 101, 12                       # grid nodes, number of hat functions
x = np.linspace(0.0, 1.0, n)
h = x[1] - x[0]
dt, n_steps, obs_every = 2e-3, 50, 5  # T = 0.1, observations every 0.01
nodes = np.linspace(0.0, 1.0, M)
Phi_np = np.maximum(0.0, 1.0 - np.abs(x[:, None] - nodes[None, :]) / (nodes[1] - nodes[0]))
Phi = torch.tensor(Phi_np)            # (n, M) hat-function basis
kappa_true = lambda z: 0.04 + 0.06 * np.exp(-((z - 0.65) / 0.1) ** 2)
centers = [0.2, 0.4, 0.6, 0.8]        # four initial bumps
u0_fun = lambda z, c: np.exp(-((z - c) / 0.07) ** 2) * np.sin(np.pi * z)
sigma_noise = 0.01


def solve_heat(c, U0):
    """Differentiable Crank-Nicolson solve; returns interior states at observation times."""
    kappa = torch.exp(Phi @ c)                          # nodal diffusivity (log-parameterized)
    kf = 0.5 * (kappa[:-1] + kappa[1:])                 # values at cell faces
    A = (torch.diag(kf[1:-1], -1) + torch.diag(kf[1:-1], 1)
         - torch.diag(kf[:-1] + kf[1:])) / h ** 2       # (n-2) x (n-2) operator (kappa u_x)_x
    I = torch.eye(n - 2)
    LU, piv = torch.linalg.lu_factor(I - 0.5 * dt * A)  # factor once per parameter value
    R = I + 0.5 * dt * A
    U, out = U0, []                                     # U0: (n-2, n_ic), one column per IC
    for k in range(1, n_steps + 1):
        U = torch.linalg.lu_solve(LU, piv, R @ U)       # one CN step for all ICs at once
        if k % obs_every == 0:
            out.append(U)
    return torch.stack(out)                             # (n_obs, n-2, n_ic)


def misfit(c, U0, data):
    return 0.5 * (solve_heat(c, U0) - data).pow(2).mean()


def adjoint_gradient(c, U0, data):
    """Hand-written discrete adjoint of the CN scheme (NumPy) for the misfit only."""
    kappa = np.exp(Phi_np @ c)
    kf = 0.5 * (kappa[:-1] + kappa[1:])
    A = (np.diag(kf[1:-1], -1) + np.diag(kf[1:-1], 1) - np.diag(kf[:-1] + kf[1:])) / h ** 2
    I = np.eye(n - 2)
    B, C = I - 0.5 * dt * A, I + 0.5 * dt * A
    Us = [U0]
    for k in range(n_steps):                            # forward sweep, store all states
        Us.append(np.linalg.solve(B, C @ Us[-1]))
    nrm = data.size
    mu_next = np.zeros_like(U0)
    g_kf = np.zeros(n - 1)
    pad = lambda V: np.vstack([np.zeros((1, V.shape[1])), V, np.zeros((1, V.shape[1]))])
    for k in range(n_steps, 0, -1):                     # backward sweep: B^T mu_k = C^T mu_{k+1} + dl_k
        rhs = C.T @ mu_next
        if k % obs_every == 0:
            rhs = rhs + (Us[k] - data[k // obs_every - 1]) / nrm
        mu = np.linalg.solve(B.T, rhs)
        # dJ/dkf_f += (dt/2) mu^T (dA/dkf_f) (u^k + u^{k-1});  mu^T A w = -sum_f kf_f Dmu_f Dw_f / h^2
        Dmu, Dw = np.diff(pad(mu), axis=0), np.diff(pad(Us[k] + Us[k - 1]), axis=0)
        g_kf += -0.5 * dt * np.sum(Dmu * Dw, axis=1) / h ** 2
        mu_next = mu
    g_kappa = np.zeros(n)
    g_kappa[:-1] += 0.5 * g_kf
    g_kappa[1:] += 0.5 * g_kf
    return Phi_np.T @ (kappa * g_kappa)


def main():
    set_style()
    t_obs = dt * obs_every * np.arange(1, n_steps // obs_every + 1)

    # ---- verify the torch solver against the shared reference solver (same grid, same dt)
    c_test = torch.tensor(np.log(kappa_true(nodes)))
    U0_test = np.stack([u0_fun(x, cc) for cc in centers], axis=1)
    ours = solve_heat(c_test, torch.tensor(U0_test[1:-1]))[-1].detach().numpy()
    kap_nodes = np.exp(Phi_np @ c_test.numpy())
    ref = heat_fd(U0_test[:, 0], kap_nodes, x, np.array([0.0, n_steps * dt]), dt=dt)[-1, 1:-1]
    print("torch CN vs heat_fd (same grid and dt): max diff %.2e" % np.abs(ours[:, 0] - ref).max())

    # ---- synthetic data: fine grid (401 nodes), dt/10, then noise
    xf = np.linspace(0, 1, 4 * (n - 1) + 1)
    t_save = np.concatenate([[0.0], t_obs])
    data = np.zeros((len(t_obs), n - 2, len(centers)))
    for j, cc in enumerate(centers):
        Uf = heat_fd(u0_fun(xf, cc), kappa_true(xf), xf, t_save, dt=dt / 10)
        data[:, :, j] = Uf[1:, ::4][:, 1:-1]
    clean = data.copy()
    data += sigma_noise * rng.standard_normal(data.shape)
    U0 = torch.tensor(U0_test[1:-1])
    data_t = torch.tensor(data)

    # ---- gradient check at the initial guess: AD vs discrete adjoint vs central differences
    c0 = torch.full((M,), math.log(0.05))
    c = c0.clone().requires_grad_(True)
    t0 = time.perf_counter()
    J = misfit(c, U0, data_t)
    g_ad, = torch.autograd.grad(J, c)
    t_ad = time.perf_counter() - t0
    g_adj = adjoint_gradient(c0.numpy(), U0_test[1:-1], data)
    eps = 1e-6
    g_fd = np.array([(misfit(c0 + eps * e, U0, data_t) - misfit(c0 - eps * e, U0, data_t)).item()
                     / (2 * eps) for e in torch.eye(M)])
    rd = lambda a, b: np.linalg.norm(a - b) / np.linalg.norm(b)
    print("gradient check: |AD-adjoint|/|adjoint| = %.2e, |AD-FD|/|AD| = %.2e"
          % (rd(g_ad.numpy(), g_adj), rd(g_fd, g_ad.numpy())))
    print("time for misfit + AD gradient: %.3f s" % t_ad)

    # ---- L-BFGS on misfit + smoothness penalty
    beta = 1e-6
    c = c0.clone().requires_grad_(True)
    opt = torch.optim.LBFGS([c], lr=1.0, max_iter=300, tolerance_grad=1e-12,
                            tolerance_change=1e-15, history_size=20, line_search_fn="strong_wolfe")
    hist = []

    def closure():
        opt.zero_grad()
        loss = misfit(c, U0, data_t) + beta * (c[1:] - c[:-1]).pow(2).sum()
        loss.backward()
        hist.append(loss.item())
        return loss
    t0 = time.perf_counter()
    opt.step(closure)
    print("L-BFGS: %d function/gradient evaluations in %.1f s; final loss %.4e"
          % (len(hist), time.perf_counter() - t0, hist[-1]))
    noise_floor = 0.5 * sigma_noise ** 2
    print("noise floor 0.5*sigma^2 = %.3e;  clean-data misfit at truth-on-coarse-grid = %.3e"
          % (noise_floor, misfit(c_test, U0, torch.tensor(clean)).item()))
    k_rec = np.exp(Phi_np @ c.detach().numpy())
    err = np.linalg.norm(k_rec - kappa_true(x)) / np.linalg.norm(kappa_true(x))
    print("relative L2 error of recovered kappa: %.3f" % err)

    # ---- figure
    fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.15))
    ax = axs[0]
    j = 2
    pred = solve_heat(c.detach(), U0).numpy()
    ax.plot(x, U0_test[:, j], color=COLORS["gray"], lw=0.9, ls="--", label=r"$u_0$")
    for i, col in zip([0, 3, 9], [COLORS["blue"], COLORS["orange"], COLORS["green"]]):
        ax.plot(x[1:-1:3], data[i, ::3, j], ".", ms=2.2, color=col)
        ax.plot(x[1:-1], pred[i, :, j], color=col, lw=1.0, label=r"$t=%.2f$" % t_obs[i])
    ax.set_xlabel(r"$x$")
    ax.set_ylabel(r"$u(x,t)$")
    ax.set_title("(a) noisy data and fitted model", loc="left")
    ax.legend(fontsize=6.5, loc="upper left", handlelength=1.2)
    ax = axs[1]
    ax.plot(x, kappa_true(x), color="k", lw=1.6, label="true")
    ax.plot(x, np.exp(Phi_np @ c0.numpy()), color=COLORS["gray"], ls=":", label="initial guess")
    ax.plot(x, k_rec, color=COLORS["red"], lw=1.2, ls="--", label="recovered")
    ax.set_xlabel(r"$x$")
    ax.set_ylabel(r"$\kappa(x)$")
    ax.set_title(r"(b) diffusivity", loc="left")
    ax.legend(fontsize=6.5, loc="upper left")
    ax = axs[2]
    ax.semilogy(np.arange(1, len(hist) + 1), hist, color=COLORS["blue"])
    ax.axhline(noise_floor, color=COLORS["gray"], ls="--", lw=0.8)
    ax.text(len(hist) * 0.35, noise_floor * 1.25, r"noise level $\sigma^2/2$", fontsize=7,
            color=COLORS["gray"])
    ax.set_xlabel("loss evaluations (L-BFGS)")
    ax.set_ylabel("loss")
    ax.set_title("(c) convergence", loc="left")
    fig.tight_layout(w_pad=0.8)
    print("saved", savefig(fig, "ch05", "heat_inverse"))


if __name__ == "__main__":
    main()

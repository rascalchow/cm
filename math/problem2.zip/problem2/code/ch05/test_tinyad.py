"""Tests for the reverse-mode engine in tinyad.py (Chapter 5).

Gradients are compared with PyTorch autograd (float64) and with central
differences. Run from the project root:  python3 code/ch05/test_tinyad.py
"""
import math
import os
import random
import sys

import torch

sys.path.insert(0, os.path.dirname(__file__))
import tinyad as ad  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)


def torch_grad(f_torch, xs):
    ts = [torch.tensor(x, requires_grad=True) for x in xs]
    y = f_torch(*ts)
    y.backward()
    return y.item(), [t.grad.item() for t in ts]


def central_diff(f_float, xs, h=1e-6):
    g = []
    for i in range(len(xs)):
        xp = list(xs); xm = list(xs)
        xp[i] += h; xm[i] -= h
        g.append((f_float(*xp) - f_float(*xm)) / (2 * h))
    return g


def check(name, f_ad, f_torch, xs, tol=1e-12):
    val, g = ad.grad(f_ad, *xs)
    val_t, g_t = torch_grad(f_torch, xs)
    err = max(abs(a - b) for a, b in zip(g, g_t)) / max(1.0, max(abs(b) for b in g_t))
    fd = central_diff(lambda *z: ad.grad(f_ad, *z)[0], xs)
    err_fd = max(abs(a - b) for a, b in zip(g, fd)) / max(1.0, max(abs(b) for b in fd))
    print("%-34s |f-f_torch|=%.1e  rel.grad err vs torch=%.1e  vs central diff=%.1e"
          % (name, abs(val - val_t), err, err_fd))
    assert abs(val - val_t) < 1e-12 * max(1.0, abs(val_t)) and err < tol and err_fd < 1e-6


def main():
    random.seed(0)
    # 1. the worked example of Section 5.2: f = x1*x2 + sin(x1)
    check("x1*x2 + sin(x1)", lambda a, b: a * b + ad.sin(a),
          lambda a, b: a * b + torch.sin(a), [0.7, 1.3])
    # 2. Rosenbrock function
    check("Rosenbrock", lambda a, b: (1 - a) ** 2 + 100 * (b - a ** 2) ** 2,
          lambda a, b: (1 - a) ** 2 + 100 * (b - a ** 2) ** 2, [-1.2, 1.0])
    # 3. shared subexpressions (diamond graph): adjoints must accumulate
    def f3(x):
        y = x * x
        return y * y + y / x - 3.0 / y
    check("shared subexpressions", f3, f3, [1.7])
    # 4. all elementary operations
    check("exp, log, tanh, cos, pow, div",
          lambda a, b: ad.exp(a / b) - ad.log(b) * ad.tanh(a) + ad.cos(a * b) ** 3 + 2 / (1 + a),
          lambda a, b: torch.exp(a / b) - torch.log(b) * torch.tanh(a) + torch.cos(a * b) ** 3 + 2 / (1 + a),
          [0.4, 1.9])
    # 5. a small tanh network 3 -> 4 -> 1 with squared loss; gradient w.r.t. all 21 weights
    x_in, target = [0.3, -0.8, 1.1], 0.25

    def mlp(*w):
        W1, b1, W2, b2 = w[:12], w[12:16], w[16:20], w[20]
        hid = []
        for j in range(4):
            s = b1[j]
            for i in range(3):
                s = s + W1[3 * j + i] * x_in[i]
            hid.append(ad.tanh(s) if isinstance(s, ad.Var) else torch.tanh(s))
        out = b2
        for j in range(4):
            out = out + W2[j] * hid[j]
        return (out - target) ** 2
    weights = [random.gauss(0, 0.8) for _ in range(21)]
    check("tanh MLP (21 parameters)", mlp, mlp, weights)
    # 6. a long computational graph: 5000 explicit Euler steps of x' = -sin(x) * p
    def euler(x, p):
        for _ in range(5000):
            x = x - 1e-3 * p * (ad.sin(x) if isinstance(x, ad.Var) else torch.sin(x))
        return x
    check("5000-step Euler loop", euler, euler, [1.0, 0.8], tol=1e-11)
    print("all tinyad tests passed")


if __name__ == "__main__":
    main()

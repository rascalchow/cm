"""tinyad: a minimal reverse-mode automatic differentiation engine (Chapter 5).

Each Var stores its primal value, its parents together with the local partial
derivatives d(self)/d(parent), and an adjoint `grad` = d(output)/d(self) that is
filled in by `backward()`. Tests: python3 code/ch05/test_tinyad.py
"""
import math


class Var:
    def __init__(self, value, parents=()):
        self.value = float(value)    # primal value v_i
        self.parents = parents       # tuple of (parent Var, local partial dv_i/dv_j)
        self.grad = 0.0              # adjoint vbar_i = dy/dv_i, set by backward()

    def __add__(self, o):
        o = o if isinstance(o, Var) else Var(o)
        return Var(self.value + o.value, ((self, 1.0), (o, 1.0)))

    def __mul__(self, o):
        o = o if isinstance(o, Var) else Var(o)
        return Var(self.value * o.value, ((self, o.value), (o, self.value)))

    def __pow__(self, p):            # constant exponent p
        return Var(self.value ** p, ((self, p * self.value ** (p - 1)),))

    __radd__, __rmul__ = __add__, __mul__
    __neg__ = lambda self: self * -1.0
    __sub__ = lambda self, o: self + (-o)
    __rsub__ = lambda self, o: (-self) + o
    __truediv__ = lambda self, o: self * o ** -1.0
    __rtruediv__ = lambda self, o: o * self ** -1.0

    def backward(self):
        # 1) topological order of the graph (iterative depth-first search)
        order, seen, stack = [], set(), [(self, False)]
        while stack:
            v, expanded = stack.pop()
            if expanded:
                order.append(v)
            elif id(v) not in seen:
                seen.add(id(v))
                stack.append((v, True))
                stack.extend((p, False) for p, _ in v.parents)
        # 2) reverse sweep, outputs before inputs: vbar_j += vbar_i * dv_i/dv_j
        self.grad = 1.0
        for v in reversed(order):
            for p, local in v.parents:
                p.grad += v.grad * local


def sin(x): return Var(math.sin(x.value), ((x, math.cos(x.value)),))
def exp(x): return Var(math.exp(x.value), ((x, math.exp(x.value)),))
def tanh(x): return Var(math.tanh(x.value), ((x, 1.0 - math.tanh(x.value) ** 2),))
def cos(x): return Var(math.cos(x.value), ((x, -math.sin(x.value)),))
def log(x): return Var(math.log(x.value), ((x, 1.0 / x.value),))


def grad(f, *xs):
    """Value and gradient of the scalar function f at the point xs (floats)."""
    vs = [Var(x) for x in xs]
    y = f(*vs)
    y.backward()
    return y.value, [v.grad for v in vs]

"""Figure 6.3: the Kolmogorov barrier for transport -- POD versus a nonlinear autoencoder.

Data: a narrow Gaussian pulse u(x; s) = exp(-(x - s)^2 / (2 w^2)) on [0, 1] (n = 128 points),
shifted to positions s in [0.15, 0.85]. The family is a one-dimensional manifold in R^128,
but it is not close to any low-dimensional linear subspace (w = 0.02).

Run from the project root:  python3 code/ch06/fig_kolmogorov_barrier.py   (2-10 minutes, depending on machine load)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
import torch
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402

torch.set_num_threads(2)
torch.manual_seed(0)
rng = np.random.default_rng(0)
set_style()

n, w = 128, 0.02
x = np.linspace(0, 1, n)
pulse = lambda s: np.exp(-(x[None, :] - np.asarray(s)[:, None]) ** 2 / (2 * w ** 2))
S_train, S_test = rng.uniform(0.15, 0.85, 400), rng.uniform(0.15, 0.85, 200)
Utr, Ute = pulse(S_train), pulse(S_test)                 # rows are snapshots

# ---- linear: POD (no mean subtraction needed for the comparison; we subtract it anyway)
mean = Utr.mean(0)
_, sv, Vt = np.linalg.svd(Utr - mean, full_matrices=False)
pod_r = np.arange(1, 65)
pod_err = [np.linalg.norm((Ute - mean) - (Ute - mean) @ Vt[:k].T @ Vt[:k]) / np.linalg.norm(Ute)
           for k in pod_r]


# ---- nonlinear: fully connected autoencoder
class AE(torch.nn.Module):
    def __init__(self, n, r, h=(128, 32)):
        super().__init__()
        act = torch.nn.ELU
        self.enc = torch.nn.Sequential(torch.nn.Linear(n, h[0]), act(), torch.nn.Linear(h[0], h[1]), act(),
                                       torch.nn.Linear(h[1], r))
        self.dec = torch.nn.Sequential(torch.nn.Linear(r, h[1]), act(), torch.nn.Linear(h[1], h[0]), act(),
                                       torch.nn.Linear(h[0], n))

    def forward(self, u):
        return self.dec(self.enc(u))


def train_ae(r, epochs=400):
    model = AE(n, r)                                      # float32 is adequate here
    opt = torch.optim.Adam(model.parameters(), lr=2e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=1e-5)
    U = torch.tensor(Utr, dtype=torch.float32)
    for ep in range(epochs):
        idx = torch.randperm(U.shape[0])
        for b in idx.split(32):                           # minibatches of 32 snapshots
            opt.zero_grad()
            loss = torch.mean((model(U[b]) - U[b]) ** 2)
            loss.backward()
            opt.step()
        sched.step()
    with torch.no_grad():
        R = model(torch.tensor(Ute, dtype=torch.float32)).double().numpy()
    return model, R


ae_r = [1, 2, 4]
ae_err, recon = [], {}
for r in ae_r:
    torch.manual_seed(r)
    model, R = train_ae(r)
    ae_err.append(np.linalg.norm(R - Ute) / np.linalg.norm(Ute))
    recon[r] = R
    print("AE  r=%d  test relative error %.3e" % (r, ae_err[-1]))
for k in (1, 2, 4, 8, 16, 24, 32, 48, 64):
    print("POD r=%2d test relative error %.3e" % (k, pod_err[k - 1]))

fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.1))
ax = axs[0]
for s in (0.2, 0.4, 0.6, 0.8):
    ax.plot(x, pulse([s])[0], color=COLORS["blue"], lw=1)
ax.set_xlabel("$x$")
ax.set_title("(a) shifted pulses $u(x;s)$")
ax = axs[1]
ax.semilogy(pod_r, pod_err, "-", color=COLORS["blue"], label="POD (linear)")
ax.semilogy(ae_r, ae_err, "o", color=COLORS["orange"], label="autoencoder")
ax.set_xlim(0, 40)
ax.set_ylim(3e-3, 1.5)
ax.set_xlabel("latent dimension $r$")
ax.set_ylabel("relative test error")
ax.set_title("(b) linear vs. nonlinear")
ax.legend(fontsize=7)
ax = axs[2]
j = int(np.argmin(np.abs(S_test - 0.5)))
c = Ute[j] - mean
ax.plot(x, Ute[j], color="0.6", lw=2.4, label="truth")
ax.plot(x, mean + Vt[:2].T @ (Vt[:2] @ c), color=COLORS["blue"], lw=1, label="POD, $r=2$")
ax.plot(x, mean + Vt[:16].T @ (Vt[:16] @ c), ":", color=COLORS["green"], lw=1.2, label="POD, $r=16$")
ax.plot(x, recon[2][j], "--", color=COLORS["orange"], lw=1.2, label="AE, $r=2$")
ax.set_xlim(0.3, 0.7)
ax.set_xlabel("$x$")
ax.set_title("(c) reconstruction of a test pulse")
ax.legend(fontsize=6.5, loc="upper left", handlelength=1.6)
fig.tight_layout(w_pad=0.6)
print("saved", savefig(fig, "ch06", "kolmogorov_barrier"))

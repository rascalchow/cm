"""Figure 6.1: Burgers snapshots, singular-value decay, and leading POD modes.

Run from the project root:  python3 code/ch06/fig_pod_burgers.py   (about 20 s)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import burgers_periodic  # noqa: E402
from rom_utils import burgers_snapshots, pod  # noqa: E402

set_style()
n, T, nt = 256, 4.0, 401
x, t, X = burgers_snapshots(nu=0.02, n=n, T=T, nt=nt)          # traveling, steepening bump

# standing shock: u0 = sin(x), nu = 0.05 (no net transport)
Xs = burgers_periodic(np.sin(x), 0.05, 2 * np.pi, t, dt=1e-3).T
# pure transport of a narrow pulse at unit speed (linear advection, exact solution)
xc = (x[:, None] - 2.0 - 1.0 * t[None, :] + np.pi) % (2 * np.pi) - np.pi
Xa = 0.5 + np.exp(-(xc / 0.15) ** 2)

sv = {}
for name, D in [("standing shock", Xs), ("traveling bump", X), ("advected pulse", Xa)]:
    sv[name] = np.linalg.svd(D - D.mean(1, keepdims=True), compute_uv=False)
ubar, V, s = pod(X, 4)
energy = np.cumsum(s ** 2) / np.sum(s ** 2)
for name, sk in sv.items():
    e = np.cumsum(sk ** 2) / np.sum(sk ** 2)
    print("%-15s modes for 99%%: %3d  99.99%%: %3d  sigma_20/sigma_1 = %.1e"
          % (name, np.searchsorted(e, 0.99) + 1, np.searchsorted(e, 0.9999) + 1, sk[19] / sk[0]))

fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.15), gridspec_kw={"width_ratios": [1, 1.05, 1.05]})
ax = axs[0]
im = ax.pcolormesh(x, t, X.T, shading="auto", cmap="viridis", rasterized=True)
ax.set_xlabel("$x$")
ax.set_ylabel("$t$")
ax.set_title("(a) snapshots $u(x,t)$")
cb = fig.colorbar(im, ax=ax, pad=0.02, fraction=0.06)
cb.ax.tick_params(labelsize=7)

ax = axs[1]
cols = [COLORS["green"], COLORS["blue"], COLORS["orange"]]
for (name, sk), c in zip(sv.items(), cols):
    k = np.arange(1, 101)
    ax.semilogy(k, sk[:100] / sk[0], "-", color=c, label=name)
ax.set_ylim(1e-12, 2)
ax.set_xlabel("index $k$")
ax.set_ylabel(r"$\sigma_k/\sigma_1$")
ax.set_title("(b) singular values")
ax.legend(loc="lower left", fontsize=7, handlelength=1.4)

ax = axs[2]
cols4 = [COLORS[c] for c in ("blue", "orange", "green", "red")]
for j in range(4):
    ax.plot(x, V[:, j] / np.abs(V[:, j]).max() * 0.45 - 1.1 * j, color=cols4[j])
    ax.text(2 * np.pi + 0.15, -1.1 * j, r"$\varphi_%d$" % (j + 1), va="center", fontsize=8)
ax.set_yticks([])
ax.spines["left"].set_visible(False)
ax.set_xlim(0, 2 * np.pi)
ax.set_xlabel("$x$")
ax.set_title("(c) POD modes (traveling bump)")
fig.tight_layout(w_pad=0.8)
print("saved", savefig(fig, "ch06", "pod_burgers"))

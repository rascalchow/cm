"""Figure 6.2: accuracy of POD-Galerkin, POD-DEIM and operator-inference ROMs for Burgers.

Run from the project root:  python3 code/ch06/fig_rom_burgers.py   (about 1-2 minutes)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys
import time

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from rom_utils import (burgers_snapshots, spectral_matrices, pod, galerkin_tensors,  # noqa: E402
                       galerkin_rhs, deim_points, deim_galerkin_rhs, opinf_fit,
                       time_derivative, simulate, rel_err)

set_style()
nu = 0.02
x, t, X = burgers_snapshots(nu=nu, n=256, T=4.0, nt=401)
D1, D2 = spectral_matrices(X.shape[0])
ubar, Vall, s = pod(X, 40)
_, Ufall, _ = pod(X * X, 80, subtract_mean=False)        # POD basis of g(u) = u*u snapshots

ranks = np.arange(4, 41, 4)
E = {k: [] for k in ("proj", "gal", "deim1", "deim2", "opinf")}
sols = {}
for r in ranks:
    V = Vall[:, :r]
    Ahat = V.T @ (X - ubar[:, None])
    a0 = Ahat[:, 0]
    lift = lambda A: ubar[:, None] + V @ A if A is not None else None
    E["proj"].append(rel_err(lift(Ahat), X))
    t0 = time.time()
    Ag = simulate(galerkin_rhs(*galerkin_tensors(V, ubar, D1, D2, nu)), a0, t)
    tg = time.time() - t0
    E["gal"].append(rel_err(lift(Ag), X))
    for key, p in (("deim1", r), ("deim2", 2 * r)):
        idx = deim_points(Ufall[:, :p])
        Ad = simulate(deim_galerkin_rhs(V, ubar, D1, D2, nu, Ufall[:, :p], idx), a0, t)
        E[key].append(rel_err(lift(Ad), X) if Ad is not None else np.nan)
        if r == 12 and key == "deim1":
            sols["deim"], idx12 = lift(Ad), idx
    # operator inference: regularisation chosen by the training-trajectory error
    dA = time_derivative(Ahat, t[1] - t[0])
    best, per_reg = np.inf, []
    for reg in 10.0 ** np.arange(-8, 1, 2):
        Ao = simulate(opinf_fit(Ahat, dA, reg), a0, t)
        e = rel_err(lift(Ao), X) if Ao is not None else np.inf     # inf = blow-up
        per_reg.append("%.0e:%.1e" % (reg, e))
        best = min(best, e)
    E["opinf"].append(best)
    print("   OpInf errors per regularization:", " ".join(per_reg))
    if r == 12:
        sols["gal"] = lift(Ag)
    print("r=%2d proj %.2e  Galerkin %.2e (%.1f s)  DEIM(p=r) %.2e  DEIM(p=2r) %.2e  OpInf %.2e"
          % (r, E["proj"][-1], E["gal"][-1], tg, E["deim1"][-1], E["deim2"][-1], E["opinf"][-1]))

fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.2), gridspec_kw={"width_ratios": [1.1, 1, 1]})
ax = axs[0]
ax.semilogy(ranks, E["proj"], "k-", lw=2.2, alpha=0.35, label="POD projection")
ax.semilogy(ranks, E["gal"], "o-", color=COLORS["blue"], label="Galerkin")
ax.semilogy(ranks, E["deim1"], "s--", color=COLORS["orange"], label="DEIM, $p=r$")
ax.semilogy(ranks, E["deim2"], "^:", color=COLORS["red"], label="DEIM, $p=2r$")
ax.semilogy(ranks, E["opinf"], "d-", color=COLORS["green"], ms=3, label="OpInf")
ax.set_xlabel("number of POD modes $r$")
ax.set_ylabel("relative error")
ax.set_title("(a) ROM error vs. $r$")
ax.legend(fontsize=6.5, handlelength=1.6, loc="upper right")

ax = axs[1]
for j, ti in enumerate([0, 200, 400]):
    ax.plot(x, X[:, ti], color="0.55", lw=2.4, label="FOM" if j == 0 else None)
    ax.plot(x, sols["gal"][:, ti], "-", color=COLORS["blue"], lw=1.0, label="Galerkin" if j == 0 else None)
    ax.plot(x, sols["deim"][:, ti], "--", color=COLORS["orange"], lw=1.0, label="DEIM" if j == 0 else None)
    ax.text(x[np.argmax(X[:, ti])] + 0.15, X[:, ti].max() + 0.02, "$t=%g$" % t[ti], fontsize=7)
ax.set_xlabel("$x$")
ax.set_ylabel("$u$")
ax.set_ylim(0.3, 1.75)
ax.set_title("(b) solutions, $r=p=12$")
ax.legend(fontsize=6.5, loc="upper right", handlelength=1.6)

ax = axs[2]
for ti in range(0, 401, 50):
    ax.plot(x, X[:, ti] ** 2, color="0.75", lw=0.8)
ax.plot(x[idx12], np.zeros_like(idx12) + 0.08, "v", color=COLORS["orange"], ms=4)
ax.set_xlabel("$x$")
ax.set_ylabel("$g(u)=u^2$")
ax.set_ylim(0, 2.6)
ax.set_title("(c) DEIM points, $p=12$")
fig.tight_layout(w_pad=0.6)
print("DEIM points (p=12, in order):", np.round(x[idx12], 2))
print("saved", savefig(fig, "ch06", "rom_burgers"))

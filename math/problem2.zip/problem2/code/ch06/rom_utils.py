"""Chapter 6 helpers: POD, Galerkin ROMs with precomputed tensors, DEIM, operator inference.

All functions use NumPy/SciPy only. The full-order model (FOM) is the Fourier
pseudo-spectral semi-discretisation of the viscous Burgers equation

    u_t + (u^2/2)_x = nu u_xx   on the periodic domain [0, 2 pi),

i.e. du/dt = f(u) = nu D2 u - 0.5 D1 (u * u), with D1, D2 spectral
differentiation matrices (2/3-rule dealiasing folded into D1). Snapshots are
produced with the verified ETDRK4 solver `burgers_periodic` in code/common.

Run `python3 code/ch06/rom_utils.py` for the self-tests.
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
from scipy.integrate import solve_ivp

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import burgers_periodic, wavenumbers  # noqa: E402


# ------------------------------------------------------------------ full-order model
def spectral_matrices(n, length=2 * np.pi):
    """Dense spectral differentiation matrices D1 (dealiased) and D2 on n points."""
    k = wavenumbers(n, length)
    mask = (np.abs(np.fft.fftfreq(n, d=1.0 / n)) < n / 3).astype(float)
    eye = np.eye(n)
    D1 = np.real(np.fft.ifft(1j * k[:, None] * mask[:, None] * np.fft.fft(eye, axis=0), axis=0))
    D2 = np.real(np.fft.ifft(-(k ** 2)[:, None] * np.fft.fft(eye, axis=0), axis=0))
    return D1, D2


def burgers_snapshots(nu=0.02, n=256, T=4.0, nt=401, dt=1e-3):
    """Traveling, steepening bump: u0 = 0.5 + exp(-((x - 2)/0.5)^2)."""
    x = 2 * np.pi * np.arange(n) / n
    t = np.linspace(0.0, T, nt)
    u0 = 0.5 + np.exp(-((x - 2.0) / 0.5) ** 2)
    U = burgers_periodic(u0, nu, 2 * np.pi, t, dt=dt)      # (nt, n)
    return x, t, U.T                                       # snapshot matrix X: (n, nt)


# ------------------------------------------------------------------ POD
def pod(X, r, subtract_mean=True):
    """POD basis of the columns of X via the thin SVD. Returns (mean, V_r, sigma)."""
    ubar = X.mean(axis=1) if subtract_mean else np.zeros(X.shape[0])
    U, s, _ = np.linalg.svd(X - ubar[:, None], full_matrices=False)
    return ubar, U[:, :r], s


def pod_snapshots(X, r, W=None):
    """Method of snapshots (Sirovich 1987): eigenvectors of the m x m correlation matrix.

    W (optional) is the n x n (or diagonal, given as a vector) inner-product weight.
    Returns Phi (n x r, W-orthonormal columns) and the singular values sigma (r,).
    """
    WX = X if W is None else (W[:, None] * X if W.ndim == 1 else W @ X)
    C = X.T @ WX                                  # m x m correlation matrix
    lam, Q = np.linalg.eigh(C)                    # ascending order
    idx = np.argsort(lam)[::-1][:r]
    sig = np.sqrt(np.maximum(lam[idx], 0.0))
    Phi = X @ Q[:, idx] / sig                     # Phi = X Q Sigma^{-1}
    return Phi, sig


# ------------------------------------------------------------------ intrusive Galerkin ROM
def galerkin_tensors(Ur, ubar, D1, D2, nu):
    """Reduced operators of da/dt = b + L a + Q(a, a) for u = ubar + Ur a (Ur orthonormal)."""
    B = lambda v, w: -0.5 * D1 @ (v * w)            # symmetric bilinear part of f
    b = Ur.T @ (nu * D2 @ ubar + B(ubar, ubar))      # b = Ur^T f(ubar)
    L = Ur.T @ (nu * D2 @ Ur - D1 @ (ubar[:, None] * Ur))   # A + 2 B(ubar, .)
    W = D1.T @ Ur                                    # Q_ijk = -0.5 phi_i^T D1 (phi_j * phi_k)
    Q = -0.5 * np.einsum("xi,xj,xk->ijk", W, Ur, Ur)
    return b, L, Q


def galerkin_rhs(b, L, Q):
    """Online right-hand side: O(r^3) operations, independent of n."""
    return lambda t, a: b + L @ a + np.einsum("ijk,j,k->i", Q, a, a)


# ------------------------------------------------------------------ DEIM
def deim_points(Ug):
    """Greedy DEIM selection (Chaturantabut & Sorensen 2010) for the basis Ug (n x p)."""
    n, p = Ug.shape
    idx = [int(np.argmax(np.abs(Ug[:, 0])))]
    for j in range(1, p):
        c = np.linalg.solve(Ug[idx, :j], Ug[idx, j])     # interpolate the next mode at current points
        res = Ug[:, j] - Ug[:, :j] @ c                   # interpolation residual
        idx.append(int(np.argmax(np.abs(res))))          # new point where the residual is largest
    return np.array(idx)


def deim_galerkin_rhs(Ur, ubar, D1, D2, nu, Ug, idx):
    """POD-DEIM ROM: the pointwise nonlinearity g(u) = u*u is sampled at the p DEIM points."""
    c0 = Ur.T @ (nu * D2 @ ubar)
    A0 = Ur.T @ (nu * D2 @ Ur)
    M = -0.5 * Ur.T @ D1 @ Ug @ np.linalg.inv(Ug[idx, :])   # r x p, precomputed offline
    ubar_p, Ur_p = ubar[idx], Ur[idx, :]                    # only p rows of u are ever needed
    return lambda t, a: c0 + A0 @ a + M @ (ubar_p + Ur_p @ a) ** 2


# ------------------------------------------------------------------ operator inference
def quad_features(A):
    """Unique quadratic monomials a_j a_k (j <= k) of the columns of A (r x m)."""
    r = A.shape[0]
    iu = np.triu_indices(r)
    return (A[:, None, :] * A[None, :, :])[iu[0], iu[1], :]


def opinf_fit(Ahat, dAhat, reg=1e-6):
    """Least-squares fit of da/dt = c + A a + H (a kron a)_unique (Peherstorfer & Willcox 2016)."""
    m = Ahat.shape[1]
    D = np.vstack([np.ones((1, m)), Ahat, quad_features(Ahat)])        # features x m
    G = D @ D.T + reg * np.eye(D.shape[0])
    O = np.linalg.solve(G, D @ dAhat.T).T                               # r x features
    r = Ahat.shape[0]
    c, A, H = O[:, 0], O[:, 1:r + 1], O[:, r + 1:]
    return lambda t, a: c + A @ a + H @ quad_features(a[:, None])[:, 0]


def time_derivative(A, dt):
    """Fourth-order finite differences along axis 1 (one-sided 2nd order at the ends)."""
    dA = np.empty_like(A)
    dA[:, 2:-2] = (-A[:, 4:] + 8 * A[:, 3:-1] - 8 * A[:, 1:-3] + A[:, :-4]) / (12 * dt)
    dA[:, :2] = (-3 * A[:, :2] + 4 * A[:, 1:3] - A[:, 2:4]) / (2 * dt)
    dA[:, -2:] = (3 * A[:, -2:] - 4 * A[:, -3:-1] + A[:, -4:-2]) / (2 * dt)
    return dA


# ------------------------------------------------------------------ simulation
def simulate(rhs, a0, t, blowup=1e3):
    """Integrate a ROM; returns (len(a0), len(t)) or None if the ROM blows up."""
    ev = lambda tt, a: blowup - np.linalg.norm(a)
    ev.terminal = True
    sol = solve_ivp(rhs, (t[0], t[-1]), a0, t_eval=t, method="RK45", rtol=1e-8, atol=1e-10,
                    events=ev)
    if sol.status != 0 or sol.y.shape[1] != len(t):
        return None
    return sol.y


def rel_err(Xa, X):
    return np.linalg.norm(Xa - X) / np.linalg.norm(X)


def _self_test():
    rng = np.random.default_rng(0)
    # 1. method of snapshots equals SVD
    X = rng.standard_normal((50, 8)) @ np.diag(2.0 ** -np.arange(8)) @ rng.standard_normal((8, 20))
    Phi, sig = pod_snapshots(X, 5)
    U, s, _ = np.linalg.svd(X, full_matrices=False)
    assert np.allclose(sig, s[:5]) and np.allclose(np.abs(Phi.T @ U[:, :5]), np.eye(5), atol=1e-8)
    # 2. spectral D1, D2 differentiate a resolved Fourier mode exactly
    n = 64
    x = 2 * np.pi * np.arange(n) / n
    D1, D2 = spectral_matrices(n)
    assert np.allclose(D1 @ np.sin(3 * x), 3 * np.cos(3 * x)) and np.allclose(D2 @ np.sin(3 * x), -9 * np.sin(3 * x))
    # 3. Galerkin tensors reproduce the projected FOM right-hand side
    V = np.linalg.qr(rng.standard_normal((n, 6)))[0]
    ubar, a, nu = np.cos(x), rng.standard_normal(6), 0.05
    b, L, Q = galerkin_tensors(V, ubar, D1, D2, nu)
    u = ubar + V @ a
    f = nu * D2 @ u - 0.5 * D1 @ (u * u)
    assert np.allclose(galerkin_rhs(b, L, Q)(0, a), V.T @ f)
    # 4. DEIM interpolates exactly at the selected points and is exact on range(Uf)
    Uf = np.linalg.qr(rng.standard_normal((n, 5)))[0]
    idx = deim_points(Uf)
    g = Uf @ rng.standard_normal(5)
    assert np.allclose(Uf @ np.linalg.solve(Uf[idx], g[idx]), g)
    print("rom_utils self-tests passed")


if __name__ == "__main__":
    _self_test()

"""Chapter 7: exact DMD and two noise-robust variants, with self-tests.

Run from the project root:  python3 code/ch07/dmd.py
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import numpy as np
from scipy.linalg import sqrtm


def exact_dmd(X, Xp, r):
    """Exact DMD (Tu et al. 2014) of snapshot pairs Xp ~ A X; X, Xp are n x m."""
    # returns eigenvalues lam (r,), exact modes Phi (n x r), Atil = Ur^* A Ur, POD basis Ur
    U, s, Vh = np.linalg.svd(X, full_matrices=False)
    Ur, Sr, Vr = U[:, :r], s[:r], Vh[:r].conj().T          # rank-r truncation
    Atil = Ur.conj().T @ Xp @ Vr / Sr                       # Ur^* Xp Vr Sr^{-1}
    lam, W = np.linalg.eig(Atil)                            # Atil W = W diag(lam)
    Phi = (Xp @ Vr / Sr) @ W                                # exact modes (Phi = Xp Vr Sr^{-1} W)
    return lam, Phi, Atil, Ur


def dmd_amplitudes(Phi, x0):
    """Least-squares amplitudes b with x0 ~ Phi b."""
    return np.linalg.lstsq(Phi, x0.astype(complex), rcond=None)[0]


def dmd_predict(Phi, lam, b, k):
    """Snapshots x_k = Phi diag(lam^k) b for the integer steps k (returns n x len(k))."""
    return np.real(Phi @ (b[:, None] * lam[:, None] ** np.asarray(k)[None, :]))


def tls_dmd(X, Xp, r):
    """Total-least-squares DMD (Hemati et al. 2017): project both X and Xp onto the
    rank-r row space of the stacked matrix [X; Xp] before applying exact DMD."""
    _, _, Vh = np.linalg.svd(np.vstack([X, Xp]), full_matrices=False)
    P = Vh[:r].conj().T @ Vh[:r]                             # m x m projector
    return exact_dmd(X @ P, Xp @ P, r)


def fb_dmd(X, Xp, r):
    """Forward-backward DMD (Dawson et al. 2016) in the rank-r POD basis of X."""
    U, _, _ = np.linalg.svd(X, full_matrices=False)
    Ur = U[:, :r]
    Y, Yp = Ur.conj().T @ X, Ur.conj().T @ Xp
    Af = Yp @ np.linalg.pinv(Y)                               # forward map
    Ab = Y @ np.linalg.pinv(Yp)                               # backward map
    Atil = sqrtm(Af @ np.linalg.inv(Ab))
    lam, W = np.linalg.eig(Atil)
    return lam, Ur @ W, Atil, Ur


def _self_test():
    rng = np.random.default_rng(1)
    # random linear system with known spectrum, observed in R^100 through a random embedding
    lam_true = np.array([0.95 * np.exp(0.3j), 0.95 * np.exp(-0.3j), 0.99 * np.exp(1.1j),
                         0.99 * np.exp(-1.1j), 0.8])
    rot = lambda rho, th: rho * np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]])
    B = np.zeros((5, 5))
    B[:2, :2], B[2:4, 2:4], B[4, 4] = rot(0.95, 0.3), rot(0.99, 1.1), 0.8   # real block form
    T = rng.standard_normal((5, 5))
    A5 = T @ B @ np.linalg.inv(T)
    C = rng.standard_normal((100, 5))
    z = rng.standard_normal(5)
    Z = np.empty((5, 41))
    for k in range(41):
        Z[:, k] = z
        z = A5 @ z
    D = C @ Z
    X, Xp = D[:, :-1], D[:, 1:]
    for f in (exact_dmd, tls_dmd, fb_dmd):
        lam = f(X, Xp, 5)[0]
        err = max(np.min(np.abs(lam - l)) for l in lam_true)
        assert err < 1e-8, (f.__name__, err)
    lam, Phi, Atil, Ur = exact_dmd(X, Xp, 5)
    # exact DMD modes are eigenvectors of the full best-fit operator A = Xp X^+
    A = Xp @ np.linalg.pinv(X)
    assert np.allclose(A @ Phi, Phi * lam, atol=1e-8)
    # reconstruction of the whole sequence from x_0
    b = dmd_amplitudes(Phi, D[:, 0])
    assert np.allclose(dmd_predict(Phi, lam, b, np.arange(41)), D, atol=1e-7)
    print("dmd self-tests passed")


if __name__ == "__main__":
    _self_test()

"""Synthetic spatio-temporal data with a known DMD/Koopman decomposition (Chapter 7).

u(x, t) = Re[ phi1(x) exp(w1 t) ] + Re[ phi2(x) exp(w2 t) ] + phi3(x) exp(w3 t),
with
    phi1 = sech(x + 3) exp(0.8 i x)          (damped travelling wave packet), w1 = -0.02 + 2.3 i
    phi2 = 2 sech(x) tanh(x) + i sech(x)^2   (neutral rocking oscillation), w2 = 2.8 i
    phi3 = 0.5 exp(-(x - 5)^2 / 2)           (decaying non-oscillatory part), w3 = -0.10
on x in [-10, 10] (n = 256), sampled at t_k = k dt, dt = 0.1.  Rank 5: two complex-conjugate
pairs and one real eigenvalue.
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import numpy as np

OMEGA_TRUE = np.array([-0.02 + 2.3j, -0.02 - 2.3j, 0.0 + 2.8j, 0.0 - 2.8j, -0.10 + 0.0j])


def modes(x):
    sech = lambda z: 1.0 / np.cosh(z)
    phi1 = sech(x + 3) * np.exp(0.8j * x)
    phi2 = 2 * sech(x) * np.tanh(x) + 1j * sech(x) ** 2
    phi3 = 0.5 * np.exp(-(x - 5) ** 2 / 2) + 0j
    return phi1, phi2, phi3


def synthetic(n=256, m=201, dt=0.1, noise=0.0, seed=0):
    """Return x, t, D (n x m snapshot matrix) and the noise-free data."""
    x = np.linspace(-10, 10, n)
    t = dt * np.arange(m)
    p1, p2, p3 = modes(x)
    w1, w2, w3 = OMEGA_TRUE[0], OMEGA_TRUE[2], OMEGA_TRUE[4]
    clean = (np.real(np.outer(p1, np.exp(w1 * t))) + np.real(np.outer(p2, np.exp(w2 * t)))
             + np.real(np.outer(p3, np.exp(w3 * t))))
    rng = np.random.default_rng(seed)
    return x, t, clean + noise * rng.standard_normal(clean.shape), clean

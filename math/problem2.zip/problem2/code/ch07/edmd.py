"""Chapter 7: extended DMD (EDMD) with monomial dictionaries, Koopman eigenfunctions,
and data-driven eigenpair residuals in the spirit of ResDMD (Colbrook & Townsend 2024).

The test problem is the slow-manifold system
    x1' = mu x1,   x2' = lam (x2 - x1^2),
whose flow map is known in closed form and whose Koopman operator has the invariant
subspace span{x1, x2, x1^2} (plus constants).

Run from the project root:  python3 code/ch07/edmd.py
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import itertools

import numpy as np


def slow_manifold_flow(X, t, mu=-0.1, lam=-1.0):
    """Exact time-t flow map of the slow-manifold system; X has shape (2, m)."""
    b = lam / (lam - 2 * mu)
    x1, x2 = X
    y1 = x1 * np.exp(mu * t)
    y2 = b * y1 ** 2 + (x2 - b * x1 ** 2) * np.exp(lam * t)   # phi_lam = x2 - b x1^2 decays like e^{lam t}
    return np.vstack([y1, y2])


def monomials(X, degree):
    """Dictionary of all monomials x1^i x2^j with i + j <= degree; returns (p, m) and labels."""
    powers = [(i, j) for d in range(degree + 1) for i, j in itertools.product(range(d + 1), repeat=2)
              if i + j == d]
    Psi = np.array([X[0] ** i * X[1] ** j for i, j in powers])
    return Psi, powers


def edmd(X, Y, degree):
    """EDMD: least-squares K with psi(F(x)) ~ K psi(x); returns eigenvalues, left eigenvectors, K."""
    PX, powers = monomials(X, degree)
    PY, _ = monomials(Y, degree)
    KT = np.linalg.lstsq(PX.T, PY.T, rcond=None)[0]      # solves PX^T K^T = PY^T
    lam, Wl = np.linalg.eig(KT)                           # K^T w = lam w  <=>  w^T K = lam w^T
    return lam, Wl, KT.T, powers


def eigenfunction(w, X, degree):
    """Evaluate phi(x) = w^T psi(x) at the columns of X."""
    return w @ monomials(X, degree)[0]


def residuals(lam, Wl, X, Y, degree):
    """Relative residuals ||phi(F(x)) - lam phi(x)|| / ||phi(x)|| over the data, per eigenpair."""
    PX, _ = monomials(X, degree)
    PY, _ = monomials(Y, degree)
    return np.array([np.linalg.norm(w @ PY - l * (w @ PX)) / np.linalg.norm(w @ PX)
                     for l, w in zip(lam, Wl.T)])


def _self_test():
    rng = np.random.default_rng(0)
    mu, lamb, dt = -0.1, -1.0, 0.1
    X = rng.uniform(-1.5, 1.5, (2, 500))
    Y = slow_manifold_flow(X, dt, mu, lamb)
    lam, Wl, K, powers = edmd(X, Y, 2)
    omega = np.log(lam.astype(complex)) / dt
    res = residuals(lam, Wl, X, Y, 2)
    exact = np.sort(omega[res < 1e-8].real)
    assert np.allclose(exact, [-1.0, -0.2, -0.1, 0.0], atol=1e-8), exact
    # the eigenfunction for lam is proportional to x2 - b x1^2 with b = lam/(lam - 2 mu)
    k = np.argmin(np.abs(omega - lamb))
    phi = eigenfunction(Wl[:, k], X, 2).real
    b = lamb / (lamb - 2 * mu)
    target = X[1] - b * X[0] ** 2
    c = (phi @ target) / (target @ target)
    assert np.allclose(phi, c * target, atol=1e-8)
    print("edmd self-tests passed; exact continuous-time eigenvalues:", exact)


if __name__ == "__main__":
    _self_test()

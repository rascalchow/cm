"""Figure 7.1: exact DMD of synthetic data -- data, discrete and continuous spectra, modes.

Run from the project root:  python3 code/ch07/fig_dmd_example.py   (a few seconds)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from dmd import exact_dmd, tls_dmd, dmd_amplitudes, dmd_predict  # noqa: E402
from dmd_data import synthetic, modes, OMEGA_TRUE  # noqa: E402

set_style()
dt = 0.1
x, t, D, _ = synthetic(dt=dt)
lam, Phi, _, _ = exact_dmd(D[:, :-1], D[:, 1:], 5)
omega = np.log(lam) / dt
print("continuous-time DMD eigenvalues:", np.round(np.sort_complex(omega), 6))

# noisy data, deliberately over-fitted rank r = 10
sig = 0.1
_, _, Dn, _ = synthetic(dt=dt, noise=sig, seed=3)
lam_n, _, _, _ = exact_dmd(Dn[:, :-1], Dn[:, 1:], 10)
omega_n = np.log(lam_n) / dt
# Gavish-Donoho optimal hard threshold for known noise level sigma
n, m = Dn.shape[0], Dn.shape[1] - 1
beta = m / n
lam_star = np.sqrt(2 * (beta + 1) + 8 * beta / ((beta + 1) + np.sqrt(beta ** 2 + 14 * beta + 1)))
s_n = np.linalg.svd(Dn[:, :-1], compute_uv=False)
print("Gavish-Donoho threshold %.2f keeps r = %d singular values (next: %.2f, %.2f)"
      % (lam_star * np.sqrt(n) * sig, np.sum(s_n > lam_star * np.sqrt(n) * sig), s_n[4], s_n[5]))

# forecasting: fit on t <= 10, predict up to t = 20
k_fit = 101
lam_f, Phi_f, _, _ = exact_dmd(D[:, :k_fit - 1], D[:, 1:k_fit], 5)
b = dmd_amplitudes(Phi_f, D[:, 0])
pred = dmd_predict(Phi_f, lam_f, b, np.arange(D.shape[1]))
print("forecast relative error on t in (10, 20]: %.2e" % (np.linalg.norm(pred[:, k_fit:] - D[:, k_fit:])
                                                       / np.linalg.norm(D[:, k_fit:])))
_, _, Dn2, _ = synthetic(dt=dt, noise=sig, seed=4)
lam_g, Phi_g, _, _ = exact_dmd(Dn2[:, :k_fit - 1], Dn2[:, 1:k_fit], 5)
pred = dmd_predict(Phi_g, lam_g, dmd_amplitudes(Phi_g, Dn2[:, 0]), np.arange(D.shape[1]))
print("noisy (sigma=%.2f) exact-DMD forecast relative error vs clean data on t in (10, 20]: %.2e"
      % (sig, np.linalg.norm(pred[:, k_fit:] - D[:, k_fit:]) / np.linalg.norm(D[:, k_fit:])))
lam_g, Phi_g, _, _ = tls_dmd(Dn2[:, :k_fit - 1], Dn2[:, 1:k_fit], 5)
pred = dmd_predict(Phi_g, lam_g, dmd_amplitudes(Phi_g, Dn2[:, 0]), np.arange(D.shape[1]))
print("noisy (sigma=%.2f) TLS-DMD forecast relative error vs clean data on t in (10, 20]: %.2e"
      % (sig, np.linalg.norm(pred[:, k_fit:] - D[:, k_fit:]) / np.linalg.norm(D[:, k_fit:])))

fig, axs = plt.subplots(2, 2, figsize=(FULL_WIDTH, 3.0))
ax = axs[0, 0]
im = ax.pcolormesh(x, t, D.T, shading="auto", cmap="RdBu_r", vmin=-1.6, vmax=1.6, rasterized=True)
ax.set_xlabel("$x$")
ax.set_ylabel("$t$")
ax.set_title("(a) data $u(x,t)$")
fig.colorbar(im, ax=ax, pad=0.02, fraction=0.05)

ax = axs[0, 1]
th = np.linspace(0, 2 * np.pi, 400)
ax.plot(np.cos(th), np.sin(th), color="0.7", lw=0.8)
lt = np.exp(OMEGA_TRUE * dt)
ax.plot(lam_n.real, lam_n.imag, ".", color=COLORS["orange"], ms=5, label=r"noisy, $r=10$")
ax.plot(lt.real, lt.imag, "o", mfc="none", mec="k", ms=8, label="true")
ax.plot(lam.real, lam.imag, "x", color=COLORS["blue"], ms=6, label="DMD, $r=5$")
ax.set_aspect("equal")
ax.set_xlabel(r"Re $\lambda$")
ax.set_ylabel(r"Im $\lambda$")
ax.set_title(r"(b) discrete-time eigenvalues $\lambda_k$")
ax.legend(fontsize=6.5, loc="center left", bbox_to_anchor=(1.0, 0.5))

ax = axs[1, 0]
ax.axvline(0, color="0.7", lw=0.8)
ax.plot(omega_n.real, omega_n.imag, ".", color=COLORS["orange"], ms=5)
ax.plot(OMEGA_TRUE.real, OMEGA_TRUE.imag, "o", mfc="none", mec="k", ms=8)
ax.plot(omega.real, omega.imag, "x", color=COLORS["blue"], ms=6)
ax.set_xlim(-0.45, 0.12)
ax.set_ylim(-3.6, 3.6)
ax.text(-0.43, -3.3, "remaining noisy eigenvalues:\nRe $\\omega<-0.45$ (off scale)", fontsize=6.5,
        color=COLORS["orange"])
ax.set_xlabel(r"growth rate Re $\omega$")
ax.set_ylabel(r"frequency Im $\omega$")
ax.set_title(r"(c) continuous-time $\omega_k=\log(\lambda_k)/\Delta t$")

ax = axs[1, 1]
true = modes(x)
order = [np.argmin(np.abs(omega - w)) for w in (OMEGA_TRUE[0], OMEGA_TRUE[2], OMEGA_TRUE[4])]
for j, (k, c) in enumerate(zip(order, [COLORS["blue"], COLORS["orange"], COLORS["green"]])):
    ph = Phi[:, k] / np.abs(Phi[:, k]).max()
    tr = true[j] / np.abs(true[j]).max()
    ax.plot(x, np.abs(tr) - 1.2 * j, color="0.65", lw=2.6)
    ax.plot(x, np.abs(ph) - 1.2 * j, "--", color=c, lw=1.1)
    w = complex(round(omega[k].real, 4) + 0.0, round(omega[k].imag, 4) + 0.0)   # avoid "-0.00"
    lab = "%.2f%+.1fi" % (w.real, w.imag) if abs(w.imag) > 0 else "%.2f" % w.real
    ax.text(10.3, -1.2 * j + 0.3, r"$\omega=%s$" % lab, fontsize=7, va="center")
ax.set_yticks([])
ax.spines["left"].set_visible(False)
ax.set_xlim(-10, 10)
ax.set_xlabel("$x$")
ax.set_title(r"(d) mode magnitudes $|\varphi_k(x)|$ (gray: truth)")
fig.tight_layout(h_pad=0.8, w_pad=0.6)
print("saved", savefig(fig, "ch07", "dmd_example"))

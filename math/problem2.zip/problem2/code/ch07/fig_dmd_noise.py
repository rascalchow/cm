"""Figure 7.2: noise-induced bias of exact DMD and two corrections (TLS-DMD, fbDMD).

Run from the project root:  python3 code/ch07/fig_dmd_noise.py   (1-3 minutes)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from dmd import exact_dmd, tls_dmd, fb_dmd  # noqa: E402
from dmd_data import synthetic, OMEGA_TRUE  # noqa: E402

set_style()
dt, r, n_real = 0.1, 5, 40
methods = {"exact DMD": exact_dmd, "TLS-DMD": tls_dmd, "fbDMD": fb_dmd}
cols = {"exact DMD": COLORS["blue"], "TLS-DMD": COLORS["orange"], "fbDMD": COLORS["green"]}
sigmas = np.array([0.0, 0.025, 0.05, 0.1, 0.15, 0.2, 0.3])


def pick(omega, target):
    return omega[np.argmin(np.abs(omega - target))]


stats = {k: [] for k in methods}
cloud = {k: [] for k in methods}
for sig in sigmas:
    est = {k: [] for k in methods}
    for seed in range(n_real):
        _, _, D, _ = synthetic(dt=dt, noise=sig, seed=100 + seed)
        for name, f in methods.items():
            om = np.log(f(D[:, :-1], D[:, 1:], r)[0]) / dt
            est[name].append([pick(om, OMEGA_TRUE[0]), pick(om, OMEGA_TRUE[2])])
            if sig == 0.2:
                cloud[name].append(om)
    for name in methods:
        e = np.array(est[name])
        stats[name].append((e[:, 0].real.mean(), e[:, 0].real.std(), e[:, 1].real.mean()))
        print("sigma=%.3f %-9s Re(w1) = %.4f +- %.4f (true -0.02)   Re(w2) = %.4f (true 0)"
              % (sig, name, *stats[name][-1]))

fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.3), gridspec_kw={"width_ratios": [1, 1.25]})
ax = axs[0]
for name in methods:
    om = np.concatenate(cloud[name])
    ax.plot(om.real, om.imag, ".", ms=2.5, color=cols[name], alpha=0.6, label=name)
ax.plot(OMEGA_TRUE.real, OMEGA_TRUE.imag, "o", mfc="none", mec="k", ms=6, label="true")
ax.set_xlim(-0.3, 0.06)
ax.set_ylim(2.05, 3.05)
ax.set_xlabel(r"Re $\omega$")
ax.set_ylabel(r"Im $\omega$")
ax.set_title(r"(a) eigenvalues, $\sigma_{\mathrm{noise}}=0.2$, %d draws" % n_real)
ax.legend(fontsize=6.5, loc="upper left", markerscale=1.5)
ax = axs[1]
for name in methods:
    s = np.array(stats[name])
    ax.errorbar(sigmas, s[:, 0], yerr=s[:, 1], fmt="o-", ms=3, capsize=2, color=cols[name], label=name)
ax.axhline(OMEGA_TRUE[0].real, color="k", lw=0.8, ls="--", label="true")
ax.set_xlabel(r"noise level $\sigma_{\mathrm{noise}}$ (signal RMS $\approx 0.38$)")
ax.set_ylabel(r"Re $\omega_1$ (growth rate)")
ax.set_title("(b) bias of the wave-packet growth rate")
ax.legend(fontsize=6.5, loc="lower left")
fig.tight_layout(w_pad=1.0)
print("saved", savefig(fig, "ch07", "dmd_noise"))

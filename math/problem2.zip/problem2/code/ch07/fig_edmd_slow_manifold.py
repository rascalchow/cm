"""Figure 7.3: EDMD and Koopman eigenfunctions for the slow-manifold system
    x1' = mu x1,  x2' = lam (x2 - x1^2),  mu = -0.1, lam = -1.

Run from the project root:  python3 code/ch07/fig_edmd_slow_manifold.py   (a few seconds)
"""
import os
os.environ.setdefault("OMP_NUM_THREADS", "2")   # be polite on shared machines
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from edmd import slow_manifold_flow, edmd, eigenfunction, residuals  # noqa: E402

set_style()
mu, lamb, dt = -0.1, -1.0, 0.1
b = lamb / (lamb - 2 * mu)
rng = np.random.default_rng(0)
X = rng.uniform(-1.5, 1.5, (2, 1000))                 # 1000 random initial states
Y = slow_manifold_flow(X, dt, mu, lamb)               # their images after one step

results = {}
for deg in (1, 2, 4):
    lam, Wl, K, powers = edmd(X, Y, deg)
    om = np.log(lam.astype(complex)) / dt
    res = residuals(lam, Wl, X, Y, deg)
    results[deg] = (om, res, Wl)
    o = np.argsort(-om.real)
    print("degree %d:" % deg, ", ".join("%.4f (res %.0e)" % (om[i].real, res[i]) for i in o))

fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.25), gridspec_kw={"width_ratios": [1, 1.1, 1.15]})
# (a) phase portrait
ax = axs[0]
xs = np.linspace(-1.6, 1.6, 200)
ax.plot(xs, b * xs ** 2, "--", color="k", lw=1.0, zorder=5)
tt = np.linspace(0, 30, 600)
for x0 in [(-1.5, -1.0), (-1.0, 2.5), (0.5, 3.0), (1.5, -1.0), (1.2, 1.0), (-0.3, -1.2)]:
    traj = np.array([slow_manifold_flow(np.array(x0)[:, None], ti, mu, lamb)[:, 0] for ti in tt])
    ax.plot(traj[:, 0], traj[:, 1], color=COLORS["blue"], lw=0.9)
    ax.plot(*x0, "o", color=COLORS["blue"], ms=3)
ax.set_xlim(-1.6, 1.6)
ax.set_ylim(-1.5, 3.2)
ax.set_xlabel("$x_1$")
ax.set_ylabel("$x_2$")
ax.set_title("(a) trajectories, slow manifold")

# (b) EDMD eigenfunction for the fast eigenvalue (degree-2 dictionary) vs DMD (degree 1)
ax = axs[1]
g1, g2 = np.meshgrid(np.linspace(-1.5, 1.5, 161), np.linspace(-1.5, 3.0, 161))
G = np.vstack([g1.ravel(), g2.ravel()])
om, res, Wl = results[2]
k = np.argmin(np.abs(om - lamb))
phi = eigenfunction(Wl[:, k], G, 2).real.reshape(g1.shape)
phi = phi / np.max(np.abs(phi))
cf = ax.contourf(g1, g2, phi, levels=21, cmap="RdBu_r")
ax.contour(g1, g2, phi, levels=[0.0], colors=COLORS["green"], linewidths=1.6)
om1, _, W1 = results[1]
k1 = np.argmin(np.abs(om1 - lamb))
phi1 = eigenfunction(W1[:, k1], G, 1).real.reshape(g1.shape)
ax.contour(g1, g2, phi1, levels=[0.0], colors=COLORS["orange"], linewidths=1.2, linestyles="--")
ax.plot(xs, b * xs ** 2, ":", color="k", lw=1.0)
ax.set_xlim(-1.5, 1.5)
ax.set_ylim(-1.5, 3.0)
ax.set_xlabel("$x_1$")
ax.set_title(r"(b) eigenfunction $\varphi_\lambda$ (EDMD)")
ax.text(-1.4, 2.65, r"green: $\varphi_\lambda=0$ (EDMD)" + "\n" + r"orange: zero set (DMD)", fontsize=6.5,
        va="top", bbox=dict(fc="white", ec="none", alpha=0.8, pad=1))
fig.colorbar(cf, ax=ax, pad=0.02, fraction=0.06, ticks=[-1, 0, 1])

# (c) continuous-time eigenvalues, coloured by data residual
ax = axs[2]
lattice = sorted({a * mu + c * lamb for a in range(5) for c in range(3) if a * mu + c * lamb >= -2.6})
for v in lattice:
    ax.axvline(v, color="0.88", lw=0.8, zorder=0)
for y, deg in enumerate((1, 2, 4)):
    om, res, _ = results[deg]
    good = res < 1e-8
    ax.plot(om.real[good], np.full(good.sum(), y), "o", color=COLORS["blue"], ms=4.5)
    ax.plot(om.real[~good], np.full((~good).sum(), y), "o", mfc="none", mec=COLORS["red"], ms=5)
ax.plot([], [], "o", color=COLORS["blue"], ms=4.5, label=r"residual $<10^{-8}$")
ax.plot([], [], "o", mfc="none", mec=COLORS["red"], ms=5, label=r"residual $>10^{-3}$")
ax.set_yticks([0, 1, 2])
ax.set_yticklabels(["DMD\n(deg 1)", "EDMD\n(deg 2)", "EDMD\n(deg 4)"], fontsize=7)
ax.set_xlim(-2.65, 0.15)
ax.set_ylim(-0.6, 3.3)
ax.set_xlabel(r"Re $\omega$  (gray: $j\mu+k\lambda$)")
ax.set_title("(c) Koopman eigenvalues")
ax.legend(fontsize=6, loc="upper center", ncol=2, handletextpad=0.2, columnspacing=0.8,
          bbox_to_anchor=(0.5, 1.03))
fig.tight_layout(w_pad=0.5)
print("saved", savefig(fig, "ch07", "edmd_slow_manifold"))

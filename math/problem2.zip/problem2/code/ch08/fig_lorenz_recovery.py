"""Figure fig:08:lorenz (figures/ch08/lorenz_recovery.pdf): SINDy recovery of the Lorenz system (true vs identified attractor).

Also prints the LaTeX rows of the coefficient table and two diagnostics of the
library matrix (condition number, mutual coherence) quoted in the text.
Run from the project root:  python3 code/ch08/fig_lorenz_recovery.py
"""
import os
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import lorenz63  # noqa: E402
from sindy import (poly_library, stlsq, fd_derivative, simulate,  # noqa: E402
                   lorenz_true_coefficients, print_model)

# ---------------------------------------------------------------- data and fit
dt = 0.002
t = np.arange(0, 20, dt)                       # 10,000 samples
x0 = np.array([-8.0, 8.0, 27.0])
X = lorenz63(x0=x0, t_eval=t)
Theta, labels = poly_library(X, degree=3)      # p = 20 candidate terms
dXdt = fd_derivative(X, dt)
Xi = stlsq(Theta, dXdt, lam=0.1)
Xi_true = lorenz_true_coefficients(labels)
print_model(Xi, labels)
print("library size p =", len(labels), " nonzeros:", int((Xi != 0).sum()))
print("relative coefficient error: %.2e"
      % (np.linalg.norm(Xi - Xi_true) / np.linalg.norm(Xi_true)))

# diagnostics of the library matrix
Tn = Theta / np.linalg.norm(Theta, axis=0)
gram = np.abs(Tn.T @ Tn)
np.fill_diagonal(gram, 0.0)
i, j = np.unravel_index(np.argmax(gram), gram.shape)
print("cond(Theta) = %.2e, cond(normalized Theta) = %.2e"
      % (np.linalg.cond(Theta), np.linalg.cond(Tn)))
print("mutual coherence = %.4f (columns %s, %s)" % (gram.max(), labels[i], labels[j]))

# coefficient table (rows: terms active in the true model)
print("\nLaTeX rows:")
for lab in ["x", "y", "z", "xy", "xz"]:
    k = labels.index(lab)
    cells = []
    for e in range(3):
        cells += ["%.4g" % Xi_true[k, e] if Xi_true[k, e] != 0 else "0",
                  "%.4f" % Xi[k, e] if Xi[k, e] != 0 else "0"]
    print("$%s$ & " % lab + " & ".join(cells) + r" \\")

# ---------------------------------------------------------------- simulate the identified model
t_test = np.arange(0, 20, 0.01)
x0_test = np.array([5.0, -6.0, 20.0])          # initial condition not in the training data
X_true = lorenz63(x0=x0_test, t_eval=t_test)
X_id = simulate(Xi, 3, x0_test, t_test)
dev = np.linalg.norm(X_true - X_id, axis=1) / np.linalg.norm(X_true, axis=1)
print("first time relative deviation exceeds 0.1: t = %.2f"
      % t_test[np.argmax(dev > 0.1)])

# ---------------------------------------------------------------- figure
set_style()
fig = plt.figure(figsize=(FULL_WIDTH, 2.0))
boxes = [[-0.03, 0.0, 0.33, 0.95], [0.29, 0.0, 0.33, 0.95]]
for k, (Y, title, c) in enumerate([(X_true, "(a) true system", COLORS["blue"]),
                                   (X_id, "(b) identified model", COLORS["orange"])]):
    ax = fig.add_axes(boxes[k], projection="3d")
    ax.plot(Y[:, 0], Y[:, 1], Y[:, 2], lw=0.4, color=c)
    ax.set_title(title, pad=-2)
    ax.set_xticks([-15, 0, 15]); ax.set_yticks([-20, 0, 20]); ax.set_zticks([10, 25, 40])
    ax.set_xticklabels([]); ax.set_yticklabels([]); ax.set_zticklabels([])
    ax.set_xlabel("$x$", labelpad=-12); ax.set_ylabel("$y$", labelpad=-12)
    ax.view_init(elev=22, azim=-60)
    for a in (ax.xaxis, ax.yaxis, ax.zaxis):
        a.pane.set_facecolor("white")
ax = fig.add_axes([0.675, 0.2, 0.325, 0.66])
ax.plot(t_test, X_true[:, 0], color=COLORS["blue"], lw=1.0, label="true")
ax.plot(t_test, X_id[:, 0], "--", color=COLORS["orange"], lw=1.0, label="identified")
ax.set_xlabel("$t$")
ax.set_title("(c) forecast of $x(t)$")
ax.legend(loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.22))
ax.set_xlim(0, 20)
savefig(fig, "ch08", "lorenz_recovery")
print("saved figures/ch08/lorenz_recovery.pdf")

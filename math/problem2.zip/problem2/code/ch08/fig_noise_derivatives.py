"""Figure fig:08:noise (figures/ch08/noise_derivatives.pdf): effect of measurement noise and of the derivative estimator on SINDy.

Lorenz data (dt = 0.002, t in [0, 20]) are corrupted by i.i.d. Gaussian noise of
standard deviation sigma (the state has standard deviation of about 8).  We compare
  FD   : central finite differences of the noisy data,
  SG   : Savitzky-Golay smoothing/differentiation (window 51, cubic),
  weak : weak-form SINDy (300 test functions, windows of 201 samples),
all followed by STLSQ with lambda = 0.2 on a cubic library (p = 20).
Run from the project root:  python3 code/ch08/fig_noise_derivatives.py  (~2 min)
"""
import os
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import lorenz63  # noqa: E402
from sindy import (poly_library, stlsq, fd_derivative, sg_derivative,  # noqa: E402
                   weak_system, lorenz_true_coefficients)

dt, lam, n_seeds = 0.002, 0.2, 10
t = np.arange(0, 20, dt)
sigma0, rho0, beta0 = 10.0, 28.0, 8.0 / 3.0
X = lorenz63(x0=(-8.0, 8.0, 27.0), t_eval=t)
dX_true = np.column_stack([sigma0 * (X[:, 1] - X[:, 0]),
                           X[:, 0] * (rho0 - X[:, 2]) - X[:, 1],
                           X[:, 0] * X[:, 1] - beta0 * X[:, 2]])
labels = poly_library(X[:2], 3)[1]
Xi_true = lorenz_true_coefficients(labels)
print("state standard deviation:", X.std(axis=0).round(2))


def fit(Y, method):
    if method == "FD":
        return stlsq(poly_library(Y, 3)[0], fd_derivative(Y, dt), lam)
    if method == "SG":
        Ys, dY = sg_derivative(Y, dt, window=51, order=3)
        return stlsq(poly_library(Ys, 3)[0], dY, lam)
    G, b, _ = weak_system(Y, t, 3, n_windows=300, half_width=100)
    return stlsq(G, b, lam)


methods = ["FD", "SG", "weak"]
sigmas = np.array([0.01, 0.03, 0.1, 0.3, 1.0, 2.0, 4.0])
err = {m: np.zeros((len(sigmas), n_seeds)) for m in methods}
ok = {m: np.zeros((len(sigmas), n_seeds), dtype=bool) for m in methods}
for i, s in enumerate(sigmas):
    for seed in range(n_seeds):
        Y = X + s * np.random.default_rng(seed).standard_normal(X.shape)
        for m in methods:
            Xi = fit(Y, m)
            err[m][i, seed] = np.linalg.norm(Xi - Xi_true) / np.linalg.norm(Xi_true)
            ok[m][i, seed] = np.array_equal(Xi != 0, Xi_true != 0)
    print("sigma=%.2f " % s + "  ".join("%s: err %.2e, support %d/%d"
          % (m, np.median(err[m][i]), ok[m][i].sum(), n_seeds) for m in methods))

# derivative estimates for one noise level (panel a)
s_demo = 0.3
Y = X + s_demo * np.random.default_rng(0).standard_normal(X.shape)
dFD = fd_derivative(Y, dt)
_, dSG = sg_derivative(Y, dt, window=51, order=3)
for name, d in [("FD", dFD), ("SG", dSG)]:
    print("sigma=%.1f: relative error of %s derivative: %.3f" % (
        s_demo, name, np.linalg.norm(d - dX_true) / np.linalg.norm(dX_true)))

# ---------------------------------------------------------------- figure
set_style()
cols = {"FD": COLORS["red"], "SG": COLORS["blue"], "weak": COLORS["green"]}
names = {"FD": "FD", "SG": "SG", "weak": "weak form"}
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 1.95),
                        gridspec_kw=dict(width_ratios=[1.25, 1, 1], wspace=0.42))
ax = axs[0]
win = (t >= 2.0) & (t <= 3.0)
ax.plot(t[win], dFD[win, 0], color=cols["FD"], lw=0.5, alpha=0.8, label="FD")
ax.plot(t[win], dSG[win, 0], color=cols["SG"], lw=1.2, label="SG")
ax.plot(t[win], dX_true[win, 0], "k--", lw=0.9, label="exact")
ax.set_xlabel("$t$")
ax.set_title(r"(a) estimates of $\dot x$, $\sigma=%.1f$" % s_demo)
ax.legend(loc="lower center", ncol=3, handlelength=1.2, columnspacing=0.8,
          frameon=True, framealpha=0.95, edgecolor="none", bbox_to_anchor=(0.5, -0.03))
ax.set_ylim(-330, 230)

ax = axs[1]
for m in methods:
    ax.loglog(sigmas, np.median(err[m], axis=1), "o-", color=cols[m], ms=3.5, label=names[m])
ax.set_xlabel(r"noise level $\sigma$")
ax.set_title(r"(b) coefficient error")
ax.legend(loc="upper left", handlelength=1.4)
ax.set_ylim(1e-5, 5)

ax = axs[2]
for k, m in enumerate(methods):
    ax.semilogx(sigmas * (1 + 0.04 * (k - 1)), ok[m].mean(axis=1), "o-", color=cols[m], ms=3.5,
                label=names[m])
ax.set_xlabel(r"noise level $\sigma$")
ax.set_title("(c) correct support (fraction)")
ax.set_ylim(-0.05, 1.05)
savefig(fig, "ch08", "noise_derivatives")
print("saved figures/ch08/noise_derivatives.pdf")

"""Figure fig:08:pareto (figures/ch08/pareto.pdf): choosing the STLSQ threshold with a Pareto front and information criteria.

Training data: noisy Lorenz trajectory (sigma = 0.2), validation data: an independent
noisy trajectory from another initial condition.  Derivatives by Savitzky-Golay.
For each threshold lambda we record the number of active terms k, the relative
validation error of the derivative prediction, and AIC/BIC computed from the
validation residual sum of squares (Gaussian errors, Mangan et al. 2017).
Run from the project root:  python3 code/ch08/fig_pareto.py
"""
import os
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import lorenz63  # noqa: E402
from sindy import poly_library, stlsq, sg_derivative, lorenz_true_coefficients  # noqa: E402

dt, s = 0.002, 0.2
rng = np.random.default_rng(1)
t = np.arange(0, 20, dt)
tv = np.arange(0, 10, dt)
Y = lorenz63(x0=(-8.0, 8.0, 27.0), t_eval=t) + s * rng.standard_normal((len(t), 3))
Yv = lorenz63(x0=(5.0, -6.0, 20.0), t_eval=tv) + s * rng.standard_normal((len(tv), 3))
Ys, dY = sg_derivative(Y, dt, 51)
Yvs, dYv = sg_derivative(Yv, dt, 51)
Theta, labels = poly_library(Ys, 3)
Theta_v = poly_library(Yvs, 3)[0]
Xi_true = lorenz_true_coefficients(labels)
m = dYv.size

lams = np.logspace(-3, 1.5, 91)
K, E, AIC, BIC, OK = [], [], [], [], []
for lam in lams:
    Xi = stlsq(Theta, dY, lam)
    k = int((Xi != 0).sum())
    rss = np.sum((Theta_v @ Xi - dYv) ** 2)
    K.append(k)
    E.append(np.sqrt(rss / np.sum(dYv ** 2)))
    AIC.append(m * np.log(rss / m) + 2 * k)
    BIC.append(m * np.log(rss / m) + k * np.log(m))
    OK.append(np.array_equal(Xi != 0, Xi_true != 0))
K, E, AIC, BIC, OK = map(np.array, (K, E, AIC, BIC, OK))
print("lambda range with the correct 7-term support: [%.3f, %.3f]"
      % (lams[OK].min(), lams[OK].max()))
for k in sorted(set(K)):
    i = np.where(K == k)[0][0]
    print("k=%2d  val. error %.4f  dAIC %10.1f  dBIC %10.1f" % (
        k, E[i], AIC[i] - AIC.min(), BIC[i] - BIC.min()))
print("AIC minimized at k =", K[np.argmin(AIC)], "; BIC minimized at k =", K[np.argmin(BIC)])

# ---------------------------------------------------------------- figure
set_style()
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 1.9),
                        gridspec_kw=dict(wspace=0.45))
ax = axs[0]
ax.semilogx(lams, K, color=COLORS["blue"], drawstyle="steps-mid")
ax.axvspan(lams[OK].min(), lams[OK].max(), color=COLORS["green"], alpha=0.12, lw=0)
ax.set_xlabel(r"threshold $\lambda$")
ax.set_ylabel("active terms $k$")
ax.set_title("(a) sparsity vs. threshold")
ax.text(0.09, 15, "correct\nsupport", color=COLORS["green"], fontsize=7, ha="center")

ax = axs[1]
uk = np.array(sorted(set(K)))
ue = np.array([E[K == k].min() for k in uk])
ax.semilogy(uk, ue, "o-", color=COLORS["blue"], ms=3.5)
ax.semilogy([7], [E[K == 7].min()], "o", ms=8, mfc="none", color=COLORS["red"])
ax.annotate("true model\n($k=7$)", (7, E[K == 7].min()), (11, 0.15), fontsize=7,
            arrowprops=dict(arrowstyle="->", lw=0.6))
ax.set_xlabel("active terms $k$")
ax.set_ylabel("validation error")
ax.set_title("(b) Pareto front")

ax = axs[2]
ua = np.array([AIC[K == k].min() for k in uk]) - AIC.min()
ub = np.array([BIC[K == k].min() for k in uk]) - BIC.min()
ax.semilogy(uk, ua + 1, "o-", color=COLORS["green"], ms=3.5, label="AIC")
ax.semilogy(uk, ub + 1, "s--", color=COLORS["purple"], ms=3, label="BIC")
ax.set_xlabel("active terms $k$")
ax.set_ylabel(r"$\Delta$IC $+ 1$")
ax.set_title("(c) information criteria")
ax.legend(loc="upper right")
savefig(fig, "ch08", "pareto")
print("saved figures/ch08/pareto.pdf")

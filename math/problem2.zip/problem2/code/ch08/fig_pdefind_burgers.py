"""Figure fig:08:pdefind (figures/ch08/pdefind_burgers.pdf): PDE-FIND on viscous Burgers data, strong form vs weak form.

Data: u_t + u u_x = 0.1 u_xx on [-8, 8) (periodic), 256 points, t in [0, 10] with 101
snapshots, u0 = exp(-(x+2)^2).  Noise: i.i.d. Gaussian with standard deviation
eta * std(u).  Library: 13 divergence-form terms d_x^m(u^k), k, m <= 3.
Methods: strong form with finite differences (FD), strong form after Savitzky-Golay
smoothing (SG), and weak form (600 space-time test functions).  STLSQ with
scale-free threshold lambda = 0.1 in all cases.
Run from the project root:  python3 code/ch08/fig_pdefind_burgers.py  (~3 min)
"""
import os
import sys

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from pdefind import burgers_data, strong_system, weak_system, identify, describe, NAMES  # noqa: E402

x, t, U = burgers_data()
dx, dt = x[1] - x[0], t[1] - t[0]
true = np.zeros(len(NAMES))
i_conv, i_diff = NAMES.index("(u^2)_x"), NAMES.index("(u)_xx")
true[i_conv], true[i_diff] = -0.5, 0.1

print("clean data, strong form: u_t =", describe(identify(*strong_system(U, dx, dt))))
print("clean data, weak form:   u_t =", describe(identify(*weak_system(U, x, t))))

methods = ["FD", "SG", "weak"]
etas = np.array([1e-4, 3e-4, 1e-3, 3e-3, 1e-2, 3e-2, 0.1, 0.2, 0.3])
n_seeds = 3
wrong = {m: np.zeros((len(etas), n_seeds)) for m in methods}
nu_hat = {m: np.zeros((len(etas), n_seeds)) for m in methods}
for i, eta in enumerate(etas):
    for seed in range(n_seeds):
        V = U + eta * U.std() * np.random.default_rng(seed).standard_normal(U.shape)
        for m in methods:
            if m == "weak":
                xi = identify(*weak_system(V, x, t))
            else:
                xi = identify(*strong_system(V, dx, dt, smooth=(m == "SG")))
            wrong[m][i, seed] = np.sum((xi != 0) != (true != 0))
            nu_hat[m][i, seed] = xi[i_diff]
            if seed == 0 and eta in (0.01, 0.1):
                print("eta=%.2f %-4s: u_t = %s" % (eta, m, describe(xi)))
    print("eta=%.0e  " % eta + "  ".join("%s: wrong terms %.1f, nu %.4f" % (
        m, wrong[m][i].mean(), nu_hat[m][i].mean()) for m in methods))

# ---------------------------------------------------------------- figure
set_style()
cols = {"FD": COLORS["red"], "SG": COLORS["blue"], "weak": COLORS["green"]}
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 1.95),
                        gridspec_kw=dict(width_ratios=[1.05, 1, 1], wspace=0.45))
ax = axs[0]
V = U + 0.1 * U.std() * np.random.default_rng(0).standard_normal(U.shape)
im = ax.pcolormesh(x, t, V, cmap="viridis", shading="auto", rasterized=True)
ax.set_xlabel("$x$")
ax.set_ylabel("$t$")
ax.set_title(r"(a) data with 10% noise")
fig.colorbar(im, ax=ax, fraction=0.05, pad=0.03)

ax = axs[1]
for k, m in enumerate(methods):
    ax.semilogx(etas * (1 + 0.06 * (k - 1)), wrong[m].mean(axis=1), "o-", color=cols[m],
                ms=3.5, label=m if m != "weak" else "weak form")
ax.set_xlabel(r"relative noise $\eta$")
ax.set_title("(b) wrong terms in model")
ax.legend(loc="upper center", ncol=3, handlelength=1.0, columnspacing=0.6,
          bbox_to_anchor=(0.5, 1.02))
ax.set_ylim(-0.4, 12.5)

ax = axs[2]
for k, m in enumerate(methods):
    ax.semilogx(etas * (1 + 0.06 * (k - 1)), nu_hat[m].mean(axis=1), "o-", color=cols[m], ms=3.5)
ax.axhline(0.1, color="k", ls="--", lw=0.8)
ax.text(1.2e-4, 0.11, r"true $\nu=0.1$", fontsize=7)
ax.set_xlabel(r"relative noise $\eta$")
ax.set_title(r"(c) identified coefficient of $u_{xx}$")
ax.set_ylim(-0.005, 0.125)
savefig(fig, "ch08", "pdefind_burgers")
print("saved figures/ch08/pdefind_burgers.pdf")

"""PDE-FIND (strong form) and weak-form sparse regression for 1D PDEs u_t = N(u).

Library terms are written in divergence form, d^m/dx^m (u^k) for k = 0..3 and
m = 0..3 (13 distinct terms), because the weak form moves every x-derivative onto
the test function:
    int int phi * d_x^m(u^k) dx dt = (-1)^m int int (d_x^m phi) u^k dx dt,
    int int phi * u_t dx dt        = -int int (d_t phi) u dx dt.
Viscous Burgers u_t = -(u^2/2)_x + nu u_xx has exactly two nonzero coefficients.
Run `python3 code/ch08/pdefind.py` for a quick test on clean data.
"""
import os
import sys

import numpy as np
from numpy.polynomial import polynomial as P
from scipy.signal import savgol_filter

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from sciml_data import burgers_periodic  # noqa: E402
from sindy import stlsq_normalized  # noqa: E402

TERMS = [(0, 0)] + [(k, m) for k in (1, 2, 3) for m in (0, 1, 2, 3)]   # (power k, order m)


def term_name(k, m):
    if k == 0:
        return "1"
    base = "u" if k == 1 else "u^%d" % k
    return base if m == 0 else "(%s)_%s" % (base, "x" * m)


NAMES = [term_name(k, m) for k, m in TERMS]


def burgers_data(n=256, nt=101, length=16.0, T=10.0, nu=0.1):
    """Periodic viscous Burgers on [-8, 8) from a Gaussian bump (ETDRK4 solver)."""
    x = -length / 2 + length * np.arange(n) / n
    t = np.linspace(0.0, T, nt)
    U = burgers_periodic(np.exp(-(x + 2.0) ** 2), nu, length=length, t_save=t, dt=1e-3)
    return x, t, U


def _dx(A, dx, m):
    """m-th periodic central-difference derivative along axis 1."""
    for _ in range(m // 2):
        A = (np.roll(A, -1, 1) - 2 * A + np.roll(A, 1, 1)) / dx ** 2
    if m % 2:
        A = (np.roll(A, -1, 1) - np.roll(A, 1, 1)) / (2 * dx)
    return A


def strong_system(U, dx, dt, smooth=False, trim=5):
    """Pointwise library Theta (rows = grid points) and target u_t."""
    if smooth:   # Savitzky-Golay smoothing in x (periodic) and t before differentiating
        U = savgol_filter(savgol_filter(U, 15, 3, axis=1, mode="wrap"), 9, 3, axis=0)
    Ut = np.gradient(U, dt, axis=0, edge_order=2)
    cols = [_dx(U ** k, dx, m) if k > 0 else np.ones_like(U) for k, m in TERMS]
    sl = slice(trim, U.shape[0] - trim)          # drop snapshots near t = 0, T
    return np.column_stack([c[sl].ravel() for c in cols]), Ut[sl].reshape(-1, 1)


def _bump(npts, h, p, order):
    """Values of d^order/ds^order of (1 - s^2)^p, s in [-1, 1], scaled to a
    physical half-width npts*h."""
    s = np.linspace(-1, 1, 2 * npts + 1)
    c = P.polypow([1.0, 0.0, -1.0], p)                 # coefficients of (1 - s^2)^p
    return P.polyval(s, P.polyder(c, order)) / (npts * h) ** order if order else P.polyval(s, c)


def weak_system(U, x, t, n_test=600, hx=20, ht=10, p=5, seed=0):
    """Weak-form system G xi = b from n_test space-time test functions
    phi(x, t) = (1 - s^2)^p (1 - r^2)^p supported on (2hx+1) x (2ht+1) grid boxes."""
    dx, dt = x[1] - x[0], t[1] - t[0]
    nt, nx = U.shape
    rng = np.random.default_rng(seed)
    ci = rng.integers(0, nx, n_test)                   # periodic in x
    cj = rng.integers(ht, nt - ht, n_test)             # box must fit inside [0, T]
    phix = [_bump(hx, dx, p, m) for m in range(4)]     # d^m phi / dx^m (1D factor)
    phit, dphit = _bump(ht, dt, p, 0), _bump(ht, dt, p, 1)
    powers = [np.ones_like(U), U, U ** 2, U ** 3]
    G = np.zeros((n_test, len(TERMS)))
    b = np.zeros((n_test, 1))
    w = dx * dt                                        # rectangle-rule weights (phi = 0 at box edges)
    for q in range(n_test):
        ix = (ci[q] + np.arange(-hx, hx + 1)) % nx
        jt = cj[q] + np.arange(-ht, ht + 1)
        box = [Pk[np.ix_(jt, ix)] for Pk in powers]
        b[q, 0] = -w * np.sum(np.outer(dphit, phix[0]) * box[1])
        for col, (k, m) in enumerate(TERMS):
            G[q, col] = (-1) ** m * w * np.sum(np.outer(phit, phix[m]) * box[k])
    return G, b


def identify(G, b, lam=0.1):
    return stlsq_normalized(G, b, lam)[:, 0]


def describe(xi, tol=0.0):
    return " ".join("%+.4f %s" % (xi[i], NAMES[i]) for i in range(len(xi)) if abs(xi[i]) > tol)


if __name__ == "__main__":
    x, t, U = burgers_data()
    dx, dt = x[1] - x[0], t[1] - t[0]
    print("strong form, clean: u_t =", describe(identify(*strong_system(U, dx, dt))))
    print("weak form,   clean: u_t =", describe(identify(*weak_system(U, x, t))))

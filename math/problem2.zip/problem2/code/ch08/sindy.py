"""Minimal SINDy toolkit for Chapter 8 (NumPy/SciPy only).

Contents
    poly_library(X, degree, names)   monomial library Theta(X) and term labels
    stlsq(Theta, dXdt, lam)          sequentially thresholded least squares
    fd_derivative(X, dt)             second-order central finite differences
    sg_derivative(X, dt, window)     Savitzky-Golay smoothing + differentiation
    weak_system(X, t, ...)           weak-form (integral) SINDy linear system
    simulate(Xi, degree, x0, t)      integrate an identified polynomial model
Run `python3 code/ch08/sindy.py` for a quick self-test on the Lorenz system.
"""
import itertools
import os
import sys

import numpy as np
from scipy.integrate import solve_ivp
from scipy.signal import savgol_filter

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))


# ------------------------------------------------------------------ library
def poly_library(X, degree, names=("x", "y", "z")):
    """Columns 1, x, y, z, xx, xy, ... (all monomials up to `degree`)."""
    m, n = X.shape
    cols, labels = [np.ones(m)], ["1"]
    for d in range(1, degree + 1):
        for idx in itertools.combinations_with_replacement(range(n), d):
            cols.append(np.prod(X[:, list(idx)], axis=1))
            labels.append("".join(names[i] for i in idx))
    return np.column_stack(cols), labels


# ------------------------------------------------------------------ STLSQ
def stlsq(Theta, dXdt, lam, max_iter=25):
    """STLSQ (Brunton et al., 2016): returns Xi (p, n) with dXdt ~ Theta @ Xi."""
    Xi = np.linalg.lstsq(Theta, dXdt, rcond=None)[0]   # dense least squares
    active = np.ones_like(Xi, dtype=bool)
    for _ in range(max_iter):
        new_active = np.abs(Xi) >= lam                 # hard thresholding
        if np.array_equal(new_active, active):         # support unchanged:
            break                                      # fixed point reached
        active = new_active
        Xi = np.zeros_like(Xi)
        for j in range(dXdt.shape[1]):                 # refit each equation
            S = active[:, j]                           # on its own support
            if S.any():
                Xi[S, j] = np.linalg.lstsq(Theta[:, S], dXdt[:, j], rcond=None)[0]
    return Xi


def stlsq_normalized(Theta, dXdt, lam, max_iter=25):
    """Scale-free STLSQ: columns of Theta and of dXdt are scaled to unit norm, so
    the threshold applies to the dimensionless coefficients
    xi_jk * ||theta_j|| / ||dXdt_k||.  Returns coefficients in original units."""
    scale = np.linalg.norm(Theta, axis=0)
    out = np.linalg.norm(dXdt, axis=0)
    Xi = stlsq(Theta / scale, dXdt / out, lam, max_iter)
    return Xi * out[None, :] / scale[:, None]


# ------------------------------------------------------------------ derivatives
def fd_derivative(X, dt):
    """Second-order central differences (one-sided at the ends)."""
    return np.gradient(X, dt, axis=0, edge_order=2)


def sg_derivative(X, dt, window, order=3):
    """Savitzky-Golay: local least-squares polynomial fit of the given order
    on a sliding window of `window` samples; returns (smoothed X, dX/dt)."""
    Xs = savgol_filter(X, window, order, axis=0)
    dX = savgol_filter(X, window, order, deriv=1, delta=dt, axis=0)
    return Xs, dX


# ------------------------------------------------------------------ weak form
def weak_system(X, t, degree, n_windows=100, half_width=40, power=4, names=("x", "y", "z")):
    """Weak SINDy (Messenger & Bortz, 2021) for x' = Theta(x) Xi.

    Test functions phi_k(t) = (t - a_k)^p (b_k - t)^p on windows [a_k, b_k] of
    2*half_width+1 samples vanish at both ends, so integrating by parts gives
        int phi_k x' dt = - int phi_k' x dt,
    and no pointwise derivative of the data is needed.  Returns (G, b, labels)
    with G[k, j] = int phi_k theta_j(x) dt and b[k, :] = - int phi_k' x dt.
    """
    Theta, labels = poly_library(X, degree, names)
    m = len(t)
    centers = np.linspace(half_width, m - 1 - half_width, n_windows).astype(int)
    G = np.zeros((n_windows, Theta.shape[1]))
    b = np.zeros((n_windows, X.shape[1]))
    for k, c in enumerate(centers):
        sl = slice(c - half_width, c + half_width + 1)
        tt = t[sl]
        a, bb = tt[0], tt[-1]
        phi = (tt - a) ** power * (bb - tt) ** power
        dphi = power * (tt - a) ** (power - 1) * (bb - tt) ** power \
            - power * (tt - a) ** power * (bb - tt) ** (power - 1)
        nrm = np.trapezoid(phi, tt)                    # normalize test function
        G[k] = np.trapezoid(phi[:, None] * Theta[sl], tt, axis=0) / nrm
        b[k] = -np.trapezoid(dphi[:, None] * X[sl], tt, axis=0) / nrm
    return G, b, labels


# ------------------------------------------------------------------ simulation
def simulate(Xi, degree, x0, t_eval):
    """Integrate x' = Theta(x) Xi for an identified polynomial model."""
    def f(t, x):
        theta, _ = poly_library(x[None, :], degree)
        return (theta @ Xi)[0]
    sol = solve_ivp(f, (t_eval[0], t_eval[-1]), x0, t_eval=t_eval,
                    method="DOP853", rtol=1e-10, atol=1e-12)
    return sol.y.T


def lorenz_true_coefficients(labels, sigma=10.0, rho=28.0, beta=8.0 / 3.0):
    Xi = np.zeros((len(labels), 3))
    idx = {lab: i for i, lab in enumerate(labels)}
    Xi[idx["x"], 0], Xi[idx["y"], 0] = -sigma, sigma
    Xi[idx["x"], 1], Xi[idx["y"], 1], Xi[idx["xz"], 1] = rho, -1.0, -1.0
    Xi[idx["z"], 2], Xi[idx["xy"], 2] = -beta, 1.0
    return Xi


def print_model(Xi, labels, lhs=("x'", "y'", "z'"), tol=0.0):
    for j, name in enumerate(lhs):
        terms = ["%+.4f %s" % (Xi[i, j], labels[i]) for i in range(len(labels))
                 if abs(Xi[i, j]) > tol]
        print("%s = %s" % (name, " ".join(terms)))


if __name__ == "__main__":
    from sciml_data import lorenz63
    dt = 0.002
    t = np.arange(0, 20, dt)
    X = lorenz63(x0=(-8.0, 8.0, 27.0), t_eval=t)
    Theta, labels = poly_library(X, 3)
    Xi = stlsq(Theta, fd_derivative(X, dt), lam=0.1)
    print_model(Xi, labels)
    Xi_true = lorenz_true_coefficients(labels)
    print("relative coefficient error:", np.linalg.norm(Xi - Xi_true) / np.linalg.norm(Xi_true))
    assert np.array_equal(Xi != 0, Xi_true != 0)
    G, b, _ = weak_system(X, t, 3)
    Xiw = stlsq(G, b, lam=0.1)
    print("weak form relative error:", np.linalg.norm(Xiw - Xi_true) / np.linalg.norm(Xi_true))
    print("self-test passed")

"""Figure 9.2: accuracy and memory of neural-ODE gradients (Chapter 9).

Vector field f(x) = -k x + MLP(x) in R^2 (random MLP, 2-32-2, tanh), 16 initial
conditions, 11 observation times on [0, 5], squared-error loss to fixed random targets.
Compares (i) backpropagation through RK4 (discretize-then-optimize), (ii) the continuous
adjoint with the state restarted from stored values at each observation time
("checkpointed"), and (iii) the continuous adjoint reconstructing x(t) backward from
x(T) only. Reference: backpropagation through RK4 with 640 steps.
Run from the project root:  python3 code/ch09/fig_gradient_accuracy.py
"""
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from node import MLP, odeint_rk4, odeint_adjoint  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)


class Damped(torch.nn.Module):
    def __init__(self, k):
        super().__init__()
        torch.manual_seed(0)
        self.mlp = MLP(2, width=32, depth=1)
        self.k = k

    def forward(self, t, x):
        return -self.k * x + self.mlp(t, x)


torch.manual_seed(1)
X0 = 2.0 * torch.randn(16, 2)
T_OBS = torch.linspace(0.0, 5.0, 11)
Y = torch.randn(len(T_OBS), 16, 2)


def gradient(f, solver):
    f.zero_grad()
    xs = solver(f, X0)
    ((xs - Y) ** 2).mean().backward()
    return torch.cat([p.grad.reshape(-1) for p in f.parameters()])


def saved_bytes(f, solver):
    """Bytes of tensors saved for the backward pass, via autograd saved-tensor hooks."""
    total = [0]

    def pack(t):
        total[0] += t.numel() * t.element_size()
        return t
    with torch.autograd.graph.saved_tensors_hooks(pack, lambda t: t):
        xs = solver(f, X0)
    return total[0]


def methods(n_sub):
    return {
        "backprop through RK4": lambda f, x0: odeint_rk4(f, x0, T_OBS, n_sub),
        "adjoint, checkpointed": lambda f, x0: odeint_adjoint(f, x0, T_OBS, n_sub, True),
        "adjoint, reconstructed": lambda f, x0: odeint_adjoint(f, x0, T_OBS, n_sub, False),
    }


def main():
    set_style()
    colors = [COLORS["blue"], COLORS["green"], COLORS["red"]]
    markers = ["o", "s", "^"]
    rel = lambda a, b: max(((a - b).norm() / b.norm()).item(), 1e-16)

    # (a) convergence in the step size for k = 1
    f = Damped(1.0)
    g_ref = gradient(f, lambda f, x0: odeint_rk4(f, x0, T_OBS, 64))
    subs = [1, 2, 4, 8, 16]
    err_a = {m: [] for m in methods(1)}
    for n_sub in subs:
        for m, solver in methods(n_sub).items():
            err_a[m].append(rel(gradient(f, solver), g_ref))
        print("k=1, N=%4d: " % (10 * n_sub) + ", ".join("%s %.2e" % (m, e[-1]) for m, e in err_a.items()))
    for m, solver in methods(32).items():
        print("saved for backward (N=320): %-24s %8.1f kB" % (m, saved_bytes(f, solver) / 1e3))
    for m, solver in methods(8).items():
        print("saved for backward (N= 80): %-24s %8.1f kB" % (m, saved_bytes(f, solver) / 1e3))

    # (b) dependence on the contraction rate k at N = 80 steps
    ks = [0.0, 2.0, 4.0, 6.0, 8.0, 10.0]
    err_b = {m: [] for m in methods(1)}
    for k in ks:
        f = Damped(k)
        g_ref = gradient(f, lambda f, x0: odeint_rk4(f, x0, T_OBS, 64))
        for m, solver in methods(8).items():
            err_b[m].append(rel(gradient(f, solver), g_ref))
        print("N=80, k=%.0f: " % k + ", ".join("%s %.2e" % (m, e[-1]) for m, e in err_b.items()))

    fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4))
    N = 10 * np.array(subs)
    for (m, e), c, mk in zip(err_a.items(), colors, markers):
        axs[0].loglog(N, e, marker=mk, color=c, label=m, ms=3.5)
    axs[0].loglog(N, 0.15 * e[0] * (N / N[0]) ** -4.0, color=COLORS["gray"], ls=":", lw=0.8)
    axs[0].text(N[2] * 1.1, 0.15 * e[0] * (N[2] / N[0]) ** -4.0 * 0.12, r"$\propto N^{-4}$",
                fontsize=7.5, color=COLORS["gray"])
    axs[0].set_xlabel(r"number of RK4 steps $N$ on $[0,5]$")
    axs[0].set_ylabel("relative gradient error")
    axs[0].set_title(r"(a) step-size convergence, $k=1$", loc="left")
    axs[0].legend(fontsize=7, loc="upper right")
    for (m, e), c, mk in zip(err_b.items(), colors, markers):
        axs[1].semilogy(ks, e, marker=mk, color=c, label=m, ms=3.5)
    axs[1].set_xlabel(r"contraction rate $k$ in $f(\mathbf{x})=-k\mathbf{x}+\mathrm{MLP}(\mathbf{x})$")
    axs[1].set_ylabel("relative gradient error")
    axs[1].set_title(r"(b) dissipative dynamics, $N=80$", loc="left")
    fig.tight_layout(w_pad=1.0)
    print("saved", savefig(fig, "ch09", "gradient_accuracy"))


if __name__ == "__main__":
    main()

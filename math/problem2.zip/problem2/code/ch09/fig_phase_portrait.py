"""Figure 9.1: a neural ODE learns the damped Duffing oscillator from noisy,
irregularly sampled trajectories (Chapter 9).

True system (code/common/sciml_data.duffing): x'' + 0.3 x' - x + x^3 = 0.
Training: 24 trajectories on t in [0, 4], 25 shared irregular sample times, noise 0.02;
model dx/dt = f_theta(x), MLP 2-64-64-2 (tanh); backpropagation through RK4
(one RK4 step between consecutive samples); Adam, 800 iterations.
Run from the project root:  python3 code/ch09/fig_phase_portrait.py
"""
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import duffing  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from node import MLP, odeint_rk4  # noqa: E402

torch.set_num_threads(1)   # tiny tensors: one thread is fastest (book limit: <= 2 threads)
torch.manual_seed(0)
rng = np.random.default_rng(0)
DELTA = 0.3


def true_field(x, v):
    return v, -DELTA * v + x - x ** 3


def main():
    set_style()
    # ---------------------------------------------------------------- data
    n_traj, T, n_obs, noise = 24, 4.0, 25, 0.02
    t_obs = np.sort(np.concatenate([[0.0], rng.uniform(0, T, n_obs - 1)]))
    X0 = np.column_stack([rng.uniform(-2.0, 2.0, n_traj), rng.uniform(-1.5, 1.5, n_traj)])
    clean = np.stack([duffing(x0, t_obs, delta=DELTA) for x0 in X0], axis=1)  # (n_obs, n_traj, 2)
    data = clean + noise * rng.standard_normal(clean.shape)
    t_t = torch.tensor(t_obs, dtype=torch.float32)
    y_t = torch.tensor(data, dtype=torch.float32)

    # ---------------------------------------------------------------- training (Adam, DtO)
    f = MLP(2, width=64, depth=2)
    opt = torch.optim.Adam(f.parameters(), lr=5e-3)
    n_iter = 800
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, n_iter, eta_min=1e-4)
    t0 = time.perf_counter()
    for it in range(n_iter):
        opt.zero_grad()
        pred = odeint_rk4(f, y_t[0], t_t, n_sub=1)    # start from the (noisy) first sample
        loss = ((pred - y_t) ** 2).mean()
        loss.backward()
        opt.step()
        sched.step()
        if it % 100 == 0 or it == n_iter - 1:
            print("iter %4d  loss %.3e" % (it, loss.item()), flush=True)
    print("training time %.0f s" % (time.perf_counter() - t0))

    # ---------------------------------------------------------------- tests
    X0_test = np.array([[-1.6, 1.0], [0.3, 1.2], [1.8, -0.6], [-0.5, -1.2]])
    t_test = np.linspace(0, 20, 801)
    true_test = np.stack([duffing(x0, t_test, delta=DELTA) for x0 in X0_test], axis=1)
    with torch.no_grad():
        pred_test = odeint_rk4(f, torch.tensor(X0_test, dtype=torch.float32),
                               torch.tensor(t_test, dtype=torch.float32), n_sub=1).numpy()
    for j in range(len(X0_test)):
        e4 = np.abs(pred_test[t_test <= 4, j] - true_test[t_test <= 4, j]).max()
        print("test IC %s: max error on [0,4] %.3f, final state true %s, NODE %s"
              % (X0_test[j], e4, np.round(true_test[-1, j], 3), np.round(pred_test[-1, j], 3)))
    # vector-field error inside / outside the sampled region
    g = np.linspace(-2.2, 2.2, 45)
    XX, VV = np.meshgrid(g, g)
    U, V = true_field(XX, VV)
    with torch.no_grad():
        F = f(None, torch.tensor(np.stack([XX.ravel(), VV.ravel()], 1), dtype=torch.float32)).numpy()
    Ul, Vl = F[:, 0].reshape(XX.shape), F[:, 1].reshape(XX.shape)
    err = np.hypot(Ul - U, Vl - V) / np.maximum(np.hypot(U, V), 1e-1)
    inside = (np.abs(XX) <= 1.5) & (np.abs(VV) <= 1.0)
    print("median relative vector-field error: |x|<=1.5,|v|<=1: %.3f; whole box: %.3f"
          % (np.median(err[inside]), np.median(err)))

    # ---------------------------------------------------------------- figure
    fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.25),
                            gridspec_kw={"width_ratios": [1, 1, 1.25]})
    for ax, (u, v), title in ((axs[0], (U, V), "(a) true field and data"),
                              (axs[1], (Ul, Vl), "(b) learned field, test ICs")):
        ax.streamplot(g, g, u, v, color=COLORS["gray"], linewidth=0.5, density=0.8, arrowsize=0.6)
        ax.set_xlim(-2.2, 2.2)
        ax.set_ylim(-2.2, 2.2)
        ax.set_xlabel(r"$x$")
        ax.set_aspect("equal")
        ax.set_title(title, loc="left")
    axs[0].set_ylabel(r"$\dot x$")
    for j in range(n_traj):
        axs[0].plot(data[:, j, 0], data[:, j, 1], ".", ms=1.5, color=COLORS["blue"])
    cols = [COLORS["orange"], COLORS["green"], COLORS["red"], COLORS["purple"]]
    for j, c in enumerate(cols):
        axs[1].plot(true_test[:, j, 0], true_test[:, j, 1], color=c, lw=1.6, alpha=0.45)
        axs[1].plot(pred_test[:, j, 0], pred_test[:, j, 1], color=c, lw=0.8, ls="--")
        axs[1].plot(*X0_test[j], "o", ms=2.5, color=c)
    ax = axs[2]
    for j, c in zip([0, 2], [cols[0], cols[2]]):
        ax.plot(t_test, true_test[:, j, 0], color=c, lw=1.6, alpha=0.45)
        ax.plot(t_test, pred_test[:, j, 0], color=c, lw=0.8, ls="--")
    ax.axvspan(0, T, color=COLORS["gray"], alpha=0.12, lw=0)
    ax.text(T / 2, 2.45, "training", fontsize=6.5, color=COLORS["gray"], ha="center", va="top")
    ax.plot([], [], color="k", lw=1.6, alpha=0.45, label="truth")
    ax.plot([], [], color="k", lw=0.8, ls="--", label="neural ODE")
    ax.legend(fontsize=6.5, loc="upper right", ncol=2, columnspacing=0.8, handlelength=1.6)
    ax.set_xlabel(r"$t$")
    ax.set_ylabel(r"$x(t)$")
    ax.set_ylim(-2.0, 2.6)
    ax.set_title("(c) extrapolation in time", loc="left")
    fig.tight_layout(w_pad=0.6)
    print("saved", savefig(fig, "ch09", "phase_portrait"))


if __name__ == "__main__":
    main()

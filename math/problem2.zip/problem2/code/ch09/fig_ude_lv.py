"""Figure 9.3: universal differential equation (UDE) for Lotka-Volterra with a missing
interaction term, followed by sparse regression on the learned term (Chapter 9).

Truth (code/common/sciml_data.lotka_volterra):
    x' = alpha x - beta x y,   y' = gamma x y - delta y,
    alpha, beta, gamma, delta = 1.3, 0.9, 0.8, 1.8.
UDE: the linear terms alpha x and -delta y are known; the interaction terms are
replaced by a neural network U_theta(x, y) in R^2. Training data: one trajectory on
t in [0, 3], 31 samples, Gaussian noise with standard deviation 2% of each component's
standard deviation. Afterwards U_theta is evaluated along the fitted trajectory and
STLSQ (Chapter 8, threshold 0.2) selects terms from a quadratic library.
Run from the project root:  python3 code/ch09/fig_ude_lv.py
"""
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import lotka_volterra, integrate  # noqa: E402
import matplotlib.pyplot as plt  # noqa: E402
from node import odeint_rk4  # noqa: E402

torch.set_num_threads(1)   # tiny tensors: one thread is fastest (book limit: <= 2 threads)
torch.set_default_dtype(torch.float64)
torch.manual_seed(0)
rng = np.random.default_rng(0)
ALPHA, BETA, GAMMA, DELTA = 1.3, 0.9, 0.8, 1.8


class UDE(torch.nn.Module):
    """Known physics (prey growth, predator decay) + neural network for the rest."""

    def __init__(self, width=32):
        super().__init__()
        self.U = torch.nn.Sequential(torch.nn.Linear(2, width), torch.nn.Tanh(),
                                     torch.nn.Linear(width, width), torch.nn.Tanh(),
                                     torch.nn.Linear(width, 2))

    def forward(self, t, z):
        known = torch.stack([ALPHA * z[..., 0], -DELTA * z[..., 1]], dim=-1)
        return known + self.U(z)             # dz/dt = known(z) + U_theta(z)


def library(Z):
    """Quadratic polynomial library Theta(z) = [1, x, y, x^2, xy, y^2]."""
    x, y = Z[:, 0], Z[:, 1]
    return np.column_stack([np.ones_like(x), x, y, x * x, x * y, y * y])


NAMES = ["1", "x", "y", "x^2", "xy", "y^2"]


def stlsq(Theta, dX, lam=0.1, n_iter=10):
    """Sequentially thresholded least squares (Brunton et al. 2016)."""
    Xi = np.linalg.lstsq(Theta, dX, rcond=None)[0]
    for _ in range(n_iter):
        small = np.abs(Xi) < lam
        Xi[small] = 0.0
        for k in range(dX.shape[1]):
            big = ~small[:, k]
            Xi[big, k] = np.linalg.lstsq(Theta[:, big], dX[:, k], rcond=None)[0]
    return Xi


def main():
    set_style()
    # ---------------------------------------------------------------- data
    x0 = np.array([0.44249296, 4.6280594])
    t_train = np.linspace(0.0, 3.0, 31)
    clean = lotka_volterra(x0, t_train)
    noise = 0.02 * clean.std(axis=0)
    data = clean + noise * rng.standard_normal(clean.shape)
    t_t, y_t = torch.tensor(t_train), torch.tensor(data)

    # ---------------------------------------------------------------- training: Adam then L-BFGS
    model = UDE()
    z0 = torch.tensor(data[0])
    loss_fn = lambda: ((odeint_rk4(model, z0, t_t, n_sub=1) - y_t) ** 2).mean()
    opt = torch.optim.Adam(model.parameters(), lr=1e-2)
    t0 = time.perf_counter()
    for it in range(500):
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        opt.step()
        if it % 100 == 0:
            print("Adam iter %3d  loss %.3e" % (it, loss.item()), flush=True)
    lbfgs = torch.optim.LBFGS(model.parameters(), lr=1.0, max_iter=300, history_size=20,
                              tolerance_grad=1e-10, tolerance_change=1e-14,
                              line_search_fn="strong_wolfe")

    def closure():
        lbfgs.zero_grad()
        loss = loss_fn()
        loss.backward()
        return loss
    lbfgs.step(closure)
    print("final training loss %.3e (noise variance %.3e); training time %.0f s"
          % (loss_fn().item(), np.mean(noise ** 2), time.perf_counter() - t0), flush=True)

    # ---------------------------------------------------------------- sparse regression on U_theta
    t_fine = torch.linspace(0.0, 3.0, 301)
    with torch.no_grad():
        Z = odeint_rk4(model, z0, t_fine, n_sub=1).numpy()
        Uhat = model.U(torch.tensor(Z)).numpy()
    Theta = library(Z)
    Xi = stlsq(Theta, Uhat, lam=0.2)
    for k, lhs in enumerate(["U1", "U2"]):
        terms = ["%+.3f %s" % (Xi[j, k], NAMES[j]) for j in range(len(NAMES)) if Xi[j, k] != 0]
        print("%s(x, y) = %s" % (lhs, " ".join(terms)))
    U_true = np.column_stack([-BETA * Z[:, 0] * Z[:, 1], GAMMA * Z[:, 0] * Z[:, 1]])
    print("relative error of learned U along the trajectory: %.3f"
          % (np.linalg.norm(Uhat - U_true) / np.linalg.norm(U_true)))

    # ---------------------------------------------------------------- extrapolation
    t_long = np.linspace(0.0, 20.0, 801)
    truth = lotka_volterra(x0, t_long)
    with torch.no_grad():
        ude = odeint_rk4(model, z0, torch.tensor(t_long), n_sub=1).numpy()

    def recovered(t, z):
        th = library(np.asarray(z)[None, :])[0]
        return [ALPHA * z[0] + th @ Xi[:, 0], -DELTA * z[1] + th @ Xi[:, 1]]
    rec = integrate(recovered, data[0], t_long)
    for name, sol in (("UDE (neural)", ude), ("recovered sparse model", rec)):
        e = np.linalg.norm(sol - truth, axis=1) / np.linalg.norm(truth, axis=1)
        print("%-24s max rel. error on [0,3]: %.3f, on [3,20]: %.3f"
              % (name, e[t_long <= 3].max(), e[t_long > 3].max()))

    # ---------------------------------------------------------------- figure
    fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.35), gridspec_kw={"width_ratios": [1.6, 1]})
    ax = axs[0]
    for k, (c, lab) in enumerate(((COLORS["blue"], "prey $x$"), (COLORS["orange"], "predator $y$"))):
        ax.plot(t_long, truth[:, k], color=c, lw=2.2, alpha=0.35)
        ax.plot(t_long, ude[:, k], color=c, lw=0.9, ls="--")
        ax.plot(t_long, rec[:, k], color=c, lw=0.9, ls=":")
        ax.plot(t_train, data[:, k], "o", ms=2.2, color=c, label=lab)
    ax.axvspan(0, 3, color=COLORS["gray"], alpha=0.12, lw=0)
    ax.plot([], [], color="k", lw=2.2, alpha=0.35, label="truth")
    ax.plot([], [], color="k", lw=0.9, ls="--", label="UDE (neural $U_\\theta$)")
    ax.plot([], [], color="k", lw=0.9, ls=":", label="UDE + sparse regression")
    ax.set_xlabel(r"$t$")
    ax.set_ylabel("population")
    ax.set_ylim(0, 12.5)
    ax.legend(fontsize=6.5, ncol=3, loc="upper center", columnspacing=0.8, handlelength=1.6)
    ax.set_title("(a) training window (shaded) and extrapolation", loc="left")
    ax = axs[1]
    tf = t_fine.numpy()
    ax.plot(tf, U_true[:, 0], color=COLORS["blue"], lw=2.2, alpha=0.35)
    ax.plot(tf, Uhat[:, 0], color=COLORS["blue"], lw=0.9, ls="--", label=r"$U_1$ vs $-\beta xy$")
    ax.plot(tf, U_true[:, 1], color=COLORS["orange"], lw=2.2, alpha=0.35)
    ax.plot(tf, Uhat[:, 1], color=COLORS["orange"], lw=0.9, ls="--", label=r"$U_2$ vs $\gamma xy$")
    ax.set_xlabel(r"$t$")
    ax.set_ylabel("missing term")
    ax.legend(fontsize=6.5, loc="lower right")
    ax.set_title("(b) learned vs. true interaction", loc="left")
    fig.tight_layout(w_pad=0.8)
    print("saved", savefig(fig, "ch09", "ude_lv"))


if __name__ == "__main__":
    main()

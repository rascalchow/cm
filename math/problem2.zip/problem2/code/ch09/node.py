"""Neural-ODE building blocks for Chapter 9 (PyTorch only; no torchdiffeq).

* rk4_step / odeint_rk4: fixed-step classical Runge-Kutta; autograd records every
  stage, so loss.backward() is backpropagation through the solver
  (discretize-then-optimize).
* odeint_adjoint: same forward solve, but gradients come from integrating the
  continuous adjoint (augmented) system backward in time (optimize-then-discretize),
  as proposed for neural ODEs by Chen et al. (2018). Only the states at the
  observation times are stored.
Tests: python3 code/ch09/test_node.py
"""
import torch


class MLP(torch.nn.Module):
    """Autonomous vector field f_theta(x): R^d -> R^d."""

    def __init__(self, dim, width=64, depth=2, act=torch.nn.Tanh):
        super().__init__()
        layers, d_in = [], dim
        for _ in range(depth):
            layers += [torch.nn.Linear(d_in, width), act()]
            d_in = width
        layers.append(torch.nn.Linear(d_in, dim))
        self.net = torch.nn.Sequential(*layers)

    def forward(self, t, x):
        return self.net(x)


def axpy(z, a, k):
    """z + a*k for a tensor or a tuple of tensors (augmented adjoint state)."""
    if isinstance(z, tuple):
        return tuple(zi + a * ki for zi, ki in zip(z, k))
    return z + a * k


def rk4_step(f, t, z, h):
    """One classical RK4 step for dz/dt = f(t, z); h may be negative."""
    k1 = f(t, z)
    k2 = f(t + h / 2, axpy(z, h / 2, k1))
    k3 = f(t + h / 2, axpy(z, h / 2, k2))
    k4 = f(t + h, axpy(z, h, k3))
    return axpy(z, h / 6, axpy(axpy(k1, 2.0, axpy(k2, 1.0, k3)), 1.0, k4))


def odeint_rk4(f, x0, t_obs, n_sub):
    """States at the times t_obs (x0 at t_obs[0]), n_sub RK4 steps per interval."""
    xs, x = [x0], x0
    for i in range(len(t_obs) - 1):
        h = (t_obs[i + 1] - t_obs[i]) / n_sub
        for j in range(n_sub):
            x = rk4_step(f, t_obs[i] + j * h, x, h)
        xs.append(x)
    return torch.stack(xs)                      # (n_obs, batch, dim)


class AdjointRK4(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x0, t_obs, n_sub, checkpoint, f, *params):
        with torch.no_grad():                   # no graph: memory independent of n_sub
            xs = odeint_rk4(f, x0, t_obs, n_sub)
        ctx.f, ctx.n_sub, ctx.checkpoint = f, n_sub, checkpoint
        ctx.save_for_backward(t_obs, xs)
        return xs

    @staticmethod
    def backward(ctx, g):                       # g[i] = dL/dx(t_i), shape like xs
        t_obs, xs = ctx.saved_tensors
        f, params = ctx.f, tuple(ctx.f.parameters())

        def aug(t, z):                          # z = (x, a, a_theta_1, ..., a_theta_P)
            with torch.enable_grad():
                x = z[0].detach().requires_grad_(True)
                fx = f(t, x)
                vjp = torch.autograd.grad(fx, (x,) + params, z[1], allow_unused=True)
            return (fx,) + tuple(-v if v is not None else torch.zeros_like(p)
                                 for v, p in zip(vjp, (x,) + params))

        z = (xs[-1], g[-1]) + tuple(torch.zeros_like(p) for p in params)
        for i in range(len(t_obs) - 1, 0, -1):  # backward in time, interval by interval
            h = (t_obs[i - 1] - t_obs[i]) / ctx.n_sub          # negative step
            for j in range(ctx.n_sub):
                z = rk4_step(aug, t_obs[i] + j * h, z, h)
            x_prev = xs[i - 1] if ctx.checkpoint else z[0]       # stored or reconstructed
            z = (x_prev, z[1] + g[i - 1]) + z[2:]               # jump: add dL/dx(t_{i-1})
        return (z[1], None, None, None, None) + z[2:]


def odeint_adjoint(f, x0, t_obs, n_sub, checkpoint=True):
    """Forward RK4 solve; backward pass by the continuous adjoint method.

    checkpoint=True restarts the backward state reconstruction from the stored forward
    state at every observation time; checkpoint=False reconstructs x(t) over the whole
    horizon by integrating backward from x(T) only.
    """
    return AdjointRK4.apply(x0, t_obs, n_sub, checkpoint, f, *f.parameters())

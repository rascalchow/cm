"""Tests for node.py: adjoint gradients vs backpropagation through the RK4 solver.

Run from the project root:  python3 code/ch09/test_node.py
"""
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(__file__))
from node import MLP, odeint_rk4, odeint_adjoint  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)


def flat_grads(f, x0, loss_fn, solver):
    f.zero_grad()
    x0 = x0.clone().requires_grad_(True)
    loss = loss_fn(solver(x0))
    loss.backward()
    return torch.cat([x0.grad.reshape(-1)] + [p.grad.reshape(-1) for p in f.parameters()]), loss.item()


def main():
    torch.manual_seed(1)
    f = MLP(2, width=32)
    x0 = torch.randn(8, 2)
    t_obs = torch.tensor([0.0, 0.3, 0.45, 1.0, 1.6, 2.0])   # irregular observation times
    y = torch.randn(len(t_obs), 8, 2)
    loss_fn = lambda xs: ((xs - y) ** 2).sum()

    rel = lambda a, b: ((a - b).norm() / b.norm()).item()
    for n_sub in (4, 16, 64):
        g_bp, L1 = flat_grads(f, x0, loss_fn, lambda z: odeint_rk4(f, z, t_obs, n_sub))
        g_ad, L2 = flat_grads(f, x0, loss_fn, lambda z: odeint_adjoint(f, z, t_obs, n_sub))
        g_nc, _ = flat_grads(f, x0, loss_fn, lambda z: odeint_adjoint(f, z, t_obs, n_sub, False))
        print("n_sub=%3d  loss %.10f/%.10f  |adjoint - backprop|/|backprop| = %.2e "
              "(no checkpoints: %.2e)" % (n_sub, L1, L2, rel(g_ad, g_bp), rel(g_nc, g_bp)))
        assert L1 == L2
    # O(h^4) agreement: differences shrink by about 2^4 = 16 per halving of the step
    assert rel(g_ad, g_bp) < 1e-8
    print("all neural-ODE gradient tests passed")


if __name__ == "__main__":
    main()

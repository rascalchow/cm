"""Inverse PINN (Section 10.4): identify lam1, lam2 in
        u_t + lam1 u u_x - lam2 u_xx = 0
from N_D scattered noisy observations of the Burgers benchmark solution
(true values lam1 = 1, lam2 = 0.01/pi).  No initial or boundary data are used.
Saves code/ch10/results/inverse.npz.
Run from the project root: python3 code/ch10/burgers_inverse.py
(about 4 min per noise level on two idle CPU threads)
"""
import math
import os

import numpy as np
import torch

from pinn_utils import MLP, RESULTS, Timer, burgers_residual, rel_l2
from sciml_data import burgers_pinn_reference

torch.set_num_threads(2)
N_ADAM = int(os.environ.get("N_ADAM", 3000))
N_LBFGS = int(os.environ.get("N_LBFGS", 1500))
NOISE = [float(s) for s in os.environ.get("NOISE", "0.0,0.01,0.05").split(",")]
N_D, N_R = 500, 2000


class InversePINN(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.u = MLP([2] + [20] * 8 + [1], lb=[-1.0, 0.0], ub=[1.0, 1.0])
        self.lam1 = torch.nn.Parameter(torch.tensor(0.0))              # initial guess 0
        self.log_lam2 = torch.nn.Parameter(torch.tensor(math.log(0.05)))  # lam2 > 0

    def residual(self, X):
        return burgers_residual(self.u, X, self.lam1, torch.exp(self.log_lam2))


def run(noise, x_ref, t_ref, U_ref, seed=0):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    idx = rng.choice(U_ref.size, N_D, replace=False)
    it, ix = np.unravel_index(idx, U_ref.shape)
    X_d = np.column_stack([x_ref[ix], t_ref[it]])
    u_d = U_ref[it, ix] + noise * U_ref.std() * rng.standard_normal(N_D)
    X_r = np.vstack([np.column_stack([rng.uniform(-1, 1, N_R), rng.uniform(0, 1, N_R)]), X_d])

    torch.set_default_dtype(torch.float32)
    model = InversePINN()
    hist = []                                      # (loss_d, loss_r, lam1, lam2)

    def make_loss(dtype):
        Xd, Ud, Xr = (torch.tensor(a, dtype=dtype) for a in (X_d, u_d[:, None], X_r))

        def loss_fn():
            l_d = (model.u(Xd) - Ud).pow(2).mean()          # data misfit
            l_r = model.residual(Xr).pow(2).mean()          # PDE residual
            hist.append((l_d.item(), l_r.item(), model.lam1.item(),
                         math.exp(model.log_lam2.item())))
            return l_d + l_r
        return loss_fn

    timer = Timer()
    loss_fn = make_loss(torch.float32)
    opt = torch.optim.Adam([{"params": model.u.parameters(), "lr": 1e-3},       # network
                            {"params": [model.lam1, model.log_lam2], "lr": 1e-2}])  # physics
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.1 ** (1 / N_ADAM))
    for k in range(N_ADAM):
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        opt.step()
        sched.step()
        if k % 500 == 0:
            print(f"  noise {noise}: adam {k} loss {loss.item():.2e} lam1 {hist[-1][2]:.4f} "
                  f"lam2 {hist[-1][3]:.5f} [{timer():.0f}s]", flush=True)
    n_switch = len(hist)
    model.double()
    torch.set_default_dtype(torch.float64)
    loss_fn = make_loss(torch.float64)
    opt = torch.optim.LBFGS(model.parameters(), lr=1.0, max_iter=N_LBFGS,
                            max_eval=int(1.25 * N_LBFGS), tolerance_grad=1e-11,
                            tolerance_change=1e-14, history_size=50,
                            line_search_fn="strong_wolfe")

    def closure():
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        return loss
    opt.step(closure)

    T, Xg = np.meshgrid(t_ref, x_ref, indexing="ij")
    with torch.no_grad():
        U = model.u(torch.tensor(np.column_stack([Xg.ravel(), T.ravel()]))).numpy().reshape(T.shape)
    lam1, lam2 = hist[-1][2], hist[-1][3]
    res = dict(lam1=lam1, lam2=lam2, err_u=rel_l2(U, U_ref), hist=np.array(hist),
               n_switch=n_switch, X_d=X_d, seconds=timer())
    print(f"noise {noise}: lam1 = {lam1:.5f} (err {abs(lam1 - 1) * 100:.2f}%), "
          f"lam2 = {lam2:.6f} (err {abs(lam2 / (0.01 / math.pi) - 1) * 100:.2f}%), "
          f"field rel L2 {res['err_u']:.2e}, {timer():.0f}s", flush=True)
    return res


def main():
    x_ref, t_ref, U_ref = burgers_pinn_reference()
    out = {"x": x_ref, "t": t_ref, "U_ref": U_ref, "noise": np.array(NOISE)}
    for k, noise in enumerate(NOISE):
        res = run(noise, x_ref, t_ref, U_ref)
        for key, val in res.items():
            out[f"{key}_{k}"] = val
    np.savez(os.path.join(RESULTS, "inverse.npz"), **out)


if __name__ == "__main__":
    main()

"""Forward PINN for the viscous Burgers benchmark (Section 10.3).

    u_t + u u_x = nu u_xx,  x in [-1, 1], t in [0, 1],  nu = 0.01/pi,
    u(x, 0) = -sin(pi x),   u(-1, t) = u(1, t) = 0.

Stage 1: Adam in float32 on N_r collocation points; stage 2: L-BFGS in float64.
The trained prediction is compared with the spectral reference
`burgers_pinn_reference()` and saved to code/ch10/results/burgers.npz.
Run from the project root: python3 code/ch10/burgers_pinn.py
(about 5-10 min on two idle CPU threads; 52 min on a heavily loaded shared machine)
"""
import math
import os

import numpy as np
import torch

from pinn_utils import MLP, RESULTS, Timer, burgers_residual, rel_l2
from sciml_data import burgers_pinn_reference

torch.set_num_threads(2)
N_ADAM = int(os.environ.get("N_ADAM", 4000))
N_LBFGS = int(os.environ.get("N_LBFGS", 2000))
N_R, N_0, N_B = 2500, 128, 128
NU = 0.01 / math.pi


def sample_points(rng):
    X_r = np.column_stack([rng.uniform(-1, 1, N_R), rng.uniform(0, 1, N_R)])
    x0 = rng.uniform(-1, 1, N_0)
    X_0, u_0 = np.column_stack([x0, 0 * x0]), -np.sin(np.pi * x0)[:, None]
    tb = rng.uniform(0, 1, N_B)
    X_b = np.column_stack([np.where(np.arange(N_B) % 2 == 0, -1.0, 1.0), tb])
    return X_r, X_0, u_0, X_b


def main():
    timer = Timer()
    x_ref, t_ref, U_ref = burgers_pinn_reference()
    t_solver = timer()
    rng = np.random.default_rng(0)
    torch.manual_seed(0)
    X_r, X_0, u_0, X_b = sample_points(rng)

    torch.set_default_dtype(torch.float32)
    net = MLP([2] + [20] * 8 + [1], lb=[-1.0, 0.0], ub=[1.0, 1.0])
    hist = []

    def make_loss(dtype):
        Xr, X0, U0, Xb = (torch.tensor(a, dtype=dtype) for a in (X_r, X_0, u_0, X_b))

        def loss_fn():
            l_r = burgers_residual(net, Xr, 1.0, NU).pow(2).mean()   # PDE residual
            l_0 = (net(X0) - U0).pow(2).mean()                      # initial condition
            l_b = net(Xb).pow(2).mean()                             # boundary condition
            hist.append((l_r.item(), l_0.item(), l_b.item()))
            return l_r + l_0 + l_b
        return loss_fn

    # ---- stage 1: Adam (float32) with a decaying learning rate
    loss_fn = make_loss(torch.float32)
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.1 ** (1 / N_ADAM))
    for it in range(N_ADAM):
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        opt.step()
        sched.step()
        if it % 500 == 0:
            print(f"adam {it:5d} loss {loss.item():.3e}  [{timer():.0f}s]", flush=True)
    n_switch = len(hist)

    # ---- stage 2: L-BFGS (float64)
    net.double()
    torch.set_default_dtype(torch.float64)
    loss_fn = make_loss(torch.float64)
    opt = torch.optim.LBFGS(net.parameters(), lr=1.0, max_iter=N_LBFGS,
                            max_eval=int(1.25 * N_LBFGS), tolerance_grad=1e-11,
                            tolerance_change=1e-14, history_size=50,
                            line_search_fn="strong_wolfe")

    def closure():
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        return loss
    opt.step(closure)
    print(f"lbfgs done: {len(hist) - n_switch} evaluations, loss {sum(hist[-1]):.3e}"
          f"  [{timer():.0f}s]", flush=True)

    # ---- evaluate on the reference grid
    T, Xg = np.meshgrid(t_ref, x_ref, indexing="ij")
    Xe = torch.tensor(np.column_stack([Xg.ravel(), T.ravel()]))
    with torch.no_grad():
        U_pinn = net(Xe).numpy().reshape(T.shape)
    err = rel_l2(U_pinn, U_ref)
    print(f"relative L2 error vs spectral reference: {err:.3e}  (train {timer():.0f}s, "
          f"reference solver {t_solver:.1f}s)")
    np.savez(os.path.join(RESULTS, "burgers.npz"), x=x_ref, t=t_ref, U_ref=U_ref, U_pinn=U_pinn,
             hist=np.array(hist), n_switch=n_switch, rel_l2=err, X_r=X_r, X_0=X_0, X_b=X_b,
             train_seconds=timer(), solver_seconds=t_solver)


if __name__ == "__main__":
    main()

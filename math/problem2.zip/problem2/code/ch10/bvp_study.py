"""Section 10.2 study: soft vs hard boundary conditions for the BVP of Listing 10.1,
plus a second-order finite-difference baseline.  Saves code/ch10/results/bvp.npz.
Run from the project root: python3 code/ch10/bvp_study.py   (about 4 min)
"""
import os
import time

import numpy as np
import torch
from scipy.linalg import solve_banded

from pinn_bvp import make_net, train, u_exact

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)
RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")


class HardBC(torch.nn.Module):
    """u(x) = x + x (1 - x) N(x): satisfies u(0) = 0 and u(1) = 1 exactly."""

    def __init__(self, net):
        super().__init__()
        self.net = net

    def forward(self, x):
        return x + x * (1 - x) * self.net(x)


def fd_solve(n):
    """Second-order central differences on n interior points."""
    h = 1.0 / (n + 1)
    x = np.linspace(0, 1, n + 2)
    ab = np.vstack([-np.ones(n), 2 * np.ones(n), -np.ones(n)]) / h ** 2   # tridiagonal matrix
    b = 4 * np.pi ** 2 * np.sin(2 * np.pi * x[1:-1])
    b[-1] += 1.0 / h ** 2                       # boundary value u(1) = 1
    u = np.concatenate([[0.0], solve_banded((1, 1), ab, b), [1.0]])
    return x, u


def main():
    xe = torch.linspace(0, 1, 1001).reshape(-1, 1)
    out = {"x": xe.numpy().ravel(), "u_exact": u_exact(xe).numpy().ravel()}
    for name, wrap in [("soft", lambda n: n), ("hard", HardBC)]:
        torch.manual_seed(0)
        model = wrap(make_net())
        t0 = time.time()
        hist = train(model)
        sec = time.time() - t0
        with torch.no_grad():
            u = model(xe).numpy().ravel()
        err = u - out["u_exact"]
        print(f"{name}: max err {np.abs(err).max():.2e}, rel L2 {np.linalg.norm(err) / np.linalg.norm(out['u_exact']):.2e},"
              f" final loss_r {hist[-1][0]:.2e}, loss_b {hist[-1][1]:.2e}, {len(hist)} evals, {sec:.0f}s")
        out[name + "_u"], out[name + "_hist"], out[name + "_sec"] = u, np.array(hist), sec
    for n in (62, 998):
        t0 = time.time()
        xf, uf = fd_solve(n)
        sec = time.time() - t0
        e = np.abs(uf - (np.sin(2 * np.pi * xf) + xf)).max()
        print(f"FD with {n} interior points: max err {e:.2e} ({sec * 1e3:.1f} ms)")
        out[f"fd{n}_x"], out[f"fd{n}_u"], out[f"fd{n}_err"] = xf, uf, e
    np.savez(os.path.join(RESULTS, "bvp.npz"), **out)


if __name__ == "__main__":
    main()

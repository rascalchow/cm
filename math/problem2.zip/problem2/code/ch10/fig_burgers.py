"""Figure 10.3: forward PINN for the viscous Burgers benchmark.
Requires results/burgers.npz from burgers_pinn.py (computed automatically if missing)."""
import os
import subprocess
import sys

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.colors import LogNorm

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

path = os.path.join(HERE, "results", "burgers.npz")
if not os.path.exists(path):
    subprocess.run([sys.executable, os.path.join(HERE, "burgers_pinn.py")], check=True)
d = np.load(path)
x, t, Ur, Up = d["x"], d["t"], d["U_ref"], d["U_pinn"]
set_style()
fig = plt.figure(figsize=(FULL_WIDTH, 3.3))
gs = fig.add_gridspec(2, 3, height_ratios=[1.15, 1], hspace=0.65, wspace=0.42)
ext = [t[0], t[-1], x[0], x[-1]]

ax = fig.add_subplot(gs[0, 0])
im = ax.imshow(Up.T, origin="lower", extent=ext, aspect="auto", cmap="RdBu_r", vmin=-1, vmax=1)
ax.plot(d["X_0"][:, 1], d["X_0"][:, 0], "k|", ms=3, mew=0.6, clip_on=False)
ax.plot(d["X_b"][:, 1], d["X_b"][:, 0], "k_", ms=3, mew=0.6, clip_on=False)
for tc in (0.25, 0.5, 0.75):
    ax.axvline(tc, color="k", lw=0.5, ls=":")
fig.colorbar(im, ax=ax, ticks=[-1, 0, 1], pad=0.03)
ax.set_xlabel("$t$")
ax.set_ylabel("$x$")
ax.set_title(r"(a) PINN $u_\theta(x,t)$")

ax = fig.add_subplot(gs[0, 1])
err = np.abs(Up - Ur)
im = ax.imshow(err.T, origin="lower", extent=ext, aspect="auto", cmap="Blues",
               norm=LogNorm(vmin=1e-5, vmax=1e-1))
fig.colorbar(im, ax=ax, pad=0.03)
ax.set_xlabel("$t$")
ax.set_title(r"(b) $|u_\theta - u_{\mathrm{ref}}|$")

ax = fig.add_subplot(gs[0, 2])
h = d["hist"]
n0 = int(d["n_switch"])
it = np.arange(1, len(h) + 1)
ax.semilogy(it, h[:, 0], color=COLORS["blue"], lw=0.8, label=r"$\mathcal{L}_r$")
ax.semilogy(it, h[:, 1] + h[:, 2], color=COLORS["orange"], lw=0.8, ls="--",
            label=r"$\mathcal{L}_0+\mathcal{L}_b$")
ax.axvline(n0, color="k", lw=0.6, ls=":")
tr = ax.get_xaxis_transform()
ax.text(n0 * 0.97, 0.97, "Adam", transform=tr, fontsize=7, ha="right", va="top")
ax.text(n0 * 1.03, 0.97, "L-BFGS", transform=tr, fontsize=7, ha="left", va="top")
ax.set_xlabel("loss evaluation")
ax.set_title("(c) training history")
ax.legend(loc="lower left", fontsize=7)

for k, tc in enumerate((0.25, 0.5, 0.75)):
    ax = fig.add_subplot(gs[1, k])
    i = int(np.argmin(np.abs(t - tc)))
    ax.plot(x, Ur[i], color=COLORS["gray"], lw=3.0, alpha=0.45, label="reference")
    ax.plot(x, Up[i], "--", color=COLORS["blue"], lw=1.2, label="PINN")
    ax.set_xlabel("$x$")
    ax.set_title(f"({'def'[k]}) $t = {t[i]:.2f}$")
    ax.set_ylim(-1.1, 1.1)
    if k == 0:
        ax.set_ylabel("$u$")
        ax.legend(loc="upper right", fontsize=7)
print(savefig(fig, "ch10", "burgers_pinn"))

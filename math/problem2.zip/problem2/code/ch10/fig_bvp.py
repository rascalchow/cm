"""Figure 10.2: minimal PINN for -u'' = f (Listing 10.1).
Requires results/bvp.npz from bvp_study.py (computed automatically if missing)."""
import os
import subprocess
import sys

import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

path = os.path.join(HERE, "results", "bvp.npz")
if not os.path.exists(path):
    subprocess.run([sys.executable, os.path.join(HERE, "bvp_study.py")], check=True)
d = np.load(path)
set_style()
fig, ax = plt.subplots(1, 3, figsize=(FULL_WIDTH, 1.95))
x, ue = d["x"], d["u_exact"]

ax[0].plot(x, ue, color=COLORS["gray"], lw=3.0, alpha=0.45, label="exact")
ax[0].plot(x, d["soft_u"], "--", color=COLORS["blue"], label=r"PINN $u_\theta$")
ax[0].set_xlabel("$x$")
ax[0].set_ylabel("$u$")
ax[0].set_title("(a) solution")
ax[0].legend(loc="lower left")

ax[1].semilogy(x, np.abs(d["soft_u"] - ue), color=COLORS["blue"], label="PINN, soft BC")
ax[1].semilogy(x, np.abs(d["hard_u"] - ue) + 1e-16, "--", color=COLORS["orange"], label="PINN, hard BC")
xf = d["fd62_x"]
ax[1].semilogy(xf, np.abs(d["fd62_u"] - (np.sin(2 * np.pi * xf) + xf)) + 1e-16, ":",
               color=COLORS["red"], label="FD, 64 nodes")
ax[1].set_ylim(1e-10, 1e-1)
ax[1].set_xlabel("$x$")
ax[1].set_title(r"(b) pointwise error $|u_\theta - u|$")
ax[1].legend(loc="lower center", ncol=1, fontsize=7, handlelength=1.8)

h = d["soft_hist"]
it = np.arange(1, len(h) + 1)
ax[2].semilogy(it, h[:, 0], color=COLORS["blue"], lw=1.0, label=r"$\mathcal{L}_r$ (residual)")
ax[2].semilogy(it, h[:, 1], color=COLORS["orange"], lw=1.0, ls="--", label=r"$\mathcal{L}_b$ (boundary)")
ax[2].axvline(4000, color="k", lw=0.6, ls=":")
tr = ax[2].get_xaxis_transform()
ax[2].text(2000, 0.97, "Adam", ha="center", va="top", fontsize=7, transform=tr)
ax[2].text(4180, 0.97, "L-BFGS", ha="left", va="top", rotation=90, fontsize=7, transform=tr)
ax[2].set_xlabel("loss evaluation")
ax[2].set_title("(c) training history")
ax[2].set_ylim(1e-14, 1e5)
ax[2].legend(loc="lower left", fontsize=7)
fig.tight_layout()
print(savefig(fig, "ch10", "bvp_pinn"))

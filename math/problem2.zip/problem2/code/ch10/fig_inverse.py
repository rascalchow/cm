"""Figure 10.4: inverse PINN identifying lam1 and lam2 in Burgers' equation.
Requires results/inverse.npz from burgers_inverse.py (computed automatically if missing)."""
import math
import os
import subprocess
import sys

import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

path = os.path.join(HERE, "results", "inverse.npz")
if not os.path.exists(path):
    subprocess.run([sys.executable, os.path.join(HERE, "burgers_inverse.py")], check=True)
d = np.load(path)
set_style()
fig, ax = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.0), gridspec_kw={"width_ratios": [1.15, 1, 1]})
x, t = d["x"], d["t"]
im = ax[0].imshow(d["U_ref"].T, origin="lower", extent=[0, 1, -1, 1], aspect="auto",
                  cmap="RdBu_r", vmin=-1, vmax=1)
Xd = d["X_d_0"]
ax[0].plot(Xd[:, 1], Xd[:, 0], "o", ms=1.6, mfc="k", mec="none", alpha=0.8)
ax[0].set_xlabel("$t$")
ax[0].set_ylabel("$x$")
ax[0].set_title(f"(a) {len(Xd)} observations")
fig.colorbar(im, ax=ax[0], ticks=[-1, 0, 1], pad=0.03)

styles = [(COLORS["blue"], "-"), (COLORS["orange"], "--"), (COLORS["red"], ":")]
for k, noise in enumerate(d["noise"]):
    h = d[f"hist_{k}"]
    it = np.arange(1, len(h) + 1)
    c, ls = styles[k]
    lab = "noise-free" if noise == 0 else f"{100 * noise:g}% noise"
    ax[1].plot(it, h[:, 2], color=c, ls=ls, lw=1.1, label=lab)
    ax[2].semilogy(it, h[:, 3], color=c, ls=ls, lw=1.1, label=lab)
for a, true, title in ((ax[1], 1.0, r"(b) estimate of $\lambda_1$"),
                      (ax[2], 0.01 / math.pi, r"(c) estimate of $\lambda_2$")):
    a.axhline(true, color="k", lw=0.7, ls=(0, (1, 2)))
    a.axvline(int(d["n_switch_0"]), color=COLORS["gray"], lw=0.5)
    a.set_xlabel("loss evaluation")
    a.set_title(title)
ax[2].set_yticks([3e-3, 1e-2, 3e-2, 5e-2])
ax[2].set_yticklabels([r"$3\times10^{-3}$", r"$10^{-2}$", r"$3\times10^{-2}$", r"$5\times10^{-2}$"])
ax[2].minorticks_off()
ax[1].set_ylim(-0.05, 1.25)
ax[1].legend(loc="lower right", fontsize=7)
fig.tight_layout()
print(savefig(fig, "ch10", "burgers_inverse"))

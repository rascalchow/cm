"""Minimal PINN for the boundary-value problem of Section 10.2 (Listings 10.1 and 10.2)

    -u''(x) = 4 pi^2 sin(2 pi x)  on (0, 1),   u(0) = 0,  u(1) = 1,
    exact solution u(x) = sin(2 pi x) + x.

Run from the project root:  python3 code/ch10/pinn_bvp.py   (1-2 min on 2 threads)
"""
import math
import torch
torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)         # float64: errors below 1e-4 need it

def u_exact(x):                                # manufactured solution
    return torch.sin(2 * math.pi * x) + x

def f(x):                                      # source term of -u'' = f
    return 4 * math.pi ** 2 * torch.sin(2 * math.pi * x)

def make_net(width=32):
    return torch.nn.Sequential(torch.nn.Linear(1, width), torch.nn.Tanh(),
                               torch.nn.Linear(width, width), torch.nn.Tanh(),
                               torch.nn.Linear(width, 1))

def residual(u, x):
    """r(x) = -u''(x) - f(x), derivatives by automatic differentiation."""
    x = x.requires_grad_(True)
    ux = u(x)
    du = torch.autograd.grad(ux.sum(), x, create_graph=True)[0]   # u'(x_i)
    d2u = torch.autograd.grad(du.sum(), x, create_graph=True)[0]  # u''(x_i)
    return -d2u - f(x)

def train(u, n_adam=4000, n_lbfgs=500, n_r=64, lam_b=1.0, seed=0):
    torch.manual_seed(seed)
    x_b, g_b = torch.tensor([[0.0], [1.0]]), torch.tensor([[0.0], [1.0]])
    x_r = torch.rand(n_r, 1)                   # collocation points in (0, 1)
    hist = []
    def closure():
        opt.zero_grad()
        loss_r = residual(u, x_r).pow(2).mean()
        loss_b = (u(x_b) - g_b).pow(2).mean()
        hist.append((loss_r.item(), loss_b.item()))
        loss = loss_r + lam_b * loss_b
        loss.backward()
        return loss
    opt = torch.optim.Adam(u.parameters(), lr=1e-3)            # stage 1: Adam
    for it in range(n_adam):
        opt.step(closure)
    opt = torch.optim.LBFGS(u.parameters(), max_iter=n_lbfgs,  # stage 2: L-BFGS
                            tolerance_grad=1e-12, tolerance_change=1e-15,
                            history_size=50, line_search_fn="strong_wolfe")
    opt.step(closure)
    return hist

if __name__ == "__main__":
    torch.manual_seed(0)
    net = make_net()
    hist = train(net)
    x = torch.linspace(0, 1, 1001).reshape(-1, 1)
    with torch.no_grad():
        err = net(x) - u_exact(x)
    print(f"loss {sum(hist[-1]):.2e}, max error {err.abs().max():.2e}")

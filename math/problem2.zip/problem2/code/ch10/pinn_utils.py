"""Small helpers shared by the Chapter 10 and 11 PINN scripts."""
import math
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
RESULTS = os.path.join(HERE, "results")
os.makedirs(RESULTS, exist_ok=True)


class MLP(torch.nn.Module):
    """Fully connected tanh network u_theta(x, t) with inputs rescaled to [-1, 1]."""

    def __init__(self, layers, lb, ub):
        super().__init__()
        self.register_buffer("lb", torch.as_tensor(lb, dtype=torch.get_default_dtype()))
        self.register_buffer("ub", torch.as_tensor(ub, dtype=torch.get_default_dtype()))
        self.linears = torch.nn.ModuleList(
            torch.nn.Linear(a, b) for a, b in zip(layers[:-1], layers[1:]))
        for lin in self.linears:                       # Glorot (Xavier) initialization
            torch.nn.init.xavier_normal_(lin.weight)
            torch.nn.init.zeros_(lin.bias)

    def forward(self, X):
        h = 2.0 * (X - self.lb) / (self.ub - self.lb) - 1.0
        for lin in self.linears[:-1]:
            h = torch.tanh(lin(h))
        return self.linears[-1](h)


def grad(y, x):
    """d y / d x for pointwise outputs y(x_i) (sum trick; keeps the graph)."""
    return torch.autograd.grad(y.sum(), x, create_graph=True)[0]


def burgers_residual(net, X, lam1=1.0, lam2=0.01 / math.pi):
    """r = u_t + lam1 * u * u_x - lam2 * u_xx at points X = [x, t]."""
    X = X.clone().requires_grad_(True)
    u = net(X)
    du = grad(u, X)
    u_x, u_t = du[:, 0:1], du[:, 1:2]
    u_xx = grad(u_x, X)[:, 0:1]
    return u_t + lam1 * u * u_x - lam2 * u_xx


class Timer:
    def __init__(self):
        self.t0 = time.time()

    def __call__(self):
        return time.time() - self.t0


def rel_l2(a, b):
    return float(np.linalg.norm(a - b) / np.linalg.norm(b))

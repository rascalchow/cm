"""Failure and remedies for the 1D convection equation (Sections 11.1 and 11.5).

    u_t + beta u_x = 0,  x in [0, 2 pi], t in [0, 1],  u(x, 0) = sin x,  periodic in x,
    exact solution u(x, t) = sin(x - beta t).

Variants (python3 code/ch11/convection_pinn.py VARIANT [BETA]):
  vanilla     tanh MLP, soft periodic BC, fixed collocation points, Adam then L-BFGS
  curriculum  as vanilla, but beta is increased stage by stage (warm starts)
  causal      exact periodic embedding (cos x, sin x) + causal residual weights
              + NTK-trace loss weights (Wang, Yu & Perdikaris 2022), updated every 500 steps
  causal_plain  as causal, but with unit loss weights (ablation)
  ntk         as vanilla, with NTK loss weights (Wang, Yu & Perdikaris 2022) every 500 Adam steps
  marching    sequence-to-sequence time marching: 10 windows of length 0.1, periodic embedding,
              each window warm-started and initialized by the previous window's prediction
Results are written to code/ch11/results/convection_<variant>_b<beta>.npz.
"""
import copy
import math
import os
import sys
import time

import numpy as np
import torch
from torch.func import functional_call, grad, vmap

torch.set_num_threads(2)
torch.set_default_dtype(torch.float32)
RESULTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(RESULTS, exist_ok=True)
N_ITER = int(os.environ.get("N_ITER", 6000))      # total Adam iterations per run
N_LBFGS = int(os.environ.get("N_LBFGS", 1000))
TWO_PI = 2 * math.pi


class Net(torch.nn.Module):
    """tanh MLP on (x, t); with periodic=True the input x enters only via (cos x, sin x)."""

    def __init__(self, width=50, depth=4, periodic=False):
        super().__init__()
        self.periodic = periodic
        sizes = [3 if periodic else 2] + [width] * depth + [1]
        self.layers = torch.nn.ModuleList(torch.nn.Linear(a, b) for a, b in zip(sizes[:-1], sizes[1:]))
        for lin in self.layers:
            torch.nn.init.xavier_normal_(lin.weight)
            torch.nn.init.zeros_(lin.bias)

    def forward(self, x, t):
        if self.periodic:
            h = torch.cat([torch.cos(x), torch.sin(x), 2 * t - 1], dim=1)
        else:
            h = torch.cat([x / math.pi - 1, 2 * t - 1], dim=1)
        for lin in self.layers[:-1]:
            h = torch.tanh(lin(h))
        return self.layers[-1](h)


def residual(net, x, t, beta):
    x, t = x.clone().requires_grad_(True), t.clone().requires_grad_(True)
    u = net(x, t)
    u_x, u_t = torch.autograd.grad(u.sum(), (x, t), create_graph=True)
    return u_t + beta * u_x


def exact(x, t, beta):
    return np.sin(x - beta * t)


def evaluate(net, beta, nx=256, nt=101):
    x = np.linspace(0, TWO_PI, nx)
    t = np.linspace(0, 1, nt)
    T, X = np.meshgrid(t, x, indexing="ij")
    with torch.no_grad():
        U = net(torch.tensor(X.reshape(-1, 1), dtype=torch.float32),
                torch.tensor(T.reshape(-1, 1), dtype=torch.float32)).numpy().reshape(T.shape)
    Ue = exact(X, T, beta)
    return x, t, U, float(np.linalg.norm(U - Ue) / np.linalg.norm(Ue))


def train_standard(net, beta, n_iter, n_lbfgs, hist, seed=0, n_r=1024, n_0=256, n_b=256,
                   use_ntk=False):
    """PINN loss lam_r L_r + lam_0 (L_0 + L_b) on fixed random points; Adam then L-BFGS.
    Unit weights by default; with use_ntk=True the weights are the NTK weights of ntk_weights(),
    recomputed every 500 Adam steps and frozen for L-BFGS."""
    g = torch.Generator().manual_seed(seed)
    xr, tr = TWO_PI * torch.rand(n_r, 1, generator=g), torch.rand(n_r, 1, generator=g)
    x0 = TWO_PI * torch.rand(n_0, 1, generator=g)
    tb = torch.rand(n_b, 1, generator=g)

    lam = [1.0, 1.0]                                  # [lam_r, lam_0]

    def loss_fn():
        l_r = residual(net, xr, tr, beta).pow(2).mean()
        l_0 = (net(x0, 0 * x0) - torch.sin(x0)).pow(2).mean()
        l_b = (net(0 * tb, tb) - net(0 * tb + TWO_PI, tb)).pow(2).mean()
        hist.append((l_r.item(), l_0.item(), l_b.item()))
        if use_ntk:
            return lam[0] * l_r + lam[1] * (l_0 + l_b)
        return l_r + l_0 + l_b

    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    for it in range(n_iter):
        if use_ntk and it % 500 == 0:
            lam[:] = ntk_weights(net, beta, seed=it)
            print(f"   iter {it}: lam_r {lam[0]:.3f} lam_0 {lam[1]:.1f}", flush=True)
        opt.zero_grad()
        loss = loss_fn()
        loss.backward()
        opt.step()
    if n_lbfgs > 0:
        opt = torch.optim.LBFGS(net.parameters(), lr=1.0, max_iter=n_lbfgs, history_size=50,
                                tolerance_grad=1e-9, tolerance_change=1e-12,
                                line_search_fn="strong_wolfe")

        def closure():
            opt.zero_grad()
            loss = loss_fn()
            loss.backward()
            return loss
        opt.step(closure)


def ntk_weights(net, beta, n_r=256, n_0=128, seed=0):
    """NTK loss weights lam_k = (t_r + t_0) / t_k, where t_k = tr(K_kk) / N_k is the mean
    squared parameter gradient of the residual (k = r) or initial-condition (k = 0) term."""
    g = torch.Generator().manual_seed(seed)
    xr, tr = TWO_PI * torch.rand(n_r, generator=g), torch.rand(n_r, generator=g)
    x0 = TWO_PI * torch.rand(n_0, generator=g)
    params = {k: v.detach() for k, v in net.named_parameters()}

    def u(p, x, t):
        return functional_call(net, p, (x.reshape(1, 1), t.reshape(1, 1))).squeeze()

    def r(p, x, t):
        return grad(u, argnums=2)(p, x, t) + beta * grad(u, argnums=1)(p, x, t)

    def sq(gd):
        return sum((v ** 2).sum() for v in gd.values())

    t_r = vmap(lambda x, t: sq(grad(r)(params, x, t)))(xr, tr).mean()
    t_0 = vmap(lambda x: sq(grad(u)(params, x, torch.zeros(()))))(x0).mean()
    return float((t_r + t_0) / t_r), float((t_r + t_0) / t_0)


def train_causal(net, beta, n_iter, hist, use_ntk=True, eps_list=(1e-2, 1e-1, 1.0, 10.0),
                 n_t=32, n_x=32, seed=0, n_0=256):
    """Causal training (Wang, Sankaran & Perdikaris): residual on n_t time slices weighted by
    w_i = exp(-eps * sum_{k<i} L_r(t_k)); eps is increased once all weights exceed 0.99."""
    torch.manual_seed(seed)
    x0 = torch.linspace(0, TWO_PI, n_0).reshape(-1, 1)
    opt = torch.optim.Adam(net.parameters(), lr=1e-3)
    sched = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=0.9 ** (1 / 1000))
    k_eps, weights, lam_r, lam_0 = 0, [], 1.0, 1.0
    for it in range(n_iter):
        if use_ntk and it % 500 == 0:                                   # rebalance the terms
            lam_r, lam_0 = ntk_weights(net, beta, seed=it)
        t = (torch.arange(n_t) + torch.rand(n_t)) / n_t                # one random time per slice
        T = t.repeat_interleave(n_x).reshape(-1, 1)
        X = TWO_PI * torch.rand(n_t * n_x, 1)                          # n_x random x per slice
        r2 = residual(net, X, T, beta).pow(2).reshape(n_t, n_x).mean(dim=1)   # L_r(t_i)
        l_0 = (net(x0, 0 * x0) - torch.sin(x0)).pow(2).mean()
        with torch.no_grad():                                          # weights: no gradient
            w = torch.exp(-eps_list[k_eps] * (torch.cumsum(r2, 0) - r2))
        loss = lam_r * (w * r2).mean() + lam_0 * l_0
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
        hist.append((r2.mean().item(), l_0.item(), w.min().item(), lam_0))
        if it % 200 == 0:
            weights.append(w.numpy().copy())
        if it % 500 == 0:
            print(f"   iter {it}: L_r {r2.mean().item():.2e} L_0 {l_0.item():.2e} "
                  f"min w {w.min().item():.3f} lam_0 {lam_0:.1f}", flush=True)
        if w.min() > 0.99 and k_eps < len(eps_list) - 1:
            k_eps += 1
            print(f"   iter {it}: eps -> {eps_list[k_eps]}", flush=True)
    return np.array(weights)


class Marching(torch.nn.Module):
    """Piecewise-in-time model: network k represents u on [k dt, (k+1) dt] in local time s."""

    def __init__(self, nets, dt):
        super().__init__()
        self.nets, self.dt = torch.nn.ModuleList(nets), dt

    def forward(self, x, t):
        k = torch.clamp((t / self.dt).floor().long(), 0, len(self.nets) - 1)
        out = torch.zeros_like(t)
        for j, net in enumerate(self.nets):
            m = (k == j).squeeze(1)
            if m.any():
                out[m] = net(x[m], t[m] / self.dt - j)
        return out


def train_marching(beta, n_iter, n_lbfgs, hist, n_win=10, n_r=1024, n_0=256, seed=0):
    dt = 1.0 / n_win
    x0 = torch.linspace(0, TWO_PI, n_0).reshape(-1, 1)
    u0 = torch.sin(x0)
    net, nets = Net(periodic=True), []
    g = torch.Generator().manual_seed(seed)
    for k in range(n_win):
        xr, sr = TWO_PI * torch.rand(n_r, 1, generator=g), torch.rand(n_r, 1, generator=g)

        def loss_fn():
            # local time s = t / dt - k, so u_t = u_s / dt
            l_r = residual(net, xr, sr, beta * dt).pow(2).mean() / dt ** 2
            l_0 = (net(x0, 0 * x0) - u0).pow(2).mean()
            hist.append((l_r.item(), l_0.item(), float(k)))
            return l_r + l_0

        opt = torch.optim.Adam(net.parameters(), lr=1e-3)
        for it in range(n_iter // n_win):
            opt.zero_grad()
            loss = loss_fn()
            loss.backward()
            opt.step()
        opt = torch.optim.LBFGS(net.parameters(), lr=1.0, max_iter=n_lbfgs // n_win, history_size=50,
                                tolerance_grad=1e-9, tolerance_change=1e-12,
                                line_search_fn="strong_wolfe")

        def closure():
            opt.zero_grad()
            loss = loss_fn()
            loss.backward()
            return loss
        opt.step(closure)
        with torch.no_grad():
            u0 = net(x0, torch.ones_like(x0))            # end of window = next initial condition
        nets.append(copy.deepcopy(net))                  # warm start for the next window
        print(f"   window {k}: L_r {hist[-1][0]:.2e} L_0 {hist[-1][1]:.2e}", flush=True)
    return Marching(nets, dt)


def main():
    variant = sys.argv[1]
    beta = float(sys.argv[2]) if len(sys.argv) > 2 else 30.0
    torch.manual_seed(0)
    t0 = time.time()
    hist, extra = [], {}
    if variant == "vanilla":
        net = Net()
        train_standard(net, beta, N_ITER, N_LBFGS, hist)
    elif variant == "curriculum":
        net = Net()
        stages = [b for b in (1.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0) if b <= beta]
        for b in stages:
            train_standard(net, b, N_ITER // len(stages), N_LBFGS // len(stages), hist)
            print(f"   stage beta={b:g}: rel L2 {evaluate(net, b)[3]:.3e}", flush=True)
    elif variant == "ntk":
        net = Net()
        train_standard(net, beta, N_ITER, N_LBFGS, hist, use_ntk=True)
    elif variant == "marching":
        net = train_marching(beta, N_ITER, N_LBFGS, hist)
    elif variant in ("causal", "causal_plain"):
        net = Net(periodic=True)
        extra["weights"] = train_causal(net, beta, N_ITER, hist, use_ntk=(variant == "causal"))
    else:
        raise SystemExit("unknown variant")
    x, t, U, err = evaluate(net, beta)
    sec = time.time() - t0
    print(f"{variant} beta={beta:g}: relative L2 error {err:.3e}  ({sec:.0f}s)", flush=True)
    np.savez(os.path.join(RESULTS, f"convection_{variant}_b{beta:g}.npz"), x=x, t=t, U=U,
             err=err, hist=np.array(hist), seconds=sec, beta=beta, **extra)


if __name__ == "__main__":
    main()

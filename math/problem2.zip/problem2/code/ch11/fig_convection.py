"""Figure 11.1: failure and remedies for u_t + 30 u_x = 0.
Requires the results of code/ch11/run_convection.sh (results/convection_*_b30.npz)."""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

maps = [("vanilla", "standard PINN"), ("ntk", "NTK loss weights"),
        ("curriculum", "curriculum in $\\beta$")]
curves = [("vanilla", "standard PINN", COLORS["red"], ":"),
          ("causal", "causal weights", COLORS["gray"], "-."),
          ("ntk", "NTK loss weights", COLORS["blue"], "-"),
          ("curriculum", "curriculum in $\\beta$", COLORS["orange"], "--"),
          ("marching", "time marching", COLORS["purple"], (0, (6, 2)))]
data = {}
for name in {m[0] for m in maps} | {c[0] for c in curves}:
    path = os.path.join(HERE, "results", f"convection_{name}_b30.npz")
    if not os.path.exists(path):
        sys.exit(f"missing {path}: run code/ch11/run_convection.sh first")
    data[name] = np.load(path)

set_style()
fig = plt.figure(figsize=(FULL_WIDTH, 3.6))
gs = fig.add_gridspec(2, 4, height_ratios=[1, 0.85], hspace=0.62, wspace=0.3)
x, t = data["vanilla"]["x"], data["vanilla"]["t"]
T, X = np.meshgrid(t, x, indexing="ij")
U_ex = np.sin(X - 30.0 * T)
panels = [("(a) exact", U_ex, None)] + [
    (f"({'bcd'[k]}) {lab}", data[n]["U"], float(data[n]["err"])) for k, (n, lab) in enumerate(maps)]
for k, (title, U, err) in enumerate(panels):
    ax = fig.add_subplot(gs[0, k])
    im = ax.imshow(U.T, origin="lower", extent=[0, 1, 0, 2 * np.pi], aspect="auto",
                   cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_title(title)
    ax.set_xlabel("$t$")
    ax.set_yticks([0, np.pi, 2 * np.pi])
    ax.set_yticklabels(["0", r"$\pi$", r"$2\pi$"] if k == 0 else [])
    if k == 0:
        ax.set_ylabel("$x$")
    if err is not None:
        ax.text(0.96, 0.04, f"error {err:.2g}", transform=ax.transAxes, ha="right", fontsize=7,
                bbox=dict(fc="white", ec="none", alpha=0.85, pad=1))
fig.colorbar(im, ax=fig.axes[:4], ticks=[-1, 0, 1], fraction=0.015, pad=0.01)

ax = fig.add_subplot(gs[1, :])
for name, lab, c, ls in curves:
    U = data[name]["U"]
    e_t = np.linalg.norm(U - U_ex, axis=1) / np.linalg.norm(U_ex, axis=1)
    ax.semilogy(t, e_t, color=c, ls=ls, label=lab)
ax.set_xlabel("$t$")
ax.set_ylabel(r"relative $L^2$ error at $t$")
ax.set_title("(e) error versus time")
ax.set_ylim(1e-6, 5)
ax.legend(loc="lower center", ncol=3, fontsize=7)
print(savefig(fig, "ch11", "convection"))

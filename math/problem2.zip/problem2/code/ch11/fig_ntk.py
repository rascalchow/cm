"""Figure 11.2: empirical NTK of the convection PINN at initialization.
Requires results/ntk.npz from ntk_convection.py (computed automatically if missing)."""
import os
import subprocess
import sys

import matplotlib.pyplot as plt
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

path = os.path.join(HERE, "results", "ntk.npz")
if not os.path.exists(path):
    subprocess.run([sys.executable, os.path.join(HERE, "ntk_convection.py")], check=True)
d = np.load(path)
set_style()
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4))

e0 = d["eig_00"]
n = 30
ax1.semilogy(np.arange(1, n + 1), e0[:n], "s-", ms=3, color=COLORS["gray"],
             label=r"$\mathbf{K}_{00}$ (initial condition)")
styles = [("1", COLORS["blue"], "-"), ("10", COLORS["orange"], "--"), ("30", COLORS["red"], ":")]
for b, c, ls in styles:
    e = d[f"eig_rr_{b}"]
    ax1.semilogy(np.arange(1, n + 1), e[:n], marker="o", ms=2.5, color=c, ls=ls,
                 label=rf"$\mathbf{{K}}_{{rr}}$, $\beta={b}$")
ax1.set_xlim(0, n + 1)
ax1.set_ylim(1e-9, 5e3)
ax1.set_xlabel("eigenvalue index $i$")
ax1.set_ylabel(r"eigenvalue $\lambda_i$")
ax1.set_title("(a) spectra of the NTK blocks")
ax1.legend(loc="upper right")

betas = d["betas"]
R = np.array([d[f"ratio_{s}"] for s in range(5)])
m = betas > 0
ax2.fill_between(betas[m], R.min(0)[m], R.max(0)[m], color=COLORS["blue"], alpha=0.2, lw=0)
ax2.loglog(betas[m], np.exp(np.log(R).mean(0))[m], "o-", color=COLORS["blue"],
           label="5 random initializations")
bb = np.array([5.0, 100.0])
ax2.loglog(bb, 0.07 * bb ** 2, "k--", lw=1.0, label=r"slope $\beta^2$")
ax2.set_xlabel(r"convection speed $\beta$")
ax2.set_ylabel(r"$(\mathrm{tr}\,\mathbf{K}_{rr}/N_r)\,/\,(\mathrm{tr}\,\mathbf{K}_{00}/N_0)$")
ax2.set_title("(b) residual vs. initial-condition kernel")
ax2.legend(loc="upper left")
fig.tight_layout()
print(savefig(fig, "ch11", "ntk_spectrum"))

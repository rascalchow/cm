"""Empirical neural tangent kernel of the convection PINN at initialization (Section 11.2).

For r = u_t + beta u_x the residual Jacobian is J_r = J_t + beta J_x, so
    K_rr(beta) = K_tt + beta (K_tx + K_xt) + beta^2 K_xx,
and all blocks can be formed from J_t, J_x computed once.  Saves results/ntk.npz.
Run from the project root: python3 code/ch11/ntk_convection.py   (about 1 min)
"""
import math
import os

import numpy as np
import torch
from torch.func import functional_call, grad, jacrev, vmap

from convection_pinn import RESULTS, Net

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)
BETAS = np.array([0.0, 1.0, 2.0, 5.0, 10.0, 20.0, 30.0, 50.0, 100.0])


def jacobians(net, x, t):
    """Per-point Jacobians of u, u_x, u_t with respect to all parameters, shape (N, p)."""
    params = {k: v.detach() for k, v in net.named_parameters()}

    def u(p, xi, ti):
        return functional_call(net, p, (xi.reshape(1, 1), ti.reshape(1, 1))).squeeze()

    def u_x(p, xi, ti):
        return grad(u, argnums=1)(p, xi, ti)

    def u_t(p, xi, ti):
        return grad(u, argnums=2)(p, xi, ti)

    out = []
    for fun in (u, u_x, u_t):
        J = vmap(jacrev(fun), in_dims=(None, 0, 0))(params, x, t)
        out.append(torch.cat([J[k].reshape(len(x), -1) for k in params], dim=1))
    return out


def main():
    n_0, n_r = 128, 512
    res = {"betas": BETAS}
    for seed in range(5):
        torch.manual_seed(seed)
        net = Net().double()
        g = torch.Generator().manual_seed(100 + seed)
        x0 = torch.linspace(0, 2 * math.pi, n_0)
        xr, tr = 2 * math.pi * torch.rand(n_r, generator=g), torch.rand(n_r, generator=g)
        J0, _, _ = jacobians(net, x0, 0 * x0)
        _, Jx, Jt = jacobians(net, xr, tr)
        # blocks scaled by 1/N as they enter the gradient flow of a mean-squared loss
        K00 = (J0 @ J0.T).numpy() / n_0
        Kxx, Ktt, Ktx = ((A @ B.T).numpy() / n_r for A, B in ((Jx, Jx), (Jt, Jt), (Jt, Jx)))
        ratio = []
        for b in BETAS:
            Krr = Ktt + b * (Ktx + Ktx.T) + b ** 2 * Kxx
            ratio.append(np.trace(Krr) / np.trace(K00))
            if seed == 0:
                res[f"eig_rr_{b:g}"] = np.linalg.eigvalsh(Krr)[::-1]
        res[f"ratio_{seed}"] = np.array(ratio)
        if seed == 0:
            res["eig_00"] = np.linalg.eigvalsh(K00)[::-1]
            res["n_params"] = J0.shape[1]
        print(f"seed {seed}: (tr K_rr/N_r)/(tr K_00/N_0) =", " ".join(f"{r:.3g}" for r in ratio), flush=True)
    np.savez(os.path.join(RESULTS, "ntk.npz"), **res)


if __name__ == "__main__":
    main()

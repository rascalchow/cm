#!/usr/bin/env bash
# All convection experiments of Chapter 11 (run from the project root), then the figure.
# Each run takes roughly 3-15 minutes on two idle CPU threads (longer on a shared machine).
set -e
python3 code/ch11/convection_pinn.py vanilla 5
python3 code/ch11/convection_pinn.py vanilla 30
python3 code/ch11/convection_pinn.py curriculum 30
python3 code/ch11/convection_pinn.py ntk 30
N_ITER=20000 python3 code/ch11/convection_pinn.py causal 30
N_ITER=20000 N_LBFGS=2000 python3 code/ch11/convection_pinn.py marching 30
python3 code/ch11/fig_convection.py

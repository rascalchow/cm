"""E(n)-equivariant graph neural network layer (Satorras, Hoogeboom & Welling, 2021).

For particles with invariant features h_i and positions x_i in R^n on a fully
connected graph, one layer computes
    m_ij   = phi_e(h_i, h_j, |x_i - x_j|^2)
    x_i'   = x_i + C sum_{j != i} (x_i - x_j) phi_x(m_ij),   C = 1/(N-1)
    h_i'   = phi_h(h_i, sum_{j != i} m_ij)
The self-test checks numerically that a stack of layers is equivariant to
rotations/reflections, translations and permutations.  This file is the starting
point for Hands-on Assignment 12.2.
Run `python3 code/ch12/egnn.py`.
"""
import torch
import torch.nn as nn

torch.set_num_threads(2)


class EGNNLayer(nn.Module):
    def __init__(self, nf, hidden=64):
        super().__init__()
        self.phi_e = nn.Sequential(nn.Linear(2 * nf + 1, hidden), nn.SiLU(),
                                   nn.Linear(hidden, hidden), nn.SiLU())
        self.phi_x = nn.Sequential(nn.Linear(hidden, hidden), nn.SiLU(), nn.Linear(hidden, 1))
        self.phi_h = nn.Sequential(nn.Linear(nf + hidden, hidden), nn.SiLU(),
                                   nn.Linear(hidden, nf))

    def forward(self, h, x):
        # h: (B, N, nf) invariant features, x: (B, N, n) positions
        B, N, nf = h.shape
        diff = x[:, :, None, :] - x[:, None, :, :]            # x_i - x_j, (B, N, N, n)
        d2 = (diff ** 2).sum(-1, keepdim=True)                 # |x_i - x_j|^2 (invariant)
        hi = h[:, :, None, :].expand(B, N, N, nf)
        hj = h[:, None, :, :].expand(B, N, N, nf)
        m = self.phi_e(torch.cat([hi, hj, d2], dim=-1))        # messages m_ij
        mask = 1.0 - torch.eye(N, dtype=h.dtype)[None, :, :, None]   # exclude j = i
        m = m * mask
        x_new = x + (diff * self.phi_x(m) * mask).sum(2) / (N - 1)   # equivariant update
        h_new = h + self.phi_h(torch.cat([h, m.sum(2)], dim=-1))     # invariant update
        return h_new, x_new


class EGNN(nn.Module):
    def __init__(self, nf=16, n_layers=4, hidden=64):
        super().__init__()
        self.layers = nn.ModuleList([EGNNLayer(nf, hidden) for _ in range(n_layers)])

    def forward(self, h, x):
        for layer in self.layers:
            h, x = layer(h, x)
        return h, x


if __name__ == "__main__":
    torch.manual_seed(0)
    dt = torch.float64
    B, N, n, nf = 2, 5, 3, 16
    model = EGNN(nf).to(dt)
    h, x = torch.randn(B, N, nf, dtype=dt), torch.randn(B, N, n, dtype=dt)
    Q, _ = torch.linalg.qr(torch.randn(n, n, dtype=dt))      # random orthogonal matrix
    g = torch.randn(1, 1, n, dtype=dt)                        # random translation
    perm = torch.randperm(N)
    h1, x1 = model(h, x)
    h2, x2 = model(h[:, perm], x[:, perm] @ Q.T + g)          # transformed input
    print("det Q = %+.0f" % torch.det(Q).item())
    print("invariance of h   : %.1e" % (h2 - h1[:, perm]).abs().max().item())
    print("equivariance of x : %.1e" % (x2 - (x1[:, perm] @ Q.T + g)).abs().max().item())
    assert (h2 - h1[:, perm]).abs().max() < 1e-10
    assert (x2 - (x1[:, perm] @ Q.T + g)).abs().max() < 1e-10
    print("self-test passed")

"""Figure fig:12:hnn (figures/ch12/hnn_energy.pdf): baseline MLP vs Hamiltonian neural network on the pendulum.

Both models are trained on the same 775 noisy derivative samples (25 short orbits
with energies in [0.2, 1.2]) for 2000 full-batch Adam epochs, and both are rolled
out with the same accurate integrator (RK4, h = 0.05) from an unseen initial state,
so differences in long-time behavior come from the learned vector fields.
Run from the project root:  python3 code/ch12/fig_hnn_energy.py  (a few minutes)
"""
import os
import sys
import time

import numpy as np
import torch
import matplotlib.pyplot as plt

torch.set_num_threads(2)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from hnn import (make_data, train, MLPField, HNN, numpy_field, numpy_hamiltonian,  # noqa: E402
                 rk4, energy, pendulum_field)

Z, dZ = make_data()
models = {}
for name, M in [("MLP", MLPField), ("HNN", HNN)]:
    torch.manual_seed(0)                      # identical initialization for both models
    t0 = time.time()
    models[name] = M()
    loss = train(models[name], Z, dZ, epochs=2000)
    print("%s: final training loss %.3e (%.0f s)" % (name, loss, time.time() - t0))

# rollouts from an unseen initial condition (energy 0.8, inside the training range)
e0 = 0.8
z0 = np.array([np.arccos(1 - e0), 0.0])
h, T = 0.05, 200.0
n = int(T / h)
t = h * np.arange(n + 1)
traj = {"true": rk4(pendulum_field, z0, h, n)}
for name, m in models.items():
    traj[name] = rk4(numpy_field(m), z0, h, n)
for name, zz in traj.items():
    E = energy(zz)
    print("%-4s: energy at t=0, 50, 100, 200: %s;  max |E - E0| = %.3e" % (
        name, np.round(E[[0, 1000, 2000, 4000]], 4), np.abs(E - E[0]).max()))
Hl = numpy_hamiltonian(models["HNN"])(traj["HNN"])
print("HNN: learned H_theta along its own rollout varies by %.2e" % (Hl.max() - Hl.min()))

# vector-field error on a grid covering the training region
qq, pp = np.meshgrid(np.linspace(-2, 2, 41), np.linspace(-1.6, 1.6, 41))
G = np.stack([qq, pp], -1)
mask = (energy(G) >= 0.2) & (energy(G) <= 1.2)
for name, m in models.items():
    err = np.linalg.norm(numpy_field(m)(G) - pendulum_field(G), axis=-1)
    print("%s: RMS vector-field error on training energy band: %.3e" % (name, np.sqrt(np.mean(err[mask] ** 2))))

# ---------------------------------------------------------------- figure
set_style()
fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4),
                        gridspec_kw=dict(width_ratios=[1, 1.5], wspace=0.28))
ax = axs[0]
Zn = Z.numpy()
ax.plot(Zn[:, 0], Zn[:, 1], ".", ms=1.2, color="0.7", label="training states")
ax.plot(traj["MLP"][:, 0], traj["MLP"][:, 1], color=COLORS["orange"], lw=0.5, label="MLP")
ax.plot(traj["HNN"][:, 0], traj["HNN"][:, 1], color=COLORS["blue"], lw=2.2, label="HNN")
ax.plot(traj["true"][:, 0], traj["true"][:, 1], "k--", lw=0.8, label="true")
ax.set_xlabel("$q$")
ax.set_ylabel("$p$")
ax.set_title("(a) rollouts in phase space, $t\\in[0,200]$")
ax.set_aspect("equal")
ax.legend(loc="upper center", ncol=2, fontsize=7, bbox_to_anchor=(0.5, -0.22), handlelength=1.2)

ax = axs[1]
ax.plot(t, energy(traj["MLP"]), color=COLORS["orange"], label="MLP")
ax.plot(t, energy(traj["HNN"]), color=COLORS["blue"], label="HNN")
ax.plot(t, energy(traj["true"]), "k--", lw=0.8, label="true")
ax.set_xlabel("$t$")
ax.set_ylabel(r"energy $H(q(t),p(t))$")
ax.set_title("(b) true energy along the rollouts")
ax.legend(loc="best")
savefig(fig, "ch12", "hnn_energy")
print("saved figures/ch12/hnn_energy.pdf")

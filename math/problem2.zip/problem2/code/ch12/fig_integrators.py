"""Figure fig:12:integrators (figures/ch12/integrators.pdf): the integrator matters -- symplectic vs non-symplectic time stepping.

(a) True pendulum H = p^2/2 + 1 - cos q integrated with explicit Euler, RK4,
    symplectic Euler and Stormer-Verlet (leapfrog) at step h = 0.25 up to t = 5000.
(b) A separable HNN, H_theta = T_theta(p) + V_theta(q), trained on the same data as
    in fig_hnn_energy.py, rolled out with RK4 and with leapfrog at the same step.
We plot the running maximum of the energy error, max_{s <= t} |H(s) - H(0)|.
Run from the project root:  python3 code/ch12/fig_integrators.py  (a few minutes)
"""
import os
import sys
import time

import numpy as np
import torch
import matplotlib.pyplot as plt

torch.set_num_threads(2)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from hnn import (make_data, train, SeparableHNN, separable_parts, numpy_hamiltonian,  # noqa: E402
                 euler, rk4, symplectic_euler, leapfrog, energy, pendulum_field)

e0 = 0.8
z0 = np.array([np.arccos(1 - e0), 0.0])
h, T = 0.25, 5000.0
n = int(T / h)
t = h * np.arange(n + 1)


def running_max_error(H):
    return np.maximum.accumulate(np.abs(H - H[0]))


# ---------------------------------------------------------------- (a) exact Hamiltonian
dT_true, dV_true = (lambda p: p), (lambda q: np.sin(q))
true_runs = {
    "explicit Euler": euler(pendulum_field, z0, h, n),
    "RK4": rk4(pendulum_field, z0, h, n),
    "symplectic Euler": symplectic_euler(dT_true, dV_true, z0, h, n),
    "Stormer-Verlet": leapfrog(dT_true, dV_true, z0, h, n),
}
err_a = {k: running_max_error(energy(v)) for k, v in true_runs.items()}
for k, e in err_a.items():
    print("(a) %-16s max|dH| up to t=10: %.2e, t=100: %.2e, t=5000: %.2e"
          % (k, e[int(10 / h)], e[int(100 / h)], e[-1]))

# ---------------------------------------------------------------- (b) learned separable HNN
Z, dZ = make_data()
torch.manual_seed(0)
model = SeparableHNN()
t0 = time.time()
loss = train(model, Z, dZ, epochs=2000)
print("separable HNN: final training loss %.3e (%.0f s)" % (loss, time.time() - t0))
dT, dV = separable_parts(model)
H_theta = numpy_hamiltonian(model)
f_theta = lambda z: np.array([dT(z[1]), -dV(z[0])])   # noqa: E731
learned_runs = {"RK4": rk4(f_theta, z0, h, n), "Stormer-Verlet": leapfrog(dT, dV, z0, h, n)}
err_b, err_b_true = {}, {}
for k, v in learned_runs.items():
    err_b[k] = running_max_error(H_theta(v))
    err_b_true[k] = running_max_error(energy(v))
    print("(b) %-15s learned-H error at t=100: %.2e, t=5000: %.2e;  true-H error at t=5000: %.2e"
          % (k, err_b[k][int(100 / h)], err_b[k][-1], err_b_true[k][-1]))

# ---------------------------------------------------------------- figure
set_style()
cols = {"explicit Euler": COLORS["red"], "RK4": COLORS["orange"],
        "symplectic Euler": COLORS["green"], "Stormer-Verlet": COLORS["blue"]}
lab = {"Stormer-Verlet": r"St$\mathrm{\"o}$rmer-Verlet"}
fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4), sharey=True,
                        gridspec_kw=dict(wspace=0.08))
ax = axs[0]
for k, e in err_a.items():
    ax.loglog(t[1:], e[1:], color=cols[k], label=lab.get(k, k))
ax.set_xlabel("$t$")
ax.set_ylabel(r"$\max_{s\leq t}\,|H(s)-H(0)|$")
ax.set_title("(a) exact pendulum Hamiltonian, $h=0.25$")
ax.legend(loc="upper left", fontsize=7)
ax.set_ylim(1e-6, 1e4)
ax = axs[1]
for k in learned_runs:
    ax.loglog(t[1:], err_b[k][1:], color=cols[k], label=lab.get(k, k) + r", $H_\theta$")
    ax.loglog(t[1:], err_b_true[k][1:], "--", color=cols[k], lw=1.0, label=lab.get(k, k) + r", true $H$")
ax.set_xlabel("$t$")
ax.set_title(r"(b) learned separable HNN, $h=0.25$")
ax.legend(loc="upper left", fontsize=7)
savefig(fig, "ch12", "integrators")
print("saved figures/ch12/integrators.pdf")

"""Hamiltonian neural networks and integrators for Chapter 12 (PyTorch + NumPy).

Pendulum with H(q, p) = p^2/2 + (1 - cos q) (unit mass, length, gravity).
Models map a state z = (q, p) to a vector field dz/dt:
    MLPField      baseline: unconstrained network for (dq/dt, dp/dt)
    HNN           scalar H_theta(q, p); vector field J grad H_theta
    SeparableHNN  H_theta = T_theta(p) + V_theta(q) (admits explicit leapfrog)
Training uses PyTorch (float32).  For long rollouts the trained weights are copied
to NumPy (float64) and H, grad H are evaluated by a hand-written backward pass,
which is checked against autograd in the self-test.
Run `python3 code/ch12/hnn.py` for the self-test.
"""
import os
import sys

import numpy as np
import torch
import torch.nn as nn

torch.set_num_threads(2)
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import pendulum  # noqa: E402


def energy(z):
    """True pendulum energy for an array of states (..., 2)."""
    return 0.5 * z[..., 1] ** 2 + 1.0 - np.cos(z[..., 0])


def pendulum_field(z):
    return np.stack([z[..., 1], -np.sin(z[..., 0])], axis=-1)


def mlp(n_in, n_out, width=64):
    return nn.Sequential(nn.Linear(n_in, width), nn.Tanh(), nn.Linear(width, width), nn.Tanh(),
                         nn.Linear(width, n_out))


class MLPField(nn.Module):
    def __init__(self, width=64):
        super().__init__()
        self.net = mlp(2, 2, width)

    def forward(self, z):
        return self.net(z)


class HNN(nn.Module):
    """dz/dt = J grad H_theta(z),  J = [[0, 1], [-1, 0]]."""
    def __init__(self, width=64):
        super().__init__()
        self.H = mlp(2, 1, width)

    def forward(self, z):
        with torch.enable_grad():
            if not z.requires_grad:
                z = z.detach().requires_grad_(True)
            dH = torch.autograd.grad(self.H(z).sum(), z, create_graph=self.training)[0]
        return torch.stack([dH[:, 1], -dH[:, 0]], dim=1)   # (dH/dp, -dH/dq)


class SeparableHNN(nn.Module):
    """H_theta(q, p) = T_theta(p) + V_theta(q)."""
    def __init__(self, width=64):
        super().__init__()
        self.T, self.V = mlp(1, 1, width), mlp(1, 1, width)

    def forward(self, z):
        with torch.enable_grad():
            if not z.requires_grad:
                z = z.detach().requires_grad_(True)
            H = (self.T(z[:, 1:2]) + self.V(z[:, 0:1])).sum()
            dH = torch.autograd.grad(H, z, create_graph=self.training)[0]
        return torch.stack([dH[:, 1], -dH[:, 0]], dim=1)


# ---------------------------------------------------------------- data and training
def make_data(n_traj=25, t_max=3.0, dt=0.1, e_range=(0.2, 1.2), noise=0.05, seed=0):
    """States along pendulum orbits with energies in e_range (released from rest at
    a random phase of the orbit); targets are exact derivatives + Gaussian noise."""
    rng = np.random.default_rng(seed)
    t = np.arange(0.0, t_max + 1e-12, dt)
    Z = []
    for _ in range(n_traj):
        e = rng.uniform(*e_range)
        q_max = np.arccos(1.0 - e)                         # turning point of the orbit
        orbit = pendulum(x0=(q_max, 0.0), t_eval=np.linspace(0, 20, 2001))
        z0 = orbit[rng.integers(0, 2001)]                  # random point on the orbit
        Z.append(pendulum(x0=z0, t_eval=t))
    Z = np.concatenate(Z)
    dZ = pendulum_field(Z) + noise * rng.standard_normal(Z.shape)
    return torch.tensor(Z, dtype=torch.float32), torch.tensor(dZ, dtype=torch.float32)


def train(model, Z, dZ, epochs=2000, lr=2e-3):
    """Full-batch Adam with cosine decay on the derivative-matching loss."""
    model.train()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    for _ in range(epochs):
        opt.zero_grad()
        loss = ((model(Z) - dZ) ** 2).mean()          # derivative matching
        loss.backward()
        opt.step()
        sched.step()
    model.eval()
    return loss.item()


# ---------------------------------------------------------------- NumPy evaluation (float64)
def weights(net):
    """[(W, b), ...] of an nn.Sequential of Linear/Tanh layers, as float64 arrays."""
    return [(m.weight.detach().double().numpy(), m.bias.detach().double().numpy())
            for m in net if isinstance(m, nn.Linear)]


def np_forward(Wb, x):
    h = x
    for W, b in Wb[:-1]:
        h = np.tanh(h @ W.T + b)
    W, b = Wb[-1]
    return h @ W.T + b


def np_grad(Wb, x):
    """Gradient of a scalar-output tanh MLP w.r.t. its input (manual backprop)."""
    hs, h = [], x
    for W, b in Wb[:-1]:
        h = np.tanh(h @ W.T + b)
        hs.append(h)
    g = np.broadcast_to(Wb[-1][0][0], h.shape)          # d(output)/d(last hidden layer)
    for (W, _), h in zip(Wb[-2::-1], hs[::-1]):
        g = (g * (1.0 - h ** 2)) @ W
    return g


def numpy_field(model):
    """Vector field z -> dz/dt in float64 NumPy, for arrays of shape (..., 2)."""
    if isinstance(model, MLPField):
        Wb = weights(model.net)
        return lambda z: np_forward(Wb, z)
    if isinstance(model, HNN):
        Wb = weights(model.H)

        def f(z):
            g = np_grad(Wb, z)
            return np.stack([g[..., 1], -g[..., 0]], axis=-1)
        return f
    raise TypeError("use separable_parts() for SeparableHNN")


def numpy_hamiltonian(model):
    if isinstance(model, HNN):
        Wb = weights(model.H)
        return lambda z: np_forward(Wb, z)[..., 0]
    WT, WV = weights(model.T), weights(model.V)
    return lambda z: (np_forward(WT, z[..., 1:2]) + np_forward(WV, z[..., 0:1]))[..., 0]


def separable_parts(model):
    """Scalar functions T'(p) and V'(q) of a trained SeparableHNN (float64)."""
    WT, WV = weights(model.T), weights(model.V)
    dT = lambda p: np_grad(WT, np.array([[p]]))[0, 0]   # noqa: E731
    dV = lambda q: np_grad(WV, np.array([[q]]))[0, 0]   # noqa: E731
    return dT, dV


# ---------------------------------------------------------------- integrators (state z = (q, p))
def euler(f, z0, h, n):
    z = np.empty((n + 1, 2)); z[0] = z0
    for k in range(n):
        z[k + 1] = z[k] + h * f(z[k])
    return z


def rk4(f, z0, h, n):
    z = np.empty((n + 1, 2)); z[0] = z0
    for k in range(n):
        y = z[k]
        k1 = f(y); k2 = f(y + 0.5 * h * k1); k3 = f(y + 0.5 * h * k2); k4 = f(y + h * k3)
        z[k + 1] = y + h / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
    return z


def symplectic_euler(dT, dV, z0, h, n):
    """p_{k+1} = p_k - h V'(q_k);  q_{k+1} = q_k + h T'(p_{k+1})."""
    z = np.empty((n + 1, 2)); z[0] = z0
    q, p = z0
    for k in range(n):
        p = p - h * dV(q)
        q = q + h * dT(p)
        z[k + 1] = (q, p)
    return z


def leapfrog(dT, dV, z0, h, n):
    """Stormer-Verlet: half kick, drift, half kick (symmetric and symplectic)."""
    z = np.empty((n + 1, 2)); z[0] = z0
    q, p = z0
    for k in range(n):
        p = p - 0.5 * h * dV(q)
        q = q + h * dT(p)
        p = p - 0.5 * h * dV(q)
        z[k + 1] = (q, p)
    return z


if __name__ == "__main__":
    torch.manual_seed(0)
    Z, dZ = make_data()
    print("training points:", Z.shape[0], " energy range: [%.2f, %.2f]"
          % (energy(Z.numpy()).min(), energy(Z.numpy()).max()))
    zt = torch.randn(5, 2, dtype=torch.float32)
    for M in (MLPField, HNN, SeparableHNN):
        m = M()
        print(M.__name__, "loss after 50 epochs %.3e" % train(m, Z, dZ, epochs=50))
        ref = m(zt).detach().double().numpy()
        if isinstance(m, SeparableHNN):
            dT, dV = separable_parts(m)
            mine = np.array([[dT(p), -dV(q)] for q, p in zt.double().numpy()])
        else:
            mine = numpy_field(m)(zt.double().numpy())
        print("   max |numpy - torch| field difference: %.1e" % np.abs(mine - ref).max())
        assert np.abs(mine - ref).max() < 1e-5
    print("self-test passed")

"""Unstacked DeepONet (Lu et al., 2021) for a 1D periodic problem.

Chapter 13, Listing "DeepONet".  The branch net sees the input function a
only through its values at m fixed sensors; the trunk net takes an output
location y in [0, 1) (encoded periodically) and returns p basis functions.
    G_theta(a)(y) = sum_k b_k(a(x_1), ..., a(x_m)) t_k(y) + b_0.

Run `python3 code/ch13/deeponet.py` for a shape/periodicity self-test.
"""
import math

import torch
import torch.nn as nn

torch.set_num_threads(2)


def mlp(sizes, act=nn.GELU):
    layers = []
    for i in range(len(sizes) - 1):
        layers.append(nn.Linear(sizes[i], sizes[i + 1]))
        if i < len(sizes) - 2:
            layers.append(act())
    return nn.Sequential(*layers)


class DeepONet(nn.Module):
    def __init__(self, m=128, p=128, width=128, depth=3, n_harmonics=4):
        super().__init__()
        self.n_harm = n_harmonics
        self.branch = mlp([m] + [width] * depth + [p])          # a(x_1..x_m) -> b
        self.trunk = mlp([2 * n_harmonics] + [width] * depth + [p])  # y -> t
        self.b0 = nn.Parameter(torch.zeros(1))

    def trunk_features(self, y):
        # periodic encoding: cos/sin(2 pi j y), j = 1..n_harmonics -> exact periodicity
        j = torch.arange(1, self.n_harm + 1, dtype=y.dtype, device=y.device)
        arg = 2 * math.pi * y[:, None] * j[None, :]
        return torch.cat([torch.cos(arg), torch.sin(arg)], dim=-1)

    def forward(self, a_sensors, y):
        """a_sensors: (batch, m) input values at the sensors; y: (n_out,) query points.
        Returns (batch, n_out): the predicted output function at every query point."""
        b = self.branch(a_sensors)                  # (batch, p) coefficients
        t = self.trunk(self.trunk_features(y))      # (n_out, p) basis functions
        return b @ t.T + self.b0                    # (batch, n_out)


def _self_test():
    torch.manual_seed(0)
    net = DeepONet(m=16, p=8, width=32)
    a = torch.randn(5, 16)
    y = torch.linspace(0, 1, 11)
    with torch.no_grad():
        out = net(a, y)
    print("output shape:", tuple(out.shape))
    print("periodicity |G(a)(0) - G(a)(1)|: %.2e" % (out[:, 0] - out[:, -1]).abs().max())
    assert out.shape == (5, 11)
    assert torch.allclose(out[:, 0], out[:, -1], atol=1e-5)
    print("parameters:", sum(p.numel() for p in net.parameters()))


if __name__ == "__main__":
    _self_test()

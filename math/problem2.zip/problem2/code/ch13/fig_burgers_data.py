"""Figure 13.1: the Burgers operator-learning data set (nu = 0.01).

(a) zero-mean samples u0 ~ mu_0 = N(0, 625 (-Laplacian + 25 I)^(-2)), constant mode removed,
(b) the corresponding solutions u(., T = 1) of Burgers' equation with nu = 0.01,
(c) average Fourier energy spectra of inputs and outputs (training set).
Usage: python3 code/ch13/fig_burgers_data.py  -> figures/ch13/burgers_data.pdf
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from ch13_data import NX_FULL, load_burgers  # noqa: E402
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402

set_style()
import matplotlib.pyplot as plt  # noqa: E402

d = load_burgers()
x = np.arange(NX_FULL) / NX_FULL
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.05))
cols = [COLORS["blue"], COLORS["orange"], COLORS["green"]]
for i, c in zip(range(3), cols):
    axs[0].plot(x, d["u0_train"][i], color=c, lw=1.1)
    axs[1].plot(x, d["uT_train"][i], color=c, lw=1.1)
axs[0].set_title(r"(a) inputs $u_0$ (zero mean)")
axs[1].set_title(r"(b) outputs $u(\cdot,1)=\mathcal{G}(u_0)$")
for ax in axs[:2]:
    ax.set_xlabel("$x$")
    ax.set_xlim(0, 1)
axs[1].set_ylim(axs[0].get_ylim())

k = np.arange(NX_FULL // 2)
for key, lab, c in (("u0_train", "inputs $u_0$", COLORS["gray"]),
                    ("uT_train", r"outputs $u(\cdot,1)$", COLORS["red"])):
    E = (np.abs(np.fft.rfft(d[key], axis=1) / NX_FULL) ** 2).mean(0)[:NX_FULL // 2]
    axs[2].semilogy(k[1:], E[1:], color=c, label=lab)
axs[2].axvline(16, color=COLORS["blue"], ls=":", lw=1)
axs[2].text(17, 1e-3, r"$k_{\max}=16$", color=COLORS["blue"], fontsize=7)
axs[2].set_xlim(0, 128)
axs[2].set_ylim(1e-16, 1)   # float32 storage limits the floor to ~1e-18
axs[2].set_xlabel("wavenumber $k$")
axs[2].set_title(r"(c) mean energy $\mathbb{E}|\hat u_k|^2$")
axs[2].legend(loc="upper right", fontsize=7)
fig.tight_layout(w_pad=0.8)
print(savefig(fig, "ch13", "burgers_data"))

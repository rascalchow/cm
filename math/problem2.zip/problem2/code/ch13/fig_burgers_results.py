"""Figure 13.2: learned Burgers operators (nu = 0.01) and their resolution behaviour.

Requires the trained models of train_burgers.py (code/ch13/cache/*.pt, results_*.json).
(a) the test input with median DeepONet error: true output and both predictions,
(b) distribution of per-sample relative errors (DeepONet, FNO, linear PCA regression),
(c) mean test error versus evaluation resolution (models trained at n = 256), and the
    error of the classical solver run on coarse grids.
Usage: python3 code/ch13/fig_burgers_results.py  -> figures/ch13/burgers_results.pdf
"""
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from ch13_data import load_burgers, rel_l2  # noqa: E402
from deeponet import DeepONet  # noqa: E402
from fno1d import FNO1d  # noqa: E402
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from train_burgers import (CACHE, M_SENSORS, N_TRAIN_RES, RESOLUTIONS,  # noqa: E402
                           pca_linear, predict_don, predict_fno, sub)

torch.set_num_threads(1)
set_style()
import matplotlib.pyplot as plt  # noqa: E402

d = load_burgers()
res = {m: json.load(open(os.path.join(CACHE, "results_%s.json" % m)))
       for m in ("fno", "deeponet", "baselines")}
fno = FNO1d(modes=res["fno"]["modes"], width=res["fno"]["width"], n_layers=res["fno"]["layers"])
fno.load_state_dict(torch.load(os.path.join(CACHE, "fno.pt")))
don = DeepONet(m=M_SENSORS, p=128, width=128, depth=3)
don.load_state_dict(torch.load(os.path.join(CACHE, "deeponet.pt")))
fno.eval()
don.eval()

n = N_TRAIN_RES
a_te, u_te = sub(d["u0_test"], n), sub(d["uT_test"], n)
p_fno, p_don = predict_fno(fno, a_te), predict_don(don, a_te, n)
p_lin = pca_linear(sub(d["u0_train"], n), sub(d["uT_train"], n), a_te,
                   res["baselines"]["pca_rank"])
e_fno, e_don, e_lin = rel_l2(p_fno, u_te), rel_l2(p_don, u_te), rel_l2(p_lin, u_te)
print("mean errors at n=256: FNO %.4f  DeepONet %.4f  PCA-linear %.4f"
      % (e_fno.mean(), e_don.mean(), e_lin.mean()))
print("95th percentiles:     FNO %.4f  DeepONet %.4f  PCA-linear %.4f"
      % tuple(np.percentile(e, 95) for e in (e_fno, e_don, e_lin)))

fig = plt.figure(figsize=(FULL_WIDTH, 2.45))
gs = fig.add_gridspec(2, 3, width_ratios=[1.2, 1, 1], height_ratios=[1.7, 1], hspace=0.08)
ax_a, ax_e = fig.add_subplot(gs[0, 0]), fig.add_subplot(gs[1, 0])
ax_b, ax_c = fig.add_subplot(gs[:, 1]), fig.add_subplot(gs[:, 2])
# (a) test sample with median DeepONet error, and pointwise errors below
i = int(np.argsort(e_don)[len(e_don) // 2])
x = np.arange(n) / n
ax_a.plot(x, u_te[i], color="k", lw=1.6, label=r"truth $u(\cdot,1)$")
ax_a.plot(x, p_don[i], color=COLORS["orange"], lw=1.1, ls="--", label="DeepONet")
ax_a.plot(x, p_fno[i], color=COLORS["blue"], lw=1.1, ls=":", label="FNO")
ax_a.set_xlim(0, 1)
ax_a.set_xticklabels([])
ax_a.set_title("(a) test sample (median DeepONet error)")
ax_a.legend(fontsize=6.5, loc="upper right", handlelength=1.8)
ax_e.semilogy(x, np.abs(p_don[i] - u_te[i]), color=COLORS["orange"], lw=0.9)
ax_e.semilogy(x, np.abs(p_fno[i] - u_te[i]), color=COLORS["blue"], lw=0.9)
ax_e.set_xlim(0, 1)
ax_e.set_ylim(1e-6, 1e-1)
ax_e.set_yticks([1e-5, 1e-3, 1e-1])
ax_e.set_xlabel("$x$")
ax_e.set_ylabel("|error|", fontsize=7)
# (b) error distributions (empirical CDF)
ax = ax_b
for e, lab, c in ((e_lin, "linear PCA", COLORS["green"]), (e_don, "DeepONet", COLORS["orange"]),
                  (e_fno, "FNO", COLORS["blue"])):
    ax.step(np.sort(e), np.arange(1, len(e) + 1) / len(e), where="post", color=c, label=lab)
ax.set_xscale("log")
ax.set_xlabel("relative $L^2$ error")
ax.set_ylabel("fraction of test inputs")
ax.set_title("(b) error distribution")
ax.legend(fontsize=6.5, loc="lower right")
# (c) zero-shot resolution transfer + classical solver on coarse grids
ax = ax_c
R = np.array(RESOLUTIONS)
for m, lab, c, mk in (("deeponet", "DeepONet", COLORS["orange"], "s"),
                      ("fno", "FNO", COLORS["blue"], "o")):
    ev = [res[m]["err_mean"][str(r)] for r in R]
    ax.loglog(R, ev, color=c, marker=mk)
    ax.text(R[-1], ev[-1] * 1.35, lab, color=c, fontsize=7, ha="right", va="bottom")
# classical solver on an r-point grid with dt = 0.02, Fourier-interpolated to n = 256 and
# scored there (computed by train_burgers.py, as in Table 13.1)
cs = res["baselines"]["coarse_solver"]
solver_n = np.array([32, 64, 128, 256])
solver_e = [cs["%d_0.02" % r]["err_mean"] for r in solver_n]
ax.loglog(solver_n, solver_e, color=COLORS["gray"], marker="^", ls="--")
ax.text(34, 1.1e-4, "spectral\nsolver", color=COLORS["gray"], fontsize=7, va="bottom")
ax.axvline(N_TRAIN_RES, color=COLORS["gray"], lw=0.8, ls=":")
ax.text(N_TRAIN_RES * 1.08, 0.97, "training\nresolution", transform=ax.get_xaxis_transform(),
        fontsize=6.5, va="top", color=COLORS["gray"])
ax.set_xticks([32, 64, 128, 256, 512, 1024])
ax.set_xticklabels(["32", "64", "128", "256", "512", "1024"])
ax.minorticks_off()
ax.set_ylim(5e-5, 3e-1)
ax.set_xlabel("grid points $n$")
ax.set_ylabel("mean relative $L^2$ error")
ax.set_title("(c) evaluation resolution")
fig.subplots_adjust(left=0.07, right=0.99, bottom=0.17, top=0.9, wspace=0.42)
print("solver errors (interpolated to n = 256):", dict(zip(solver_n.tolist(), np.round(solver_e, 7))))
print(savefig(fig, "ch13", "burgers_results"))

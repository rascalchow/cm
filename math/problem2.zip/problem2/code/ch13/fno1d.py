"""Fourier neural operator (FNO) in one space dimension (Li et al., 2021).

Chapter 13, Listing "spectral convolution".  The model maps a function a(x)
sampled on a uniform periodic grid of ANY size n to a function u(x) on the
same grid: input shape (batch, n), output shape (batch, n).

Run `python3 code/ch13/fno1d.py` for a self-test that checks
  (i)  the spectral convolution equals a circular convolution with the
       kernel whose Fourier coefficients are the learned weights, and
  (ii) the model runs at several resolutions with the same weights.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(2)


class SpectralConv1d(nn.Module):
    """Kernel integral (K v)(x) = F^{-1}[ R(k) (F v)(k) ](x), |k| < modes."""

    def __init__(self, c_in, c_out, modes):
        super().__init__()
        self.modes = modes                      # number of retained Fourier modes
        scale = 1.0 / (c_in * c_out)
        # one complex c_in x c_out matrix R(k) per retained wavenumber k
        self.R = nn.Parameter(scale * torch.randn(c_in, c_out, modes,
                                                  dtype=torch.cfloat))

    def forward(self, v):                       # v: (batch, c_in, n)
        n = v.shape[-1]
        v_hat = torch.fft.rfft(v, norm="forward")   # Fourier coefficients
        out_hat = torch.zeros(v.shape[0], self.R.shape[1], n // 2 + 1,
                              dtype=v_hat.dtype, device=v.device)
        m = min(self.modes, n // 2 + 1)         # cannot keep more modes than grid has
        out_hat[:, :, :m] = torch.einsum("bik,iok->bok",
                                         v_hat[:, :, :m], self.R[:, :, :m])
        return torch.fft.irfft(out_hat, n=n, norm="forward")


class FNO1d(nn.Module):
    """Lifting P -> L Fourier layers -> projection Q (all acting pointwise in x)."""

    def __init__(self, modes=16, width=64, n_layers=4):
        super().__init__()
        self.P = nn.Linear(2, width)            # input channels: a(x) and x
        self.spectral = nn.ModuleList(
            [SpectralConv1d(width, width, modes) for _ in range(n_layers)])
        self.W = nn.ModuleList(
            [nn.Conv1d(width, width, 1) for _ in range(n_layers)])  # local term
        self.Q = nn.Sequential(nn.Linear(width, 128), nn.GELU(), nn.Linear(128, 1))

    def forward(self, a):                       # a: (batch, n) on grid x_j = j/n
        n = a.shape[-1]
        x = torch.arange(n, dtype=a.dtype, device=a.device) / n
        v = self.P(torch.stack([a, x.expand_as(a)], dim=-1))  # (batch, n, width)
        v = v.permute(0, 2, 1)                  # (batch, width, n)
        for l, (K, W) in enumerate(zip(self.spectral, self.W)):
            v = K(v) + W(v)                     # nonlocal + local linear parts
            if l < len(self.spectral) - 1:
                v = F.gelu(v)                   # pointwise nonlinearity
        return self.Q(v.permute(0, 2, 1)).squeeze(-1)


def _self_test():
    torch.manual_seed(0)
    # (i) spectral convolution == circular convolution with a band-limited kernel
    layer = SpectralConv1d(1, 1, modes=5).double()
    layer.R.data = layer.R.data.to(torch.cdouble)
    n = 32
    v = torch.randn(1, 1, n, dtype=torch.double)
    with torch.no_grad():
        y = layer(v)[0, 0]
    # build the kernel kappa on the grid: kappa_hat(k) = R(k) for k < modes,
    # conjugate-symmetric extension for negative k (irfft drops Im of R(0))
    kap_hat = torch.zeros(n, dtype=torch.cdouble)
    R = layer.R.data[0, 0]
    kap_hat[0] = R[0].real
    for k in range(1, 5):
        kap_hat[k] = R[k]
        kap_hat[-k] = R[k].conj()
    kappa = torch.fft.ifft(kap_hat).real          # (1/n) sum_k kappa_hat e^{ikx}
    conv = torch.stack([sum(kappa[(i - j) % n] * v[0, 0, j] for j in range(n))
                        for i in range(n)])
    print("spectral conv vs circular conv, max diff: %.2e" % (y - conv).abs().max())
    assert torch.allclose(y, conv, atol=1e-12)
    # (ii) one set of weights, several resolutions
    model = FNO1d(modes=8, width=16)
    for n in (32, 64, 256):
        a = torch.sin(2 * math.pi * torch.arange(n) / n).unsqueeze(0)
        with torch.no_grad():
            print("n = %4d -> output shape %s" % (n, tuple(model(a).shape)))
    print("parameters:", sum(p.numel() for p in model.parameters()))


if __name__ == "__main__":
    _self_test()

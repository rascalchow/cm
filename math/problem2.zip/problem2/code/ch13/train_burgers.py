"""Train a DeepONet and an FNO on the 1D Burgers operator u0 -> u(., T=1), nu = 0.01.

Chapter 13, Section "A computed comparison on Burgers' equation" and Table 13.1.
  * 1000 training pairs at resolution n = 256, 200 test pairs (stored at 1024 points),
    Galilean-reduced to zero mean (see ch13_data.py; --raw-mean disables this)
  * relative L2 training loss, Adam with step decay
  * zero-shot evaluation of the trained models at n = 64, 128, 256, 512, 1024
  * baselines: conserved mean, heat propagator, linear PCA regression, and the
    spectral solver on coarse grids; wall-clock timings
Outputs (all in code/ch13/cache/): fno.pt, deeponet.pt, results_fno.json,
results_deeponet.json, results_baselines.json (suffix _raw with --raw-mean, _nu<nu>
for other viscosities).
Runtime on one CPU thread: about 10 min (FNO), 6 min (DeepONet), 1 min (baselines).
Usage: python3 code/ch13/train_burgers.py [--only fno|don|base|all] [--threads 1]
       [--raw-mean] [--nu 0.01]       (the two models can train in two processes)
The text of Chapter 13 used: --only fno/don/base --threads 1, plus --raw-mean for the
raw-data DeepONet and baselines, and --only base --nu 0.1 --raw-mean for the nu = 0.1
baselines.
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ch13_data import NU, NX_FULL, T_FINAL, burgers_batch, load_burgers, rel_l2  # noqa: E402
from deeponet import DeepONet  # noqa: E402
from fno1d import FNO1d  # noqa: E402

torch.set_num_threads(2)
CACHE = os.path.join(HERE, "cache")
N_TRAIN_RES = 256                     # training resolution
M_SENSORS = 128                       # DeepONet sensors x_j = j / 128
RESOLUTIONS = [64, 128, 256, 512, 1024]


def sub(u, n):
    """Restrict fields stored at NX_FULL points to the uniform n-point grid."""
    return u[:, ::NX_FULL // n]


def to_sensors(a, m=M_SENSORS):
    """Periodic linear interpolation of grid values a (batch, n) to the m sensors.
    Exact (pure subsampling) whenever the sensors are grid points."""
    n = a.shape[1]
    x, xs = np.arange(n) / n, np.arange(m) / m
    return np.stack([np.interp(xs, x, ai, period=1.0) for ai in a])


def rel_l2_loss(pred, true):
    return (torch.norm(pred - true, dim=1) / torch.norm(true, dim=1)).mean()


def t32(x):
    return torch.tensor(x, dtype=torch.float32)


# ------------------------------------------------------------------ predictors
def predict_fno(model, a):
    with torch.no_grad():
        return np.concatenate([model(t32(a[i:i + 50])).numpy() for i in range(0, len(a), 50)])


def predict_don(model, a, n_out):
    y = t32(np.arange(n_out) / n_out)
    with torch.no_grad():
        return model(t32(to_sensors(a)), y).numpy()


# ------------------------------------------------------------------ training
def train(model, step_fn, n_train, epochs, batch, lr, eval_fn, eval_every):
    opt = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.StepLR(opt, step_size=max(1, epochs // 5), gamma=0.5)
    hist = {"epoch": [], "train": [], "test": []}
    t0 = time.time()
    for ep in range(1, epochs + 1):
        perm = torch.randperm(n_train)
        tot = 0.0
        for i in range(0, n_train, batch):
            loss = step_fn(perm[i:i + batch])
            opt.zero_grad()
            loss.backward()
            opt.step()
            tot += loss.item() * len(perm[i:i + batch])
        sched.step()
        if ep % eval_every == 0 or ep == 1:
            hist["epoch"].append(ep)
            hist["train"].append(tot / n_train)
            hist["test"].append(eval_fn())
            print("  epoch %4d  train %.4f  test %.4f  (%.0f s)"
                  % (ep, hist["train"][-1], hist["test"][-1], time.time() - t0), flush=True)
    return hist, time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fno-epochs", type=int, default=100)
    ap.add_argument("--fno-width", type=int, default=32)
    ap.add_argument("--don-epochs", type=int, default=400)
    ap.add_argument("--only", choices=["fno", "don", "base", "all"], default="all")
    ap.add_argument("--threads", type=int, default=2)
    ap.add_argument("--nu", type=float, default=NU)
    ap.add_argument("--raw-mean", action="store_true",
                    help="train on the raw pairs instead of the Galilean-reduced ones")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)   # on a heavily shared machine 1 thread was faster
    os.makedirs(CACHE, exist_ok=True)

    suffix = ("" if args.nu == NU else "_nu%g" % args.nu) + ("_raw" if args.raw_mean else "")

    def save(name, obj):
        json.dump(obj, open(os.path.join(CACHE, "results_%s%s.json" % (name, suffix)), "w"),
                  indent=1)

    d = load_burgers(args.nu, reduced=not args.raw_mean)
    a_tr, u_tr = sub(d["u0_train"], N_TRAIN_RES), sub(d["uT_train"], N_TRAIN_RES)
    a_te, u_te = sub(d["u0_test"], N_TRAIN_RES), sub(d["uT_test"], N_TRAIN_RES)
    A, U = t32(a_tr), t32(u_tr)
    n = len(a_tr)

    # ---------------------------------------------------------------- FNO
    if args.only in ("fno", "all"):
        torch.manual_seed(0)
        fno = FNO1d(modes=16, width=args.fno_width, n_layers=4)
        print("FNO parameters:", sum(p.numel() for p in fno.parameters()))
        hist, ttrain = train(
            fno, lambda idx: rel_l2_loss(fno(A[idx]), U[idx]), n, args.fno_epochs,
            batch=20, lr=1e-3, eval_every=10,
            eval_fn=lambda: float(rel_l2(predict_fno(fno, a_te), u_te).mean()))
        torch.save(fno.state_dict(), os.path.join(CACHE, "fno%s.pt" % suffix))
        errs = {r: rel_l2(predict_fno(fno, sub(d["u0_test"], r)), sub(d["uT_test"], r))
                for r in RESOLUTIONS}
        t0 = time.time()
        predict_fno(fno, sub(d["u0_test"], 256))
        t_inf = (time.time() - t0) / len(a_te)
        save("fno", {
            "params": sum(p.numel() for p in fno.parameters()), "epochs": args.fno_epochs,
            "width": args.fno_width, "modes": 16, "layers": 4, "threads": args.threads,
            "train_time_s": ttrain, "history": hist, "infer_s_per_sample_256": t_inf,
            "err_mean": {str(r): float(e.mean()) for r, e in errs.items()},
            "err_median": {str(r): float(np.median(e)) for r, e in errs.items()},
            "err_q95": {str(r): float(np.percentile(e, 95)) for r, e in errs.items()},
            "err_max": {str(r): float(e.max()) for r, e in errs.items()}})
        print("FNO: train %.0f s, mean test errors" % ttrain,
              {r: round(float(e.mean()), 5) for r, e in errs.items()})

    # ---------------------------------------------------------------- DeepONet
    if args.only in ("don", "all"):
        torch.manual_seed(0)
        don = DeepONet(m=M_SENSORS, p=128, width=128, depth=3)
        print("DeepONet parameters:", sum(p.numel() for p in don.parameters()))
        S = t32(to_sensors(a_tr))
        Y = t32(np.arange(N_TRAIN_RES) / N_TRAIN_RES)
        hist, ttrain = train(
            don, lambda idx: rel_l2_loss(don(S[idx], Y), U[idx]), n, args.don_epochs,
            batch=20, lr=1e-3, eval_every=25,
            eval_fn=lambda: float(rel_l2(predict_don(don, a_te, N_TRAIN_RES), u_te).mean()))
        torch.save(don.state_dict(), os.path.join(CACHE, "deeponet%s.pt" % suffix))
        errs = {r: rel_l2(predict_don(don, sub(d["u0_test"], r), r), sub(d["uT_test"], r))
                for r in RESOLUTIONS}
        t0 = time.time()
        predict_don(don, a_te, 256)
        t_inf = (time.time() - t0) / len(a_te)
        save("deeponet", {
            "params": sum(p.numel() for p in don.parameters()), "epochs": args.don_epochs,
            "threads": args.threads,
            "train_time_s": ttrain, "history": hist, "infer_s_per_sample_256": t_inf,
            "err_mean": {str(r): float(e.mean()) for r, e in errs.items()},
            "err_median": {str(r): float(np.median(e)) for r, e in errs.items()},
            "err_q95": {str(r): float(np.percentile(e, 95)) for r, e in errs.items()},
            "err_max": {str(r): float(e.max()) for r, e in errs.items()}})
        print("DeepONet: train %.0f s, mean test errors" % ttrain,
              {r: round(float(e.mean()), 5) for r, e in errs.items()})
    if args.only in ("base", "all"):
        baselines(d, a_tr, u_tr, a_te, u_te, save, args.nu)


def pca_linear(a_fit, u_fit, a_eval, r):
    """Linear least squares between the leading r PCA coefficients of inputs and outputs."""
    ma, mu = a_fit.mean(0), u_fit.mean(0)
    Va = np.linalg.svd(a_fit - ma, full_matrices=False)[2][:r]
    Vu = np.linalg.svd(u_fit - mu, full_matrices=False)[2][:r]
    C = np.linalg.lstsq((a_fit - ma) @ Va.T, (u_fit - mu) @ Vu.T, rcond=None)[0]
    return mu + ((a_eval - ma) @ Va.T) @ C @ Vu


def fourier_interp(u, n_new):
    """Trigonometric interpolation of periodic grid data u (batch, n) to n_new >= n points."""
    n = u.shape[1]
    U = np.fft.rfft(u, axis=1)
    if n % 2 == 0:
        U[:, -1] *= 0.5                      # split the Nyquist mode symmetrically
    Unew = np.zeros((u.shape[0], n_new // 2 + 1), complex)
    Unew[:, :U.shape[1]] = U
    return np.fft.irfft(Unew, n=n_new, axis=1) * (n_new / n)


def baselines(d, a_tr, u_tr, a_te, u_te, save, nu):
    # (0) the conserved mean: int u dx is invariant, so predict the constant mean of u0
    mean_pred = np.repeat(a_te.mean(1, keepdims=True), a_te.shape[1], axis=1)
    # (1) exact solution operator of the *linear* heat equation u_t = nu u_xx (no data)
    k = np.fft.fftfreq(N_TRAIN_RES, d=1.0 / N_TRAIN_RES)
    heat = np.real(np.fft.ifft(np.exp(-nu * (2 * np.pi * k) ** 2 * T_FINAL)
                               * np.fft.fft(a_te, axis=1), axis=1))
    # (2) linear least squares between PCA coefficients (a linear "PCA-Net");
    #     rank r chosen on the last 100 training pairs
    val = {r: rel_l2(pca_linear(a_tr[:900], u_tr[:900], a_tr[900:], r), u_tr[900:]).mean()
           for r in (4, 8, 16, 32, 64, 128)}
    r_best = min(val, key=val.get)
    t0 = time.time()
    lin = pca_linear(a_tr, u_tr, a_te, r_best)
    t_lin = time.time() - t0
    t0 = time.time()
    np.real(np.fft.ifft(np.exp(-nu * (2 * np.pi * k) ** 2 * T_FINAL)
                        * np.fft.fft(a_te, axis=1), axis=1))
    t_heat = (time.time() - t0) / len(a_te)
    # (3) the classical solver itself on coarse grids with a large time step,
    #     Fourier-interpolated to the 256-point grid; batched over the 200 test inputs
    coarse = {}
    for n in (32, 64, 128, 256):
        for dt in (0.02, 0.05):
            t0 = time.time()
            uc = burgers_batch(sub(d["u0_test"], n), nu=nu, dt=dt)
            tc = (time.time() - t0) / len(a_te)
            e = rel_l2(fourier_interp(uc, N_TRAIN_RES), u_te)
            stable = bool(np.isfinite(e).all())   # explicit nonlinear term: advective CFL limit
            coarse["%d_%g" % (n, dt)] = {"n": n, "dt": dt, "stable": stable,
                                         "err_mean": float(e.mean()) if stable else None,
                                         "err_max": float(e.max()) if stable else None,
                                         "err_q95": float(np.percentile(e, 95)) if stable else None,
                                         "s_per_sample": tc}
    out = {"conserved_mean": float(rel_l2(mean_pred, u_te).mean()),
           "heat_linear": float(rel_l2(heat, u_te).mean()), "heat_s_per_sample": t_heat,
           "heat_q95": float(np.percentile(rel_l2(heat, u_te), 95)),
           "pca_linear": float(rel_l2(lin, u_te).mean()), "pca_rank": r_best,
           "pca_q95": float(np.percentile(rel_l2(lin, u_te), 95)),
           "pca_fit_and_predict_s": t_lin,
           "pca_val": {str(r): float(v) for r, v in val.items()},
           "coarse_solver": coarse,
           "setup": {"nu": nu, "T": T_FINAL, "n_train": len(a_tr), "n_test": len(a_te),
                     "train_res": N_TRAIN_RES, "sensors": M_SENSORS}}
    save("baselines", out)
    print(json.dumps(out, indent=1))


if __name__ == "__main__":
    main()

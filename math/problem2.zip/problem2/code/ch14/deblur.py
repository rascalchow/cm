"""1D deblurring (deconvolution) test problem and Tikhonov regularization via the SVD.

Used by fig_deblur.py (Figure "deblur" in Chapter 14) and by the exercises.
Run from the project root:  python3 code/ch14/deblur.py   (prints a short self-test)
"""
import numpy as np


def true_signal(x):
    """Piecewise-smooth signal on [0, 1]: a smooth bump plus a box (two jumps)."""
    bump = 0.8 * np.exp(-((x - 0.28) / 0.07) ** 2)
    box = 0.6 * ((x > 0.55) & (x < 0.80))
    return bump + box


def blur_matrix(n, width=0.03, n_fine=None):
    """Discretized Gaussian convolution (Af)(x) = int k(x - s) f(s) ds on [0, 1].

    Returns grid midpoints x (n,) and A (n, n) using the midpoint rule.  If n_fine is
    given, the matrix maps a fine-grid signal (n_fine,) to n coarse observation points;
    we use this to generate data without committing the 'inverse crime'.
    """
    x = (np.arange(n) + 0.5) / n
    m = n if n_fine is None else n_fine
    s = (np.arange(m) + 0.5) / m
    kern = np.exp(-0.5 * ((x[:, None] - s[None, :]) / width) ** 2) / (np.sqrt(2 * np.pi) * width)
    return x, kern / m


def make_data(n=128, width=0.03, noise=0.01, seed=0):
    """Blurred, noisy observations of true_signal at the n grid midpoints."""
    rng = np.random.default_rng(seed)
    n_fine = 8 * n
    x, A_fine = blur_matrix(n, width, n_fine=n_fine)
    s = (np.arange(n_fine) + 0.5) / n_fine
    y_clean = A_fine @ true_signal(s)                 # data from a finer model
    y = y_clean + noise * rng.standard_normal(n)
    _, A = blur_matrix(n, width)                      # model used for inversion
    return x, A, y, y_clean


# ---------------------------------------------------------------- listing: Tikhonov via SVD
def tikhonov_svd(A, y, lams):
    """Tikhonov solutions m_lam = argmin |A m - y|^2 + lam |m|^2 for many lam.

    Uses the SVD A = U diag(s) V^T: m_lam = sum_i f_i (u_i^T y / s_i) v_i with
    filter factors f_i = s_i^2 / (s_i^2 + lam).  Returns solutions (len(lams), n),
    residual norms and solution norms (the two axes of the L-curve).
    """
    U, s, Vt = np.linalg.svd(A)
    beta = U.T @ y                                    # data in the singular basis
    sols, res, nrm = [], [], []
    for lam in lams:
        f = s ** 2 / (s ** 2 + lam)                  # filter factors in (0, 1)
        m = Vt.T @ (f * beta / s)
        sols.append(m)
        res.append(np.linalg.norm(A @ m - y))
        nrm.append(np.linalg.norm(m))
    return np.array(sols), np.array(res), np.array(nrm)


def lcurve_corner(res, nrm, lams):
    """Index of maximum curvature of the L-curve (log residual, log norm)."""
    t = np.log(lams)
    a, b = np.log(res), np.log(nrm)
    da, db = np.gradient(a, t), np.gradient(b, t)
    d2a, d2b = np.gradient(da, t), np.gradient(db, t)
    kappa = (da * d2b - d2a * db) / (da ** 2 + db ** 2) ** 1.5
    return int(np.argmax(kappa))


def discrepancy_index(res, lams, noise, n, tau=1.0):
    """Largest lam with residual norm <= tau * sqrt(n) * noise (Morozov's principle)."""
    ok = np.where(res <= tau * np.sqrt(n) * noise)[0]
    return int(ok.max()) if ok.size else 0


if __name__ == "__main__":
    x, A, y, yc = make_data()
    s = np.linalg.svd(A, compute_uv=False)
    print("condition number of A: %.2e" % (s[0] / s[-1]))
    lams = np.logspace(-10, 1, 111)
    sols, res, nrm = tikhonov_svd(A, y, lams)
    # check against the normal equations for one lam
    lam = lams[60]
    m_ne = np.linalg.solve(A.T @ A + lam * np.eye(len(x)), A.T @ y)
    print("SVD vs normal equations:", np.abs(m_ne - sols[60]).max())
    assert np.abs(m_ne - sols[60]).max() < 1e-8
    print("self-test passed")

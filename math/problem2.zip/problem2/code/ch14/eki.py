"""Ensemble Kalman inversion (EKI) with optional covariance inflation (ES-MDA).

Described in Chapter 14 (Section on ensemble Kalman inversion); tested in test_mh.py.
G is the forward map R^n -> R^d.  With inflate=True each of the n_iter updates uses the
noise covariance n_iter * Gamma (ensemble smoother with multiple data assimilation); for
a linear G and an initial ensemble drawn from a Gaussian prior, the final ensemble then
samples the posterior as the ensemble size J -> infinity.  With inflate=False the
iteration is plain EKI, an optimizer whose ensemble collapses.
"""
import numpy as np


def eki(G, ens, y, Gamma, n_iter, rng, inflate=True):
    """Derivative-free ensemble Kalman updates of ens (J, n); returns the final ensemble."""
    alpha = float(n_iter) if inflate else 1.0
    L = np.linalg.cholesky(alpha * Gamma)
    J = ens.shape[0]
    for _ in range(n_iter):
        Gs = np.array([G(u) for u in ens])             # J forward solves (parallelizable)
        du, dg = ens - ens.mean(0), Gs - Gs.mean(0)
        C_ug = du.T @ dg / (J - 1)                     # cross-covariance  (n, d)
        C_gg = dg.T @ dg / (J - 1)                     # output covariance (d, d)
        y_pert = y + rng.standard_normal(Gs.shape) @ L.T   # perturbed observations
        ens = ens + (y_pert - Gs) @ np.linalg.solve(C_gg + alpha * Gamma, C_ug.T)
    return ens

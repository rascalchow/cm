"""Figure 14.1: ill-posedness and regularization for 1D deblurring.

(a) truth and data, (b) discrete Picard plot, (c) L-curve, (d) Tikhonov solutions for
several lam, (e) Tikhonov vs total variation, (f) Gaussian posterior (MAP = Tikhonov) with
95% credible band.  Run from the project root: python3 code/ch14/fig_deblur.py
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")             # CPU etiquette on shared machines

import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from deblur import make_data, true_signal, tikhonov_svd, lcurve_corner, discrepancy_index  # noqa: E402

set_style()
NOISE = 0.01
x, A, y, y_clean = make_data(n=128, width=0.03, noise=NOISE, seed=0)
n = len(x)
m_true = true_signal(x)
rel = lambda m: np.linalg.norm(m - m_true) / np.linalg.norm(m_true)  # noqa: E731

# ---------------------------------------------------------------- SVD / Picard
U, s, Vt = np.linalg.svd(A)
beta = U.T @ y
print("cond(A) = %.1e, sigma_1 = %.3f, sigma_n = %.1e" % (s[0] / s[-1], s[0], s[-1]))
m_naive = np.linalg.solve(A, y)
print("naive solution: |m| = %.1e, rel. error = %.1e" % (np.linalg.norm(m_naive), rel(m_naive)))

# ---------------------------------------------------------------- Tikhonov + parameter choice
lams = np.logspace(-10, 1, 221)
sols, res, nrm = tikhonov_svd(A, y, lams)
ic = lcurve_corner(res, nrm, lams)
idp = discrepancy_index(res, lams, NOISE, n)
errs = np.array([rel(m) for m in sols])
print("L-curve corner: lam = %.2e, rel. error = %.3f" % (lams[ic], errs[ic]))
print("discrepancy:    lam = %.2e, rel. error = %.3f" % (lams[idp], errs[idp]))
print("optimal (oracle): lam = %.2e, rel. error = %.3f" % (lams[errs.argmin()], errs.min()))
i_under = np.argmin(np.abs(lams - 1e-5))
i_over = np.argmin(np.abs(lams - 1e-1))
print("under-regularized lam=1e-5: rel. error %.2f; over-regularized lam=1e-1: %.3f"
      % (errs[i_under], errs[i_over]))

# ---------------------------------------------------------------- total variation (smoothed, L-BFGS)
D = np.diff(np.eye(n), axis=0)
mu, eps = 3e-3, 1e-3


def tv_obj(m):
    r, d = A @ m - y, D @ m
    sq = np.sqrt(d ** 2 + eps ** 2)
    return 0.5 * r @ r + mu * sq.sum(), A.T @ r + mu * D.T @ (d / sq)


out = minimize(tv_obj, np.zeros(n), jac=True, method="L-BFGS-B",
               options={"maxiter": 50000, "maxfun": 100000, "gtol": 1e-10})
m_tv = out.x
print("TV (mu=%.0e): rel. error = %.3f, iterations %d" % (mu, rel(m_tv), out.nit))

# ---------------------------------------------------------------- linear-Gaussian posterior
# prior N(0, C) with exponential (Ornstein-Uhlenbeck) covariance; (gamma, ell) by max evidence


def ou_cov(g, ell):
    return g ** 2 * np.exp(-np.abs(x[:, None] - x[None, :]) / ell)


def log_evidence(g, ell):
    S = A @ ou_cov(g, ell) @ A.T + NOISE ** 2 * np.eye(n)
    L = np.linalg.cholesky(S)
    a = np.linalg.solve(L, y)
    return -0.5 * a @ a - np.log(np.diag(L)).sum() - 0.5 * n * np.log(2 * np.pi)


grid = [(g, ell) for g in np.linspace(0.2, 1.0, 9) for ell in np.logspace(-2, 0, 11)]
g, ell = max(grid, key=lambda p: log_evidence(*p))
C = ou_cov(g, ell)
S = A @ C @ A.T + NOISE ** 2 * np.eye(n)
K = np.linalg.solve(S, A @ C).T                     # Kalman-gain form C A^T S^{-1}
m_post = K @ y
C_post = C - K @ A @ C
sd = np.sqrt(np.clip(np.diag(C_post), 0, None))
cover = np.mean(np.abs(m_post - m_true) <= 1.96 * sd)
print("posterior: gamma=%.2f ell=%.3f, rel. error of mean %.3f, prior sd %.2f, post sd in [%.3f, %.3f],"
      " truth inside 95%% band at %.0f%% of points" % (g, ell, rel(m_post), g, sd.min(), sd.max(), 100 * cover))
# MAP = Tikhonov check: solve the weighted Tikhonov problem directly
m_map = np.linalg.solve(A.T @ A / NOISE ** 2 + np.linalg.inv(C), A.T @ y / NOISE ** 2)
print("|MAP (Tikhonov form) - posterior mean (Kalman form)| =", np.abs(m_map - m_post).max())
rng = np.random.default_rng(1)
Lp = np.linalg.cholesky(C_post + 1e-12 * np.eye(n))
samples = m_post[:, None] + Lp @ rng.standard_normal((n, 3))

# ---------------------------------------------------------------- figure
fig, axs = plt.subplots(2, 3, figsize=(FULL_WIDTH, 3.55))
ax = axs[0, 0]
ax.plot(x, m_true, color="k", lw=1.2, label="truth $m^\\dagger$")
ax.plot(x, y_clean, color=COLORS["blue"], label="blurred $\\mathbf{A}m^\\dagger$")
ax.plot(x, y, ".", color=COLORS["orange"], ms=2.5, label="data $\\mathbf{y}$")
ax.set_title("(a) truth and data")
ax.set_xlabel("$x$")
ax.legend(loc="upper right", fontsize=6.5, handlelength=1.2)
ax.set_ylim(-0.1, 1.6)

ax = axs[0, 1]
idx = np.arange(1, n + 1)
ax.semilogy(idx, s, color="k", lw=1.2, label="$\\sigma_i$")
ax.semilogy(idx, np.abs(beta), ".", color=COLORS["blue"], ms=2.5, label="$|\\mathbf{u}_i^\\top\\mathbf{y}|$")
ax.semilogy(idx, np.abs(beta) / s, ".", color=COLORS["orange"], ms=2.5,
            label="$|\\mathbf{u}_i^\\top\\mathbf{y}|/\\sigma_i$")
ax.axhline(NOISE, color=COLORS["gray"], lw=0.8, ls="--")
ax.set_ylim(1e-18, 1e17)
ax.set_yticks([1e-15, 1e-10, 1e-5, 1, 1e5, 1e10, 1e15])
ax.set_xlabel("index $i$")
ax.set_title("(b) discrete Picard plot")
ax.legend(loc="upper left", fontsize=6.5, handlelength=1.0, ncol=1)

ax = axs[0, 2]
ax.loglog(res, nrm, color="k", lw=1.0)
ax.loglog(res[ic], nrm[ic], "o", color=COLORS["red"], label="corner")
ax.loglog(res[idp], nrm[idp], "s", color=COLORS["green"], label="discrepancy")
ax.loglog(res[i_under], nrm[i_under], "^", color=COLORS["purple"], label="$\\lambda=10^{-5}$")
ax.loglog(res[i_over], nrm[i_over], "v", color=COLORS["teal"], label="$\\lambda=10^{-1}$")
ax.set_xlabel("$\\|\\mathbf{A}\\mathbf{m}_\\lambda-\\mathbf{y}\\|$")
ax.set_ylabel("$\\|\\mathbf{m}_\\lambda\\|$")
ax.set_title("(c) L-curve")
ax.legend(fontsize=6.5, handlelength=1.0)

ax = axs[1, 0]
ax.plot(x, m_true, color="k", lw=1.2)
ax.plot(x, sols[i_under], color=COLORS["purple"], lw=0.8, label="$\\lambda=10^{-5}$")
ax.plot(x, sols[i_over], color=COLORS["teal"], label="$\\lambda=10^{-1}$")
ax.plot(x, sols[ic], color=COLORS["red"], label="corner")
ax.set_ylim(-0.6, 1.75)
ax.set_xlabel("$x$")
ax.set_title("(d) Tikhonov ($\\mathbf{L}=\\mathbf{I}$)")
ax.legend(loc="upper right", fontsize=6.5, handlelength=1.2)

ax = axs[1, 1]
ax.plot(x, m_true, color="k", lw=1.2, label="truth")
ax.plot(x, sols[ic], color=COLORS["red"], label="Tikhonov")
ax.plot(x, m_tv, color=COLORS["blue"], label="TV")
ax.set_ylim(-0.25, 1.6)
ax.set_xlabel("$x$")
ax.set_title("(e) Tikhonov vs. total variation")
ax.legend(loc="upper right", fontsize=6.5, handlelength=1.2)

ax = axs[1, 2]
ax.fill_between(x, m_post - 1.96 * sd, m_post + 1.96 * sd, color=COLORS["blue"], alpha=0.2, lw=0,
                label="95% credible")
ax.plot(x, samples, color=COLORS["blue"], lw=0.4, alpha=0.7)
ax.plot(x, m_post, color=COLORS["blue"], label="posterior mean")
ax.plot(x, m_true, color="k", lw=1.2, label="truth")
ax.set_ylim(-0.25, 1.6)
ax.set_xlabel("$x$")
ax.set_title("(f) Gaussian posterior")
ax.legend(loc="upper right", fontsize=6.5, handlelength=1.2, ncol=1)
fig.tight_layout(h_pad=0.6, w_pad=0.6)
print("saved", savefig(fig, "ch14", "deblur"))

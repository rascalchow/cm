"""Figure 14.2: Bayesian calibration of the Lotka-Volterra model.

Four adaptive random-walk Metropolis chains (mcmc.py) are compared with the
ensemble Kalman methods of eki.py.  Prints diagnostics (acceptance, R-hat, ESS) and
posterior summaries quoted in the text.  Runtime: about 2-3 minutes on one core.
Run from the project root:  python3 code/ch14/fig_mcmc_lv.py
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")             # CPU etiquette on shared machines

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from mcmc import (adaptive_mh, forward, log_post, make_data, rhat, ess,  # noqa: E402
                  TRUE, T_OBS, SIG, MU0, S0)
from eki import eki  # noqa: E402

set_style()
NAMES = ["alpha", "beta", "gamma", "delta"]
y, y_clean = make_data(seed=0)
rng = np.random.default_rng(42)

# ---------------------------------------------------------------- ensemble Kalman methods
J = 100
Gamma = SIG ** 2 * np.eye(y.size)
ens0 = MU0 + S0 * rng.standard_normal((J, 4))
ens_mda = eki(forward, ens0, y, Gamma, n_iter=4, rng=rng, inflate=True)
ens_eki = eki(forward, ens0, y, Gamma, n_iter=20, rng=rng, inflate=False)
for name, e in [("ES-MDA (4 x 100 solves)", ens_mda), ("plain EKI (20 x 100 solves)", ens_eki)]:
    print(name, "mean", np.exp(e).mean(0).round(3), "sd", np.exp(e).std(0).round(3))


def run_chains(starts, n_steps, n_adapt):
    out, accs = [], []
    for th0 in starts:
        ch, acc = adaptive_mh(lambda th: log_post(th, y), th0, n_steps, n_adapt, rng)
        out.append(ch)
        accs.append(acc)
    return np.array(out), np.array(accs)


# ---------------------------------------------------------------- MCMC attempt 1: starts drawn from the prior
pilot, _ = run_chains(MU0 + S0 * rng.standard_normal((4, 4)), 2500, 1500)
print("prior starts: R-hat", rhat(pilot).round(2), " final log-posterior per chain",
      [round(log_post(c[-1], y), 1) for c in pilot], " log-posterior at truth %.1f" % log_post(TRUE, y))

# ---------------------------------------------------------------- MCMC attempt 2: starts from the ES-MDA ensemble
N_STEPS, N_ADAPT = 5000, 2000
chains, accs = run_chains(ens_mda[rng.choice(J, 4, replace=False)], N_STEPS, N_ADAPT)
samples = chains.reshape(-1, 4)                # (4 x 3000, 4) log-parameters
R = rhat(chains)
E = [sum(ess(chains[m, :, i]) for m in range(4)) for i in range(4)]
print("ES-MDA starts: acceptance rates", accs.round(3))
print("R-hat:", R.round(3), " total ESS:", np.round(E).astype(int), " of", samples.shape[0])
P = np.exp(samples)
print("truth:          ", np.exp(TRUE).round(3))
print("posterior mean: ", P.mean(0).round(3))
print("posterior sd:   ", P.std(0).round(3))
lo, hi = np.percentile(P, [2.5, 97.5], axis=0)
print("95% intervals:  ", [(round(a, 2), round(b, 2)) for a, b in zip(lo, hi)])
print("correlation of log-params:\n", np.corrcoef(samples.T).round(2))

# ---------------------------------------------------------------- figure
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.25))
ax = axs[0]
t_fine = np.linspace(0.05, 10, 200)
idx = rng.choice(len(samples), 300, replace=False)
traj = np.array([forward(th, t_fine).reshape(-1, 2) for th in samples[idx]])
true_traj = forward(TRUE, t_fine).reshape(-1, 2)
for j, (col, lab) in enumerate([(COLORS["blue"], "prey"), (COLORS["orange"], "predator")]):
    q = np.percentile(traj[:, :, j], [2.5, 97.5], axis=0)
    ax.fill_between(t_fine, q[0], q[1], color=col, alpha=0.3, lw=0)
    ax.plot(t_fine, true_traj[:, j], color=col, lw=1.0, label=lab)
    ax.plot(T_OBS, y.reshape(-1, 2)[:, j], "o", color=col, ms=2.5, mfc="white", mew=0.8)
ax.set_xlabel("$t$")
ax.set_title("(a) data and 95% posterior band")
ax.legend(loc="upper right", fontsize=6.5, handlelength=1.2)
ax.set_ylim(0, 6.3)

ax = axs[1]
k = 1  # beta
for c in range(4):
    ax.plot(np.arange(N_ADAPT, N_STEPS), np.exp(chains[c, :, k]), lw=0.4, alpha=0.8)
ax.axhline(np.exp(TRUE[k]), color="k", lw=0.8, ls="--")
ax.set_xlabel("iteration")
ax.set_ylabel("$\\beta$")
ax.set_title("(b) traces of 4 chains")

ax = axs[2]
i, j = 0, 1
sub = P[rng.choice(len(P), 3000, replace=False)]
ax.plot(sub[:, i], sub[:, j], ".", color=COLORS["gray"], ms=1.0, alpha=0.35, label="MH")
ax.plot(np.exp(ens_mda[:, i]), np.exp(ens_mda[:, j]), "x", color=COLORS["orange"], ms=3, mew=0.8,
        label="ES-MDA")
ax.plot(np.exp(ens_eki[:, i]), np.exp(ens_eki[:, j]), "+", color=COLORS["green"], ms=3.5, mew=0.8,
        label="EKI")
ax.plot(*np.exp(TRUE[[i, j]]), "*", color=COLORS["red"], ms=6, label="truth")
ax.set_xlabel("$\\alpha$")
ax.set_ylabel("$\\beta$")
ax.set_title("(c) posterior samples")
leg = ax.legend(loc="upper left", fontsize=6.5, handlelength=1.0)
leg.legend_handles[0].set_markersize(4)
leg.legend_handles[0].set_alpha(1)
fig.tight_layout(w_pad=0.8)
print("saved", savefig(fig, "ch14", "mcmc_lv"))

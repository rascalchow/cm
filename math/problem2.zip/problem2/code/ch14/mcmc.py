"""Bayesian parameter inference for the Lotka-Volterra ODE with adaptive random-walk Metropolis.

The listing in Chapter 14 is an excerpt of this file.  Unknowns are the log-parameters
theta = log(alpha, beta, gamma, delta); both species are observed with Gaussian noise.
Run from the project root:  python3 code/ch14/mcmc.py   (short smoke test)
"""
import numpy as np
from scipy.integrate import odeint

SIG = 0.25                     # observation noise standard deviation (known)
MU0, S0 = 0.0, 0.5             # prior: theta_i ~ N(MU0, S0^2), independent
TRUE = np.log([1.3, 0.9, 0.8, 1.8])
T_OBS = np.linspace(0.5, 10.0, 20)


def lv_rhs(z, t, a, b, c, d):                        # Lotka-Volterra right-hand side
    x, y = z
    return [a * x - b * x * y, c * x * y - d * y]


def forward(theta, t_obs=T_OBS, z0=(1.0, 1.0)):
    """Parameter-to-observable map: log-parameters -> (prey, predator) at t_obs."""
    t = np.concatenate([[0.0], t_obs])
    Z = odeint(lv_rhs, z0, t, args=tuple(np.exp(theta)), rtol=1e-8, atol=1e-10)
    return Z[1:].ravel()


def log_post(theta, y):                               # unnormalized log posterior
    r = y - forward(theta)
    return -0.5 * (r @ r) / SIG ** 2 - 0.5 * np.sum((theta - MU0) ** 2) / S0 ** 2


def adaptive_mh(logp, theta0, n_steps, n_adapt, rng, step0=0.02):
    """Random-walk Metropolis; the proposal covariance is adapted during burn-in only."""
    d = len(theta0)
    th = np.array(theta0, float)
    lp = logp(th)
    C = step0 ** 2 * np.eye(d)
    chain, n_acc = np.empty((n_steps, d)), 0
    for k in range(n_steps):
        prop = rng.multivariate_normal(th, C)          # symmetric proposal
        lp_prop = logp(prop)
        if np.log(rng.uniform()) < lp_prop - lp:       # accept w.p. min(1, ratio)
            th, lp = prop, lp_prop
            n_acc += k >= n_adapt
        chain[k] = th
        if 500 <= k < n_adapt and k % 100 == 0:        # Haario et al.: 2.38^2/d * Cov
            C = 2.38 ** 2 / d * np.cov(chain[k // 2:k].T) + 1e-10 * np.eye(d)
    return chain[n_adapt:], n_acc / (n_steps - n_adapt)   # discard burn-in


def make_data(seed=0):
    rng = np.random.default_rng(seed)
    y_clean = forward(TRUE)
    return y_clean + SIG * rng.standard_normal(y_clean.size), y_clean


# ---------------------------------------------------------------- diagnostics
def rhat(chains):
    """Gelman-Rubin potential scale reduction factor for chains of shape (M, N, d)."""
    M, N, _ = chains.shape
    means = chains.mean(axis=1)
    W = chains.var(axis=1, ddof=1).mean(axis=0)
    B = N * means.var(axis=0, ddof=1)
    return np.sqrt(((N - 1) / N * W + B / N) / W)


def ess(x):
    """Effective sample size of a 1D chain (initial positive sequence of autocorrelations)."""
    x = x - x.mean()
    n = len(x)
    f = np.fft.rfft(x, 2 * n)
    acf = np.fft.irfft(f * np.conj(f))[:n] / (x @ x)
    s = 0.0
    for k in range(1, n - 1, 2):                       # sum pairs while positive (Geyer)
        pair = acf[k] + acf[k + 1]
        if pair < 0:
            break
        s += pair
    return n / (1 + 2 * s)


if __name__ == "__main__":
    y, _ = make_data()
    rng = np.random.default_rng(0)
    ch, acc = adaptive_mh(lambda th: log_post(th, y), np.zeros(4), 3000, 1500, rng)
    print("acceptance %.2f, posterior mean of exp(theta):" % acc, np.exp(ch.mean(0)).round(3))

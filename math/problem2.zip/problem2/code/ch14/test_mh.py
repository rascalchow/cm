"""Tests for the sampler and diagnostics in mcmc.py and the ensemble Kalman update in eki.py.

1. adaptive_mh on a strongly correlated 2D Gaussian reproduces its mean and covariance.
2. ess() recovers the known effective sample size of an AR(1) process; rhat() ~ 1 for iid chains.
3. eki(..., inflate=True) on a linear-Gaussian problem reproduces the exact posterior.
Run from the project root:  python3 code/ch14/test_mh.py
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(__file__))
from mcmc import adaptive_mh, ess, rhat  # noqa: E402
from eki import eki  # noqa: E402


def test_mh_gaussian():
    rng = np.random.default_rng(1)
    mean = np.array([1.0, -2.0])
    cov = np.array([[1.0, 0.95 * 0.5], [0.95 * 0.5, 0.25]])
    P = np.linalg.inv(cov)
    logp = lambda th: -0.5 * (th - mean) @ P @ (th - mean)  # noqa: E731
    chains = np.stack([adaptive_mh(logp, np.zeros(2), 40000, 5000, rng, step0=0.1)[0] for _ in range(4)])
    s = chains.reshape(-1, 2)
    err_m = np.abs(s.mean(0) - mean).max()
    err_c = np.abs(np.cov(s.T) - cov).max()
    print("MH Gaussian test: mean err %.3f, cov err %.3f, Rhat %s, ESS/chain %.0f"
          % (err_m, err_c, rhat(chains).round(3), ess(chains[0, :, 0])))
    assert err_m < 0.05 and err_c < 0.05
    assert np.all(rhat(chains) < 1.01)


def test_ess_ar1():
    rng = np.random.default_rng(2)
    phi, n = 0.9, 200000
    x = np.empty(n)
    x[0] = 0.0
    e = rng.standard_normal(n)
    for k in range(1, n):
        x[k] = phi * x[k - 1] + e[k]
    exact = n * (1 - phi) / (1 + phi)
    est = ess(x)
    print("AR(1) ESS: estimated %.0f, exact %.0f" % (est, exact))
    assert abs(est / exact - 1) < 0.1
    iid = rng.standard_normal((4, 5000, 3))
    assert np.all(np.abs(rhat(iid) - 1) < 0.01)


def test_eki_linear_gaussian():
    rng = np.random.default_rng(3)
    n, d, J = 3, 5, 20000
    A = rng.standard_normal((d, n))
    Gamma = 0.3 * np.eye(d)
    C0 = np.diag([1.0, 0.5, 2.0])
    y = A @ np.array([0.5, -1.0, 0.3]) + rng.multivariate_normal(np.zeros(d), Gamma)
    Cpost = np.linalg.inv(A.T @ np.linalg.inv(Gamma) @ A + np.linalg.inv(C0))
    mpost = Cpost @ A.T @ np.linalg.inv(Gamma) @ y
    ens0 = rng.multivariate_normal(np.zeros(n), C0, size=J)
    ens = eki(lambda u: A @ u, ens0, y, Gamma, n_iter=4, rng=rng, inflate=True)
    err_m = np.abs(ens.mean(0) - mpost).max()
    err_c = np.abs(np.cov(ens.T) - Cpost).max()
    print("ES-MDA linear-Gaussian test: mean err %.3f, cov err %.3f" % (err_m, err_c))
    assert err_m < 0.03 and err_c < 0.03


if __name__ == "__main__":
    test_mh_gaussian()
    test_ess_ar1()
    test_eki_linear_gaussian()
    print("all tests passed")

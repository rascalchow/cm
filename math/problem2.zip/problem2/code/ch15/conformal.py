"""Split conformal prediction for regression.  Listing in Chapter 15.

Run from the project root for a self-test of the coverage guarantee:
    python3 code/ch15/conformal.py
"""
import numpy as np


def conformal_quantile(scores, alpha):
    """The ceil((n+1)(1-alpha))-th smallest calibration score (inf if that exceeds n)."""
    n = len(scores)
    k = int(np.ceil((n + 1) * (1 - alpha)))
    return np.inf if k > n else np.sort(scores)[k - 1]


def split_conformal(mu_cal, y_cal, mu_test, alpha=0.1, sig_cal=None, sig_test=None):
    """Prediction intervals with marginal coverage >= 1 - alpha under exchangeability.

    mu_*: point predictions of a model fitted on a separate training set.  If sig_* are
    given, the normalized score |y - mu| / sig is used and the width adapts to sig(x)."""
    if sig_cal is None:
        sig_cal, sig_test = np.ones_like(mu_cal), np.ones_like(mu_test)
    scores = np.abs(y_cal - mu_cal) / sig_cal           # nonconformity scores
    q = conformal_quantile(scores, alpha)
    return mu_test - q * sig_test, mu_test + q * sig_test


if __name__ == "__main__":
    # coverage check with a deliberately bad model and heavy-tailed, heteroscedastic noise
    rng = np.random.default_rng(0)
    alpha, n, reps = 0.1, 50, 20000
    cov = np.empty(reps)
    for r in range(reps):
        x = rng.uniform(-1, 1, n + 1)
        y = np.sin(3 * x) + (0.1 + np.abs(x)) * rng.standard_t(3, n + 1)
        mu = 0.5 * x                                   # misspecified "model"
        lo, hi = split_conformal(mu[:n], y[:n], mu[n:], alpha)
        cov[r] = (lo[0] <= y[n]) & (y[n] <= hi[0])
    k = np.ceil((n + 1) * (1 - alpha))
    print("empirical coverage %.4f +- %.4f; theory: in [%.4f, %.4f]"
          % (cov.mean(), cov.std() / np.sqrt(reps), 1 - alpha, k / (n + 1)))
    assert 1 - alpha - 0.01 < cov.mean() < k / (n + 1) + 0.01
    print("self-test passed")

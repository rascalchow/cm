"""Figure 15.3: deep ensemble vs. split conformal intervals, in and out of distribution.

A 5-member ensemble of mean-variance MLPs (Gaussian NLL) is trained on x in [-1, 1];
intervals at level 90% are compared on in-distribution (ID) test data and on an
out-of-distribution (OOD) region x in [1, 1.6].  Panel (c) checks the distribution of the
coverage conditional on the calibration set against Beta(k, n + 1 - k).
Runtime: about a minute on two threads.  Run from the project root:
    python3 code/ch15/fig_ensemble_conformal.py
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")             # CPU etiquette on shared machines

import numpy as np
import torch
import matplotlib.pyplot as plt
from scipy.stats import beta as beta_dist

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from conformal import split_conformal  # noqa: E402

torch.set_num_threads(2)
torch.manual_seed(0)
set_style()
rng = np.random.default_rng(0)
ALPHA = 0.1


def f(x):
    return np.sin(3 * x) + 0.3 * x


def noise_sd(x):
    return 0.05 + 0.1 * (x + 1) ** 2 / 4          # heteroscedastic: grows to the right


def sample(n, lo=-1.0, hi=1.0):
    x = rng.uniform(lo, hi, n)
    return x, f(x) + noise_sd(x) * rng.standard_normal(n)


x_tr, y_tr = sample(300)
x_cal, y_cal = sample(200)
x_id, y_id = sample(100000)                      # ID pool (test + repeated calibration draws)
x_ood, y_ood = sample(5000, 1.0, 1.6)


class MeanVar(torch.nn.Module):
    """MLP with two outputs: mean and variance (softplus) of a Gaussian predictive."""

    def __init__(self, width=64):
        super().__init__()
        self.net = torch.nn.Sequential(torch.nn.Linear(1, width), torch.nn.SiLU(),
                                       torch.nn.Linear(width, width), torch.nn.SiLU(),
                                       torch.nn.Linear(width, 2))

    def forward(self, x):
        out = self.net(x)
        return out[:, 0], torch.nn.functional.softplus(out[:, 1]) + 1e-6


def train_member(seed, epochs=2000, lr=3e-3):
    torch.manual_seed(seed)                       # different random initialization per member
    model = MeanVar()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    X = torch.tensor(x_tr[:, None], dtype=torch.float32)
    Y = torch.tensor(y_tr, dtype=torch.float32)
    for _ in range(epochs):
        mu, var = model(X)
        loss = 0.5 * torch.mean(torch.log(var) + (Y - mu) ** 2 / var)   # Gaussian NLL
        opt.zero_grad()
        loss.backward()
        opt.step()
    return model


members = [train_member(s) for s in range(5)]


def ensemble_predict(x):
    """Gaussian-mixture moments: mean of means; total var = aleatoric + epistemic."""
    X = torch.tensor(np.asarray(x)[:, None], dtype=torch.float32)
    with torch.no_grad():
        outs = [m(X) for m in members]
    mus = np.stack([o[0].numpy() for o in outs]).astype(float)
    vars_ = np.stack([o[1].numpy() for o in outs]).astype(float)
    mu = mus.mean(0)
    alea, epi = vars_.mean(0), mus.var(0)
    return mu, np.sqrt(alea + epi), np.sqrt(alea), np.sqrt(epi)


z = 1.6449                                         # standard normal 95% quantile -> 90% interval
mu_cal, sd_cal, _, _ = ensemble_predict(x_cal)
pred = {"ID": ensemble_predict(x_id[50000:]) + (y_id[50000:],),
        "OOD": ensemble_predict(x_ood) + (y_ood,)}
for name, (mu, sd, sa, se, yt) in pred.items():
    print("%-4s mean aleatoric sd %.3f, mean epistemic sd %.3f, RMSE %.3f"
          % (name, sa.mean(), se.mean(), np.sqrt(np.mean((mu - yt) ** 2))))
    cov = np.mean(np.abs(yt - mu) <= z * sd)
    print("%-4s ensemble 90%% interval: coverage %.3f, mean width %.3f" % (name, cov, 2 * z * sd.mean()))
    for lab, sc, st in [("conformal", None, None), ("conformal (normalized)", sd_cal, sd)]:
        lo, hi = split_conformal(mu_cal, y_cal, mu, ALPHA, sc, st)
        print("%-4s %s with the single calibration set: coverage %.3f, mean width %.3f"
              % (name, lab, np.mean((lo <= yt) & (yt <= hi)), np.mean(hi - lo)))

# ---------------------------------------------------------------- repeated calibration draws (n = 200)
# calibration sets are drawn from the first half of the ID pool, coverage is measured on the
# second half (ID) and on the OOD set; averaging over draws gives the marginal coverage.
mu_p, sd_p, _, _ = ensemble_predict(x_id[:50000])
y_p = y_id[:50000]
n_cal, R = 200, 3000
k = int(np.ceil((n_cal + 1) * (1 - ALPHA)))
cov_draws = {key: np.empty(R) for key in [("ID", 0), ("ID", 1), ("OOD", 0), ("OOD", 1)]}
for r in range(R):
    idx = rng.choice(50000, n_cal, replace=False)
    for v, (sc, use_sd) in enumerate([(np.ones(n_cal), False), (sd_p[idx], True)]):
        q = np.sort(np.abs(y_p[idx] - mu_p[idx]) / sc)[k - 1]
        for name, (mu, sd, _, _, yt) in pred.items():
            w = q * (sd if use_sd else 1.0)
            cov_draws[(name, v)][r] = np.mean(np.abs(yt - mu) <= w)
results = {}
for name, (mu, sd, _, _, yt) in pred.items():
    results[(name, "ensemble")] = (np.mean(np.abs(yt - mu) <= z * sd), 0.0, 0.0)
    for v, lab in enumerate(["conformal", "conformal (normalized)"]):
        c = cov_draws[(name, v)]
        results[(name, lab)] = (c.mean(), c.mean() - np.quantile(c, 0.05), np.quantile(c, 0.95) - c.mean())
        print("%-4s %-24s coverage over %d calibration draws: mean %.4f, 5%%-95%% range [%.3f, %.3f]"
              % (name, lab, R, c.mean(), np.quantile(c, 0.05), np.quantile(c, 0.95)))
cond_cov = cov_draws[("ID", 0)]
print("Beta(%d,%d): mean %.4f sd %.4f; empirical sd of conditional coverage %.4f"
      % (k, n_cal + 1 - k, k / (n_cal + 1), beta_dist(k, n_cal + 1 - k).std(), cond_cov.std()))

# ---------------------------------------------------------------- figure
fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.35), gridspec_kw={"width_ratios": [1.6, 1, 1]})
ax = axs[0]
xs = np.linspace(-1, 1.6, 400)
mu, sd, _, _ = ensemble_predict(xs)
lo_c, hi_c = split_conformal(mu_cal, y_cal, mu, ALPHA)
lo_n, hi_n = split_conformal(mu_cal, y_cal, mu, ALPHA, sd_cal, sd)
ax.axvspan(1.0, 1.6, color=COLORS["gray"], alpha=0.08, lw=0)
ax.plot(x_tr, y_tr, ".", color=COLORS["gray"], ms=1.5, alpha=0.5)
ax.plot(x_ood[:100], y_ood[:100], ".", color=COLORS["gray"], ms=1.5, alpha=0.3)
ax.fill_between(xs, mu - z * sd, mu + z * sd, color=COLORS["blue"], alpha=0.2, lw=0, label="ensemble 90%")
ax.plot(xs, mu, color=COLORS["blue"], lw=1.0, label="ensemble mean")
ax.plot(xs, lo_c, "--", color=COLORS["orange"], lw=0.9, label="conformal")
ax.plot(xs, hi_c, "--", color=COLORS["orange"], lw=0.9)
ax.plot(xs, lo_n, ":", color=COLORS["red"], lw=1.1, label="conformal (norm.)")
ax.plot(xs, hi_n, ":", color=COLORS["red"], lw=1.1)
ax.plot(xs, f(xs), color="k", lw=0.8, label="truth $f$")
ax.text(1.03, -1.45, "OOD", fontsize=7, color=COLORS["gray"])
ax.set_xlabel("$x$")
ax.set_title("(a) 90% intervals")
ax.legend(loc="upper left", fontsize=6.0, handlelength=1.5, ncol=2, columnspacing=0.8)
ax.set_ylim(-1.6, 2.4)

ax = axs[1]
names = ["ensemble", "conformal", "conformal (normalized)"]
cols = [COLORS["blue"], COLORS["orange"], COLORS["red"]]
labels = ["ens.", "conf.", "norm."]
for j, reg in enumerate(["ID", "OOD"]):
    for i, nm in enumerate(names):
        val, elo, ehi = results[(reg, nm)]
        ax.bar(j + (i - 1) * 0.27, val, 0.25, color=cols[i], alpha=0.85,
               yerr=[[elo], [ehi]] if elo > 0 else None, error_kw={"lw": 0.8, "capsize": 1.5},
               label=labels[i] if j == 0 else None)
ax.axhline(1 - ALPHA, color="k", lw=0.8, ls="--")
ax.set_xticks([0, 1])
ax.set_xticklabels(["ID", "OOD"])
ax.set_ylim(0, 1.05)
ax.set_ylabel("empirical coverage")
ax.set_title("(b) coverage at nominal 90%")
ax.legend(fontsize=6.0, loc="upper right", bbox_to_anchor=(1.0, 0.8), handlelength=1.0)

ax = axs[2]
ax.hist(cond_cov, bins=40, density=True, color=COLORS["orange"], alpha=0.5, label="%d draws" % R)
cc = np.linspace(0.82, 0.97, 300)
ax.plot(cc, beta_dist(k, n_cal + 1 - k).pdf(cc), color="k", lw=1.0, label="Beta$(%d,%d)$" % (k, n_cal + 1 - k))
ax.axvline(1 - ALPHA, color=COLORS["gray"], lw=0.8, ls="--")
ax.set_xlabel("conditional coverage")
ax.set_title("(c) conformal, $n=200$")
ax.legend(fontsize=6.0, loc="upper left", handlelength=1.2)
fig.tight_layout(w_pad=0.6)
print("saved", savefig(fig, "ch15", "ensemble_conformal"))

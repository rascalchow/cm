"""Figure 15.2: GP regression with credible bands and the log-marginal-likelihood landscape.

Run from the project root:  python3 code/ch15/fig_gp.py
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")             # CPU etiquette on shared machines

import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import solve_triangular

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from gp import gp_fit, gp_predict, gp_train, sq_exp  # noqa: E402

set_style()
rng = np.random.default_rng(3)


def f(x):
    return np.sin(2 * np.pi * x) + 0.5 * x


SN = 0.1
x_tr = np.concatenate([rng.uniform(0.0, 0.4, 9), rng.uniform(0.7, 1.0, 7)])
y_tr = f(x_tr) + SN * rng.standard_normal(x_tr.size)
X = x_tr[:, None]
theta, nlml = gp_train(X, y_tr, np.log([0.3, 1.0, 0.1]), n_restarts=10)
ell, sf, sn = theta
print("optimal hyperparameters: ell=%.3f sf=%.3f sn=%.3f (true noise %.2f), -log ML %.3f"
      % (ell, sf, sn, SN, nlml))

xs = np.linspace(-0.1, 1.3, 300)
L, alpha, _ = gp_fit(X, y_tr, ell, sf, sn)
m, v = gp_predict(xs[:, None], X, L, alpha, ell, sf)
sd = np.sqrt(v)
inside = np.abs(m - f(xs)) <= 1.96 * sd
print("truth inside 95%% band for f: %.0f%% of plotting grid" % (100 * inside.mean()))
print("posterior sd: min %.3f, at x=0.55 %.3f, at x=1.3 %.3f"
      % (sd.min(), np.interp(0.55, xs, sd), sd[-1]))
# posterior samples of f
Ks = sq_exp(xs[:, None], X, ell, sf)
V = solve_triangular(L, Ks.T, lower=True)
Cpost = sq_exp(xs[:, None], xs[:, None], ell, sf) - V.T @ V
samp = m[:, None] + np.linalg.cholesky(Cpost + 1e-8 * np.eye(len(xs))) @ rng.standard_normal((len(xs), 3))

# log marginal likelihood landscape over (ell, sn) with sf fixed at its optimal value
ells = np.logspace(-2.3, 0.5, 90)
sns = np.logspace(-2.5, 0.3, 90)
Z = np.array([[gp_fit(X, y_tr, l_, sf, s_n)[2] for l_ in ells] for s_n in sns])
i0, j0 = np.unravel_index(Z.argmin(), Z.shape)
print("grid minimum: ell=%.3f sn=%.3f, -log ML %.3f" % (ells[j0], sns[i0], Z.min()))
# report a second (interpolating) local minimum at small noise, if present
mask = sns[:, None] < 0.03
Zs = np.where(mask, Z, np.inf)
i1, j1 = np.unravel_index(Zs.argmin(), Z.shape)
print("best with sn<0.03: ell=%.3f sn=%.4f, -log ML %.3f" % (ells[j1], sns[i1], Zs.min()))

fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4), gridspec_kw={"width_ratios": [1.45, 1]})
ax = axs[0]
ax.axvspan(1.0, 1.3, color=COLORS["gray"], alpha=0.08, lw=0)
ax.fill_between(xs, m - 1.96 * sd, m + 1.96 * sd, color=COLORS["blue"], alpha=0.2, lw=0,
                label="95% credible band of $f$")
ax.fill_between(xs, m - 1.96 * np.sqrt(v + sn ** 2), m + 1.96 * np.sqrt(v + sn ** 2),
                color=COLORS["blue"], alpha=0.08, lw=0, label="95% predictive band of $y$")
ax.plot(xs, samp, color=COLORS["blue"], lw=0.5, alpha=0.6)
ax.plot(xs, m, color=COLORS["blue"], label="posterior mean")
ax.plot(xs, f(xs), "--", color="k", lw=1.0, label="truth $f$")
ax.plot(x_tr, y_tr, "o", color=COLORS["orange"], ms=3.5, label="data")
ax.set_xlabel("$x$")
ax.set_title("(a) GP posterior (learned $\\ell,\\sigma_f,\\sigma_n$)")
ax.legend(loc="lower left", fontsize=6.5, handlelength=1.3, ncol=2)
ax.set_ylim(-2.6, 2.3)

ax = axs[1]
lev = Z.min() + np.array([0.5, 1, 2, 4, 8, 16, 32, 64])
ax.contour(ells, sns, Z, levels=lev, colors=COLORS["gray"], linewidths=0.6, linestyles="solid")
ax.set_xscale("log")
ax.set_yscale("log")
ax.plot(ell, sn, "*", color=COLORS["red"], ms=8, label="optimum")
ax.axhline(SN, color=COLORS["green"], lw=0.8, ls="--", label="true $\\sigma_n$")
ax.set_xlabel("length scale $\\ell$")
ax.set_ylabel("noise level $\\sigma_n$")
ax.set_title("(b) $-\\log p(\\mathbf{y}\\mid\\ell,\\sigma_f,\\sigma_n)$ at optimal $\\sigma_f$")
ax.legend(loc="upper right", fontsize=6.5)
fig.tight_layout(w_pad=1.0)
print("saved", savefig(fig, "ch15", "gp"))

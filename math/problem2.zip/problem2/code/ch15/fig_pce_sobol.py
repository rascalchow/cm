"""Figure 15.1: PCE convergence and Sobol indices for the Ishigami function.

(a) relative error of the variance estimate and of the surrogate vs. number of model runs,
    PCE regression (N = 2 x #terms) vs. plain Monte Carlo;
(b) first-order and total Sobol indices: exact, from PCE coefficients, pick-freeze Monte Carlo.
Run from the project root:  python3 code/ch15/fig_pce_sobol.py
"""
import os
import sys

for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ.setdefault(_v, "2")             # CPU etiquette on shared machines
from math import comb

import numpy as np
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from pce import ishigami, ishigami_exact, pce_fit, pce_sobol, design_matrix, sobol_mc  # noqa: E402

set_style()
rng = np.random.default_rng(0)
mean_ex, V_ex, S_ex, ST_ex = ishigami_exact()
xi_val = rng.uniform(-1, 1, (5000, 3))
q_val = ishigami(xi_val)
REPS = 5

# ---------------------------------------------------------------- PCE convergence
rows = []
for p in range(1, 15):
    P = comb(3 + p, p)
    N = 2 * P
    ev, el = [], []
    for r in range(REPS):
        xi = rng.uniform(-1, 1, (N, 3))
        al, c = pce_fit(xi, ishigami(xi), p)
        _, V, _, _ = pce_sobol(al, c)
        ev.append(abs(V - V_ex) / V_ex)
        pred = design_matrix(xi_val, al) @ c
        el.append(np.linalg.norm(pred - q_val) / np.linalg.norm(q_val - q_val.mean()))
    rows.append((p, P, N, np.median(ev), np.median(el)))
    print("p=%2d terms=%4d N=%4d  var rel.err %.2e  surrogate rel. L2 err %.2e" % rows[-1])
rows = np.array(rows)

# ---------------------------------------------------------------- Monte Carlo variance estimate
Ns = np.unique(np.logspace(1, 4.5, 15).astype(int))
mc = []
for N in Ns:
    e = [abs(np.var(ishigami(rng.uniform(-1, 1, (N, 3))), ddof=1) - V_ex) / V_ex for _ in range(200)]
    mc.append(np.median(e))
mc = np.array(mc)
print("MC variance rel. err at N=%d: %.2e" % (Ns[-1], mc[-1]))

# ---------------------------------------------------------------- Sobol indices
p = 10
P = comb(3 + p, p)
xi = rng.uniform(-1, 1, (2 * P, 3))
al, c = pce_fit(xi, ishigami(xi), p)
m_pce, V_pce, S_pce, ST_pce = pce_sobol(al, c)
print("PCE p=%d with N=%d runs: mean %.4f var %.4f S %s ST %s"
      % (p, 2 * P, m_pce, V_pce, S_pce.round(3), ST_pce.round(3)))
N_mc = 2000
est = np.array([np.concatenate(sobol_mc(ishigami, 3, N_mc, rng)) for _ in range(20)])
S_mc, ST_mc = est[:, :3], est[:, 3:]
print("MC pick-freeze N=%d (cost %d per estimate): S %s +- %s, ST %s +- %s"
      % (N_mc, N_mc * 5, S_mc.mean(0).round(3), S_mc.std(0).round(3),
         ST_mc.mean(0).round(3), ST_mc.std(0).round(3)))
print("exact: S %s ST %s" % (S_ex.round(4), ST_ex.round(4)))

# ---------------------------------------------------------------- figure
fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4), gridspec_kw={"width_ratios": [1.15, 1]})
ax = axs[0]
ax.loglog(rows[:, 2], rows[:, 3], "o-", color=COLORS["blue"], ms=3, label="PCE: variance")
ax.loglog(rows[:, 2], rows[:, 4], "s-", color=COLORS["green"], ms=3, label="PCE: surrogate $L^2$ error")
ax.loglog(Ns, mc, "^-", color=COLORS["orange"], ms=3, label="Monte Carlo: variance")
ax.loglog(Ns, 1.0 / np.sqrt(Ns), ":", color=COLORS["gray"], lw=1.0, label="$N^{-1/2}$")
for (pp, _, N, ev, _) in rows[[3, 7, 11]]:
    ax.annotate("$p=%d$" % pp, (N, ev), textcoords="offset points", xytext=(-4, -11), fontsize=6.5,
                color=COLORS["blue"])
ax.set_xlabel("number of model evaluations $N$")
ax.set_ylabel("relative error")
ax.set_title("(a) convergence (Ishigami, $d=3$)")
ax.legend(loc="lower left", fontsize=6.5, handlelength=1.5)
ax.set_ylim(1e-7, 3)

ax = axs[1]
w = 0.13
xpos = np.arange(3)
bars = [(S_ex, None, "exact $S_i$", COLORS["blue"], None),
        (S_pce, None, "PCE $S_i$", COLORS["blue"], "//"),
        (S_mc.mean(0), S_mc.std(0), "MC $S_i$", COLORS["blue"], ".."),
        (ST_ex, None, "exact $S_{T_i}$", COLORS["orange"], None),
        (ST_pce, None, "PCE $S_{T_i}$", COLORS["orange"], "//"),
        (ST_mc.mean(0), ST_mc.std(0), "MC $S_{T_i}$", COLORS["orange"], "..")]
for k, (val, err, lab, col, hatch) in enumerate(bars):
    ax.bar(xpos + (k - 2.5) * w, val, w, yerr=err, color=col if hatch is None else "white",
           edgecolor=col, hatch=hatch, lw=0.8, label=lab, error_kw={"lw": 0.8, "capsize": 1.5})
ax.set_xticks(xpos)
ax.set_xticklabels(["$\\xi_1$", "$\\xi_2$", "$\\xi_3$"])
ax.set_ylabel("Sobol index")
ax.set_title("(b) first-order and total indices")
ax.legend(fontsize=6.0, ncol=2, loc="upper right", handlelength=1.2, columnspacing=0.8)
ax.set_ylim(0, 0.85)
fig.tight_layout(w_pad=1.0)
print("saved", savefig(fig, "ch15", "pce_sobol"))

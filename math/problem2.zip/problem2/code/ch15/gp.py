"""Gaussian-process regression from scratch (Cholesky-based).  Listing in Chapter 15.

Tested in test_gp.py against direct linear algebra and scikit-learn.
"""
import numpy as np
from scipy.linalg import solve_triangular
from scipy.optimize import minimize


def sq_exp(X1, X2, ell, sf):
    """Squared-exponential kernel sf^2 exp(-|x - x'|^2 / (2 ell^2)); X1 (n1, d), X2 (n2, d)."""
    d2 = np.sum((X1[:, None, :] - X2[None, :, :]) ** 2, axis=-1)
    return sf ** 2 * np.exp(-0.5 * d2 / ell ** 2)


def gp_fit(X, y, ell, sf, sn, jitter=1e-10):
    """Cholesky factor of K + sn^2 I, weights alpha, and negative log marginal likelihood."""
    n = len(X)
    K = sq_exp(X, X, ell, sf) + (sn ** 2 + jitter) * np.eye(n)
    L = np.linalg.cholesky(K)                               # K = L L^T, O(n^3)
    alpha = solve_triangular(L.T, solve_triangular(L, y, lower=True), lower=False)
    nlml = 0.5 * y @ alpha + np.sum(np.log(np.diag(L))) + 0.5 * n * np.log(2 * np.pi)
    return L, alpha, nlml


def gp_predict(Xs, X, L, alpha, ell, sf):
    """Posterior mean and variance of the latent f at test inputs Xs (add sn^2 for y)."""
    Ks = sq_exp(Xs, X, ell, sf)                             # (n_test, n)
    mean = Ks @ alpha
    V = solve_triangular(L, Ks.T, lower=True)               # L^{-1} k(X, x*)
    var = sf ** 2 - np.sum(V ** 2, axis=0)
    return mean, np.maximum(var, 0.0)


def gp_train(X, y, log_theta0, n_restarts=5, seed=0):
    """Minimize the negative log marginal likelihood over log(ell, sf, sn) (L-BFGS-B),
    restarting from perturbed initial guesses because the objective is non-convex."""
    rng = np.random.default_rng(seed)
    obj = lambda lt: gp_fit(X, y, *np.exp(lt))[2]          # noqa: E731
    best = None
    for r in range(n_restarts):
        lt0 = np.asarray(log_theta0, float) + (r > 0) * rng.normal(0, 1, 3)
        res = minimize(obj, lt0, method="L-BFGS-B", bounds=[(-5, 5)] * 3)
        if best is None or res.fun < best.fun:
            best = res
    return np.exp(best.x), best.fun

"""Polynomial chaos expansion (Legendre, uniform inputs) by least-squares regression and
Sobol indices from PCE coefficients; Monte Carlo (pick-freeze) Sobol estimators.

Used by fig_pce_sobol.py and the exercises of Chapter 15.  Self-test: python3 code/ch15/pce.py
"""
import itertools
from math import comb

import numpy as np
from numpy.polynomial import legendre


def ishigami(xi, a=7.0, b=0.1):
    """Ishigami function; xi has shape (N, 3) with entries in [-1, 1] (scaled to [-pi, pi])."""
    x = np.pi * xi
    return np.sin(x[:, 0]) + a * np.sin(x[:, 1]) ** 2 + b * x[:, 2] ** 4 * np.sin(x[:, 0])


def ishigami_exact(a=7.0, b=0.1):
    """Analytical mean, variance, first-order and total Sobol indices."""
    p4, p8 = np.pi ** 4, np.pi ** 8
    V1 = 0.5 * (1 + b * p4 / 5) ** 2
    V2 = a ** 2 / 8
    V13 = b ** 2 * p8 * (1 / 18 - 1 / 50)
    V = V1 + V2 + V13
    S = np.array([V1, V2, 0.0]) / V
    ST = np.array([V1 + V13, V2, V13]) / V
    return a / 2, V, S, ST


# ---------------------------------------------------------------- listing: PCE regression + Sobol
def total_degree(d, p):
    """All multi-indices alpha in N^d with |alpha| <= p; there are comb(d + p, p) of them."""
    return np.array([a for a in itertools.product(range(p + 1), repeat=d) if sum(a) <= p])


def design_matrix(xi, alphas):
    """Psi[n, j] = prod_i sqrt(2 a_i + 1) P_{a_i}(xi_ni): orthonormal for U(-1, 1)^d."""
    p = alphas.max()
    # P1[k] = sqrt(2k + 1) P_k(xi) for k = 0..p, evaluated at all samples
    P1 = np.stack([np.sqrt(2 * k + 1) * legendre.legval(xi, np.eye(p + 1)[k]) for k in range(p + 1)])
    return np.prod([P1[alphas[:, i], :, i] for i in range(xi.shape[1])], axis=0).T


def pce_fit(xi, q, p):
    """Least-squares PCE of total degree p from samples xi (N, d) and outputs q (N,)."""
    alphas = total_degree(xi.shape[1], p)
    c, *_ = np.linalg.lstsq(design_matrix(xi, alphas), q, rcond=None)
    return alphas, c


def pce_sobol(alphas, c):
    """Mean, variance, first-order and total Sobol indices from the coefficients."""
    nz = alphas.sum(axis=1) > 0
    var = np.sum(c[nz] ** 2)                       # orthonormality: Var = sum of c_alpha^2
    S, ST = [], []
    for i in range(alphas.shape[1]):
        only_i = (alphas[:, i] > 0) & (alphas.sum(axis=1) == alphas[:, i])
        S.append(np.sum(c[only_i] ** 2) / var)
        ST.append(np.sum(c[alphas[:, i] > 0] ** 2) / var)
    return c[~nz][0], var, np.array(S), np.array(ST)


# ---------------------------------------------------------------- Monte Carlo pick-freeze estimators
def sobol_mc(f, d, N, rng):
    """Saltelli et al. (2010) first-order and Jansen (1999) total-effect estimators.
    Cost: N (d + 2) model evaluations."""
    A, B = rng.uniform(-1, 1, (N, d)), rng.uniform(-1, 1, (N, d))
    fA, fB = f(A), f(B)
    V = np.var(np.concatenate([fA, fB]))
    S, ST = np.empty(d), np.empty(d)
    for i in range(d):
        ABi = A.copy()
        ABi[:, i] = B[:, i]
        fABi = f(ABi)
        S[i] = np.mean(fB * (fABi - fA)) / V
        ST[i] = 0.5 * np.mean((fA - fABi) ** 2) / V
    return S, ST


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    mean, V, S, ST = ishigami_exact()
    print("exact: mean %.4f var %.4f S %s ST %s" % (mean, V, S.round(4), ST.round(4)))
    # orthonormality check of the basis by Gauss-Legendre quadrature
    x, w = legendre.leggauss(12)
    X = np.array(list(itertools.product(x, repeat=2)))
    W = np.prod(np.array(list(itertools.product(w, repeat=2))), axis=1) / 4
    al = total_degree(2, 4)
    Psi = design_matrix(X, al)
    G = Psi.T @ (W[:, None] * Psi)
    print("orthonormality error:", np.abs(G - np.eye(len(al))).max(), " #terms", len(al), comb(6, 4))
    assert np.abs(G - np.eye(len(al))).max() < 1e-12
    p = 10
    P = comb(3 + p, p)
    xi = rng.uniform(-1, 1, (3 * P, 3))
    al, c = pce_fit(xi, ishigami(xi), p)
    print("PCE p=10:", [np.round(v, 4) for v in pce_sobol(al, c)])
    print("self-test passed")

"""Tests for gp.py.

1. Posterior mean/variance and log marginal likelihood agree with dense linear algebra and
   scipy.stats.multivariate_normal.
2. Predictions and log marginal likelihood agree with scikit-learn for fixed hyperparameters.
3. As the noise level -> 0 the posterior mean interpolates the data and the variance vanishes there.
Run from the project root:  python3 code/ch15/test_gp.py
"""
import os
import sys

import numpy as np
from scipy.stats import multivariate_normal

sys.path.insert(0, os.path.dirname(__file__))
from gp import sq_exp, gp_fit, gp_predict, gp_train  # noqa: E402


def data(n=25, d=2, seed=0):
    rng = np.random.default_rng(seed)
    X = rng.uniform(-2, 2, (n, d))
    y = np.sin(X[:, 0]) * np.cos(X[:, 1]) + 0.05 * rng.standard_normal(n)
    return X, y, rng.uniform(-2, 2, (40, d))


def test_dense():
    X, y, Xs = data()
    ell, sf, sn = 0.8, 1.3, 0.1
    L, alpha, nlml = gp_fit(X, y, ell, sf, sn, jitter=0.0)
    m, v = gp_predict(Xs, X, L, alpha, ell, sf)
    K = sq_exp(X, X, ell, sf) + sn ** 2 * np.eye(len(X))
    Ks = sq_exp(Xs, X, ell, sf)
    m_ref = Ks @ np.linalg.solve(K, y)
    v_ref = np.diag(sq_exp(Xs, Xs, ell, sf) - Ks @ np.linalg.solve(K, Ks.T))
    lml_ref = multivariate_normal(np.zeros(len(X)), K).logpdf(y)
    errs = (np.abs(m - m_ref).max(), np.abs(v - v_ref).max(), abs(-nlml - lml_ref))
    print("dense check: mean %.1e, var %.1e, log ML %.1e" % errs)
    assert max(errs) < 1e-9


def test_sklearn():
    from sklearn.gaussian_process import GaussianProcessRegressor
    from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
    X, y, Xs = data(seed=1)
    ell, sf, sn = 0.7, 0.9, 0.2
    kern = ConstantKernel(sf ** 2) * RBF(ell) + WhiteKernel(sn ** 2)
    sk = GaussianProcessRegressor(kern, optimizer=None, alpha=1e-10).fit(X, y)
    m_sk, s_sk = sk.predict(Xs, return_std=True)            # std of y (includes noise)
    L, alpha, nlml = gp_fit(X, y, ell, sf, sn)
    m, v = gp_predict(Xs, X, L, alpha, ell, sf)
    errs = (np.abs(m - m_sk).max(), np.abs(np.sqrt(v + sn ** 2) - s_sk).max(),
            abs(-nlml - sk.log_marginal_likelihood_value_))
    print("sklearn check: mean %.1e, std %.1e, log ML %.1e" % errs)
    assert max(errs) < 1e-7
    # hyperparameter optimization reaches at least the sklearn optimum
    sk2 = GaussianProcessRegressor(kern, alpha=1e-10, n_restarts_optimizer=5, random_state=0).fit(X, y)
    theta, nl = gp_train(X, y, np.log([1.0, 1.0, 0.1]))
    print("optimized -log ML: ours %.4f, sklearn %.4f" % (nl, -sk2.log_marginal_likelihood_value_))
    assert nl <= -sk2.log_marginal_likelihood_value_ + 1e-4


def test_interpolation():
    X, y, _ = data(n=10, seed=2)
    L, alpha, _ = gp_fit(X, y, 1.0, 1.0, 1e-6)
    m, v = gp_predict(X, X, L, alpha, 1.0, 1.0)
    print("noise-free limit: max |m - y| = %.1e, max var = %.1e" % (np.abs(m - y).max(), v.max()))
    assert np.abs(m - y).max() < 1e-5 and v.max() < 1e-5


if __name__ == "__main__":
    test_dense()
    test_sklearn()
    test_interpolation()
    print("all tests passed")

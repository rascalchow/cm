"""Figure 16.3: generating 1D periodic Gaussian random fields, with a spectral check.

Data: 20000 fields from grf_1d(nx=64, alpha=1.5, tau=5), divided by their standard
deviation. Models: DDPM and flow matching with the MLP of gen2d.py (width 256, depth 3).
Because the data are Gaussian, the exact power spectrum E|u_hat_k|^2 is known:
    sigma^2 ((2 pi k)^2 + tau^2)^(-alpha) / s^2,  u_hat = fft(u) / nx.
Writes figures/ch16/grf_spectrum.pdf and prints spectral ratios (quoted in the text).
Run from the project root: python3 code/ch16/fig_grf_fields.py   (several minutes on 2 threads)
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from sciml_data import grf_1d  # noqa: E402
from gen2d import (TimeMLP, ddpm_schedule, ddpm_loss, ddpm_sample, fm_loss, fm_sample,  # noqa: E402
                   train)

torch.set_num_threads(2)
NX, ALPHA, TAU, SIGMA = 64, 1.5, 5.0, 25.0
N_ITER, N_GEN = 4000, 2000

raw = grf_1d(20000, nx=NX, alpha=ALPHA, tau=TAU, sigma=SIGMA, seed=0)
scale = raw.std()
data = (raw / scale).astype(np.float32)
kk = np.fft.fftfreq(NX, d=1.0 / NX)
exact = SIGMA ** 2 * ((2 * np.pi * kk) ** 2 + TAU ** 2) ** (-ALPHA) / scale ** 2


def spectrum(u):
    return np.mean(np.abs(np.fft.fft(u, axis=1) / NX) ** 2, axis=0)


sched = ddpm_schedule()
torch.manual_seed(0)
ddpm = TimeMLP(dim=NX, width=256, depth=3)
train(ddpm, lambda m, x: ddpm_loss(m, x, sched[2]), data, n_iter=N_ITER, batch=256, lr=1e-3)
torch.manual_seed(0)
flow = TimeMLP(dim=NX, width=256, depth=3)
train(flow, fm_loss, data, n_iter=N_ITER, batch=256, lr=1e-3)

torch.manual_seed(1)
x_ddpm = ddpm_sample(ddpm, N_GEN, sched, dim=NX)[0].numpy()
torch.manual_seed(2)
x_fm = fm_sample(flow, N_GEN, n_steps=100, dim=NX).numpy()

ks = np.arange(1, NX // 2 + 1)
fields = {"data": data[:N_GEN], "DDPM": x_ddpm, "FM": x_fm}
S = {name: spectrum(u) for name, u in fields.items()}
for name, u in fields.items():
    r = S[name][ks] / exact[ks]
    print(f"{name:5s} variance {u.var():.3f}  ratio to exact spectrum at k=1,4,8,12,16,24,32: "
          + " ".join(f"{r[k - 1]:.2f}" for k in (1, 4, 8, 12, 16, 24, 32)))

set_style()
fig, axes = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.3), gridspec_kw={"width_ratios": [1.15, 1]})
x = np.arange(NX) / NX
ax = axes[0]
for i in range(3):
    ax.plot(x, data[i], color=COLORS["gray"], lw=1.0, label="training data" if i == 0 else None)
    ax.plot(x, x_fm[i], color=COLORS["purple"], lw=1.0, ls="--",
            label="flow matching" if i == 0 else None)
ax.set_xlabel(r"$x$")
ax.set_ylabel(r"$u(x)$ (normalized)")
ax.set_ylim(-3.2, 2.4)
ax.legend(loc="lower center", ncol=2)
ax.set_title("sample fields")

ax = axes[1]
ax.loglog(ks, exact[ks], color="k", lw=1.0, label="exact")
ax.loglog(ks, S["data"][ks], "o", color=COLORS["gray"], ms=3, label="data (2000 fields)")
ax.loglog(ks, S["DDPM"][ks], "-", color=COLORS["orange"], label="DDPM (1000 NFE)")
ax.loglog(ks, S["FM"][ks], "-", color=COLORS["purple"], label="flow matching (100 NFE)")
ax.set_xlabel(r"wavenumber $\kappa$")
ax.set_ylabel(r"$\mathbb{E}\,|\hat u_\kappa|^2$")
ax.set_title("power spectrum")
ax.legend(loc="lower left")
fig.tight_layout(w_pad=1.0)
savefig(fig, "ch16", "grf_spectrum")

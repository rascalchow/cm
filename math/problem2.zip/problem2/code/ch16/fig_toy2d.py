"""Figures 16.1 and 16.2: DDPM and flow matching on the 2D "two moons" distribution.

Trains one DDPM (epsilon-prediction, K = 1000) and one flow-matching model with the
same MLP architecture, then draws samples with three samplers:
  * DDPM ancestral sampling (1000 network evaluations, stochastic),
  * DDIM / probability-flow ODE (50 evaluations, deterministic),
  * flow matching, explicit Euler (50 evaluations, deterministic).
Writes figures/ch16/diffusion_forward_reverse.pdf, figures/ch16/toy_samples.pdf and
prints sliced Wasserstein and nearest-neighbour distances to held-out data (quoted in the text).
Run from the project root: python3 code/ch16/fig_toy2d.py   (a few minutes on 2 CPU threads)
"""
import os
import sys

import matplotlib.pyplot as plt
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from gen2d import (TimeMLP, moons_data, ddpm_schedule, ddpm_loss, ddpm_sample,  # noqa: E402
                   ddim_sample, fm_loss, fm_sample, train, sliced_wasserstein, nn_distance)

torch.set_num_threads(2)
N_ITER, N_SHOW = 10000, 3000

data = moons_data(20000, seed=0)
test = moons_data(N_SHOW, seed=1)
sched = ddpm_schedule()

torch.manual_seed(0)
ddpm = TimeMLP()
train(ddpm, lambda m, x: ddpm_loss(m, x, sched[2]), data, n_iter=N_ITER, batch=256, seed=0)
torch.manual_seed(0)
flow = TimeMLP()
train(flow, fm_loss, data, n_iter=N_ITER, batch=256, seed=0)

ks = [0, 100, 250, 500, 1000]
torch.manual_seed(1)
x_anc, saved = ddpm_sample(ddpm, N_SHOW, sched, keep=ks)
torch.manual_seed(2)
x_ddim = ddim_sample(ddpm, N_SHOW, sched, n_steps=50)
torch.manual_seed(3)
x_fm, path = fm_sample(flow, N_SHOW, n_steps=50, return_path=True)

samples = {"data (indep.)": moons_data(N_SHOW, seed=2), "DDPM ancestral": x_anc.numpy(),
           "DDIM (PF-ODE)": x_ddim.numpy(), "flow matching": x_fm.numpy()}
sw = {k: sliced_wasserstein(v, test) for k, v in samples.items()}
nn = {k: nn_distance(v, test) for k, v in samples.items()}
for k in samples:
    print(f"{k:15s}: SW1 to held-out data {sw[k]:.4f}   mean NN distance {nn[k]:.4f}")

set_style()
lim = 3.0

# ---------------------------------------------------------------- figure 1: forward / reverse
fig, axes = plt.subplots(2, 5, figsize=(FULL_WIDTH, 2.75), sharex=True, sharey=True)
x0 = torch.as_tensor(test)
g = torch.Generator().manual_seed(5)
for j, k in enumerate(ks):
    if k == 0:
        xk = x0
    else:
        ab = sched[2][k - 1]
        xk = ab.sqrt() * x0 + (1 - ab).sqrt() * torch.randn(x0.shape, generator=g)
    axes[0, j].scatter(xk[:, 0], xk[:, 1], s=0.3, color=COLORS["blue"], alpha=0.5, rasterized=True)
    axes[0, j].set_title(rf"$k={k}$" + ("" if k == 0 else rf", $\bar\alpha_k={sched[2][k - 1]:.2g}$"))
    xr = saved[k]                                       # reverse-process state x_k
    axes[1, j].scatter(xr[:, 0], xr[:, 1], s=0.3, color=COLORS["orange"], alpha=0.5, rasterized=True)
for ax in axes.ravel():
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
axes[0, 0].set_ylabel(r"forward $q(\mathbf{x}_k)$")
axes[1, 0].set_ylabel(r"reverse $p_\theta(\mathbf{x}_k)$")
fig.tight_layout(h_pad=0.4, w_pad=0.2)
savefig(fig, "ch16", "diffusion_forward_reverse")

# ---------------------------------------------------------------- figure 2: samplers
fig, axes = plt.subplots(1, 4, figsize=(FULL_WIDTH, 1.9), sharex=True, sharey=True)
panels = [("independent data", samples["data (indep.)"], COLORS["gray"]),
          ("DDPM ancestral (1000 NFE)", x_anc.numpy(), COLORS["orange"]),
          ("DDIM / PF-ODE (50 NFE)", x_ddim.numpy(), COLORS["green"]),
          ("flow matching (50 NFE)", x_fm.numpy(), COLORS["purple"])]
names = list(sw.keys())
for ax, (title, pts, c), nm in zip(axes, panels, names):
    ax.scatter(pts[:, 0], pts[:, 1], s=0.3, color=c, alpha=0.5, rasterized=True)
    ax.set_title(title + "\n" + rf"$SW_1={sw[nm]:.3f}$, $d_{{NN}}={nn[nm]:.3f}$")
P = path.numpy()
for i in range(12):                                     # a few flow-matching trajectories
    axes[3].plot(P[:, i, 0], P[:, i, 1], color="k", lw=0.5, alpha=0.8)
    axes[3].plot(P[0, i, 0], P[0, i, 1], "o", ms=1.5, color="k")
for ax in axes:
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    ax.set_aspect("equal")
    ax.set_xticks([])
    ax.set_yticks([])
fig.tight_layout(w_pad=0.3)
savefig(fig, "ch16", "toy_samples")

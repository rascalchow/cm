"""Chapter 16: denoising diffusion (DDPM) and flow matching on 2D toy data.

Everything here is small enough to train on a laptop CPU in about a minute.
Conventions (as in the text): t = 0 is data, t = 1 (or step K) is noise.

    x_k = sqrt(abar_k) x_0 + sqrt(1 - abar_k) eps          (DDPM, k = 1..K)
    x_t = (1 - t) x_0 + t eps                              (flow matching, t in [0, 1])

Run from the project root:  python3 code/ch16/gen2d.py   (self-test, ~1 min)
"""
import numpy as np
import torch
import torch.nn as nn

torch.set_num_threads(2)


# ------------------------------------------------------------------ data
def moons_data(n, noise=0.05, seed=0):
    """Two interleaved half circles ("two moons"), standardized per coordinate."""
    rng = np.random.default_rng(seed)
    th = rng.uniform(0.0, np.pi, n)
    upper = rng.integers(0, 2, n)[:, None] == 0
    x = np.where(upper, np.stack([np.cos(th), np.sin(th)], 1),
                 np.stack([1.0 - np.cos(th), 0.5 - np.sin(th)], 1))
    x = x + noise * rng.standard_normal((n, 2))
    # fixed affine map to zero mean and unit variance per coordinate (population values)
    return ((x - np.array([0.5, 0.25])) / np.array([0.868, 0.497])).astype(np.float32)


def spiral_data(n, noise=0.04, seed=0):
    """Noisy two-armed spiral in R^2 (much harder than the moons for a small MLP)."""
    rng = np.random.default_rng(seed)
    s = np.sqrt(rng.uniform(0.0, 1.0, n)) * 3.0 * np.pi       # arc parameter
    arm = rng.integers(0, 2, n) * np.pi                          # two arms
    r = s / (3.0 * np.pi)
    x = np.stack([r * np.cos(s + arm), r * np.sin(s + arm)], axis=1)
    x = x + noise * rng.standard_normal((n, 2))
    return (x / 0.45).astype(np.float32)


# ------------------------------------------------------------------ network
class TimeMLP(nn.Module):
    """MLP v(x, t) with a sinusoidal embedding of the time t in [0, 1]."""

    def __init__(self, dim=2, width=128, depth=3, n_freq=16):
        super().__init__()
        # geometric frequencies 1 ... 1000 rad per unit time (transformer-style)
        self.register_buffer("freqs", torch.logspace(0.0, 3.0, n_freq))
        layers, d_in = [], dim + 2 * n_freq
        for _ in range(depth):
            layers += [nn.Linear(d_in, width), nn.SiLU()]
            d_in = width
        self.net = nn.Sequential(*layers, nn.Linear(width, dim))

    def forward(self, x, t):                      # x: (B, dim), t: (B,)
        a = t[:, None] * self.freqs[None, :]
        return self.net(torch.cat([x, torch.sin(a), torch.cos(a)], dim=1))


# ------------------------------------------------------------------ DDPM
def ddpm_schedule(K=1000, beta_1=1e-4, beta_K=0.02):
    """Linear beta schedule of Ho et al. (2020); returns beta_k, alpha_k, abar_k (k=1..K)."""
    beta = torch.linspace(beta_1, beta_K, K)
    alpha = 1.0 - beta
    return beta, alpha, torch.cumprod(alpha, dim=0)


def ddpm_loss(model, x0, abar):
    """L_simple: regress the noise eps from x_k = sqrt(abar_k) x0 + sqrt(1-abar_k) eps."""
    K = abar.shape[0]
    k = torch.randint(0, K, (x0.shape[0],))             # index k-1 in 0..K-1
    eps = torch.randn_like(x0)
    ab = abar[k][:, None]
    xk = ab.sqrt() * x0 + (1.0 - ab).sqrt() * eps
    return ((model(xk, (k + 1) / K) - eps) ** 2).sum(dim=1).mean()


@torch.no_grad()
def ddpm_sample(model, n, sched, dim=2, keep=()):
    """Ancestral sampling p_theta(x_{k-1} | x_k) with sigma_k^2 = beta_k."""
    beta, alpha, abar = sched
    K = beta.shape[0]
    x = torch.randn(n, dim)
    saved = {K: x.clone()} if K in keep else {}
    for k in range(K, 0, -1):
        i = k - 1
        eps_hat = model(x, torch.full((n,), k / K))
        mean = (x - beta[i] / (1.0 - abar[i]).sqrt() * eps_hat) / alpha[i].sqrt()
        x = mean + (beta[i].sqrt() * torch.randn_like(x) if k > 1 else 0.0)
        if k - 1 in keep:
            saved[k - 1] = x.clone()
    return x, saved


@torch.no_grad()
def ddim_sample(model, n, sched, n_steps=50, dim=2):
    """Deterministic DDIM (eta = 0) = a discretization of the probability-flow ODE."""
    _, _, abar = sched
    K = abar.shape[0]
    ks = np.linspace(K, 0, n_steps + 1).round().astype(int)
    x = torch.randn(n, dim)
    for k, k_next in zip(ks[:-1], ks[1:]):
        ab = abar[k - 1]
        ab_next = abar[k_next - 1] if k_next > 0 else torch.tensor(1.0)
        eps_hat = model(x, torch.full((n,), k / K))
        x0_hat = (x - (1 - ab).sqrt() * eps_hat) / ab.sqrt()        # Tweedie estimate
        x = ab_next.sqrt() * x0_hat + (1 - ab_next).sqrt() * eps_hat
    return x


# ------------------------------------------------------------------ flow matching
def fm_loss(model, x0):
    """Conditional flow matching on the straight path x_t = (1-t) x0 + t eps."""
    t = torch.rand(x0.shape[0])
    eps = torch.randn_like(x0)
    xt = (1 - t[:, None]) * x0 + t[:, None] * eps
    return ((model(xt, t) - (eps - x0)) ** 2).sum(dim=1).mean()


@torch.no_grad()
def fm_sample(model, n, n_steps=50, dim=2, return_path=False):
    """Integrate dx/dt = v_theta(x, t) backward from t = 1 (noise) to t = 0 (data), Euler."""
    x, dt = torch.randn(n, dim), 1.0 / n_steps
    path = [x.clone()]
    for j in range(n_steps, 0, -1):
        x = x - dt * model(x, torch.full((n,), j * dt))
        path.append(x.clone())
    return (x, torch.stack(path)) if return_path else x


# ------------------------------------------------------------------ training & metrics
def train(model, loss_fn, data, n_iter=12000, batch=512, lr=2e-3, seed=0, log_every=0):
    torch.manual_seed(seed)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, n_iter)
    data = torch.as_tensor(data)
    hist = []
    for it in range(n_iter):
        idx = torch.randint(0, data.shape[0], (batch,))
        loss = loss_fn(model, data[idx])
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
        hist.append(loss.item())
        if log_every and (it + 1) % log_every == 0:
            print(f"  iter {it + 1:6d}  loss {np.mean(hist[-log_every:]):.4f}", flush=True)
    return hist


def nn_distance(a, b):
    """Mean distance from each point of a to its nearest neighbour in b (off-support check)."""
    from scipy.spatial import cKDTree
    return cKDTree(np.asarray(b, float)).query(np.asarray(a, float))[0].mean()


def sliced_wasserstein(a, b, n_proj=200, seed=0):
    """Sliced 1-Wasserstein distance between two equal-size point clouds in R^d."""
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a, float), np.asarray(b, float)
    th = rng.standard_normal((n_proj, a.shape[1]))
    th /= np.linalg.norm(th, axis=1, keepdims=True)
    pa, pb = np.sort(a @ th.T, axis=0), np.sort(b @ th.T, axis=0)
    return np.mean(np.abs(pa - pb))


if __name__ == "__main__":
    import time
    torch.manual_seed(0)
    data, test = moons_data(20000, seed=0), moons_data(3000, seed=1)
    t0 = time.time()
    m = TimeMLP()
    train(m, fm_loss, data, n_iter=2000, batch=256, log_every=500)
    xs = fm_sample(m, 3000)
    print("flow matching (2000 iters): SW1 %.4f, NN distance %.4f   [%.0f s]"
          % (sliced_wasserstein(xs.numpy(), test), nn_distance(xs.numpy(), test), time.time() - t0))
    ref = moons_data(3000, seed=2)
    print("independent data:           SW1 %.4f, NN distance %.4f"
          % (sliced_wasserstein(ref, test), nn_distance(ref, test)))

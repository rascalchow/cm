"""Chapter 17: learned closures for coarse-grid Burgers, a priori vs a posteriori.

Truth   : u_t + (u^2/2)_x = nu u_xx on [0, 2 pi), nu = 0.01, pseudo-spectral ETDRK4
          with NF = 1024 points (code/common/sciml_data.burgers_periodic).
Filter  : cell averages on NC = 64 cells [x_j, x_{j+1}), x_j = j * DX.  Exactly,
              d ubar_j / dt = -(F(x_{j+1}) - F(x_j)) / DX,   F = u^2/2 - nu u_x,
          so the "true" coarse flux at face x_j is the fine flux sampled there.
Coarse  : finite-volume model with the energy-conserving central flux plus a
          learned (or Smagorinsky) flux correction, SSP-RK3 with DT = 0.01.

The module is imported by fig_closure_rollout.py; running it directly performs
consistency checks (python3 code/ch17/burgers_closure.py, ~2 min first time,
because it generates and caches the fine-grid data in code/ch17/cache/).
"""
import os
import sys

import numpy as np
import torch
import torch.nn as nn

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import burgers_periodic, grf_1d  # noqa: E402

torch.set_num_threads(2)
torch.set_default_dtype(torch.float64)

LENGTH, NU, NF, NC = 2 * np.pi, 0.01, 1024, 64
DX, DT = LENGTH / NC, 0.01
CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cache")


# ------------------------------------------------------------------ data
def initial_conditions(n, seed):
    """Zero-mean GRF initial conditions with random rms amplitude in [0.75, 1.25]."""
    rng = np.random.default_rng(seed + 1000)
    u0 = grf_1d(n, nx=NF, seed=seed)
    u0 -= u0.mean(axis=1, keepdims=True)
    u0 /= u0.std(axis=1, keepdims=True)
    return u0 * rng.uniform(0.75, 1.25, (n, 1))


def filter_to_coarse(U):
    """Fine fields U (nt, NF) -> cell averages ubar (nt, NC) and face fluxes F (nt, NC)."""
    k = np.fft.fftfreq(NF, d=1.0 / NF)                   # integer wavenumbers (L = 2 pi)
    Uh = np.fft.fft(U, axis=-1)
    kd = k * DX
    G = np.ones_like(kd, dtype=complex)                    # box filter over [x, x + DX]
    G[k != 0] = (np.exp(1j * kd[k != 0]) - 1.0) / (1j * kd[k != 0])
    r = NF // NC
    ubar = np.real(np.fft.ifft(Uh * G, axis=-1))[:, ::r]
    ux = np.real(np.fft.ifft(1j * k * Uh, axis=-1))
    F = 0.5 * U ** 2 - NU * ux
    return ubar, F[:, ::r]


def make_dataset(n_traj, T, seed, dt_save=DT):
    """Filtered DNS trajectories: ubar, F of shape (n_traj, nt, NC); cached on disk."""
    os.makedirs(CACHE, exist_ok=True)
    path = os.path.join(CACHE, f"burgers_n{n_traj}_T{T}_s{seed}.npz")
    if os.path.exists(path):
        d = np.load(path)
        return d["t"], d["ubar"], d["F"]
    t = np.round(np.arange(0.0, T + 1e-9, dt_save), 10)
    UB, FF = [], []
    for u0 in initial_conditions(n_traj, seed):
        U = burgers_periodic(u0, NU, LENGTH, t_save=t, dt=2e-3)
        ub, F = filter_to_coarse(U)
        UB.append(ub)
        FF.append(F)
    UB, FF = np.array(UB), np.array(FF)
    np.savez_compressed(path, t=t, ubar=UB, F=FF)
    return t, UB, FF


def true_tendency(F):
    """Exact filtered tendency d ubar/dt = -(F_{j+1} - F_j)/DX from face fluxes."""
    return -(np.roll(F, -1, axis=-1) - F) / DX


# ------------------------------------------------------------------ coarse model
def central_flux(u):
    """Energy-conserving flux at face j (between cells j-1 and j) plus viscous flux."""
    um = torch.roll(u, 1, -1)                               # u_{j-1}
    return (um * um + um * u + u * u) / 6.0 - NU * (u - um) / DX


class FluxNet(nn.Module):
    """Learned flux correction c_theta(u_{j-2}, u_{j-1}, u_j, u_{j+1}) at every face j."""
    # translation equivariant (same MLP at every face) and conservative by construction
    def __init__(self, width=32, scale=0.05):
        super().__init__()
        self.scale = scale
        self.net = nn.Sequential(nn.Linear(4, width), nn.Tanh(), nn.Linear(width, width),
                                 nn.Tanh(), nn.Linear(width, 1))

    def forward(self, u):                                   # u: (batch, NC)
        s = torch.stack([torch.roll(u, 2, -1), torch.roll(u, 1, -1), u,
                         torch.roll(u, -1, -1)], dim=-1)    # (batch, NC, 4)
        return self.scale * self.net(s).squeeze(-1)


def smagorinsky(cs):
    """Classical eddy-viscosity flux -(cs DX)^2 |u_x| u_x at the faces."""
    def flux(u):
        ux = (u - torch.roll(u, 1, -1)) / DX
        return -(cs * DX) ** 2 * ux.abs() * ux
    return flux


def rhs(u, closure=None):
    """Semi-discrete finite-volume right-hand side d ubar/dt."""
    flux = central_flux(u)
    if closure is not None:
        flux = flux + closure(u)
    return -(torch.roll(flux, -1, -1) - flux) / DX


def step(u, closure=None, dt=DT):
    """One SSP-RK3 (Shu-Osher) step; differentiable with respect to closure parameters."""
    u1 = u + dt * rhs(u, closure)
    u2 = 0.75 * u + 0.25 * (u1 + dt * rhs(u1, closure))
    return u / 3.0 + 2.0 / 3.0 * (u2 + dt * rhs(u2, closure))


def rollout(u0, n_steps, closure=None, dt=DT):
    """Return the trajectory (n_steps + 1, batch, NC); stops early if the state blows up."""
    u, traj = u0, [u0]
    for _ in range(n_steps):
        u = step(u, closure, dt)
        traj.append(u)
        if not torch.isfinite(u).all() or u.abs().max() > 1e3:
            break
    return torch.stack(traj)


# ------------------------------------------------------------------ training
def train_a_priori(model, ubar, F, n_iter=4000, batch=128, lr=3e-3, seed=0):
    """Match filtered tendencies: min E || rhs_theta(ubar) - d ubar/dt ||^2."""
    torch.manual_seed(seed)
    X = torch.as_tensor(ubar.reshape(-1, NC))
    Y = torch.as_tensor(true_tendency(F).reshape(-1, NC))
    Y0 = rhs(X)                                            # no-closure tendency
    s2 = ((Y - Y0) ** 2).mean()                            # normalise by closure-term variance
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, n_iter)
    for it in range(n_iter):
        i = torch.randint(0, X.shape[0], (batch,))
        loss = ((rhs(X[i], model) - Y[i]) ** 2).mean() / s2
        opt.zero_grad()
        loss.backward()
        opt.step()
        sch.step()
    return loss.item()


def train_a_posteriori(model, ubar, n_iter=1500, batch=16, horizon=20, lr=3e-3, seed=0,
                       dt=DT, stride=1):
    """Unroll the differentiable coarse solver for `horizon` steps of size dt and match
    the filtered DNS trajectory, min E sum_n || u_theta(t_n) - ubar(t_n) ||^2.
    Every `stride`-th saved frame is used, so stride * (save interval) must equal dt."""
    torch.manual_seed(seed)
    U = torch.as_tensor(ubar[:, ::stride])                 # (n_traj, nt, NC), spacing dt
    n_traj, nt, _ = U.shape
    s2 = (U ** 2).mean()
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, n_iter)
    for it in range(n_iter):
        j = torch.randint(0, n_traj, (batch,))
        n0 = torch.randint(0, nt - horizon, (batch,))
        target = torch.stack([U[j, n0 + m] for m in range(horizon + 1)])
        u, loss = target[0], 0.0
        for m in range(1, horizon + 1):
            u = step(u, model, dt)
            loss = loss + ((u - target[m]) ** 2).mean() / s2
        loss = loss / horizon
        opt.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sch.step()
    return loss.item()


def rel_error(pred, true):
    """Relative L2 error per time and trajectory; pred, true: (nt, batch, NC)."""
    return (torch.linalg.norm(pred - true, dim=-1) / torch.linalg.norm(true, dim=-1)).numpy()


if __name__ == "__main__":
    import time
    t0 = time.time()
    t, ub, F = make_dataset(48, 2.0, seed=0)
    print("train data", ub.shape, "%.0f s" % (time.time() - t0))
    # consistency: exact tendency vs centred finite difference in time of ubar
    fd = (ub[:, 2:] - ub[:, :-2]) / (2 * DT)
    ex = true_tendency(F)[:, 1:-1]
    print("max |FV identity - FD tendency| / max|tendency|: %.2e"
          % (np.abs(fd - ex).max() / np.abs(ex).max()))
    # no-closure coarse model vs filtered DNS
    U = torch.as_tensor(ub[:8])
    traj = rollout(U[:, 0], 200)
    e = rel_error(traj, U.transpose(0, 1))
    print("no-closure rel. error at t = 0.5, 1, 2:", e[50].mean(), e[100].mean(), e[200].mean())

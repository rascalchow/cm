"""Figure 17.1 and Table 17.1: a priori vs a posteriori closures for coarse-grid Burgers.

Models (64 cells, SSP-RK3):
  none        central energy-conserving flux only
  Smagorinsky eddy-viscosity flux, constant tuned on the TRAINING trajectories
  a priori    FluxNet trained to match exact filtered tendencies (time-step independent)
  a posteriori FluxNet trained by unrolling H = 10 solver steps of size DT_COARSE
All models are evaluated on 16 unseen test trajectories (t in [0, 4]) at several coarse
time steps. Writes figures/ch17/closure_rollout.pdf and prints the table quoted in the text.
Run from the project root: python3 code/ch17/fig_closure_rollout.py
(about 15 min on 2 threads; the first run also generates the cached fine-grid data)
"""
import os
import sys
import time

import matplotlib.pyplot as plt
import numpy as np
import torch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
sys.path.insert(0, os.path.dirname(__file__))
from plotstyle import set_style, COLORS, savefig, FULL_WIDTH  # noqa: E402
from burgers_closure import (DT, DX, NC, FluxNet, smagorinsky, make_dataset, rhs,  # noqa: E402
                             true_tendency, rollout, train_a_priori, train_a_posteriori)

torch.set_num_threads(2)
DT_COARSE = 0.1                       # largest step used: CFL = max|u| dt/dx up to ~2.2 (test set)
STEPS = (0.01, 0.05, 0.1)

t_tr, ub, F = make_dataset(48, 2.0, seed=0)          # training: 48 trajectories, t in [0, 2]
t_te, ubt, Ft = make_dataset(16, 4.0, seed=1)        # test: 16 trajectories, t in [0, 4]
U_te = torch.as_tensor(ubt).transpose(0, 1)          # (nt, 16, NC), saved every DT = 0.01


def evaluate(closure, dt, U=U_te):
    """Roll out each trajectory separately; return rel. error (nt, n) with NaN after blow-up."""
    stride = int(round(dt / DT))
    Us = U[::stride]
    err = np.full((Us.shape[0], Us.shape[1]), np.nan)
    with torch.no_grad():
        for i in range(Us.shape[1]):
            tr = rollout(Us[0, i:i + 1], Us.shape[0] - 1, closure, dt=dt)[:, 0]
            n = tr.shape[0]
            e = torch.linalg.norm(tr - Us[:n, i], dim=-1) / torch.linalg.norm(Us[:n, i], dim=-1)
            err[:n, i] = e.numpy()
            if n < Us.shape[0] or not np.isfinite(err[n - 1, i]):
                err[n - 1:, i] = np.nan
    return err


def summary(err):
    """(mean error over time and stable trajectories, number of blown-up trajectories)."""
    blown = int(np.isnan(err[-1]).sum())
    ok = ~np.isnan(err[-1])
    return (np.nanmean(err[:, ok]) if ok.any() else np.nan), blown


# ---------------------------------------------------------------- 1. tune Smagorinsky (training set)
U_tr = torch.as_tensor(ub).transpose(0, 1)
cs_grid = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]
cs_err = [summary(evaluate(smagorinsky(c), DT_COARSE, U_tr))[0] for c in cs_grid]
cs = cs_grid[int(np.nanargmin(cs_err))]
print("Smagorinsky training errors:", np.round(cs_err, 4), "-> C_s =", cs)

# ---------------------------------------------------------------- 2. train the closures
t0 = time.time()
torch.manual_seed(0)
prior = FluxNet()
train_a_priori(prior, ub, F, n_iter=3000, seed=0)
t1 = time.time()
torch.manual_seed(0)
post = FluxNet()
train_a_posteriori(post, ub, n_iter=1000, batch=16, horizon=10, dt=DT_COARSE,
                   stride=int(round(DT_COARSE / DT)), seed=0)
t2 = time.time()
print(f"training time: a priori {t1 - t0:.0f} s, a posteriori {t2 - t1:.0f} s")

# ---------------------------------------------------------------- 3. a priori metric on test snapshots
X = torch.as_tensor(ubt.reshape(-1, NC))
Y = torch.as_tensor(true_tendency(Ft).reshape(-1, NC))
with torch.no_grad():
    s2 = ((Y - rhs(X)) ** 2).mean()
    tend = {name: (((rhs(X, cl) - Y) ** 2).mean() / s2).item() for name, cl in
            [("none", None), ("Smagorinsky", smagorinsky(cs)), ("a priori", prior),
             ("a posteriori", post)]}

# ---------------------------------------------------------------- 4. rollouts on the test set
models = [("none", None), ("Smagorinsky", smagorinsky(cs)), ("a priori", prior),
          ("a posteriori", post)]
results = {(name, dt): evaluate(cl, dt) for name, cl in models for dt in STEPS}
print(f"\n{'model':14s} {'tendency':>9s} " + " ".join(f"dt={dt:<5} " for dt in STEPS))
for name, _ in models:
    cells = []
    for dt in STEPS:
        m, b = summary(results[(name, dt)])
        cells.append(f"{m:.3f}" + (f"({b})" if b else "   "))
    print(f"{name:14s} {tend[name]:9.3f} " + " ".join(f"{c:10s}" for c in cells))
print("(mean relative L2 error over t in [0,4] and stable trajectories; (n) = n of 16 blew up)")
for name in ("a priori", "a posteriori"):
    e = results[(name, DT_COARSE)]
    bt = [np.argmax(np.isnan(e[:, i])) * DT_COARSE for i in range(e.shape[1]) if np.isnan(e[-1, i])]
    print(f"{name} at dt={DT_COARSE}: blow-up times", np.round(sorted(bt), 2))

# ---------------------------------------------------------------- 5. figure
set_style()
fig, axes = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.25))
cols = {"none": COLORS["gray"], "Smagorinsky": COLORS["green"], "a priori": COLORS["orange"],
        "a posteriori": COLORS["blue"]}
stride = int(round(DT_COARSE / DT))
Us = U_te[::stride]
tc = np.arange(Us.shape[0]) * DT_COARSE

# (a) resolved energy of the test trajectory on which the a priori closure fails (if any)
e_pr = results[("a priori", DT_COARSE)]
bad = [i for i in range(e_pr.shape[1]) if np.isnan(e_pr[-1, i])]
i0 = bad[0] if bad else 0
n_bad = int(np.argmax(np.isnan(e_pr[:, i0]))) if bad else len(tc) - 1
ax = axes[0]
ax.semilogy(t_te, 0.5 * DX * (U_te[:, i0] ** 2).sum(-1).numpy(), color="k", lw=2.2, alpha=0.35,
            label="filtered DNS")
with torch.no_grad():
    for name, cl in models:
        tr = rollout(Us[0, i0:i0 + 1], Us.shape[0] - 1, cl, dt=DT_COARSE)[:, 0]
        E = np.minimum(0.5 * DX * (tr ** 2).sum(-1).numpy(), 1e3)      # clip blow-up for display
        ax.semilogy(tc[:len(E)], E, color=cols[name], label=name)
        if len(E) < len(tc):
            ax.plot(tc[len(E) - 1], E[-1], "x", color=cols[name], ms=6, mew=1.5)
ax.set_ylim(0.2, 2e3)
ax.set_xlabel(r"$t$")
ax.set_ylabel(r"energy $\frac{1}{2}\sum_j \bar u_j^2 \Delta x$")
ax.set_title(rf"(a) test case {i0 + 1}, $\Delta t={DT_COARSE}$")
ax.legend(loc="upper right", fontsize=6.5)

# (b) mean relative error over the test set vs time
ax = axes[1]
for name, _ in models:
    e = results[(name, DT_COARSE)]
    ok = ~np.isnan(e[-1])
    if ok.any():
        ax.plot(tc, e[:, ok].mean(axis=1), color=cols[name], label=name)
e01 = results[("a priori", 0.01)]
ax.plot(t_te, np.nanmean(e01, axis=1), color=cols["a priori"], ls="--", label=r"a priori, $\Delta t=0.01$")
ax.set_xlabel(r"$t$")
ax.set_ylabel("relative $L^2$ error")
ax.set_title(r"(b) mean over stable test runs")
ax.legend(loc="upper right", fontsize=6.5)

# (c) the same test case shortly before the a priori model blows up (zoom on the worst region)
ax = axes[2]
n1 = max(n_bad - 2, 1)
xc = (np.arange(NC) + 0.5) * DX
ref = Us[n1, i0].numpy()
with torch.no_grad():
    snaps = {name: rollout(Us[0, i0:i0 + 1], n1, cl, dt=DT_COARSE)[-1, 0].numpy() for name, cl in models}
jc = int(np.argmax(np.abs(snaps["a priori"] - ref)))
win = (xc > xc[jc] - 1.3) & (xc < xc[jc] + 1.3)
ax.plot(xc[win], ref[win], color="k", lw=2.2, alpha=0.35)
for name, _ in models:
    ax.plot(xc[win], snaps[name][win], "-", color=cols[name], lw=1.0, marker="o", ms=1.8)
print(f"panel (c): test case {i0 + 1}, t = {n1 * DT_COARSE:.1f}, max |a priori - DNS| = "
      f"{np.abs(snaps['a priori'] - ref).max():.2f}")
ax.set_xlabel(r"$x$")
ax.set_ylabel(r"$\bar u_j$")
ax.set_title(rf"(c) $t={n1 * DT_COARSE:.1f}$, $\Delta t={DT_COARSE}$ (zoom)")
fig.tight_layout(w_pad=0.6)
savefig(fig, "ch17", "closure_rollout")

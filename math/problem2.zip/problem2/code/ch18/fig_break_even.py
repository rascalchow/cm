"""Break-even analysis for the Burgers neural operator of Chapter 13.

Chapter 18, Example "Break-even" and Figure "break_even".  All per-query costs are
measured here, on one CPU thread, for batches of 100 test inputs (nu = 0.01):
  c_gen   : the solver configuration used to generate the training data
            (ETDRK4, 1024 points, dt = 1e-3)
  c_tuned : the cheapest coarse-grid configuration whose mean error is at most the
            FNO's (from code/ch13/cache/results_baselines.json)
  c_fno   : FNO inference at the training resolution n = 256
The training time C_train is read from code/ch13/cache/results_fno.json.
Requires: python3 code/ch13/train_burgers.py (trained FNO and baselines).
Output: figures/ch18/break_even.pdf and code/ch18/cache/break_even.json.
"""
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
CH13 = os.path.join(HERE, "..", "ch13")
sys.path.insert(0, CH13)
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from ch13_data import burgers_batch, load_burgers  # noqa: E402
from fno1d import FNO1d  # noqa: E402
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from train_burgers import CACHE as CACHE13, predict_fno, sub  # noqa: E402

torch.set_num_threads(1)
OUT = os.path.join(HERE, "cache", "break_even.json")


def best_time(f, repeats=3):
    """Minimum wall-clock time over repeats (least affected by other load)."""
    ts = []
    for _ in range(repeats):
        t0 = time.time()
        f()
        ts.append(time.time() - t0)
    return min(ts)


def measure():
    d = load_burgers()
    rf = json.load(open(os.path.join(CACHE13, "results_fno.json")))
    rb = json.load(open(os.path.join(CACHE13, "results_baselines.json")))
    B = 100
    a1024 = d["u0_test"][:B]
    c_gen = best_time(lambda: burgers_batch(a1024), repeats=2) / B
    # cheapest coarse configuration that is at least as accurate as the FNO
    err_fno = rf["err_mean"]["256"]
    ok = [v for v in rb["coarse_solver"].values() if v["stable"] and v["err_mean"] <= err_fno]
    tuned = min(ok, key=lambda v: v["n"] / v["dt"])          # fewest grid-point updates
    a_c = sub(d["u0_test"], tuned["n"])[:B]
    c_tuned = best_time(lambda: burgers_batch(a_c, dt=tuned["dt"])) / B
    fno = FNO1d(modes=rf["modes"], width=rf["width"], n_layers=rf["layers"])
    fno.load_state_dict(torch.load(os.path.join(CACHE13, "fno.pt")))
    fno.eval()
    a256 = sub(d["u0_test"], 256)[:B]
    c_fno = best_time(lambda: predict_fno(fno, a256)) / B
    N, C_train = rb["setup"]["n_train"], rf["train_time_s"]
    C_off = N * c_gen + C_train
    out = {"c_gen": c_gen, "c_tuned": c_tuned, "c_fno": c_fno, "N": N, "C_train": C_train,
           "C_off": C_off, "err_fno": err_fno, "tuned": tuned,
           "n_star_gen": C_off / (c_gen - c_fno) if c_gen > c_fno else None,
           "n_star_tuned": C_off / (c_tuned - c_fno) if c_tuned > c_fno else None}
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    json.dump(out, open(OUT, "w"), indent=1)
    return out


def plot(o):
    set_style()
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(1, 2, figsize=(FULL_WIDTH, 2.4))
    n = np.logspace(0, 7, 300)
    ax = axs[0]
    ax.loglog(n, n * o["c_gen"], color=COLORS["gray"],
              label="solver, 1024 pts, $\\Delta t=10^{-3}$")
    ax.loglog(n, n * o["c_tuned"], color=COLORS["green"], ls="--",
              label="solver, %d pts, $\\Delta t=%g$" % (o["tuned"]["n"], o["tuned"]["dt"]))
    ax.loglog(n, o["C_off"] + n * o["c_fno"], color=COLORS["blue"], label="FNO (offline + online)")
    if o["n_star_gen"]:
        ax.plot(o["n_star_gen"], o["n_star_gen"] * o["c_gen"], "o", color=COLORS["red"], ms=4)
        ax.annotate("$n^*\\approx%.0f$" % o["n_star_gen"],
                    (o["n_star_gen"], o["n_star_gen"] * o["c_gen"]), xytext=(6, -14),
                    textcoords="offset points", fontsize=7, color=COLORS["red"])
    ax.set_xlabel("number of queries $n$")
    ax.set_ylabel("cumulative CPU time [s]")
    ax.set_title("(a) measured costs, Burgers ($\\nu=0.01$)")
    ax.legend(fontsize=6.5, loc="lower right")
    ax.set_ylim(1e-3, 1e7)
    # (b) generic break-even curve n*/N = (1 + rho) / (1 - 1/S), with c_gen = c_cl
    ax = axs[1]
    S = np.logspace(0.01, 4, 300)
    rho_meas = o["C_train"] / (o["N"] * o["c_gen"])
    for rho, c in ((0.0, COLORS["gray"]), (1.0, COLORS["orange"]), (10.0, COLORS["purple"])):
        ax.loglog(S, (1 + rho) / (1 - 1 / S), color=c, label="$\\rho=%g$" % rho)
    S_meas = o["c_gen"] / o["c_fno"]
    ax.loglog(S_meas, (1 + rho_meas) / (1 - 1 / S_meas), "o", color=COLORS["red"], ms=4)
    ax.annotate("this example", (S_meas, (1 + rho_meas) / (1 - 1 / S_meas)), xytext=(-30, 8),
                textcoords="offset points", fontsize=7, color=COLORS["red"])
    ax.set_xlabel("speed-up $S=c_{\\mathrm{cl}}/c_{\\mathrm{s}}$")
    ax.set_ylabel("break-even $n^*/N$")
    ax.set_title("(b) $n^*/N=(1+\\rho)/(1-1/S)$")
    ax.legend(fontsize=6.5, title="$\\rho=C_{\\mathrm{train}}/(Nc_{\\mathrm{cl}})$",
              title_fontsize=6.5, loc="upper right")
    ax.set_ylim(0.5, 300)
    fig.tight_layout(w_pad=1.0)
    print(savefig(fig, "ch18", "break_even"))


if __name__ == "__main__":
    o = json.load(open(OUT)) if os.path.exists(OUT) and "--rerun" not in sys.argv else measure()
    for k, v in o.items():
        print(k, v)
    plot(o)

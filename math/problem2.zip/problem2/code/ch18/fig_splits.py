"""How the train/test split changes the *measured* error of a surrogate.

Chapter 18, Figure "split_errors".  Surrogate task: learn the map
    (theta0, c, t)  ->  theta(t)
for the damped pendulum  theta'' + c theta' + sin(theta) = 0,  theta(0) = theta0,
theta'(0) = 0, from 80 simulated trajectories (theta0 in [0.3, 2.8], c in [0, 0.3],
t in [0, 15]).  The same models are scored under four splits:
  random      : random 20% of all (trajectory, time) points          (leaky)
  trajectory  : random 20% of the trajectories held out              (interpolation)
  parameter   : trajectories with theta0 > 2.3 held out              (extrapolation)
  temporal    : times t > 12 held out for every trajectory           (forecasting)
Models: an MLP (3-64-64-64-1, tanh, Adam) and a 1-nearest-neighbour lookup.
Results are cached in code/ch18/cache/splits.json; the figure is
figures/ch18/split_errors.pdf.  Runtime: a few minutes on one CPU thread.
"""
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "common"))
from plotstyle import COLORS, FULL_WIDTH, savefig, set_style  # noqa: E402
from sciml_data import pendulum  # noqa: E402

torch.set_num_threads(1)
CACHE = os.path.join(HERE, "cache", "splits.json")
N_TRAJ, T_END, N_T = 80, 15.0, 151
T_SPLIT, THETA_SPLIT = 12.0, 2.3
SPLITS = ["random", "trajectory", "parameter", "temporal"]


def make_data(seed=0):
    rng = np.random.default_rng(seed)
    theta0 = rng.uniform(0.3, 2.8, N_TRAJ)
    c = rng.uniform(0.0, 0.3, N_TRAJ)
    t = np.linspace(0, T_END, N_T)
    Y = np.stack([pendulum((th, 0.0), t, damping=ci)[:, 0] for th, ci in zip(theta0, c)])
    return theta0, c, t, Y                                  # Y: (N_TRAJ, N_T)


def features(theta0, c, t):
    """Inputs scaled to [-1, 1] (fixed physical ranges, not fitted on the data)."""
    return np.stack([(theta0 - 1.55) / 1.25, (c - 0.15) / 0.15, t / T_END * 2 - 1], -1)


def split_masks(name, theta0, t, rng):
    """Boolean test mask of shape (N_TRAJ, N_T) for each splitting strategy."""
    if name == "random":
        return rng.random((N_TRAJ, N_T)) < 0.2
    if name == "trajectory":
        test = np.zeros(N_TRAJ, bool)
        test[rng.choice(N_TRAJ, N_TRAJ // 5, replace=False)] = True
        return np.repeat(test[:, None], N_T, axis=1)
    if name == "parameter":
        return np.repeat((theta0 > THETA_SPLIT)[:, None], N_T, axis=1)
    if name == "temporal":
        return np.repeat((t > T_SPLIT)[None, :], N_TRAJ, axis=0)
    raise ValueError(name)


def fit_mlp(X, y, seed, iters=4000, batch=512):
    torch.manual_seed(seed)
    net = torch.nn.Sequential(torch.nn.Linear(3, 64), torch.nn.Tanh(),
                              torch.nn.Linear(64, 64), torch.nn.Tanh(),
                              torch.nn.Linear(64, 64), torch.nn.Tanh(), torch.nn.Linear(64, 1))
    opt = torch.optim.Adam(net.parameters(), lr=3e-3)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, iters)
    Xt, yt = torch.tensor(X, dtype=torch.float32), torch.tensor(y, dtype=torch.float32)
    g = torch.Generator().manual_seed(seed)
    for _ in range(iters):
        idx = torch.randint(0, len(Xt), (batch,), generator=g)
        loss = ((net(Xt[idx]).squeeze(-1) - yt[idx]) ** 2).mean()
        opt.zero_grad()
        loss.backward()
        opt.step()
        sched.step()
    return lambda Z: net(torch.tensor(Z, dtype=torch.float32)).squeeze(-1).detach().numpy()


def fit_1nn(X, y):
    def predict(Z):
        out = np.empty(len(Z))
        for i in range(0, len(Z), 500):       # chunked brute-force nearest neighbour
            d2 = ((Z[i:i + 500, None, :] - X[None, :, :]) ** 2).sum(-1)
            out[i:i + 500] = y[d2.argmin(1)]
        return out
    return predict


def rel_err(pred, true):
    return float(np.linalg.norm(pred - true) / np.linalg.norm(true))


def run(seeds=(0, 1, 2)):
    theta0, c, t, Y = make_data()
    TH, CC = np.repeat(theta0[:, None], N_T, 1), np.repeat(c[:, None], N_T, 1)
    TT = np.repeat(t[None, :], N_TRAJ, 0)
    X = features(TH, CC, TT)                                # (N_TRAJ, N_T, 3)
    res = {s: {"mlp": [], "1nn": []} for s in SPLITS}
    examples = {}
    for seed in seeds:
        rng = np.random.default_rng(100 + seed)
        for s in SPLITS:
            test = split_masks(s, theta0, t, rng)
            Xtr, ytr, Xte, yte = X[~test], Y[~test], X[test], Y[test]
            mlp = fit_mlp(Xtr, ytr, seed)
            res[s]["mlp"].append(rel_err(mlp(Xte), yte))
            res[s]["1nn"].append(rel_err(fit_1nn(Xtr, ytr)(Xte), yte))
            print("seed %d %-10s  MLP %.3f   1-NN %.3f  (test fraction %.2f)"
                  % (seed, s, res[s]["mlp"][-1], res[s]["1nn"][-1], test.mean()), flush=True)
            if seed == 0 and s in ("temporal", "parameter"):
                j = int(np.argmax(theta0)) if s == "parameter" else int(np.argmin(np.abs(theta0 - 1.5)))
                examples[s] = {"theta0": float(theta0[j]), "c": float(c[j]), "t": t.tolist(),
                               "true": Y[j].tolist(), "mlp": mlp(X[j]).tolist()}
    out = {"errors": res, "examples": examples, "n_traj": N_TRAJ, "n_t": N_T,
           "t_split": T_SPLIT, "theta_split": THETA_SPLIT,
           "n_param_test": int((theta0 > THETA_SPLIT).sum())}
    os.makedirs(os.path.dirname(CACHE), exist_ok=True)
    json.dump(out, open(CACHE, "w"), indent=1)
    return out


def plot(out):
    set_style()
    import matplotlib.pyplot as plt
    fig, axs = plt.subplots(1, 3, figsize=(FULL_WIDTH, 2.25),
                            gridspec_kw={"width_ratios": [1.25, 1, 1]})
    ax = axs[0]
    xs = np.arange(len(SPLITS))
    for off, (m, lab, col) in zip((-0.18, 0.18), (("mlp", "MLP", COLORS["blue"]),
                                                  ("1nn", "1-NN lookup", COLORS["orange"]))):
        v = np.array([out["errors"][s][m] for s in SPLITS])
        ax.bar(xs + off, v.mean(1), 0.34, color=col, label=lab)
        ax.errorbar(xs + off, v.mean(1), yerr=[v.mean(1) - v.min(1), v.max(1) - v.mean(1)],
                    fmt="none", ecolor="k", elinewidth=0.7, capsize=1.5)
    ax.set_yscale("log")
    ax.set_xticks(xs)
    ax.set_xticklabels(["random\npoints", "held-out\ntrajectories", "parameter\nextrap.",
                        "temporal\nextrap."], fontsize=7)
    ax.set_ylabel("measured test error (rel. $L^2$)")
    ax.legend(loc="upper left", fontsize=7)
    ax.set_title("(a) same models, four splits")
    for ax, key, title in ((axs[1], "temporal", "(b) temporal extrapolation"),
                           (axs[2], "parameter", "(c) parameter extrapolation")):
        e = out["examples"][key]
        t = np.array(e["t"])
        ax.plot(t, e["true"], color="k", lw=1.2, label="truth")
        ax.plot(t, e["mlp"], color=COLORS["blue"], lw=1.2, ls="--", label="MLP")
        if key == "temporal":
            ax.axvspan(out["t_split"], t[-1], color=COLORS["red"], alpha=0.10, lw=0)
            ax.text(out["t_split"] + 0.25, 0.04, "test", transform=ax.get_xaxis_transform(),
                    fontsize=7, color=COLORS["red"])
        ax.set_title(title)
        ax.set_xlabel("$t$")
        ax.text(0.97, 0.97, r"$\theta_0=%.2f,\ c=%.2f$" % (e["theta0"], e["c"]),
                transform=ax.transAxes, ha="right", va="top", fontsize=7)
    axs[1].set_ylabel(r"$\theta(t)$")
    axs[2].legend(loc="lower left", fontsize=7, ncol=2, bbox_to_anchor=(0.0, -0.02))
    axs[2].set_ylim(-2.6, 3.4)
    fig.tight_layout(w_pad=0.6)
    savefig(fig, "ch18", "split_errors")


if __name__ == "__main__":
    out = json.load(open(CACHE)) if os.path.exists(CACHE) and "--rerun" not in sys.argv else run()
    for s in SPLITS:
        print("%-10s MLP %.3f  1-NN %.3f" % (s, np.mean(out["errors"][s]["mlp"]),
                                            np.mean(out["errors"][s]["1nn"])))
    plot(out)

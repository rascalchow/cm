"""Shared Matplotlib style for all figures in the book.

Usage (from a script in code/chNN/):
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
    from plotstyle import set_style, COLORS, savefig, FULL_WIDTH, HALF_WIDTH
    set_style()
    fig, ax = plt.subplots(figsize=(FULL_WIDTH, 2.6))
    ...
    savefig(fig, "ch07", "dmd_spectrum")   # -> figures/ch07/dmd_spectrum.pdf
"""
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

# Colours match the LaTeX palette defined in preamble.tex
COLORS = {
    "blue": "#1F4E79",
    "orange": "#B5520B",
    "green": "#2E6B30",
    "red": "#9B1C1C",
    "gray": "#555555",
    "purple": "#5B3A8C",
    "teal": "#1B7A7A",
    "gold": "#B08900",
}
CYCLE = [COLORS[k] for k in ("blue", "orange", "green", "red", "purple", "teal", "gold", "gray")]

FULL_WIDTH = 6.2   # inches; include with width=\textwidth
HALF_WIDTH = 3.0   # inches; include with width=0.48\textwidth


def set_style():
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["STIXGeneral", "DejaVu Serif"],
        "mathtext.fontset": "stix",
        "font.size": 9,
        "axes.titlesize": 9,
        "axes.labelsize": 9,
        "legend.fontsize": 8,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "axes.prop_cycle": matplotlib.cycler(color=CYCLE),
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.7,
        "lines.linewidth": 1.4,
        "lines.markersize": 4,
        "legend.frameon": False,
        "figure.dpi": 150,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.03,
        "image.cmap": "RdBu_r",
        "pdf.fonttype": 42,
    })


def savefig(fig, chapter, name):
    out = os.path.join(ROOT, "figures", chapter)
    os.makedirs(out, exist_ok=True)
    path = os.path.join(out, name + ".pdf")
    fig.savefig(path)
    plt.close(fig)
    return path

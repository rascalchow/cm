"""Reference solvers and data generators shared by all chapters.

Every function is deterministic given its `seed` argument, depends only on
NumPy/SciPy, and has been verified against analytical solutions or
convergence tests (see `python3 code/common/sciml_data.py`).

Contents
--------
ODEs
    lorenz63(x0, t_eval, sigma, rho, beta)          Lorenz (1963) system
    pendulum(x0, t_eval, damping)                    (damped) pendulum
    lotka_volterra(x0, t_eval, alpha, beta, gamma, delta)
    duffing(x0, t_eval, delta, alpha, beta)
    lorenz96(x0, t_eval, F)                          single-scale Lorenz-96
    integrate(f, x0, t_eval)                         generic tight-tolerance RK45 / DOP853
PDEs (periodic, pseudo-spectral ETDRK4; Kassam & Trefethen 2005)
    etdrk4_periodic(u0, L, N, dt, t_save)            generic semilinear solver
    burgers_periodic(u0, nu, L, t_save, dt)          u_t + u u_x = nu u_xx
    burgers_pinn_reference(nx, nt)                   classic PINN benchmark (nu = 0.01/pi)
    allen_cahn_reference(nx, nt)                     u_t = 1e-4 u_xx + 5u - 5u^3
    kuramoto_sivashinsky(u0, L, t_save, dt)          u_t + u u_x + u_xx + u_xxxx = 0
    heat_fd(u0, kappa, x, t_save)                    1D heat equation, Dirichlet BCs (Crank-Nicolson)
Random fields and elliptic problems
    grf_1d(n_samples, nx, alpha, tau, sigma, seed)   periodic Gaussian random fields on [0, 1)
    grf_2d(n_samples, n, alpha, tau, seed)           periodic GRFs on [0, 1)^2
    darcy_2d(a)                                      -div(a grad u) = 1, u = 0 on boundary
    burgers_operator_dataset(n, nx, nu, T, seed)     (u0, u(T)) pairs as in Li et al. (2021)
"""
import numpy as np
from scipy.integrate import solve_ivp
import scipy.sparse as sp
import scipy.sparse.linalg as spla


# =============================================================== ODEs

def integrate(f, x0, t_eval, method="DOP853", rtol=1e-10, atol=1e-12):
    """Integrate x' = f(t, x) and return an array of shape (len(t_eval), dim)."""
    sol = solve_ivp(f, (t_eval[0], t_eval[-1]), np.asarray(x0, float), t_eval=t_eval,
                    method=method, rtol=rtol, atol=atol)
    if not sol.success:
        raise RuntimeError(sol.message)
    return sol.y.T


def lorenz63(x0=(-8.0, 8.0, 27.0), t_eval=None, sigma=10.0, rho=28.0, beta=8.0 / 3.0):
    t_eval = np.arange(0, 10, 0.002) if t_eval is None else t_eval

    def f(t, x):
        return [sigma * (x[1] - x[0]), x[0] * (rho - x[2]) - x[1], x[0] * x[1] - beta * x[2]]
    return integrate(f, x0, t_eval)


def pendulum(x0=(1.0, 0.0), t_eval=None, damping=0.0, omega0=1.0):
    """theta'' + damping * theta' + omega0^2 sin(theta) = 0; state (theta, theta')."""
    t_eval = np.linspace(0, 20, 2001) if t_eval is None else t_eval

    def f(t, x):
        return [x[1], -damping * x[1] - omega0 ** 2 * np.sin(x[0])]
    return integrate(f, x0, t_eval)


def lotka_volterra(x0=(1.0, 1.0), t_eval=None, alpha=1.3, beta=0.9, gamma=0.8, delta=1.8):
    """x' = alpha x - beta x y,  y' = gamma x y - delta y (Rackauckas et al. 2020 parameters)."""
    t_eval = np.linspace(0, 10, 201) if t_eval is None else t_eval

    def f(t, z):
        x, y = z
        return [alpha * x - beta * x * y, gamma * x * y - delta * y]
    return integrate(f, x0, t_eval)


def duffing(x0=(1.0, 0.0), t_eval=None, delta=0.0, alpha=-1.0, beta=1.0):
    """x'' + delta x' + alpha x + beta x^3 = 0 (unforced)."""
    t_eval = np.linspace(0, 20, 2001) if t_eval is None else t_eval

    def f(t, z):
        return [z[1], -delta * z[1] - alpha * z[0] - beta * z[0] ** 3]
    return integrate(f, x0, t_eval)


def lorenz96(x0=None, t_eval=None, F=8.0, K=40, seed=0):
    """dx_k/dt = (x_{k+1} - x_{k-2}) x_{k-1} - x_k + F, periodic in k."""
    rng = np.random.default_rng(seed)
    x0 = F + 0.01 * rng.standard_normal(K) if x0 is None else np.asarray(x0, float)
    t_eval = np.arange(0, 20, 0.01) if t_eval is None else t_eval

    def f(t, x):
        return (np.roll(x, -1) - np.roll(x, 2)) * np.roll(x, 1) - x + F
    return integrate(f, x0, t_eval, rtol=1e-9, atol=1e-11)


# =============================================================== periodic spectral PDE solvers

def wavenumbers(n, length):
    return 2.0 * np.pi * np.fft.fftfreq(n, d=length / n)


def _etdrk4_coeffs(Lh, dt, m=32):
    """Kassam & Trefethen (2005) contour-integral evaluation of the phi functions."""
    E = np.exp(dt * Lh)
    E2 = np.exp(dt * Lh / 2)
    r = np.exp(1j * np.pi * (np.arange(1, m + 1) - 0.5) / m)
    LR = dt * Lh[:, None] + r[None, :]
    Q = dt * np.real(np.mean((np.exp(LR / 2) - 1) / LR, axis=1))
    f1 = dt * np.real(np.mean((-4 - LR + np.exp(LR) * (4 - 3 * LR + LR ** 2)) / LR ** 3, axis=1))
    f2 = dt * np.real(np.mean((2 + LR + np.exp(LR) * (-2 + LR)) / LR ** 3, axis=1))
    f3 = dt * np.real(np.mean((-4 - 3 * LR - LR ** 2 + np.exp(LR) * (4 - LR)) / LR ** 3, axis=1))
    return E, E2, Q, f1, f2, f3


def etdrk4_periodic(u0, Lh, Nfun, dt, t_save):
    """Solve u_t = L u + N(u) with L diagonal in Fourier space.

    u0     : initial condition on a uniform periodic grid (real array, length n)
    Lh     : Fourier symbol of L (array of length n, ordering as np.fft.fft)
    Nfun   : function mapping v_hat = fft(u) -> fft(N(u))
    t_save : increasing times (t_save[0] must be 0) at which to store the solution
    Returns array of shape (len(t_save), n).
    """
    Lh = np.asarray(Lh, dtype=float)
    E, E2, Q, f1, f2, f3 = _etdrk4_coeffs(Lh, dt)
    v = np.fft.fft(u0)
    out = [np.real(np.fft.ifft(v))]
    t = 0.0
    for ts in t_save[1:]:
        nsteps = int(round((ts - t) / dt))
        if abs(nsteps * dt - (ts - t)) > 1e-9 * max(1.0, ts):
            raise ValueError("t_save must be multiples of dt")
        for _ in range(nsteps):
            Nv = Nfun(v)
            a = E2 * v + Q * Nv
            Na = Nfun(a)
            b = E2 * v + Q * Na
            Nb = Nfun(b)
            c = E2 * a + Q * (2 * Nb - Nv)
            Nc = Nfun(c)
            v = E * v + Nv * f1 + 2 * (Na + Nb) * f2 + Nc * f3
        t = ts
        out.append(np.real(np.fft.ifft(v)))
    return np.array(out)


def _dealias_mask(n):
    k = np.fft.fftfreq(n, d=1.0 / n)
    return (np.abs(k) < n / 3).astype(float)


def burgers_periodic(u0, nu, length=2 * np.pi, t_save=None, dt=1e-3):
    """Viscous Burgers u_t + (u^2/2)_x = nu u_xx on a periodic domain of given length."""
    n = len(u0)
    k = wavenumbers(n, length)
    mask = _dealias_mask(n)
    t_save = np.linspace(0, 1, 11) if t_save is None else t_save

    def Nfun(v):
        u = np.real(np.fft.ifft(v * mask))
        return -0.5j * k * np.fft.fft(u * u) * mask
    return etdrk4_periodic(u0, -nu * k ** 2, Nfun, dt, t_save)


def burgers_pinn_reference(nx=512, nt=101, nu=0.01 / np.pi, dt=2.5e-5):
    """Reference solution of the classic PINN benchmark (Raissi et al. 2019):
        u_t + u u_x = nu u_xx,  x in [-1, 1],  t in [0, 1],
        u(0, x) = -sin(pi x),   u(t, -1) = u(t, 1) = 0.
    The odd, 2-periodic extension makes a periodic spectral solver exact.
    Returns x (nx,), t (nt,), U (nt, nx) on x = linspace(-1, 1, nx, endpoint=False).
    """
    x = np.linspace(-1, 1, nx, endpoint=False)
    t = np.linspace(0, 1, nt)
    U = burgers_periodic(-np.sin(np.pi * x), nu, length=2.0, t_save=t, dt=dt)
    return x, t, U


def allen_cahn_reference(nx=512, nt=201, eps=1e-4, dt=1e-4):
    """u_t = eps u_xx + 5u - 5u^3, x in [-1,1] periodic, u0 = x^2 cos(pi x), t in [0,1]."""
    x = np.linspace(-1, 1, nx, endpoint=False)
    t = np.linspace(0, 1, nt)
    k = wavenumbers(nx, 2.0)

    def Nfun(v):
        u = np.real(np.fft.ifft(v))
        return np.fft.fft(-5.0 * u ** 3)
    U = etdrk4_periodic(x ** 2 * np.cos(np.pi * x), -eps * k ** 2 + 5.0, Nfun, dt, t)
    return x, t, U


def kuramoto_sivashinsky(u0=None, length=32 * np.pi, n=128, t_save=None, dt=0.25):
    """u_t + u u_x + u_xx + u_xxxx = 0, periodic (Kassam & Trefethen 2005 setup)."""
    x = length * np.arange(n) / n
    if u0 is None:
        u0 = np.cos(x / 16) * (1 + np.sin(x / 16))
    k = wavenumbers(n, length)
    t_save = np.arange(0, 150 + 1e-9, 0.5) if t_save is None else t_save

    def Nfun(v):
        u = np.real(np.fft.ifft(v))
        return -0.5j * k * np.fft.fft(u * u)
    return x, etdrk4_periodic(u0, k ** 2 - k ** 4, Nfun, dt, t_save)


def heat_fd(u0, kappa, x, t_save, dt=None):
    """u_t = (kappa(x) u_x)_x on [x0, x1] with u = 0 at both ends; Crank-Nicolson.

    u0, kappa: arrays on the full grid x (including boundary nodes); kappa may be scalar.
    """
    x = np.asarray(x, float)
    n = len(x)
    h = x[1] - x[0]
    kap = np.full(n, kappa, float) if np.isscalar(kappa) else np.asarray(kappa, float)
    kf = 0.5 * (kap[:-1] + kap[1:])                     # face values
    main = -(kf[:-1] + kf[1:]) / h ** 2
    A = sp.diags([kf[1:-1] / h ** 2, main, kf[1:-1] / h ** 2], [-1, 0, 1], format="csc")
    dt = (t_save[1] - t_save[0]) / 20 if dt is None else dt
    Id = sp.identity(n - 2, format="csc")
    lhs = spla.factorized((Id - 0.5 * dt * A).tocsc())
    rhs = (Id + 0.5 * dt * A).tocsc()
    u = np.asarray(u0, float)[1:-1].copy()
    out = [np.concatenate([[0.0], u, [0.0]])]
    t = 0.0
    for ts in t_save[1:]:
        m = int(round((ts - t) / dt))
        for _ in range(m):
            u = lhs(rhs @ u)
        t = ts
        out.append(np.concatenate([[0.0], u, [0.0]]))
    return np.array(out)


# =============================================================== random fields & operator data

def grf_1d(n_samples, nx=1024, alpha=2.0, tau=5.0, sigma=25.0, seed=0):
    """Periodic GRF on [0,1) with covariance sigma^2 (-Laplacian + tau^2 I)^(-alpha).

    The defaults reproduce mu_0 = N(0, 625 (-Delta + 25 I)^(-2)) used for the
    Burgers benchmark of Li et al. (2021).
    """
    rng = np.random.default_rng(seed)
    k = np.fft.fftfreq(nx, d=1.0 / nx)
    sqrt_eig = sigma * ((2 * np.pi * k) ** 2 + tau ** 2) ** (-alpha / 2.0)
    # Karhunen-Loeve: u(x) = Re sum_k sqrt(lambda_k) zeta_k exp(2 pi i k x), zeta_k complex N(0,1)+iN(0,1)
    zeta = rng.standard_normal((n_samples, nx)) + 1j * rng.standard_normal((n_samples, nx))
    u = np.real(np.fft.ifft(sqrt_eig * zeta, axis=1)) * nx
    return u


def grf_2d(n_samples, n=64, alpha=2.0, tau=3.0, seed=0):
    """Periodic GRF on [0,1)^2 with covariance (-Laplacian + tau^2 I)^(-alpha) (unnormalised)."""
    rng = np.random.default_rng(seed)
    k = np.fft.fftfreq(n, d=1.0 / n)
    K1, K2 = np.meshgrid(k, k, indexing="ij")
    sqrt_eig = tau ** (alpha - 1) * (4 * np.pi ** 2 * (K1 ** 2 + K2 ** 2) + tau ** 2) ** (-alpha / 2.0)
    xi = rng.standard_normal((n_samples, n, n))
    return np.real(np.fft.ifft2(sqrt_eig * np.fft.fft2(xi), axes=(1, 2))) * n


def darcy_2d(a, f=1.0):
    """Solve -div(a grad u) = f on (0,1)^2, u = 0 on the boundary.

    a : (n, n) array of cell-centred permeabilities on the interior nodes grid.
    Uses a 5-point finite-volume stencil with harmonic face averages.
    Returns u on the same (n, n) interior grid (boundary values are zero).
    """
    n = a.shape[0]
    h = 1.0 / (n + 1)
    ap = np.pad(a, 1, mode="edge")

    def hm(p, q):
        return 2 * p * q / (p + q)
    aE = hm(ap[1:-1, 1:-1], ap[2:, 1:-1])
    aW = hm(ap[1:-1, 1:-1], ap[:-2, 1:-1])
    aN = hm(ap[1:-1, 1:-1], ap[1:-1, 2:])
    aS = hm(ap[1:-1, 1:-1], ap[1:-1, :-2])
    idx = np.arange(n * n).reshape(n, n)
    rows, cols, vals = [idx.ravel()], [idx.ravel()], [(aE + aW + aN + aS).ravel()]
    for coef, di, dj in ((aE, 1, 0), (aW, -1, 0), (aN, 0, 1), (aS, 0, -1)):
        I, J = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
        I2, J2 = I + di, J + dj
        ok = (I2 >= 0) & (I2 < n) & (J2 >= 0) & (J2 < n)
        rows.append(idx[ok])
        cols.append(idx[I2[ok], J2[ok]])
        vals.append(-coef[ok])
    A = sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                      shape=(n * n, n * n)) / h ** 2
    rhs = np.full(n * n, f, float) if np.isscalar(f) else np.asarray(f, float).ravel()
    return spla.spsolve(A.tocsc(), rhs).reshape(n, n)


def darcy_dataset(n_samples=200, n=63, seed=0, a_plus=12.0, a_minus=3.0):
    """Piecewise-constant permeability a = 12 or 3 from thresholded GRFs (Li et al. 2021 style)."""
    g = grf_2d(n_samples, n=n, alpha=2.0, tau=3.0, seed=seed)
    A = np.where(g >= 0, a_plus, a_minus)
    U = np.stack([darcy_2d(ai) for ai in A])
    return A, U


def burgers_operator_dataset(n_samples=200, nx=256, nu=0.1, T=1.0, seed=0, dt=1e-3, nx_solve=1024):
    """Pairs (u0, u(T)) for Burgers on the periodic domain [0, 1) (Li et al. 2021 setting).

    Fields are solved on nx_solve points and subsampled to nx points.
    """
    u0 = grf_1d(n_samples, nx=nx_solve, seed=seed)
    uT = np.empty_like(u0)
    for i in range(n_samples):
        uT[i] = burgers_periodic(u0[i], nu, length=1.0, t_save=np.array([0.0, T]), dt=dt)[-1]
    s = nx_solve // nx
    return u0[:, ::s], uT[:, ::s]


# =============================================================== self-tests

def _self_test():
    # 1. heat equation with constant kappa vs exact sine mode
    x = np.linspace(0, 1, 201)
    t = np.linspace(0, 0.1, 6)
    U = heat_fd(np.sin(np.pi * x), 1.0, x, t, dt=1e-4)
    err = np.max(np.abs(U[-1] - np.exp(-np.pi ** 2 * t[-1]) * np.sin(np.pi * x)))
    print("heat_fd max error vs exact:", err)
    assert err < 1e-4

    # 2. linear advection-diffusion through ETDRK4 (N = 0) is exact
    n = 64
    xx = 2 * np.pi * np.arange(n) / n
    k = wavenumbers(n, 2 * np.pi)
    U = etdrk4_periodic(np.sin(3 * xx), -0.1 * k ** 2, lambda v: 0 * v, 0.01, np.array([0, 1.0]))
    err = np.max(np.abs(U[-1] - np.exp(-0.9) * np.sin(3 * xx)))
    print("ETDRK4 linear test error:", err)
    assert err < 1e-10

    # 3. Burgers: Cole-Hopf exact solution for u0 = 2 nu * (sin x) / (a + cos x) style
    nu = 0.1
    a = 2.0
    n = 256
    xx = 2 * np.pi * np.arange(n) / n

    def exact(tt):
        # phi = a + exp(-nu t) cos x solves heat eq; u = -2 nu phi_x / phi
        phi = a + np.exp(-nu * tt) * np.cos(xx)
        phix = -np.exp(-nu * tt) * np.sin(xx)
        return -2 * nu * phix / phi
    U = burgers_periodic(exact(0.0), nu, 2 * np.pi, np.array([0, 1.0]), dt=1e-3)
    err = np.max(np.abs(U[-1] - exact(1.0)))
    print("Burgers vs Cole-Hopf error:", err)
    assert err < 1e-8

    # 4. PINN Burgers reference: value at the shock location is 0 and steep gradient forms
    xr, tr, Ur = burgers_pinn_reference(nx=512, nt=11)
    print("PINN-Burgers reference: max|u(t=1)| = %.4f, max|u_x(t=1)| = %.1f"
          % (np.abs(Ur[-1]).max(), np.abs(np.gradient(Ur[-1], xr)).max()))

    # 5. Lorenz and Darcy smoke tests
    L = lorenz63(t_eval=np.linspace(0, 1, 101))
    print("Lorenz final state:", L[-1])
    A, Ud = darcy_dataset(2, n=31)
    print("Darcy max u:", Ud.max())
    g = grf_1d(2000, nx=256)
    print("GRF pointwise std (Burgers prior):", g.std())
    print("all self-tests passed")


if __name__ == "__main__":
    _self_test()

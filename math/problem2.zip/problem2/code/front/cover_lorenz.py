"""Cover decoration: a Lorenz-63 trajectory (x-z projection) drawn in white."""
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "common"))
from sciml_data import lorenz63  # noqa: E402

t = np.arange(0, 60, 0.005)
X = lorenz63(x0=(-8.0, 8.0, 27.0), t_eval=t)
fig = plt.figure(figsize=(3.2, 2.0))
ax = fig.add_axes([0, 0, 1, 1])
ax.plot(X[:, 0], X[:, 2], color="white", lw=0.35, alpha=0.75)
ax.set_axis_off()
out = os.path.join(os.path.dirname(__file__), "..", "..", "figures", "front")
os.makedirs(out, exist_ok=True)
fig.savefig(os.path.join(out, "cover_lorenz.pdf"), transparent=True)
print("saved")

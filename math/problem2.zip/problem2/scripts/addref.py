#!/usr/bin/env python3
"""Add a *verified* reference to the bibliography, or look up existing keys.

Every entry is generated from authoritative metadata (Crossref / arXiv /
PMLR / NeurIPS / JMLR indexes); nothing is typed by hand.

Examples
  # search the existing bibliography (core + additions) by keyword
  python3 scripts/addref.py --lookup "operator inference"

  # add by DOI (journal articles, books, chapters)
  python3 scripts/addref.py --chapter 07 --doi 10.1017/jfm.2018.283

  # add an arXiv paper, optionally with a verified venue
  python3 scripts/addref.py --chapter 13 --arxiv 2010.08895 --iclr 2021
  python3 scripts/addref.py --chapter 13 --arxiv 1806.07366 --neurips 2018
  python3 scripts/addref.py --chapter 13 --arxiv 2002.09405 --icml 2020
  python3 scripts/addref.py --chapter 13 --arxiv 2108.08481 --jmlr 24

  # find a DOI by title when you do not know it
  python3 scripts/addref.py --chapter 07 --search "Spectral proper orthogonal decomposition" --author Towne --year 2018

The command prints the citation key to use with \\citet{} / \\citep{}.
If the work is already in the bibliography, the existing key is printed.
"""
import argparse
import fcntl
import glob
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import bibtool as bt  # noqa: E402
import build_core_bib as bcb  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BIBDIR = os.path.join(ROOT, "bib")


def parse_bib(text):
    out = []
    for m in re.finditer(r"@(\w+)\{([^,]+),(.*?)\n\}", text, flags=re.S):
        body = m.group(3)
        f = dict(re.findall(r"^\s*(\w+)\s*=\s*\{(.*)\},?\s*$", body, flags=re.M))
        out.append(dict(type=m.group(1), key=m.group(2).strip(), **{k.lower(): v for k, v in f.items()}))
    return out


def all_entries():
    ents = []
    for p in sorted(glob.glob(os.path.join(BIBDIR, "*.bib"))):
        with open(p) as fh:
            for e in parse_bib(fh.read()):
                e["_file"] = os.path.basename(p)
                ents.append(e)
    return ents


def existing_key(doi=None, eprint=None, key=None):
    for e in all_entries():
        if doi and e.get("doi", "").lower() == doi.lower():
            return e["key"]
        if eprint and e.get("eprint", "") == eprint:
            return e["key"]
        if key and e["key"] == key:
            return e["key"]
    return None


def unique_key(k):
    keys = {e["key"] for e in all_entries()}
    if k not in keys:
        return k
    for suf in "bcdefghijk":
        if k + suf not in keys:
            return k + suf
    raise SystemExit("could not create unique key")


def append(chapter, bib):
    path = os.path.join(BIBDIR, "added_ch%s.bib" % chapter)
    with open(path, "a") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        fh.write("\n" + bib + "\n")
        fcntl.flock(fh, fcntl.LOCK_UN)


def first_family_crossref(msg):
    a = (msg.get("author") or msg.get("editor") or [{}])[0]
    return a.get("family") or a.get("name") or "anon"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lookup")
    ap.add_argument("--chapter")
    ap.add_argument("--doi")
    ap.add_argument("--arxiv")
    ap.add_argument("--search")
    ap.add_argument("--author")
    ap.add_argument("--year", type=int)
    ap.add_argument("--key")
    ap.add_argument("--neurips", type=int)
    ap.add_argument("--icml", type=int)
    ap.add_argument("--pmlr", type=int, help="PMLR volume (e.g. AISTATS)")
    ap.add_argument("--iclr", type=int)
    ap.add_argument("--jmlr", type=int)
    a = ap.parse_args()

    if a.lookup:
        words = a.lookup.lower().split()
        for e in all_entries():
            hay = (e["key"] + " " + e.get("title", "") + " " + e.get("author", "")).lower()
            if all(w in hay for w in words):
                print("%-34s %s | %s | %s" % (e["key"], e.get("year", ""), e.get("author", "")[:50], e.get("title", "")[:90]))
        return

    if not a.chapter:
        sys.exit("--chapter NN is required when adding references")
    a.chapter = "%02d" % int(a.chapter) if a.chapter.isdigit() else a.chapter

    if a.search:
        items = bt.crossref_search(a.search, a.author, rows=8)
        for it in items:
            t = " ".join(it.get("title", [""]))
            y = bt.year_of(it, False)
            if bt.title_matches(a.search, t) and (a.year is None or (y and abs(int(y) - a.year) <= 1)):
                a.doi = it["DOI"]
                print("search resolved to DOI %s: %s (%s)" % (a.doi, t, y))
                break
        else:
            print("No confident match. Candidates:")
            for it in items[:6]:
                print("  ", it.get("DOI"), "|", " ".join(it.get("title", [""]))[:100], "|", bt.year_of(it, False))
            sys.exit(1)

    if a.doi:
        k = existing_key(doi=a.doi)
        if k:
            print("ALREADY PRESENT: \\cite{%s}" % k)
            return
        msg = bt.crossref_work(a.doi)
        title = " ".join(msg.get("title", [""]))
        key = a.key or bt.make_key(first_family_crossref(msg), bt.year_of(msg, True) or "", title)
        key = unique_key(key)
        flags = []
        bib, t = bt.bib_from_crossref(key, msg, {}, flags)
        append(a.chapter, bib)
        print(bib)
        if flags:
            print("% notes:", "; ".join(flags))
        print("ADDED: \\cite{%s}" % key)
        return

    if a.arxiv:
        aid = re.sub(r"v\d+$", "", a.arxiv)
        k = existing_key(eprint=aid)
        if k:
            print("ALREADY PRESENT: \\cite{%s}" % k)
            return
        meta = bt.arxiv_batch([aid]).get(aid)
        if not meta:
            sys.exit("arXiv id not found")
        rep, over = [], {}
        venue = None
        if a.neurips:
            venue = ("neurips", a.neurips)
        elif a.icml:
            venue = bcb_icml(a.icml)
        elif a.pmlr:
            venue = ("pmlr", a.pmlr)
        elif a.jmlr:
            venue = ("jmlr", a.jmlr)
        if venue:
            vo, ok = bcb.apply_venue(venue, meta["title"], rep)
            if not ok:
                sys.exit("Venue could not be verified: %s. Re-run without the venue flag to cite the arXiv version." % rep)
            over.update(vo)
        if a.iclr:
            c = meta.get("comment", "") + " " + (meta.get("journal_ref") or "")
            if "ICLR" not in c and "Learning Representations" not in c:
                print("WARNING: arXiv comment does not mention ICLR; double-check the venue (comment: %r)" % c[:100])
            over.update(type="inproceedings", booktitle="International Conference on Learning Representations (ICLR)",
                        year=str(a.iclr))
        fam = meta["authors"][0].split()[-1] if meta["authors"] else "anon"
        key = a.key or bt.make_key(fam, over.get("year", meta["year"]), meta["title"])
        key = unique_key(key)
        bib, _ = bt.bib_from_arxiv(key, aid, meta, over, rep)
        append(a.chapter, bib)
        print(bib)
        print("ADDED: \\cite{%s}" % key)
        return
    ap.print_help()


def bcb_icml(year):
    from core_sources import ICML
    return ICML(year)


if __name__ == "__main__":
    main()

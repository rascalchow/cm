#!/usr/bin/env python3
"""Audit citations across the book.

Reports, per chapter/appendix: number of citation commands and distinct keys,
keys missing from references.bib, and, for the cited entries, how each was
verified (DOI via Crossref, arXiv identifier, or a manually verified classic).
"""
import glob
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from addref import parse_bib  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CITE = re.compile(r"\\(?:cite|citet|citep|citealt|citealp|citeauthor|citeyear|nocite)\*?(?:\[[^\]]*\]){0,2}\{([^}]*)\}")


def main():
    bib = {e["key"]: e for e in parse_bib(open(os.path.join(ROOT, "references.bib")).read())}
    files = sorted(glob.glob(os.path.join(ROOT, "chapters", "*.tex"))) + \
        sorted(glob.glob(os.path.join(ROOT, "appendices", "*.tex"))) + \
        sorted(glob.glob(os.path.join(ROOT, "frontmatter", "*.tex")))
    all_keys = set()
    missing_total = 0
    print("%-36s %6s %6s %s" % ("file", "cites", "keys", "missing"))
    for f in files:
        text = open(f).read()
        text = re.sub(r"(?<!\\)%.*", "", text)
        keys = [k.strip() for m in CITE.finditer(text) for k in m.group(1).split(",") if k.strip()]
        distinct = set(keys)
        all_keys |= distinct
        missing = sorted(k for k in distinct if k not in bib)
        missing_total += len(missing)
        print("%-36s %6d %6d %s" % (os.path.relpath(f, ROOT), len(keys), len(distinct), " ".join(missing)))
    kinds = {"doi": 0, "arxiv": 0, "other": []}
    for k in sorted(all_keys):
        e = bib.get(k)
        if not e:
            continue
        if e.get("doi"):
            kinds["doi"] += 1
        elif e.get("eprint"):
            kinds["arxiv"] += 1
        else:
            kinds["other"].append(k)
    print("\ndistinct works cited: %d  (with DOI: %d, arXiv id: %d, other verified: %d)"
          % (len(all_keys), kinds["doi"], kinds["arxiv"], len(kinds["other"])))
    print("cited without DOI/arXiv:", " ".join(kinds["other"]))
    print("missing keys in total:", missing_total)


if __name__ == "__main__":
    main()

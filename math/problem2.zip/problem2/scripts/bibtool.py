"""Bibliography tooling for the Scientific Machine Learning textbook.

Every BibTeX entry is generated from authoritative metadata:
  * Crossref (https://api.crossref.org) for anything with a DOI,
  * the arXiv API for preprints and for conference papers without DOIs,
  * Open Library (ISBN lookup) to confirm the titles of books without DOIs.
The expected title supplied by the author is compared against the fetched
title, and mismatches are reported so that no citation is entered from memory.
"""
import difflib
import json
import re
import time
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

UA = "SciML-Textbook-BibBuilder/1.0 (bibliography verification script)"

# ---------------------------------------------------------------------------
# HTTP helpers
# ---------------------------------------------------------------------------

import hashlib
import os as _os
_CACHE = _os.path.join(_os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))), "build", "httpcache")


def http_get(url, accept=None, retries=5, timeout=40):
    _os.makedirs(_CACHE, exist_ok=True)
    cpath = _os.path.join(_CACHE, hashlib.sha1((url + str(accept)).encode()).hexdigest())
    if _os.path.exists(cpath):
        with open(cpath, encoding="utf-8") as fh:
            return fh.read()
    text = _http_get(url, accept, retries, timeout)
    with open(cpath, "w", encoding="utf-8") as fh:
        fh.write(text)
    return text


def _http_get(url, accept=None, retries=5, timeout=40):
    last = None
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA})
            if accept:
                req.add_header("Accept", accept)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.read().decode("utf-8", errors="replace")
        except urllib.error.HTTPError as e:
            last = e
            if e.code == 404:
                raise
            time.sleep((8.0 if e.code == 429 else 2.0) * (attempt + 1))
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2.0 * (attempt + 1))
    raise last


def crossref_work(doi):
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="/()<>;:.-_")
    return json.loads(http_get(url))["message"]


def crossref_search(title, author=None, rows=5):
    q = {"query.bibliographic": title, "rows": str(rows)}
    if author:
        q["query.author"] = author
    url = "https://api.crossref.org/works?" + urllib.parse.urlencode(q)
    return json.loads(http_get(url))["message"]["items"]


ATOM = "{http://www.w3.org/2005/Atom}"


def arxiv_batch(ids):
    """Return {arxiv_id: {'title','authors','year','doi','journal_ref'}}."""
    out = {}
    ids = list(ids)
    for i in range(0, len(ids), 50):
        chunk = ids[i:i + 50]
        url = ("https://export.arxiv.org/api/query?max_results=100&id_list="
               + ",".join(chunk))
        xml = http_get(url, timeout=90)
        root = ET.fromstring(xml)
        for entry in root.findall(ATOM + "entry"):
            aid = entry.find(ATOM + "id").text.strip().split("/abs/")[-1]
            aid = re.sub(r"v\d+$", "", aid)
            title = " ".join(entry.find(ATOM + "title").text.split())
            authors = [" ".join(a.find(ATOM + "name").text.split())
                       for a in entry.findall(ATOM + "author")]
            year = entry.find(ATOM + "published").text[:4]
            doi = entry.find("{http://arxiv.org/schemas/atom}doi")
            jref = entry.find("{http://arxiv.org/schemas/atom}journal_ref")
            com = entry.find("{http://arxiv.org/schemas/atom}comment")
            out[aid] = {"title": title, "authors": authors, "year": year,
                        "doi": doi.text.strip() if doi is not None else None,
                        "journal_ref": jref.text.strip() if jref is not None else None,
                        "comment": " ".join(com.text.split()) if com is not None else ""}
        time.sleep(3.0)
    return out


def openlibrary_isbn(isbn):
    url = "https://openlibrary.org/isbn/%s.json" % isbn.replace("-", "")
    d = json.loads(http_get(url))
    t = d.get("title", "")
    if d.get("subtitle"):
        t += ": " + d["subtitle"]
    return {"title": t, "publishers": d.get("publishers", []),
            "publish_date": d.get("publish_date", "")}


# ---------------------------------------------------------------------------
# Text normalisation
# ---------------------------------------------------------------------------

ACCENTS = {"́": "\\'", "̀": "\\`", "̈": '\\"', "̂": "\\^",
           "̃": "\\~", "̌": "\\v", "̧": "\\c", "̄": "\\=",
           "̆": "\\u", "̊": "\\r", "̨": "\\k", "̋": "\\H",
           "̇": "\\."}
SPECIAL = {"ø": "{\\o}", "Ø": "{\\O}", "ß": "{\\ss}", "æ": "{\\ae}", "Æ": "{\\AE}",
           "œ": "{\\oe}", "Œ": "{\\OE}", "ł": "{\\l}", "Ł": "{\\L}", "ı": "{\\i}",
           "đ": "{\\dj}", "Đ": "{\\DJ}",
           "–": "--", "—": "---", "‘": "`", "’": "'",
           "“": "``", "”": "''", " ": "~", " ": "\\,",
           "‐": "-", "‑": "-", "−": "-", "×": "$\\times$",
           "…": "\\ldots{}", "´": "'", "ʼ": "'",
           "ε": "$\\varepsilon$", "ϵ": "$\\epsilon$", "α": "$\\alpha$",
           "β": "$\\beta$", "γ": "$\\gamma$", "δ": "$\\delta$", "λ": "$\\lambda$",
           "μ": "$\\mu$", "π": "$\\pi$", "σ": "$\\sigma$", "θ": "$\\theta$",
           "Φ": "$\\Phi$", "φ": "$\\phi$", "ψ": "$\\psi$", "ω": "$\\omega$",
           "²": "$^2$", "³": "$^3$", "∞": "$\\infty$", "≈": "$\\approx$",
           "→": "$\\to$", "∼": "$\\sim$", "≤": "$\\leq$", "≥": "$\\geq$",
           "ℓ": "$\\ell$", "∈": "$\\in$", "\u200b": "", "\ufeff": "",
           "\u2032": "'", "\u00ae": "", "\u2122": "", "\u00ad": ""}


def to_latex(s, flags=None):
    out = []
    in_math = False
    for ch in unicodedata.normalize("NFC", s):
        if ch == "$":
            in_math = not in_math
            out.append(ch)
            continue
        if ord(ch) < 128:
            out.append(ch)
            continue
        if ch in SPECIAL:
            rep = SPECIAL[ch]
            if in_math and rep.startswith("$") and rep.endswith("$"):
                rep = rep[1:-1] + " "
            out.append(rep)
            continue
        d = unicodedata.normalize("NFD", ch)
        base, marks = d[0], d[1:]
        if marks and ord(base) < 128 and all(m in ACCENTS for m in marks):
            r = "\\i" if base == "i" else ("\\j" if base == "j" else base)
            for m in marks:
                r = "%s{%s}" % (ACCENTS[m], r)
            out.append("{" + r + "}")
        else:
            out.append(ch)
            if flags is not None:
                flags.append("non-ASCII character %r" % ch)
    return "".join(out)


def clean_html(s, flags=None):
    s = s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
    s = re.sub(r"<tex-math[^>]*>\s*\\\((.*?)\\\)\s*</tex-math>", r"$\1$", s, flags=re.S)
    s = re.sub(r"<tex-math[^>]*>\s*(.*?)\s*</tex-math>", r"$\1$", s, flags=re.S)
    s = re.sub(r"<\s*sub\s*>(.*?)<\s*/\s*sub\s*>", r"$_{\1}$", s, flags=re.S)
    s = re.sub(r"<\s*sup\s*>(.*?)<\s*/\s*sup\s*>", r"$^{\1}$", s, flags=re.S)
    if "<mml" in s and flags is not None:
        flags.append("MathML in title")
    s = re.sub(r"<[^>]+>", "", s)
    return " ".join(s.split())


def escape_specials(s):
    """Escape &, %, # and _ outside of $...$ math."""
    parts = re.split(r"(\$[^$]*\$)", s)
    for i, p in enumerate(parts):
        if p.startswith("$") and p.endswith("$") and len(p) > 1:
            continue
        p = re.sub(r"(?<!\\)&", r"\\&", p)
        p = re.sub(r"(?<!\\)%", r"\\%", p)
        p = re.sub(r"(?<!\\)#", r"\\#", p)
        p = re.sub(r"(?<!\\)_", r"\\_", p)
        parts[i] = p
    return "".join(parts)


PROPER = set("""
koopman hamiltonian hamiltonians lagrangian lagrangians fourier gaussian bayesian
lorenz galerkin ritz kalman monte carlo markov euler eulerian runge kutta burgers
taylor hessian hessians jacobian newton krylov langevin chebyshev legendre hermite
wiener askey boltzmann schrodinger earth julia python matlab navier stokes reynolds
kolmogorov hilbert banach sobolev lipschitz laplace laplacian poisson helmholtz darcy
allen cahn kuramoto sivashinsky korteweg vries riemann lyapunov cauchy dirichlet
neumann green bregman nesterov gibbs metropolis hastings bernoulli dirac feynman
noether einstein maxwell bayes kullback leibler wasserstein stein gauss seidel jacobi
arnoldi lanczos tikhonov hadamard picard lax wendroff friedrichs lewy courant
imagenet alphafold graphcast fourcastnet pangu fuxi gencast aurora ecmwf nvidia
google microsoft brownian ornstein uhlenbeck ito stratonovich fokker planck liouville
perron frobenius mori zwanzig kohn sham rayleigh benard karman couette poiseuille
ginzburg landau schmidt gram eckart young moore penrose hopf duffing rossler lotka
volterra michaelis menten fitzhugh nagumo hodgkin huxley kepler newtonian lagrange
hamilton bellman pontryagin frechet kantorovich monge sinkhorn shannon fisher
rademacher vapnik smagorinsky germano boussinesq prandtl rossby kelvin
pytorch tensorflow jax numpy scipy matplotlib python julia fenics dolfin
africa europe american atlantic pacific arctic antarctic nasa
latin hypercube sobol rao cramer kronecker mercer hilbert-schmidt cole hopf turing petrov
levenberg marquardt nystrom karhunen loeve hopfield arnold hodge ising heisenberg fermi hubbard
hilliard pol stuart bayes' cartesian riccati sylvester lie poincare kac feynman-kac koopmanism
english french german chinese copernicus galileo ptolemy
""".split())


def protect_title(title):
    """Brace-protect acronyms, mixed-case words and proper nouns."""
    tokens = re.split(r"(\s+)", title)
    out = []
    for tok in tokens:
        if not tok or tok.isspace() or tok.startswith("$"):
            out.append(tok)
            continue
        core = re.sub(r"[^A-Za-z0-9\-\\{}']", "", tok)
        letters = re.sub(r"[^A-Za-z]", "", core)
        need = False
        if len(letters) > 1 and any(c.isupper() for c in letters[1:]):
            need = True
        if any(c.isdigit() for c in core) and any(c.isalpha() for c in core):
            need = True
        if letters == "I" or re.fullmatch(r"(II|III|IV|VI|VII|VIII|IX|XI|XII)", letters or ""):
            need = True
        for part in re.split(r"[-']", core):
            p = re.sub(r"[^A-Za-z]", "", part)
            if p and p[0].isupper() and p.lower() in PROPER:
                need = True
        if "\\" in tok:  # accented proper names such as Schr{\"o}dinger
            if re.search(r"[A-Z]", tok[:3]):
                need = True
        if need:
            m = re.match(r"^([\(\[\"`']*)(.*?)([\)\]\.,:;\?!\"']*)$", tok)
            pre, mid, post = m.group(1), m.group(2), m.group(3)
            out.append("%s{%s}%s" % (pre, mid, post))
        else:
            out.append(tok)
    s = "".join(out)
    # math segments must be protected as well
    s = re.sub(r"(?<!\{)(\$[^$]+\$)", r"{\1}", s)
    return s


def norm_for_compare(s):
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"\\[a-zA-Z]+", " ", s)
    s = re.sub(r"[^a-z0-9]+", " ", s.lower())
    return " ".join(s.split())


def title_matches(expected, actual):
    a, b = norm_for_compare(expected), norm_for_compare(actual)
    if not a:
        return True
    if a in b:
        return True
    return difflib.SequenceMatcher(None, a, b).ratio() > 0.85


# ---------------------------------------------------------------------------
# BibTeX construction
# ---------------------------------------------------------------------------

PUBLISHER_MAP = {
    "Springer New York": "Springer",
    "Springer Berlin Heidelberg": "Springer",
    "Springer International Publishing": "Springer",
    "Springer Netherlands": "Springer",
    "Springer US": "Springer",
    "Springer Nature Switzerland": "Springer",
    "Springer Science and Business Media LLC": "Springer",
    "Society for Industrial and Applied Mathematics": "SIAM",
    "Society for Industrial & Applied Mathematics (SIAM)": "SIAM",
    "Cambridge University Press": "Cambridge University Press",
    "The MIT Press": "MIT Press",
    "MIT Press": "MIT Press",
    "Chapman and Hall/CRC": "Chapman and Hall/CRC",
    "CRC Press": "CRC Press",
    "Wiley": "Wiley",
    "American Mathematical Society": "American Mathematical Society",
    "Office of Scientific and Technical Information (OSTI)": "U.S. Department of Energy, Office of Scientific and Technical Information",
}


def _fix_case(name):
    letters = [c for c in name if c.isalpha()]
    if len(letters) > 3 and sum(c.isupper() for c in letters) / len(letters) > 0.9:
        return name.title(), True
    return name, False


def _fix_initials(given):
    given = re.sub(r"\.(?=[^\s.\-])", ". ", given)            # "G.E." -> "G. E."
    given = re.sub(r"(^|\s)([A-Z])$", r"\1\2.", given)          # trailing bare initial
    given = re.sub(r"(^|\s)([A-Z])(?=\s)", r"\1\2.", given)    # bare initial inside
    return given


def fmt_person_crossref(p, flags):
    if "family" in p:
        fam_raw, c1 = _fix_case(p["family"])
        giv_raw, c2 = _fix_case(p.get("given", ""))
        if c1 or c2:
            flags.append("ALL-CAPS name normalised: %s, %s" % (fam_raw, giv_raw))
        fam = to_latex(fam_raw, flags)
        giv = to_latex(_fix_initials(giv_raw), flags)
        if " " in fam.strip() and not re.match(r"^(van|von|de|der|den|du|di|da|del|le|la) ", fam):
            fam = "{" + fam + "}"
        return "%s, %s" % (fam, giv) if giv else fam
    if "name" in p:
        return "{" + to_latex(p["name"], flags) + "}"
    return None


def year_of(msg, prefer_print=True):
    keys = ["published-print", "issued", "published-online", "published", "created"]
    if not prefer_print:
        keys = ["issued", "published-print", "published-online", "published", "created"]
    for k in keys:
        dp = msg.get(k, {}).get("date-parts")
        if dp and dp[0] and dp[0][0]:
            return str(dp[0][0])
    return None


def field_block(entry_type, key, fields):
    order = ["author", "editor", "title", "journal", "booktitle", "series",
             "edition", "volume", "number", "pages", "publisher", "school",
             "institution", "organization", "address", "howpublished", "year",
             "month", "isbn", "doi", "eprint", "archiveprefix", "url", "note"]
    lines = ["@%s{%s," % (entry_type, key)]
    for f in order:
        v = fields.get(f)
        if v:
            lines.append("  %s = {%s}," % (f, v))
    for f, v in fields.items():
        if f not in order and v:
            lines.append("  %s = {%s}," % (f, v))
    lines[-1] = lines[-1].rstrip(",")
    lines.append("}")
    return "\n".join(lines)


def bib_from_crossref(key, msg, overrides=None, flags=None):
    flags = [] if flags is None else flags
    overrides = overrides or {}
    ctype = msg.get("type", "")
    title = clean_html(" ".join(msg.get("title", [""])), flags)
    sub = msg.get("subtitle") or []
    if sub:
        st = clean_html(sub[0], flags)
        if norm_for_compare(st) not in norm_for_compare(title):
            title = title.rstrip(".") + ": " + st
    title = title.rstrip("*").strip()
    _letters = [c for c in title if c.isalpha()]
    if len(_letters) > 12 and sum(c.isupper() for c in _letters) / len(_letters) > 0.85:
        flags.append("ALL-CAPS title, converted to sentence case (check proper nouns)")
        title = title.capitalize()
    title_tex = re.sub(r"\$(\s*)\$", "", to_latex(title, flags))   # merge adjacent math
    title_tex = protect_title(escape_specials(title_tex))
    authors = [fmt_person_crossref(a, flags) for a in msg.get("author", [])]
    authors = [a for a in authors if a]
    editors = [fmt_person_crossref(a, flags) for a in msg.get("editor", [])]
    editors = [a for a in editors if a]
    container = [clean_html(c, flags) for c in msg.get("container-title", [])]
    series = None
    if len(container) > 1:
        ser = [c for c in container if re.match(r"^(Lecture Notes|Springer Series|Studies in|Advances in Intelligent|Communications in Computer)", c)]
        if ser:
            series = ser[0]
            container = [c for c in container if c != series] + [series]
    pub = msg.get("publisher", "")
    pub = PUBLISHER_MAP.get(pub, pub)
    fields = {"title": title_tex, "doi": msg.get("DOI", "").lower()}
    if authors:
        fields["author"] = " and ".join(authors)
    pages = msg.get("page") or msg.get("article-number")
    if pages:
        pages = pages.replace("--", "-").replace("-", "--")
    if ctype == "journal-article":
        etype = "article"
        fields["journal"] = escape_specials(to_latex(container[0], flags)) if container else ""
        fields["volume"] = msg.get("volume")
        fields["number"] = msg.get("issue")
        fields["pages"] = pages
        fields["year"] = year_of(msg, True)
        if not fields["journal"]:
            flags.append("journal-article without container title")
    elif ctype in ("book", "monograph", "edited-book", "reference-book", "book-set"):
        etype = "book"
        if not authors and editors:
            fields["editor"] = " and ".join(editors)
        fields["publisher"] = escape_specials(to_latex(pub, flags))
        if container:
            fields["series"] = escape_specials(to_latex(container[0], flags))
        if msg.get("edition-number") and str(msg["edition-number"]).strip() not in ("0", "1"):
            fields["edition"] = ordinal(msg["edition-number"])
        fields["year"] = year_of(msg, False)
    elif ctype in ("book-chapter", "reference-entry", "book-part", "book-section"):
        etype = "incollection"
        fields["booktitle"] = escape_specials(to_latex(container[0], flags)) if container else ""
        if series:
            fields["series"] = escape_specials(to_latex(series, flags))
            fields["volume"] = msg.get("volume")
        if editors:
            fields["editor"] = " and ".join(editors)
        fields["publisher"] = escape_specials(to_latex(pub, flags))
        fields["pages"] = pages
        fields["year"] = year_of(msg, False)
    elif ctype == "proceedings-article":
        etype = "inproceedings"
        fields["booktitle"] = escape_specials(to_latex(container[0], flags)) if container else ""
        if series:
            fields["series"] = escape_specials(to_latex(series, flags))
            fields["volume"] = msg.get("volume")
        fields["publisher"] = escape_specials(to_latex(pub, flags))
        fields["pages"] = pages
        fields["year"] = year_of(msg, False)
    elif ctype == "report":
        etype = "techreport"
        fields["institution"] = escape_specials(to_latex(pub, flags))
        fields["year"] = year_of(msg, False)
    elif ctype == "dissertation":
        etype = "phdthesis"
        inst = msg.get("institution", [{}])
        fields["school"] = to_latex(inst[0].get("name", pub) if inst else pub, flags)
        fields["year"] = year_of(msg, False)
    else:
        etype = "misc"
        fields["howpublished"] = escape_specials(to_latex(pub, flags))
        fields["year"] = year_of(msg, False)
        flags.append("Crossref type %r mapped to @misc" % ctype)
    etype = overrides.pop("type", etype)
    for k, v in overrides.items():
        fields[k] = v
    return field_block(etype, key, fields), title


def ordinal(n):
    n = str(n)
    if not n.isdigit():
        return n
    i = int(n)
    suf = "th" if 10 <= i % 100 <= 20 else {1: "st", 2: "nd", 3: "rd"}.get(i % 10, "th")
    return "%d%s" % (i, suf)


def bib_from_arxiv(key, aid, meta, overrides=None, flags=None):
    flags = [] if flags is None else flags
    overrides = dict(overrides or {})
    title_tex = protect_title(escape_specials(to_latex(meta["title"], flags)))
    authors = []
    for a in meta["authors"]:
        a_tex = to_latex(a, flags)
        # "Tim De Ryck" -> "{De Ryck}, Tim": a capitalised particle would otherwise be
        # parsed by BibTeX as part of the given name
        toks = a_tex.split()
        for i, tk in enumerate(toks[1:-1], start=1):
            if tk in ("De", "Van", "Von", "Di", "Da", "Del", "Der", "Dos", "Du", "Ter", "La"):
                a_tex = "{%s}, %s" % (" ".join(toks[i:]), " ".join(toks[:i]))
                break
        authors.append(a_tex)
    fields = {"author": " and ".join(authors), "title": title_tex}
    etype = overrides.pop("type", "misc")
    if etype == "misc":
        fields["howpublished"] = "arXiv preprint arXiv:%s" % aid
        fields["year"] = meta["year"]
    else:
        fields["year"] = meta["year"]
        fields["note"] = "arXiv:%s" % aid
    for k, v in overrides.items():
        fields[k] = v
    fields["eprint"] = aid
    fields["archiveprefix"] = "arXiv"
    return field_block(etype, key, fields), meta["title"]


def make_key(family, year, title):
    fam = unicodedata.normalize("NFKD", family)
    fam = "".join(c for c in fam if c.isalpha() and ord(c) < 128).lower()
    stop = {"a", "an", "the", "on", "of", "for", "and", "in", "to", "with", "via",
            "from", "by", "using", "towards", "toward", "is", "are", "do", "can"}
    words = [w for w in re.findall(r"[A-Za-z]+", title.lower()) if w not in stop]
    return "%s%s%s" % (fam, year, words[0] if words else "")

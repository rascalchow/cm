#!/usr/bin/env bash
# Build the complete book: merge bibliographies, run pdflatex/bibtex/makeindex, report problems.
# Usage: scripts/build_book.sh          -> main.pdf in the project root
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
python3 scripts/merge_bib.py || exit 1
OUT=build/book
mkdir -p "$OUT"
run() { pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$OUT" main.tex > "$OUT/pdflatex.out" 2>&1; }
run || { echo "=== LaTeX ERROR ==="; grep -n -A8 "^!" "$OUT/main.log" | head -40; exit 1; }
BIBINPUTS=".:" bibtex "$OUT/main" > "$OUT/bibtex.out" 2>&1
makeindex -q "$OUT/main.idx" 2> "$OUT/makeindex.out"
run && run || { echo "=== LaTeX ERROR ==="; grep -n -A8 "^!" "$OUT/main.log" | head -40; exit 1; }
cp "$OUT/main.pdf" "$ROOT/Scientific_Machine_Learning.pdf"
echo "=== book built: Scientific_Machine_Learning.pdf, $(pdfinfo Scientific_Machine_Learning.pdf | awk '/^Pages:/{print $2}') pages ==="
echo "undefined citations: $(grep -c 'Citation .* undefined' $OUT/main.log)"
grep -o "Citation \`[^']*' on page [0-9]* undefined" $OUT/main.log | sort -u | head -20
echo "undefined references: $(grep -c 'Reference .* undefined' $OUT/main.log)"
grep -o "Reference \`[^']*' on page [0-9]* undefined" $OUT/main.log | sort -u | head -20
echo "multiply defined labels: $(grep -c 'multiply defined' $OUT/main.log)"
grep "multiply defined" $OUT/main.log | sort -u | head -20
echo "bibtex warnings:"; grep -i "warning" "$OUT/bibtex.out" | head -20
echo "overfull hboxes >10pt: $(grep -c 'Overfull \\hbox ([0-9][0-9]\.' $OUT/main.log)"

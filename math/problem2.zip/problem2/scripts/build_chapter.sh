#!/usr/bin/env bash
# Build a single chapter (or appendix) in isolation and report problems.
# Usage: scripts/build_chapter.sh chapters/ch07_dmd_koopman.tex
#        scripts/build_chapter.sh appendices/appA_python.tex
# Output: build/<stem>/test.pdf plus a short report on stdout.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
SRC="$1"
STEM="$(basename "$SRC" .tex)"
OUT="build/$STEM"
mkdir -p "$OUT"

# chapter number from file name (chNN_...); appendices get letter numbering
NUM=$(echo "$STEM" | sed -n 's/^ch\([0-9][0-9]\).*/\1/p')
if [ -n "$NUM" ]; then
  SETUP="\\setcounter{chapter}{$((10#$NUM - 1))}"
else
  LET=$(echo "$STEM" | sed -n 's/^app\([A-Z]\).*/\1/p')
  IDX=$(( $(printf '%d' "'$LET") - 65 ))
  SETUP="\\appendix\\setcounter{chapter}{$IDX}"
fi

# merged bibliography: core + every chapter's additions
cat bib/core.bib bib/added_*.bib 2>/dev/null > "$OUT/all.bib"

cat > "$OUT/test.tex" <<EOF
\\documentclass[11pt,twoside,openany]{book}
\\input{preamble}
\\begin{document}
\\frontmatter\\mainmatter
$SETUP
\\input{${SRC%.tex}}
\\clearpage
\\typeout{CHAPTER-LAST-PAGE: \\the\\numexpr\\value{page}-1\\relax}
\\bibliographystyle{plainnat}
\\bibliography{$OUT/all}
\\end{document}
EOF

run() { pdflatex -interaction=nonstopmode -halt-on-error -output-directory="$OUT" "$OUT/test.tex" > "$OUT/pdflatex.out" 2>&1; }
run; STATUS=$?
if [ $STATUS -ne 0 ]; then
  echo "=== LaTeX ERROR in $SRC (first error shown) ==="
  grep -n -A6 "^!" "$OUT/test.log" | head -40
  exit 1
fi
bibtex "$OUT/test" > "$OUT/bibtex.out" 2>&1
run; run
grep -q "^!" "$OUT/test.log" && { echo "=== LaTeX ERROR ==="; grep -n -A6 "^!" "$OUT/test.log" | head -40; exit 1; }

PAGES=$(grep -o "CHAPTER-LAST-PAGE: [0-9]*" "$OUT/test.log" | tail -1 | awk '{print $2}')
TOTAL=$(pdfinfo "$OUT/test.pdf" 2>/dev/null | awk '/^Pages:/{print $2}')
WORDS=$(pdftotext -l "$PAGES" "$OUT/test.pdf" - 2>/dev/null | wc -w)
echo "=== $SRC ==="
echo "chapter pages: $PAGES   (pdf total incl. references: $TOTAL, ~words: $WORDS)"
UC=$(grep -c "Citation .* undefined" "$OUT/test.log")
echo "undefined citations: $UC"
grep -o "Citation \`[^']*' on page [0-9]* undefined" "$OUT/test.log" | sort -u | head -20
UR=$(grep -o "Reference \`[^']*' on page [0-9]* undefined" "$OUT/test.log" | sed "s/ on page.*//" | sort -u)
echo "undefined references (cross-chapter ch:* refs are expected here):"
echo "$UR" | grep -v "^Reference \`ch:" | grep -v "^Reference \`app:" | grep -v "^$" | head -20
grep -i "warning" "$OUT/bibtex.out" | head -10
OF=$(grep -c "Overfull \\\\hbox ([0-9][0-9]\." "$OUT/test.log")
echo "overfull hboxes >10pt: $OF"
grep -n "Overfull \\\\hbox ([0-9][0-9]\." "$OUT/test.log" | head -10
echo "pdf: $OUT/test.pdf"

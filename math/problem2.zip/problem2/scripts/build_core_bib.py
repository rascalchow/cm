"""Build bib/core.bib from scripts/core_sources.py with full verification.

Usage: python3 scripts/build_core_bib.py
Outputs: bib/core.bib, bib/core_report.txt, bib/core_index.tsv
"""
import concurrent.futures as cf
import html
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
import bibtool as bt  # noqa: E402
from core_sources import SOURCES  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_cache = {}


def cached(url):
    if url not in _cache:
        _cache[url] = bt.http_get(url, timeout=90)
    return _cache[url]


# --------------------------------------------------------------- venue indexes

_nt = {}


def neurips_titles(year):
    if year in _nt:
        return _nt[year]
    page = cached("https://papers.nips.cc/paper_files/paper/%d" % year)
    titles = re.findall(r'title="paper title"[^>]*>(.*?)</a>', page, flags=re.S)
    _nt[year] = {bt.norm_for_compare(html.unescape(t)) for t in titles}
    return _nt[year]


_pm = {}


def pmlr_entries(vol):
    if vol in _pm:
        return _pm[vol]
    page = cached("https://proceedings.mlr.press/v%d/" % vol)
    head = re.search(r"<h2>(.*?)</h2>", page, flags=re.S)
    years = re.findall(r"(19\d\d|20\d\d)", head.group(1) if head else page[:3000])
    year = years[-1] if years else None
    out = {}
    for chunk in page.split('<div class="paper">')[1:]:
        mt = re.search(r'<p class="title">(.*?)</p>', chunk, flags=re.S)
        mi = re.search(r'<span class="info"><i>(.*?)</i>,\s*PMLR\s*(\d+)(?:\((\d+)\))?:([0-9]+)(?:-|&ndash;)([0-9]+)</span>', chunk, flags=re.S)
        if not (mt and mi):
            continue
        t = html.unescape(" ".join(mt.group(1).split()))
        out[bt.norm_for_compare(t)] = dict(title=t, booktitle=html.unescape(" ".join(mi.group(1).split())),
                                           volume=mi.group(2), number=mi.group(3), pages="%s--%s" % (mi.group(4), mi.group(5)), year=year)
    _pm[vol] = out
    return out


_jm = {}


def jmlr_entries(vol):
    if vol in _jm:
        return _jm[vol]
    page = cached("https://jmlr.org/papers/v%d/" % vol)
    out = {}
    for m in re.finditer(r"<dt>(.*?)</dt>\s*<dd>(.*?)(?:</dd>|</dl>)", page, flags=re.S):
        t = html.unescape(" ".join(re.sub(r"<[^>]+>", "", m.group(1)).split()))
        dd = html.unescape(m.group(2)).replace("−", "-")
        mm = re.search(r"\(([A-Za-z0-9]+)\):\s*(\d+)\s*-+\s*(\d+),\s*(\d{4})", dd)
        if mm:
            out[bt.norm_for_compare(t)] = dict(title=t, number=mm.group(1), pages="%s--%s" % (mm.group(2), mm.group(3)),
                                               year=mm.group(4), volume=str(vol))
    _jm[vol] = out
    return out


def find(entries, title):
    n = bt.norm_for_compare(title)
    if n in entries:
        return entries[n]
    for k, v in entries.items():
        if bt.title_matches(title, v["title"] if isinstance(v, dict) else k):
            return v
    return None


def apply_venue(venue, title, report):
    """Return (overrides, ok). venue = (kind, arg[, title_at_venue])."""
    kind, arg = venue[0], venue[1]
    if len(venue) > 2 and venue[2]:
        title = venue[2]
    if kind == "neurips":
        nt = bt.norm_for_compare(title)
        if nt in neurips_titles(arg) or any(bt.title_matches(title, t) and abs(len(t) - len(bt.norm_for_compare(title))) < 25
               for t in neurips_titles(arg)):
            return dict(type="inproceedings", booktitle="Advances in Neural Information Processing Systems",
                        volume=str(arg - 1987), year=str(arg)), True
        report.append("NeurIPS %d: title not found in proceedings index" % arg)
        return {}, False
    if kind == "pmlr":
        e = find(pmlr_entries(arg), title)
        if e:
            return dict(type="inproceedings", booktitle=e["booktitle"], series="Proceedings of Machine Learning Research",
                        volume=e["volume"], pages=e["pages"], year=e["year"]), True
        report.append("PMLR v%d: title not found" % arg)
        return {}, False
    if kind == "jmlr":
        e = find(jmlr_entries(arg), title)
        if e:
            return dict(type="article", journal="Journal of Machine Learning Research", volume=e["volume"],
                        number=e["number"], pages=e["pages"], year=e["year"]), True
        report.append("JMLR v%d: title not found" % arg)
        return {}, False
    return {}, False


# --------------------------------------------------------------- resolvers

def resolve_doi(src):
    rep = []
    try:
        msg = bt.crossref_work(src["id"])
    except Exception as e:  # noqa: BLE001
        return None, ["DOI fetch failed (%s)" % e]
    bib, title = bt.bib_from_crossref(src["key"], msg, dict(src["over"]), rep)
    if not bt.title_matches(src["title"], title):
        rep.append("TITLE MISMATCH: expected %r, Crossref has %r" % (src["title"], title))
        return None, rep
    return bib, rep


def resolve_search(src):
    rep = []
    try:
        items = bt.crossref_search(src["title"], src["author"], rows=8)
    except Exception as e:  # noqa: BLE001
        return None, ["search failed (%s)" % e]
    for it in items:
        t = " ".join(it.get("title", [""]))
        y = bt.year_of(it, False)
        if bt.title_matches(src["title"], t) and y and abs(int(y) - src["year"]) <= 1:
            fam = [a.get("family", "") for a in it.get("author", [])]
            bib, title = bt.bib_from_crossref(src["key"], it, dict(src["over"]), rep)
            rep.append("resolved by search -> DOI %s (authors: %s)" % (it.get("DOI"), ", ".join(fam[:4])))
            return bib, rep
    cands = ["%s | %s | %s" % (it.get("DOI"), " ".join(it.get("title", [""]))[:80], bt.year_of(it, False)) for it in items[:4]]
    return None, ["SEARCH FAILED; candidates: " + " || ".join(cands)]


def resolve_manual(src):
    rep = []
    f = dict(src["fields"])
    v = src.get("verify")
    if v:
        kind = v[0]
        try:
            if kind == "isbn":
                ol = bt.openlibrary_isbn(v[1])
                if not bt.title_matches(v[2], ol["title"]):
                    rep.append("ISBN title mismatch: Open Library has %r" % ol["title"])
                    return None, rep
                rep.append("ISBN verified: %s (%s)" % (ol["title"], ", ".join(ol["publishers"])))
            elif kind == "url":
                page = bt.http_get(v[1])
                if v[2].lower() not in page.lower():
                    rep.append("URL check failed for %s" % v[1])
                    return None, rep
                rep.append("URL verified")
            elif kind in ("pmlr", "jmlr", "neurips"):
                over, ok = apply_venue((kind, v[1]), v[2], rep)
                if not ok:
                    return None, rep
                etype = over.pop("type")
                f.update(over)
                src = dict(src, etype=etype)
                rep.append("%s index verified" % kind.upper())
        except Exception as e:  # noqa: BLE001
            return None, ["verification error: %s" % e]
    else:
        rep.append("manual entry (classic reference, no online index)")
    return bt.field_block(src["etype"], src["key"], f), rep


def main():
    results = {}
    doi_srcs = [s for s in SOURCES if s["kind"] == "doi"]
    srch = [s for s in SOURCES if s["kind"] == "search"]
    with cf.ThreadPoolExecutor(8) as ex:
        futs = {ex.submit(resolve_doi, s): s for s in doi_srcs}
        futs.update({ex.submit(resolve_search, s): s for s in srch})
        for fu in cf.as_completed(futs):
            results[futs[fu]["key"]] = fu.result()

    ax = [s for s in SOURCES if s["kind"] == "arxiv"]
    meta = bt.arxiv_batch([s["id"] for s in ax])
    for s in ax:
        rep = []
        m = meta.get(s["id"])
        if not m:
            results[s["key"]] = (None, ["arXiv id not found"])
            continue
        if not bt.title_matches(s["title"], m["title"]):
            results[s["key"]] = (None, ["TITLE MISMATCH: expected %r, arXiv has %r" % (s["title"], m["title"])])
            continue
        over = dict(s["over"])
        venue = s.get("venue")
        if venue:
            if venue[0] == "iclr":
                c = m.get("comment", "") + " " + (m.get("journal_ref") or "")
                if "ICLR" in c or "Learning Representations" in c:
                    rep.append("ICLR confirmed by arXiv comment: %s" % c.strip()[:90])
                else:
                    rep.append("ICLR %d venue not confirmed by arXiv comment (%r)" % (venue[1], c.strip()[:90]))
                over.update(type="inproceedings", booktitle="International Conference on Learning Representations (ICLR)",
                            year=str(venue[1]))
            else:
                try:
                    vo, ok = apply_venue(venue, m["title"], rep)
                except Exception as e:  # noqa: BLE001
                    vo, ok = {}, False
                    rep.append("venue lookup error %s" % e)
                if ok:
                    over.update(vo)
                    rep.append("venue verified: %s" % (venue,))
                    if len(venue) > 2 and venue[2]:
                        over["title"] = bt.protect_title(bt.escape_specials(bt.to_latex(venue[2])))
        bib, _ = bt.bib_from_arxiv(s["key"], s["id"], m, over, rep)
        results[s["key"]] = (bib, rep)

    for s in SOURCES:
        if s["kind"] == "manual":
            results[s["key"]] = resolve_manual(s)

    ok, bad = [], []
    lines_report = []
    for s in SOURCES:
        bib, rep = results.get(s["key"], (None, ["missing"]))
        if bib:
            ok.append(bib)
        else:
            bad.append(s["key"])
        if rep:
            lines_report.append("%-32s %s %s" % (s["key"], "OK " if bib else "FAIL", " | ".join(rep)))
    with open(os.path.join(ROOT, "bib", "core.bib"), "w") as fh:
        fh.write("% Core bibliography for 'Scientific Machine Learning'.\n"
                 "% Generated by scripts/build_core_bib.py from Crossref, arXiv, PMLR,\n"
                 "% NeurIPS, JMLR and Open Library metadata. Do not edit by hand.\n\n")
        fh.write("\n\n".join(ok) + "\n")
    with open(os.path.join(ROOT, "bib", "core_report.txt"), "w") as fh:
        fh.write("\n".join(lines_report) + "\n")
    print("entries ok: %d, failed: %d" % (len(ok), len(bad)))
    print("FAILED:", " ".join(bad))


if __name__ == "__main__":
    main()

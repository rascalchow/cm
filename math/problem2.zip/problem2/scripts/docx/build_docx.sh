#!/usr/bin/env bash
# =====================================================================
#  Word edition of the book:  Scientific_Machine_Learning.docx
#
#  Usage:  scripts/docx/build_docx.sh [--no-toc-pages] [--verify] [--aux FILE] [--out FILE.docx]
#
#  1. cross-reference data: build/book/main.aux (from scripts/build_book.sh; run if
#     missing).  If it is older than the sources, the book is recompiled into
#     build/docx/latex (nothing outside build/docx is touched) and that aux is used.
#  2. scripts/docx/prep.py      LaTeX -> build/docx/book.tex (+ PNG figures, rendered
#                               TikZ pictures and algorithms in build/docx/img)
#  3. pandoc + filters.lua + citeproc (APA CSL, references.bib) + filters_post.lua
#     with scripts/docx/reference.docx (styles; rebuilt by make_reference.py)
#  4. scripts/docx/postprocess.py   boxes, equation numbers, tables, TOC, sections
#  5. LibreOffice rendering -> page numbers for the pre-filled table of contents
#  6. --verify: render the final DOCX to PDF and run scripts/docx/verify.py
# =====================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
cd "$ROOT"
HERE=scripts/docx
OUT=build/docx
DOCX="$ROOT/Scientific_Machine_Learning.docx"
AUX="build/book/main.aux"
TOC_PAGES=1
VERIFY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --no-toc-pages) TOC_PAGES=0 ;;
    --verify) VERIFY=1 ;;
    --aux) AUX="$2"; shift ;;
    --out) DOCX="$2"; shift ;;
    -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
    *) echo "unknown option $1"; exit 2 ;;
  esac
  shift
done
mkdir -p "$OUT"
log() { echo "== $*"; }

# ------------------------------------------------------------------ 1. aux file
aux_state() { python3 "$HERE/prep.py" --check-aux --aux "$1" | cut -d' ' -f1; }
if [ ! -f "$AUX" ] && [ "$AUX" = "build/book/main.aux" ]; then
  log "$AUX not found: running scripts/build_book.sh"
  scripts/build_book.sh || log "warning: scripts/build_book.sh reported a problem"
fi
if [ "$(aux_state "$AUX")" != "fresh" ]; then
  if [ "$(aux_state "$OUT/latex/main.aux")" = "fresh" ]; then
    AUX="$OUT/latex/main.aux"
  else
    log "aux file missing or older than the sources: compiling the book into $OUT/latex"
    mkdir -p "$OUT/latex"
    pdftex() { pdflatex -interaction=nonstopmode -output-directory="$OUT/latex" main.tex > "$OUT/latex/pdflatex.out" 2>&1 || true; }
    pdftex
    BIBINPUTS=".:" bibtex "$OUT/latex/main" > "$OUT/latex/bibtex.out" 2>&1 || true
    pdftex; pdftex
    AUX="$OUT/latex/main.aux"
    [ -f "$AUX" ] || { echo "error: LaTeX did not produce $AUX (see $OUT/latex/main.log)"; exit 1; }
  fi
fi
log "cross-references from $AUX"

# ------------------------------------------------------------------ 2. style files
if [ ! -f "$HERE/apa.csl" ]; then
  log "downloading the APA CSL style"
  curl -sSfL -o "$HERE/apa.csl" https://raw.githubusercontent.com/citation-style-language/styles/master/apa.csl
fi
# natbib look: no given-name / extra-name disambiguation ("Baker et al., 2019", not "N. Baker et al.")
sed -e 's/disambiguate-add-givenname="true"/disambiguate-add-givenname="false"/' \
    -e 's/disambiguate-add-names="true"/disambiguate-add-names="false"/' "$HERE/apa.csl" > "$OUT/apa-natbib.csl"
if [ ! -f "$HERE/reference.docx" ] || [ "$HERE/make_reference.py" -nt "$HERE/reference.docx" ]; then
  python3 "$HERE/make_reference.py" -o "$HERE/reference.docx"
fi

# ------------------------------------------------------------------ 3. preprocess
python3 "$HERE/prep.py" --aux "$AUX" --out "$OUT"

# ------------------------------------------------------------------ 4. pandoc
log "pandoc"
pandoc "$OUT/book.tex" -f latex -t docx \
  --top-level-division=chapter \
  --lua-filter "$HERE/filters.lua" \
  --citeproc --bibliography references.bib --csl "$OUT/apa-natbib.csl" \
  -M link-citations=true -M lang=en-US \
  --lua-filter "$HERE/filters_post.lua" \
  --highlight-style "$HERE/code.theme" \
  --reference-doc "$HERE/reference.docx" \
  --resource-path . \
  -o "$OUT/pandoc.docx" 2> "$OUT/pandoc.log" || { cat "$OUT/pandoc.log"; exit 1; }
grep -v '^\s*$' "$OUT/pandoc.log" | head -20 || true

# ------------------------------------------------------------------ 5. post-process (+ TOC pages)
python3 "$HERE/postprocess.py" "$OUT/pandoc.docx" "$OUT/pass1.docx" --toc-json "$OUT/toc.json"
SOFFICE="python3 $HERE/run_soffice.py"
if [ "$TOC_PAGES" = 1 ] && command -v soffice > /dev/null; then
  log "LibreOffice rendering for the table-of-contents page numbers"
  mkdir -p "$OUT/render"
  rm -f "$OUT/render/pass1.pdf"
  $SOFFICE "$OUT/pass1.docx" "$OUT/render" > "$OUT/render/soffice.log" 2>&1 || true
  if [ -f "$OUT/render/pass1.pdf" ]; then
    python3 "$HERE/toc_pages.py" "$OUT/render/pass1.pdf" "$OUT/toc.json" "$OUT/toc_pages.json"
    python3 "$HERE/postprocess.py" "$OUT/pandoc.docx" "$DOCX" --toc-pages "$OUT/toc_pages.json"
  else
    log "warning: LibreOffice rendering failed; table of contents left for Word to fill"
    cp "$OUT/pass1.docx" "$DOCX"
  fi
else
  cp "$OUT/pass1.docx" "$DOCX"
fi
log "written $(python3 -c "import os,sys; print(os.path.relpath(sys.argv[1]))" "$DOCX") ($(du -h "$DOCX" | cut -f1))"

# ------------------------------------------------------------------ 6. verification
if [ "$VERIFY" = 1 ]; then
  python3 "$HERE/check_refs.py" --aux "$AUX" --work "$OUT/refcheck" | tail -5
  python3 "$HERE/verify.py" "$DOCX" --render "$OUT/render"
fi

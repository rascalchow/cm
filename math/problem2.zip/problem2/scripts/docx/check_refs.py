#!/usr/bin/env python3
"""Verify the Python cleveref emulation (xref.py) against LaTeX itself.

Collects every distinct \\ref/\\cref/\\Cref/\\eqref/\\crefrange of the book, typesets
them in a scratch document that reads the book's aux file (so LaTeX + cleveref
resolve them exactly as in the PDF), extracts the text with pdftotext and compares
with what xref.Resolver produces.

Usage: python3 scripts/docx/check_refs.py [--aux build/book/main.aux]
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from texutil import load_tex, read_group  # noqa: E402
from xref import Aux, Resolver  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(HERE))


def norm(s):
    s = unicodedata.normalize("NFKC", s).replace("\u00a0", " ").replace("~", " ")
    return re.sub(r"\s+", " ", s).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aux", default=os.path.join(ROOT, "build/book/main.aux"))
    ap.add_argument("--work", default=os.path.join(ROOT, "build/docx/refcheck"))
    a = ap.parse_args()
    text, _ = load_tex(os.path.join(ROOT, "main.tex"), ROOT)
    cmds = []
    for m in re.finditer(r"\\(cref|Cref|ref|eqref|crefrange)(?![A-Za-z])", text):
        try:
            arg, j = read_group(text, m.end())
            if m.group(1) == "crefrange":
                arg2, j = read_group(text, j)
                arg = arg + "}{" + arg2
        except ValueError:
            continue
        c = "\\%s{%s}" % (m.group(1), arg)
        if c not in cmds:
            cmds.append(c)
    os.makedirs(a.work, exist_ok=True)
    shutil.copy(a.aux, os.path.join(a.work, "refs.aux"))
    with open(os.path.join(a.work, "refs.tex"), "w") as fh:
        fh.write("\\documentclass[11pt,twoside,openany]{book}\n\\input{preamble}\n"
                 "\\pdfpagewidth=40in \\textwidth=38in \\hsize=38in \\linewidth=38in\n"
                 "\\begin{document}\\pagestyle{empty}\\raggedright\\nofiles\n")
        for i, c in enumerate(cmds):
            fh.write("@@%d@@ %s @@END@@\\par\n" % (i, c))
        fh.write("\\end{document}\n")
    env = dict(os.environ, TEXINPUTS=ROOT + "//:")
    subprocess.run(["pdflatex", "-interaction=nonstopmode", "refs.tex"], cwd=a.work, env=env,
                   stdout=subprocess.DEVNULL)
    out = subprocess.run(["pdftotext", "-raw", "refs.pdf", "-"], cwd=a.work,
                         capture_output=True, text=True).stdout
    truth = {}
    for m in re.finditer(r"@@(\d+)@@(.*?)@@END@@", out, re.S):
        truth[int(m.group(1))] = norm(m.group(2))
    res = Resolver(Aux(a.aux))
    bad = 0
    for i, c in enumerate(cmds):
        m = re.match(r"\\(\w+)\{(.*)\}$", c, re.S)
        kind, arg = m.group(1), m.group(2)
        if kind in ("cref", "Cref"):
            mine = res.cref(arg.split(","), capital=(kind == "Cref"))
        elif kind == "ref":
            mine = res.ref(arg)
        elif kind == "eqref":
            mine = res.eqref(arg)
        else:
            x, y = arg.split("}{")
            mine = res.crefrange(x, y)
        if norm(mine) != truth.get(i):
            bad += 1
            print("MISMATCH %s\n   latex : %s\n   python: %s" % (c, truth.get(i), norm(mine)))
    print("checked %d distinct references, %d mismatches" % (len(cmds), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())

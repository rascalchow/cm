#!/usr/bin/env python3
"""Tile rendered page images into one contact sheet (for visual checks).
usage: contact_sheet.py out.png cols page1.png page2.png ..."""
import sys
from PIL import Image

out, cols, files = sys.argv[1], int(sys.argv[2]), sys.argv[3:]
ims = [Image.open(f).convert("RGB") for f in files]
w = max(i.width for i in ims)
h = max(i.height for i in ims)
rows = (len(ims) + cols - 1) // cols
sheet = Image.new("RGB", (cols * w + (cols + 1) * 6, rows * h + (rows + 1) * 6), (120, 120, 120))
for k, im in enumerate(ims):
    r, c = divmod(k, cols)
    sheet.paste(im, (6 + c * (w + 6), 6 + r * (h + 6)))
sheet.save(out)

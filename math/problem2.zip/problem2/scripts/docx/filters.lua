--[[
filters.lua -- structural mapping for the DOCX edition (runs BEFORE --citeproc).

Input: the AST pandoc reads from build/docx/book.tex (written by prep.py).
Marker Divs (upper-case classes) become Word custom styles; boxes are bracketed
by marker paragraphs that postprocess.py turns into shaded, bordered table cells.
Display equations carrying \EQNUM{n}{label} get an "Equation Number" span that
postprocess.py moves into a right-aligned cell next to the equation.
]]

local stringify = pandoc.utils.stringify

-- box kind -> {text style, title style}
local BOX = {
  objectives   = {"Objectives Text",      "Objectives Title"},
  summarybox   = {"Summary Text",         "Summary Title"},
  keyidea      = {"Key Idea Text",        "Key Idea Title"},
  practicaltip = {"Practical Tip Text",   "Practical Tip Title"},
  caution      = {"Caution Text",         "Caution Title"},
  historybox   = {"Historical Note Text", "Historical Note Title"},
  assignment   = {"Assignment Text",      "Assignment Title"},
  definition   = {"Definition Text",      nil},
  theorem      = {"Theorem Text",         nil},
  proposition  = {"Theorem Text",         nil},
  generic      = {"Box Text",             "Box Title"},
}
-- unboxed theorem-like environments
local THM = {
  lemma = "Lemma Text", corollary = "Lemma Text",
  example = "Example Text", remark = "Example Text",
}
-- simple one-to-one Div class -> paragraph style
local DIVSTYLE = {
  APART = "Assignment Part",
  CAPTIONlisting = "Listing Caption",
  CAPTIONalgorithm = "Algorithm Caption",
  ALGIMAGE = "Algorithm Image",
  PARTHEAD = "Part Title",
  TITLEBANDTEXT = "Title Band Text",
  TITLEBANDIMAGE = "Title Band Image",
  TITLEMAIN = "Book Title",
  TITLESUB = "Book Subtitle",
  TITLEDESC = "Book Description",
  TITLETAG = "Book Tagline",
  TITLEEDITION = "Book Edition",
  BIBNOTE = "Bibliography Note",
  EXERCISE = "Exercise Text",
  SUBFIGURES = "Captioned Figure",
  SUBCAPTIONS = "Subfigure Caption",
  FIGCAPTION = "Image Caption",
}
-- inline colour markers -> character styles / classes
local SPANSTYLE = {
  CSstars = "Difficulty Stars",
  CSexlabel = "Exercise Label",
  CSthmhead = "Theorem Head",
  CSthmnote = "Theorem Note",
  CSremarkhead = "Remark Head",
}

local function marker(text)
  return pandoc.Para({pandoc.Span({pandoc.Str(text)}, {["custom-style"] = "Box Marker"})})
end

local function styled(blocks, style)
  return pandoc.Div(blocks, {["custom-style"] = style})
end

local function raw(xml)
  return pandoc.RawBlock("openxml", xml)
end

local REVERSE_SPACER = '<w:p><w:pPr><w:pageBreakBefore/><w:spacing w:before="0" w:after="0" ' ..
  'w:line="6400" w:lineRule="exact"/></w:pPr></w:p>'

local TOC = [[
<w:sdt><w:sdtPr><w:docPartObj><w:docPartGallery w:val="Table of Contents"/><w:docPartUnique/></w:docPartObj></w:sdtPr><w:sdtContent>
<w:p><w:pPr><w:pStyle w:val="TOCHeading"/></w:pPr><w:r><w:t>Contents</w:t></w:r></w:p>
<w:p><w:r><w:fldChar w:fldCharType="begin" w:dirty="true"/></w:r><w:r><w:instrText xml:space="preserve"> TOC \h \z \t "Part Title,1,Heading 1,1,Heading 2,2" </w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>Right-click and choose Update Field to build the table of contents.</w:t></w:r><w:r><w:fldChar w:fldCharType="end"/></w:r></w:p>
</w:sdtContent></w:sdt>]]

local function has_class(el, c)
  return el.classes and el.classes:includes(c)
end

-- Div ----------------------------------------------------------------------
function Div(el)
  local c = el.classes[1]
  if not c then return nil end
  local kind = c:match("^BOX(.+)$")
  if kind and kind ~= "TITLE" then
    local spec = BOX[kind] or BOX.generic
    local out = {marker("BOXSTART:" .. kind)}
    local body = {}
    for _, b in ipairs(el.content) do
      if b.t == "Div" and has_class(b, "BOXTITLE") then
        table.insert(out, styled(b.content, spec[2] or "Box Title"))
      else
        table.insert(body, b)
      end
    end
    table.insert(out, styled(body, spec[1]))
    table.insert(out, marker("BOXEND:" .. kind))
    return out
  end
  local thm = c:match("^THM(.+)$")
  if thm then
    return styled(el.content, THM[thm] or "Example Text")
  end
  if c == "PROOF" then
    local content = el.content
    local last = content[#content]
    if last and (last.t == "Para" or last.t == "Plain") then
      last.content:insert(pandoc.Space())
      last.content:insert(pandoc.Str("\u{220E}"))
    else
      content:insert(pandoc.Para({pandoc.Str("\u{220E}")}))
    end
    return styled(content, "Proof Text")
  end
  if c == "TOCHERE" then
    return raw(TOC)
  end
  if c == "TITLEBAND" then
    local out = {marker("BOXSTART:titleband")}
    for _, b in ipairs(el.content) do table.insert(out, b) end
    table.insert(out, marker("BOXEND:titleband"))
    return out
  end
  if c == "REVERSEPAGE" then
    -- new page; an exact-height spacer pushes the text towards the bottom
    local out = {raw(REVERSE_SPACER)}
    for _, b in ipairs(el.content) do
      table.insert(out, styled({b}, "Reverse Page"))
    end
    return out
  end
  if c == "REFS" then
    return pandoc.Div({}, {id = "refs"})
  end
  if DIVSTYLE[c] then
    return styled(el.content, DIVSTYLE[c])
  end
  return nil
end

-- Blocks: run-in headings ------------------------------------------------------
local function first_inlines(div)
  -- inline content of a RUNHEAD / RUNPARA div
  local b = div.content[1]
  if b and (b.t == "Para" or b.t == "Plain") then return b.content end
  return pandoc.Inlines({})
end

local function merge_anchors(blocks)
  -- \hypertarget{key}{} at the start of a paragraph is read as an empty Div with
  -- an identifier: turn it into an (empty) Span anchor inside the next paragraph
  local out = pandoc.Blocks({})
  local pending = {}
  for _, b in ipairs(blocks) do
    if b.t == "Div" and b.identifier ~= "" and #b.content == 0 then
      table.insert(pending, b.identifier)
    else
      if #pending > 0 and (b.t == "Para" or b.t == "Plain") then
        for k = #pending, 1, -1 do
          b.content:insert(1, pandoc.Span({}, {id = pending[k]}))
        end
        pending = {}
      elseif #pending > 0 and b.t == "Div" and b.content[1] and
             (b.content[1].t == "Para" or b.content[1].t == "Plain") then
        for k = #pending, 1, -1 do
          b.content[1].content:insert(1, pandoc.Span({}, {id = pending[k]}))
        end
        pending = {}
      elseif #pending > 0 then
        for _, id in ipairs(pending) do out:insert(pandoc.Div({}, {id = id})) end
        pending = {}
      end
      out:insert(b)
    end
  end
  for _, id in ipairs(pending) do out:insert(pandoc.Div({}, {id = id})) end
  return out
end

local function merge_runin(blocks)
  blocks = merge_anchors(blocks)
  local out = pandoc.Blocks({})
  local i = 1
  while i <= #blocks do
    local b = blocks[i]
    if b.t == "Div" and (has_class(b, "RUNHEAD") or has_class(b, "RUNPARA")) then
      local head = first_inlines(b)
      if has_class(b, "RUNPARA") then
        local h = pandoc.Inlines({})
        h:extend(head)
        h:insert(pandoc.Str("."))
        head = pandoc.Inlines({pandoc.Span({pandoc.Strong(h)}, {["custom-style"] = "Run-in Heading"})})
      end
      local nxt = blocks[i + 1]
      if nxt and (nxt.t == "Para" or nxt.t == "Plain") then
        local inl = pandoc.Inlines({})
        inl:extend(head)
        inl:insert(pandoc.Space())
        inl:extend(nxt.content)
        nxt.content = inl
        out:insert(nxt)
        i = i + 2
      else
        out:insert(pandoc.Para(head))
        i = i + 1
      end
    else
      out:insert(b)
      i = i + 1
    end
  end
  return out
end

-- unnumbered (starred) sections stay out of the table of contents, as in the PDF
function Header(el)
  if el.level >= 2 and el.classes:includes("unnumbered") then
    local style = "Heading " .. math.min(el.level, 4) .. " Unnumbered"
    return pandoc.Div({pandoc.Para(el.content)}, {["custom-style"] = style})
  end
  return nil
end

-- Inlines: equation numbers, marker spans ---------------------------------------
function Math(el)
  if el.mathtype ~= "DisplayMath" then return nil end
  local nums = {}
  local txt = el.text:gsub("\\EQNUM{([^}]*)}{([^}]*)}", function(n, key)
    table.insert(nums, {n, key})
    return ""
  end)
  if #nums == 0 then return nil end
  local out = {pandoc.Math("DisplayMath", txt)}
  for _, nk in ipairs(nums) do
    local attr = {["custom-style"] = "Equation Number"}
    local span = pandoc.Span({pandoc.Str("(" .. nk[1] .. ")")}, attr)
    if nk[2] ~= "" then span.identifier = nk[2] end
    table.insert(out, span)
  end
  return out
end

function Span(el)
  local st = el.attributes["style"]
  if st then
    local name = st:match("^color:%s*(CS%w+)")
    if name then
      if SPANSTYLE[name] then
        return pandoc.Span(el.content, {["custom-style"] = SPANSTYLE[name]})
      end
      if name == "CScitealp" then return pandoc.Span(el.content, {class = "citealp"}) end
      if name == "CShidecite" then return pandoc.Span(el.content, {class = "hidecite"}) end
    end
  end
  return nil
end

-- Code blocks: keep the language for highlighting, no line numbers ------------------
function CodeBlock(el)
  local lang = el.attributes["language"]
  el.attributes = {}
  if lang then el.classes = {lang:lower()} end
  if el.classes[1] == "python" or el.classes[1] == nil then el.classes = {"python"} end
  el.identifier = ""
  return el
end

-- Images: drop the alt text pandoc fills with the caption -----------------------------
function Image(el)
  el.caption = {}
  return el
end

return {
  {Math = Math, Span = Span, CodeBlock = CodeBlock, Image = Image},
  {Div = Div, Header = Header},
  {Blocks = merge_runin},
}

--[[
filters_post.lua -- runs AFTER --citeproc.

* \citealp-style citations (marked by prep.py/filters.lua with class "citealp")
  lose the enclosing parentheses that citeproc adds: "(Smith, 2020)" -> "Smith, 2020".
* hidden citations (class "hidecite", used for \citeauthor, \citeyear and natbib
  citation aliases whose text was written out by prep.py) are removed after
  citeproc has registered them for the bibliography.
* the reference list gets the "Bibliography" paragraph style.
]]

local function strip_parens(inlines)
  -- find first and last Str and remove "(" / ")"
  local first, last
  for i, x in ipairs(inlines) do
    if x.t == "Str" then
      first = first or i
      last = i
    end
  end
  if first and inlines[first].text:sub(1, 1) == "(" then
    inlines[first].text = inlines[first].text:sub(2)
  end
  if last and inlines[last].text:sub(-1) == ")" then
    inlines[last].text = inlines[last].text:sub(1, -2)
  end
  return inlines
end

local function unwrap_cites(inlines)
  -- citeproc output lives inside Cite elements; flatten for editing
  local out = pandoc.Inlines({})
  for _, x in ipairs(inlines) do
    if x.t == "Cite" then out:extend(x.content) else out:insert(x) end
  end
  return out
end

function Span(el)
  if el.classes:includes("hidecite") then
    return {}
  end
  if el.classes:includes("citealp") then
    local inl = unwrap_cites(el.content)
    return pandoc.Span(strip_parens(inl))
  end
  return nil
end

-- natbib (and APA narrative citations) join two authors with "and", not "&"
function Cite(el)
  el.content = el.content:walk({
    Str = function(s)
      if s.text == "&" then return pandoc.Str("and") end
      return nil
    end
  })
  return el
end

function Div(el)
  if el.identifier == "refs" then
    el.attributes["custom-style"] = "Bibliography"
    return el
  end
  return nil
end

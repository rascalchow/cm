#!/usr/bin/env python3
"""Print the (1-based) pages of a PDF that contain each search string.
usage: find_pages.py file.pdf "text 1" "text 2" ..."""
import subprocess
import sys

pdf, needles = sys.argv[1], sys.argv[2:]
txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout
pages = txt.split("\f")
for n in needles:
    hits = [str(i + 1) for i, p in enumerate(pages) if n in " ".join(p.split())]
    print("%-40s %s" % (n[:40], " ".join(hits[:12]) or "-"))

#!/usr/bin/env python3
"""Create scripts/docx/reference.docx: page setup, footer page numbers and all
paragraph / character styles used by the DOCX edition.

Starts from pandoc's default reference.docx (so every style pandoc expects is
present) and edits its OOXML directly (lxml): page size and margins, a footer
with a PAGE field, fonts with fallbacks, and the book's styles (headings in dark
blue sans, Palatino body, box styles in the PDF's colours, code, captions, ...).

    python3 scripts/docx/make_reference.py [-o scripts/docx/reference.docx]
"""
import argparse
import os
import subprocess
import tempfile
import zipfile

from lxml import etree

HERE = os.path.dirname(os.path.abspath(__file__))
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS = {"w": W, "r": R}

SERIF, SERIF_ALT, SANS, MONO = "Palatino Linotype", "Book Antiqua", "Arial", "Consolas"
BLUE, BLUE_L = "1F4E79", "EAF1F8"
GREEN, GREEN_L = "2E6B30", "EDF5EC"
ORANGE, ORANGE_L = "B5520B", "FDF1E6"
RED, RED_L = "9B1C1C", "FBECEC"
GREY, GREY_L = "555555", "F7F7F5"
CODE_BG = "F7F7F5"
TEXT_WIDTH = 9360          # twips (6.5in)

PPR_ORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr",
             "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "kinsoku", "wordWrap",
             "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
             "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc",
             "textDirection", "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr",
             "sectPr", "pPrChange"]
RPR_ORDER = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike", "outline",
             "shadow", "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden", "color", "spacing",
             "w", "kern", "position", "sz", "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText",
             "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath"]
STYLE_ORDER = ["name", "aliases", "basedOn", "next", "link", "autoRedefine", "hidden", "uiPriority",
               "semiHidden", "unhideWhenUsed", "qFormat", "locked", "personal", "personalCompose",
               "personalReply", "rsid", "pPr", "rPr", "tblPr", "trPr", "tcPr", "tblStylePr"]


def w(tag):
    return "{%s}%s" % (W, tag)


def el(tag, **attrs):
    e = etree.Element(w(tag))
    for k, v in attrs.items():
        e.set(w(k), str(v))
    return e


def put(parent, child, order):
    """Insert child at its schema position, replacing elements with the same tag."""
    tag = etree.QName(child).localname
    for old in parent.findall(w(tag)):
        parent.remove(old)
    idx = order.index(tag)
    for c in parent:
        name = etree.QName(c).localname
        if name in order and order.index(name) > idx:
            c.addprevious(child)
            return child
    parent.append(child)
    return child


def sub(parent, tag, order):
    e = parent.find(w(tag))
    if e is None:
        e = put(parent, el(tag), order)
    return e


class Styles:
    def __init__(self, root):
        self.root = root

    def find(self, name):
        for s in self.root.findall(w("style")):
            n = s.find(w("name"))
            if n is not None and n.get(w("val")).lower() == name.lower():
                return s
        return None

    def get(self, name, kind="paragraph", base=None, sid=None):
        s = self.find(name)
        if s is None:
            s = el("style", type=kind, styleId=sid or name.replace(" ", ""))
            s.set(w("customStyle"), "1")
            s.append(el("name", val=name))
            put(s, el("qFormat"), STYLE_ORDER)
            self.root.append(s)
        if base:
            b = self.find(base)
            put(s, el("basedOn", val=b.get(w("styleId"))), STYLE_ORDER)
        return Style(s)


class Style:
    def __init__(self, e):
        self.e = e

    @property
    def ppr(self):
        return sub(self.e, "pPr", STYLE_ORDER)

    @property
    def rpr(self):
        return sub(self.e, "rPr", STYLE_ORDER)

    def font(self, name=None, size=None, bold=None, italic=None, color=None, hidden=None):
        r = self.rpr
        if name:
            put(r, el("rFonts", ascii=name, hAnsi=name, cs=name, eastAsia=name), RPR_ORDER)
        for tag, val in (("b", bold), ("bCs", bold), ("i", italic), ("iCs", italic), ("vanish", hidden)):
            if val is not None:
                put(r, el(tag) if val else el(tag, val="0"), RPR_ORDER)
        if color:
            put(r, el("color", val=color), RPR_ORDER)
        if size:
            put(r, el("sz", val=int(round(size * 2))), RPR_ORDER)
            put(r, el("szCs", val=int(round(size * 2))), RPR_ORDER)
        return self

    def para(self, before=None, after=None, line=None, exact=None, first=None, hanging=None, left=None,
             right=None, align=None, keep_next=None, keep_lines=None, page_break=None):
        p = self.ppr
        if before is not None or after is not None or line is not None or exact is not None:
            sp = sub(p, "spacing", PPR_ORDER)
            if before is not None:
                sp.set(w("before"), str(int(before * 20)))
            if after is not None:
                sp.set(w("after"), str(int(after * 20)))
            if line is not None:
                sp.set(w("line"), str(int(line * 240)))
                sp.set(w("lineRule"), "auto")
            if exact is not None:
                sp.set(w("line"), str(int(exact * 20)))
                sp.set(w("lineRule"), "exact")
        if any(v is not None for v in (first, hanging, left, right)):
            ind = sub(p, "ind", PPR_ORDER)
            if left is not None:
                ind.set(w("left"), str(int(left * 1440)))
            if right is not None:
                ind.set(w("right"), str(int(right * 1440)))
            if first is not None:
                ind.attrib.pop(w("hanging"), None)
                ind.set(w("firstLine"), str(int(first * 1440)))
            if hanging is not None:
                ind.attrib.pop(w("firstLine"), None)
                ind.set(w("hanging"), str(int(hanging * 1440)))
        if align:
            put(p, el("jc", val=align), PPR_ORDER)
        for tag, val in (("keepNext", keep_next), ("keepLines", keep_lines), ("pageBreakBefore", page_break)):
            if val is not None:
                put(p, el(tag) if val else el(tag, val="0"), PPR_ORDER)
        return self

    def shade(self, fill):
        put(self.ppr, el("shd", val="clear", color="auto", fill=fill), PPR_ORDER)
        return self

    def border(self, **sides):
        b = el("pBdr")
        for side in ("top", "left", "bottom", "right"):
            if side in sides:
                sz, color, space = sides[side]
                b.append(el(side, val="single", sz=sz, space=space, color=color))
        put(self.ppr, b, PPR_ORDER)
        return self

    def outline(self, level):
        put(self.ppr, el("outlineLvl", val=level), PPR_ORDER)
        return self

    def tab(self, val, pos, leader=None):
        t = el("tabs")
        t.append(el("tab", val=val, pos=pos, leader=leader) if leader else el("tab", val=val, pos=pos))
        put(self.ppr, t, PPR_ORDER)
        return self


def build_styles(root):
    S = Styles(root)
    # document defaults: Palatino 10.5pt
    rpr = root.find("w:docDefaults/w:rPrDefault/w:rPr", NS)
    put(rpr, el("rFonts", ascii=SERIF, hAnsi=SERIF, cs=SERIF, eastAsia=SERIF), RPR_ORDER)
    put(rpr, el("sz", val=21), RPR_ORDER)
    put(rpr, el("szCs", val=21), RPR_ORDER)
    put(rpr, el("lang", val="en-US"), RPR_ORDER)

    normal = S.get("Normal")
    normal.para(before=0, after=0)
    # remove theme fonts on Normal (pandoc's default uses them via docDefaults)
    S.get("Body Text").para(before=0, after=0, line=1.0, first=0.22, align="both")
    S.get("First Paragraph", base="Body Text").para(first=0)
    S.get("Compact", base="Body Text").para(first=0, before=1, after=1)
    S.get("Block Text", base="Body Text").para(first=0, left=0.3, right=0.3, before=4, after=4).font(size=10)

    # headings
    S.get("Heading 1").font(SANS, 21, bold=True, italic=False, color=BLUE).para(
        before=0, after=20, line=1.0, keep_next=True, page_break=True, align="left").border(
        bottom=(12, BLUE, 6)).outline(0)
    S.get("Heading 2").font(SANS, 14.5, bold=True, italic=False, color=BLUE).para(
        before=18, after=8, line=1.0, keep_next=True, align="left").outline(1)
    S.get("Heading 3").font(SANS, 12, bold=True, italic=False, color=BLUE).para(
        before=12, after=6, line=1.0, keep_next=True, align="left").outline(2)
    for n in range(4, 10):
        S.get("Heading %d" % n).font(SANS, 11, bold=True, italic=False, color="000000").para(
            before=10, after=4, keep_next=True)
    for n in (2, 3, 4):
        S.get("Heading %d Unnumbered" % n, base="Heading %d" % n)
    S.get("Part Title", base="Normal").font(SANS, 30, bold=True, color=BLUE).para(
        before=190, after=24, align="center", keep_next=True, page_break=True).outline(0)
    for name in ("Title", "Subtitle", "Author", "Date"):
        S.get(name).font(SANS, color=BLUE)

    # TOC
    S.get("TOC Heading", base="Heading 1").font(SANS, 21, bold=True, color=BLUE).para(
        before=0, after=20, page_break=True).outline(9)
    for lvl, (fnt, size, bold, left, before, color) in {
            1: (SANS, 10.5, True, 0, 7, BLUE), 2: (SERIF, 10.5, False, 0.35, 1, "000000"),
            3: (SERIF, 10, False, 0.7, 0, "000000")}.items():
        S.get("toc %d" % lvl, base="Normal", sid="TOC%d" % lvl).font(fnt, size, bold=bold, color=color).para(
            before=before, after=1, left=left).tab("right", TEXT_WIDTH, "dot")

    # captions, figures, code
    S.get("Caption").font(SERIF, 9.5, italic=False, color="000000").para(
        before=4, after=12, line=1.05, left=0.1, right=0.1, align="both")
    S.get("Image Caption", base="Caption").para(before=4, after=14, keep_next=False)
    S.get("Table Caption", base="Caption").para(before=12, after=6, keep_next=True)
    for name in ("Listing Caption", "Algorithm Caption"):
        S.get(name, base="Caption").para(before=10, after=4, keep_next=True, left=0, right=0)
    for name in ("Figure", "Captioned Figure"):
        S.get(name, base="Normal").para(before=10, after=2, keep_next=True, align="center")
    S.get("Algorithm Image", base="Normal").para(before=2, after=12, align="center")
    S.get("Source Code", base="Normal").font(MONO, 9).para(
        before=4, after=10, line=1.0, left=0.12, right=0.05, align="left").shade(CODE_BG).border(
        left=(18, BLUE, 6), top=(2, CODE_BG, 3), bottom=(2, CODE_BG, 3))
    S.get("Verbatim Char", kind="character").font(MONO, 9.5)
    S.get("Hyperlink", kind="character").font(color=BLUE)
    hl = S.find("Hyperlink")
    put(sub(hl, "rPr", STYLE_ORDER), el("u", val="none"), RPR_ORDER)

    S.get("Bibliography", base="Normal").font(SERIF, 8.5).para(
        before=0, after=1.5, line=1.0, hanging=0.2, left=0.2, align="left")
    S.get("Bibliography Note", base="Normal").font(SERIF, 9.5).para(after=12, align="both")
    S.get("Table Text", base="Normal").font(SERIF, 9.5).para(before=1, after=1, line=1.0, align="left")
    S.get("Equation", base="Normal").para(before=3, after=3, line=1.0, align="center")
    S.get("Equation Number Cell", base="Normal").para(before=3, after=3, line=1.0, align="right")
    S.get("Equation Number", kind="character")

    # book elements
    S.get("Run-in Heading", kind="character").font(bold=True)
    S.get("Theorem Head", kind="character").font(bold=True, italic=False)
    S.get("Theorem Note", kind="character").font(bold=False, italic=False)
    S.get("Remark Head", kind="character").font(bold=False, italic=True)
    S.get("Exercise Label", kind="character").font(SANS, 10.5, bold=True, color=BLUE)
    S.get("Difficulty Stars", kind="character").font("Segoe UI Symbol", color=ORANGE)
    S.get("Box Marker", kind="character").font(hidden=True)
    S.get("Exercise Text", base="Body Text").para(first=0, before=7, after=0)
    # no keep-with-next inside box tables: LibreOffice then refuses to split the box
    S.get("Assignment Part", base="Normal").font(SANS, 10.5, bold=True, color=ORANGE).para(
        before=7, after=2, keep_next=False)
    for name, light, frame in [("Objectives", "FFFFFF", BLUE), ("Summary", BLUE_L, BLUE),
                               ("Key Idea", GREEN_L, GREEN), ("Practical Tip", ORANGE_L, ORANGE),
                               ("Caution", RED_L, RED), ("Historical Note", GREY_L, GREY),
                               ("Assignment", "FFFFFF", ORANGE), ("Box", GREY_L, GREY)]:
        S.get(name + " Title", base="Normal").font(SANS, 10.5, bold=True, color="FFFFFF").para(
            before=2, after=2, line=1.0, keep_next=True, align="left").shade(frame)
        S.get(name + " Text", base="Body Text").para(first=0, before=2, after=3).shade(light)
    S.get("Definition Text", base="Body Text").para(first=0, before=2, after=3).shade(BLUE_L)
    S.get("Theorem Text", base="Body Text").para(first=0, before=2, after=3).font(italic=True).shade(GREEN_L)
    S.get("Lemma Text", base="Body Text").para(first=0, before=6, after=4).font(italic=True)
    S.get("Subfigure Caption", base="Caption").para(before=2, after=4, align="center", keep_next=True)
    S.get("Example Text", base="Body Text").para(first=0, before=6, after=4)
    S.get("Proof Text", base="Body Text").para(first=0, before=2, after=6)

    # title page
    S.get("Title Band Text", base="Normal").font(SANS, 15, bold=True, color="FFFFFF").para(
        before=30, after=30, left=0.15, line=1.15)
    S.get("Title Band Image", base="Normal").para(before=6, after=6, align="right")
    S.get("Book Title", base="Normal").font(SANS, 40, bold=True, color=BLUE).para(before=96, after=10, line=1.0)
    S.get("Book Subtitle", base="Normal").font(SANS, 20, color=ORANGE).para(before=0, after=36)
    S.get("Book Description", base="Normal").font(SERIF, 13).para(before=0, after=110, right=0.9, line=1.15)
    S.get("Book Tagline", base="Normal").font(SANS, 12).para(after=6)
    S.get("Book Edition", base="Normal").font(SANS, 11, color=GREY)
    S.get("Reverse Page", base="Normal").font(SERIF, 9.5).para(before=0, after=7, line=1.1, align="left")
    S.get("Footer", base="Normal", sid="Footer").font(SANS, 9, color="404040").para(align="center")

    # table style used by pandoc ("Table"): compact cells, booktabs rules are set per table
    tbl = S.find("Table")
    if tbl is not None:
        tp = tbl.find(w("tblPr"))
        if tp is None:
            tp = put(tbl, el("tblPr"), STYLE_ORDER)
        mar = tp.find(w("tblCellMar"))
        if mar is not None:
            tp.remove(mar)
        mar = el("tblCellMar")
        for side, v in (("top", 20), ("left", 85), ("bottom", 20), ("right", 85)):
            mar.append(el(side, w=v, type="dxa"))
        tp.append(mar)


FONT_XML = (
    '<w:font w:name="%s"><w:altName w:val="%s"/><w:panose1 w:val="02040502050505030304"/>'
    '<w:charset w:val="00"/><w:family w:val="roman"/><w:pitch w:val="variable"/></w:font>'
    '<w:font w:name="%s"><w:altName w:val="Times New Roman"/><w:panose1 w:val="02040602050305030304"/>'
    '<w:charset w:val="00"/><w:family w:val="roman"/><w:pitch w:val="variable"/></w:font>'
    '<w:font w:name="Arial"><w:altName w:val="Helvetica"/><w:panose1 w:val="020B0604020202020204"/>'
    '<w:charset w:val="00"/><w:family w:val="swiss"/><w:pitch w:val="variable"/></w:font>'
    '<w:font w:name="Consolas"><w:altName w:val="Courier New"/><w:panose1 w:val="020B0609020204030204"/>'
    '<w:charset w:val="00"/><w:family w:val="modern"/><w:pitch w:val="fixed"/></w:font>'
) % (SERIF, SERIF_ALT, SERIF_ALT)

FOOTER_XML = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
              '<w:ftr xmlns:w="%s" xmlns:r="%s"><w:p><w:pPr><w:pStyle w:val="Footer"/><w:jc w:val="center"/>'
              '</w:pPr><w:r><w:fldChar w:fldCharType="begin"/></w:r><w:r><w:instrText xml:space="preserve"> PAGE '
              '</w:instrText></w:r><w:r><w:fldChar w:fldCharType="separate"/></w:r><w:r><w:t>1</w:t></w:r>'
              '<w:r><w:fldChar w:fldCharType="end"/></w:r></w:p></w:ftr>' % (W, R))

SECTPR = ('<w:sectPr xmlns:w="%s" xmlns:r="%s"><w:footerReference w:type="default" r:id="rIdBookFooter"/>'
          '<w:pgSz w:w="12240" w:h="15840"/>'
          '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="648" '
          'w:gutter="0"/><w:cols w:space="720"/></w:sectPr>' % (W, R))


def build(out):
    with tempfile.TemporaryDirectory() as tmp:
        base = os.path.join(tmp, "default.docx")
        subprocess.run(["pandoc", "-o", base, "--print-default-data-file", "reference.docx"], check=True)
        zin = zipfile.ZipFile(base)
        files = {i.filename: zin.read(i.filename) for i in zin.infolist()}
        infos = {i.filename: i for i in zin.infolist()}

    styles = etree.fromstring(files["word/styles.xml"])
    build_styles(styles)
    files["word/styles.xml"] = etree.tostring(styles, xml_declaration=True, encoding="UTF-8", standalone=True)

    doc = etree.fromstring(files["word/document.xml"])
    body = doc.find(w("body"))
    for sp in body.findall(w("sectPr")):
        body.remove(sp)
    body.append(etree.fromstring(SECTPR))
    files["word/document.xml"] = etree.tostring(doc, xml_declaration=True, encoding="UTF-8", standalone=True)
    files["word/footer1.xml"] = FOOTER_XML.encode("utf-8")

    rels = files["word/_rels/document.xml.rels"].decode("utf-8")
    if "rIdBookFooter" not in rels:
        rels = rels.replace("</Relationships>",
                            '<Relationship Id="rIdBookFooter" Type="http://schemas.openxmlformats.org/'
                            'officeDocument/2006/relationships/footer" Target="footer1.xml"/></Relationships>')
    files["word/_rels/document.xml.rels"] = rels.encode("utf-8")
    ct = files["[Content_Types].xml"].decode("utf-8")
    if "/word/footer1.xml" not in ct:
        ct = ct.replace("</Types>", '<Override PartName="/word/footer1.xml" ContentType="application/'
                        'vnd.openxmlformats-officedocument.wordprocessingml.footer+xml"/></Types>')
    files["[Content_Types].xml"] = ct.encode("utf-8")
    ft = files["word/fontTable.xml"].decode("utf-8")
    if SERIF not in ft:
        ft = ft.replace("</w:fonts>", FONT_XML + "</w:fonts>")
    files["word/fontTable.xml"] = ft.encode("utf-8")

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in files.items():
            zout.writestr(infos.get(name, name), data)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("-o", "--out", default=os.path.join(HERE, "reference.docx"))
    a = ap.parse_args()
    build(a.out)
    print("reference document: %s" % os.path.relpath(a.out))

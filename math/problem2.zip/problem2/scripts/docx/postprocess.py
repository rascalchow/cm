#!/usr/bin/env python3
"""postprocess.py -- finish the pandoc DOCX (OOXML-level fixes pandoc cannot do).

    python3 scripts/docx/postprocess.py IN.docx OUT.docx [--toc-pages pages.json]

* box markers (BOXSTART:kind ... BOXEND:kind) -> one-cell tables with the PDF's
  colours (title bar + light body, or a coloured left rule for theorem boxes)
* numbered display equations -> borderless 3-column table [ | equation | (7.4) ]
* pandoc tables -> booktabs look (top/bottom rules, rule under the header row)
* bookmark names sanitised for Word (letters, digits, underscore; <= 40 chars)
* a pre-populated table of contents inside the TOC field (page numbers from a
  LibreOffice rendering when --toc-pages is given; Word refreshes it on open)
* front matter in a section with roman page numbers, main matter from 1
* bold-italic for \\boldsymbol letters, centred unnumbered display math,
  alt text for figures, schema order of pPr/rPr children, settings.
"""
import argparse
import copy
import json
import re
import sys
import zipfile

from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"
NS = {"w": W, "m": M, "r": R, "wp": WP, "pic": PIC}


def w(tag):
    return "{%s}%s" % (W, tag)


def m(tag):
    return "{%s}%s" % (M, tag)


def el(tag, **attrs):
    e = etree.Element(w(tag))
    for k, v in attrs.items():
        e.set(w(k), str(v))
    return e


def sub(parent, tag, **attrs):
    e = el(tag, **attrs)
    parent.append(e)
    return e


PPR_ORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr",
             "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "kinsoku", "wordWrap",
             "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd",
             "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc",
             "textDirection", "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr",
             "sectPr", "pPrChange"]
RPR_ORDER = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike", "outline",
             "shadow", "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden", "color", "spacing",
             "w", "kern", "position", "sz", "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText",
             "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath"]
TBLPR_ORDER = ["tblStyle", "tblpPr", "tblOverlap", "bidiVisual", "tblStyleRowBandSize", "tblStyleColBandSize",
               "tblW", "jc", "tblCellSpacing", "tblInd", "tblBorders", "shd", "tblLayout", "tblCellMar",
               "tblLook", "tblCaption", "tblDescription"]
TCPR_ORDER = ["cnfStyle", "tcW", "gridSpan", "hMerge", "vMerge", "tcBorders", "shd", "noWrap", "tcMar",
              "textDirection", "tcFitText", "vAlign", "hideMark"]

SECTPR_ORDER = ["headerReference", "footerReference", "footnotePr", "endnotePr", "type", "pgSz", "pgMar",
                "paperSrc", "pgBorders", "lnNumType", "pgNumType", "cols", "formProt", "vAlign", "noEndnote",
                "titlePg", "textDirection", "bidi", "rtlGutter", "docGrid", "printerSettings", "sectPrChange"]
STYLE_ORDER = ["name", "aliases", "basedOn", "next", "link", "autoRedefine", "hidden", "uiPriority",
               "semiHidden", "unhideWhenUsed", "qFormat", "locked", "personal", "personalCompose",
               "personalReply", "rsid", "pPr", "rPr", "tblPr", "trPr", "tcPr", "tblStylePr"]
BORDER_ORDER = ["top", "left", "start", "bottom", "right", "end", "insideH", "insideV", "tl2br", "tr2bl",
                "between", "bar"]
# children order of OOXML containers that pandoc/texmath sometimes emit out of order
ORDERS = {
    (W, "pPr"): PPR_ORDER, (W, "rPr"): RPR_ORDER, (W, "tblPr"): TBLPR_ORDER, (W, "tcPr"): TCPR_ORDER,
    (W, "sectPr"): SECTPR_ORDER, (W, "style"): STYLE_ORDER, (W, "pBdr"): BORDER_ORDER,
    (W, "tblBorders"): BORDER_ORDER, (W, "tcBorders"): BORDER_ORDER, (W, "tblCellMar"): BORDER_ORDER,
    (W, "tcMar"): BORDER_ORDER,
    (M, "rPr"): ["lit", "nor", "scr", "sty", "brk", "aln"],
    (M, "dPr"): ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"],
    (M, "mcPr"): ["count", "mcJc"],
    (M, "mPr"): ["baseJc", "plcHide", "rSpRule", "cGapRule", "rSp", "cSp", "cGap", "mcs", "ctrlPr"],
    (M, "naryPr"): ["chr", "limLoc", "grow", "subHide", "supHide", "ctrlPr"],
    (M, "fPr"): ["type", "ctrlPr"],
    (M, "eqArrPr"): ["baseJc", "maxDist", "objDist", "rSpRule", "rSp", "ctrlPr"],
}


SETTINGS_ORDER = [
    "writeProtection", "view", "zoom", "removePersonalInformation", "removeDateAndTime",
    "doNotDisplayPageBoundaries", "displayBackgroundShape", "printPostScriptOverText",
    "printFractionalCharacterWidth", "printFormsData", "embedTrueTypeFonts", "embedSystemFonts",
    "saveSubsetFonts", "saveFormsData", "mirrorMargins", "alignBordersAndEdges", "bordersDoNotSurroundHeader",
    "bordersDoNotSurroundFooter", "gutterAtTop", "hideSpellingErrors", "hideGrammaticalErrors",
    "activeWritingStyle", "proofState", "formsDesign", "attachedTemplate", "linkStyles", "stylePaneFormatFilter",
    "stylePaneSortMethod", "documentType", "mailMerge", "revisionView", "trackRevisions", "doNotTrackMoves",
    "doNotTrackFormatting", "documentProtection", "autoFormatOverride", "styleLockTheme", "styleLockQFSet",
    "defaultTabStop", "autoHyphenation", "consecutiveHyphenLimit", "hyphenationZone", "doNotHyphenateCaps",
    "showEnvelope", "summaryLength", "clickAndTypeStyle", "defaultTableStyle", "evenAndOddHeaders",
    "bookFoldRevPrinting", "bookFoldPrinting", "bookFoldPrintingSheets", "drawingGridHorizontalSpacing",
    "drawingGridVerticalSpacing", "displayHorizontalDrawingGridEvery", "displayVerticalDrawingGridEvery",
    "doNotUseMarginsForDrawingGridOrigin", "drawingGridHorizontalOrigin", "drawingGridVerticalOrigin",
    "doNotShadeFormData", "noPunctuationKerning", "characterSpacingControl", "printTwoOnOne",
    "strictFirstAndLastChars", "noLineBreaksAfter", "noLineBreaksBefore", "savePreviewPicture",
    "doNotValidateAgainstSchema", "saveInvalidXml", "ignoreMixedContent", "alwaysShowPlaceholderText",
    "doNotDemarcateInvalidXml", "saveXmlDataOnly", "useXSLTWhenSaving", "saveThroughXslt", "showXMLTags",
    "alwaysMergeEmptyNamespace", "updateFields", "hdrShapeDefaults", "footnotePr", "endnotePr", "compat",
    "docVars", "rsids", "mathPr", "attachedSchema", "themeFontLang", "clrSchemeMapping",
    "doNotIncludeSubdocsInStats", "doNotAutoCompressPictures", "forceUpgrade", "captions",
    "readModeInkLockDown", "smartTagType", "schemaLibrary", "shapeDefaults", "doNotEmbedSmartTags",
    "decimalSymbol", "listSeparator"]


def normalize(root):
    """Put children of known OOXML containers into schema order; drop stray text."""
    for e in root.iter():
        if not isinstance(e.tag, str):
            continue
        q = etree.QName(e)
        if (q.namespace, q.localname) == (M, "rPr") and e.find(m("nor")) is not None:
            for x in e.findall(m("sty")) + e.findall(m("scr")):
                e.remove(x)
        order = ORDERS.get((q.namespace, q.localname))
        if order:
            order_children(e, order)
            if q.localname in ("rPr", "pPr") and e.text and e.text.strip():
                e.text = None
            for c in e:
                if c.tail and c.tail.strip():
                    c.tail = None


# kind -> (frame colour, title fill, body fill, style)  style: "titled" | "rule" | "band"
BOXES = {
    "objectives": ("1F4E79", "1F4E79", "FFFFFF", "titled"),
    "summarybox": ("1F4E79", "1F4E79", "EAF1F8", "titled"),
    "keyidea": ("2E6B30", "2E6B30", "EDF5EC", "titled"),
    "practicaltip": ("B5520B", "B5520B", "FDF1E6", "titled"),
    "caution": ("9B1C1C", "9B1C1C", "FBECEC", "titled"),
    "historybox": ("555555", "555555", "F7F7F5", "titled"),
    "assignment": ("B5520B", "B5520B", "FFFFFF", "titled"),
    "generic": ("555555", "555555", "F7F7F5", "titled"),
    "definition": ("1F4E79", None, "EAF1F8", "rule"),
    "theorem": ("2E6B30", None, "EDF5EC", "rule"),
    "proposition": ("2E6B30", None, "EDF5EC", "rule"),
    "titleband": ("B5520B", None, "1F4E79", "band"),
}


def order_children(parent, order):
    kids = list(parent)
    known = [k for k in kids if etree.QName(k).localname in order]
    if not known:
        return
    known_sorted = sorted(known, key=lambda k: order.index(etree.QName(k).localname))
    if known_sorted == known:
        return
    for k in known:
        parent.remove(k)
    others = [k for k in parent]
    for k in others:
        parent.remove(k)
    for k in known_sorted + others:
        parent.append(k)


def pstyle(p):
    ppr = p.find(w("pPr"))
    if ppr is None:
        return None
    s = ppr.find(w("pStyle"))
    return None if s is None else s.get(w("val"))


def set_pstyle(p, style):
    ppr = p.find(w("pPr"))
    if ppr is None:
        ppr = el("pPr")
        p.insert(0, ppr)
    s = ppr.find(w("pStyle"))
    if s is None:
        s = el("pStyle")
        ppr.insert(0, s)
    s.set(w("val"), style)


def text_of(e):
    return "".join(t.text or "" for t in e.iter(w("t"), m("t")))


def run_style(r):
    rs = r.find("w:rPr/w:rStyle", NS)
    return None if rs is None else rs.get(w("val"))


def marker_of(p):
    """'BOXSTART:kind' / 'BOXEND:kind' if p is a box marker paragraph."""
    if p.tag != w("p"):
        return None
    runs = p.findall(w("r"))
    if runs and all(run_style(r) == "BoxMarker" for r in runs):
        return text_of(p).strip()
    return None


def has_content(p):
    for e in p.iter():
        tag = etree.QName(e).localname
        if tag in ("oMath", "oMathPara", "drawing", "pict", "object", "br", "tab", "fldChar", "instrText"):
            return True
        if tag == "t" and (e.text or "").strip():
            return True
    return False


# ---------------------------------------------------------------------------
class Post:
    def __init__(self, files):
        self.files = files
        self.doc = etree.fromstring(files["word/document.xml"])
        self.body = self.doc.find(w("body"))
        self.stats = {}

    def count(self, k, n=1):
        self.stats[k] = self.stats.get(k, 0) + n

    # -- tables --------------------------------------------------------------
    @staticmethod
    def new_table(widths_pct, borders=None, layout_fixed=True, jc=None, cell_mar=None, indent=None):
        tbl = el("tbl")
        tp = sub(tbl, "tblPr")
        sub(tp, "tblW", w=5000, type="pct")
        if jc:
            sub(tp, "jc", val=jc)
        if indent is not None:
            sub(tp, "tblInd", w=indent, type="dxa")
        b = sub(tp, "tblBorders")
        for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
            spec = (borders or {}).get(side)
            if spec:
                sz, color = spec
                sub(b, side, val="single", sz=sz, space=0, color=color)
            else:
                sub(b, side, val="nil")
        if layout_fixed:
            sub(tp, "tblLayout", type="fixed")
        mar = sub(tp, "tblCellMar")
        t, l, bt, r = cell_mar or (0, 0, 0, 0)
        for side, v in (("top", t), ("left", l), ("bottom", bt), ("right", r)):
            sub(mar, side, w=v, type="dxa")
        sub(tp, "tblLook", val="0000", firstRow="0", lastRow="0", firstColumn="0", lastColumn="0",
            noHBand="1", noVBand="1")
        grid = sub(tbl, "tblGrid")
        for pct in widths_pct:
            sub(grid, "gridCol", w=int(9360 * pct / 100.0))
        return tbl

    @staticmethod
    def new_cell(tr, pct, fill=None, valign=None, borders=None):
        tc = sub(tr, "tc")
        tcpr = sub(tc, "tcPr")
        sub(tcpr, "tcW", w=int(pct * 50), type="pct")
        if borders:
            b = sub(tcpr, "tcBorders")
            for side in ("top", "left", "bottom", "right"):
                if side in borders:
                    sz, color = borders[side]
                    sub(b, side, val="single", sz=sz, space=0, color=color)
        if fill:
            sub(tcpr, "shd", val="clear", color="auto", fill=fill)
        if valign:
            sub(tcpr, "vAlign", val=valign)
        return tc

    # -- 1. numbered equations ------------------------------------------------
    def equations(self):
        for p in list(self.body.iter(w("p"))):
            if p.find(m("oMathPara")) is None:
                continue
            parent = p.getparent()
            if parent is None:
                continue
            nxt = p.getnext()
            nums = []
            if nxt is not None and nxt.tag == w("p"):
                kids = [k for k in nxt if k.tag != w("pPr")]
                take = []
                for k in kids:
                    if k.tag in (w("bookmarkStart"), w("bookmarkEnd")):
                        take.append(k)
                        continue
                    if k.tag == w("r") and run_style(k) == "EquationNumber":
                        take.append(k)
                        nums.append(text_of(k))
                        continue
                    break
                # keep bookmarkStart/End pairs that belong to the number only
                if nums:
                    last_num = max(i for i, k in enumerate(take) if k.tag == w("r"))
                    take = take[:last_num + 1] + [k for k in take[last_num + 1:] if k.tag == w("bookmarkEnd")]
                    for k in take:
                        nxt.remove(k)
                    # strip the space that followed the number
                    for k in [k for k in nxt if k.tag != w("pPr")]:
                        if k.tag == w("r") and not text_of(k).strip() and k.find(w("t")) is not None:
                            nxt.remove(k)
                            continue
                        if k.tag == w("r"):
                            t = k.find(w("t"))
                            if t is not None and t.text:
                                t.text = t.text.lstrip()
                        break
                    if not has_content(nxt):
                        # keep any remaining bookmarks by moving them into the number paragraph
                        leftovers = [k for k in nxt if k.tag in (w("bookmarkStart"), w("bookmarkEnd"))]
                        take.extend(leftovers)
                        nxt.getparent().remove(nxt)
            set_pstyle(p, "Equation")
            ppr = p.find(w("pPr"))
            for tag in ("numPr", "ind"):
                for x in ppr.findall(w(tag)):
                    ppr.remove(x)
            if not nums:
                self.count("display math (unnumbered)")
                continue
            tbl = self.new_table([9, 82, 9])
            tr = sub(tbl, "tr")
            sub(sub(tr, "trPr"), "cantSplit")
            c1 = self.new_cell(tr, 9, valign="center")
            sub(c1, "p").append(el("pPr"))
            set_pstyle(c1.find(w("p")), "Equation")
            c2 = self.new_cell(tr, 82, valign="center")
            idx = parent.index(p)
            parent.remove(p)
            c2.append(p)
            c3 = self.new_cell(tr, 9, valign="center")
            pn = sub(c3, "p")
            set_pstyle(pn, "EquationNumberCell")
            for k in take:
                pn.append(k)
            parent.insert(idx, tbl)
            self.count("numbered equations")

    # -- 2. boxes -------------------------------------------------------------
    def boxes(self, container):
        kids = list(container)
        i = 0
        while i < len(kids):
            mk = marker_of(kids[i])
            if mk and mk.startswith("BOXSTART:"):
                kind = mk.split(":", 1)[1]
                depth, j = 1, i + 1
                while j < len(kids):
                    mj = marker_of(kids[j])
                    if mj and mj.startswith("BOXSTART:"):
                        depth += 1
                    elif mj and mj.startswith("BOXEND:"):
                        depth -= 1
                        if depth == 0:
                            break
                    j += 1
                inner = kids[i + 1:j]
                start = kids[i]
                idx = container.index(start)
                for k in kids[i:j + 1]:
                    container.remove(k)
                holder = el("holder")
                for k in inner:
                    holder.append(k)
                self.boxes(holder)          # nested boxes first
                container.insert(idx, self.make_box(kind, list(holder)))
                self.count("box:" + kind)
                kids = list(container)
                i = kids.index(container[idx]) + 1
                continue
            if kids[i].tag == w("tbl"):
                for tc in kids[i].iter(w("tc")):
                    self.boxes(tc)
            i += 1

    def make_box(self, kind, content):
        frame, title_fill, fill, style = BOXES.get(kind, BOXES["generic"])
        if style == "band":
            tbl = self.new_table([62, 38], borders={"bottom": (48, frame)}, cell_mar=(60, 160, 60, 160))
            tr = sub(tbl, "tr")
            paras = [c for c in content if c.tag == w("p")]
            texts = [c for c in paras if pstyle(c) == "TitleBandText"] or paras[:1]
            imgs = [c for c in paras if c not in texts]
            c1 = self.new_cell(tr, 62, fill=fill, valign="center")
            for c in texts:
                c1.append(c)
            c2 = self.new_cell(tr, 38, fill=fill, valign="center")
            for c in imgs:
                c2.append(c)
            for tc in (c1, c2):
                if tc.find(w("p")) is None:
                    sub(tc, "p")
            return tbl
        if style == "rule":
            tbl = self.new_table([100], borders={"left": (20, frame)}, cell_mar=(70, 150, 70, 150))
            tr = sub(tbl, "tr")
            c = self.new_cell(tr, 100, fill=fill)
            for k in content:
                c.append(k)
            self.ensure_last_p(c)
            return tbl
        borders = {"top": (6, frame), "bottom": (6, frame), "right": (6, frame), "left": (24, frame)}
        tbl = self.new_table([100], borders=borders, cell_mar=(50, 150, 50, 150))
        title = [k for k in content[:1] if k.tag == w("p") and (pstyle(k) or "").endswith("Title")]
        if title:
            tr = sub(tbl, "tr")
            trpr = sub(tr, "trPr")
            sub(trpr, "cantSplit")
            c = self.new_cell(tr, 100, fill=title_fill)
            c.append(title[0])
            content = content[1:]
        tr = sub(tbl, "tr")
        c = self.new_cell(tr, 100, fill=fill)
        for k in content:
            c.append(k)
        self.ensure_last_p(c)
        return tbl

    @staticmethod
    def ensure_last_p(tc):
        kids = [k for k in tc if k.tag != w("tcPr")]
        if not kids or kids[-1].tag != w("p"):
            p = sub(tc, "p")
            ppr = sub(p, "pPr")
            sp = sub(ppr, "spacing", before=0, after=0, line=120, lineRule="exact")
            sp.tail = None

    # -- 3. pandoc tables -> booktabs -----------------------------------------
    def booktabs(self):
        for tbl in self.body.iter(w("tbl")):
            ts = tbl.find("w:tblPr/w:tblStyle", NS)
            if ts is None or ts.get(w("val")) != "Table":
                continue
            tp = tbl.find(w("tblPr"))
            for tag in ("tblBorders", "jc"):
                for x in tp.findall(w(tag)):
                    tp.remove(x)
            tp.append(el("jc", val="center"))
            b = el("tblBorders")
            for side in ("top", "left", "bottom", "right", "insideH", "insideV"):
                if side in ("top", "bottom"):
                    sub(b, side, val="single", sz=10, space=0, color="000000")
                else:
                    sub(b, side, val="nil")
            tp.append(b)
            order_children(tp, TBLPR_ORDER)
            rows = tbl.findall(w("tr"))
            header = [r for r in rows if r.find("w:trPr/w:tblHeader", NS) is not None]
            if header:
                for tc in header[-1].findall(w("tc")):
                    tcpr = tc.find(w("tcPr"))
                    if tcpr is None:
                        tcpr = el("tcPr")
                        tc.insert(0, tcpr)
                    tb = el("tcBorders")
                    sub(tb, "bottom", val="single", sz=5, space=0, color="000000")
                    tcpr.append(tb)
                    order_children(tcpr, TCPR_ORDER)
            for p in tbl.iter(w("p")):
                if pstyle(p) in (None, "Compact", "BodyText", "FirstParagraph"):
                    set_pstyle(p, "TableText")
            self.count("tables")

    # -- 4. maths: bold vectors are bold italic as in LaTeX's \bm ---------------
    def math_bold_italic(self):
        n = 0
        for r in self.body.iter(m("r")):
            sty = r.find("m:rPr/m:sty", NS)
            if sty is None or sty.get(m("val")) != "b":
                continue
            t = r.find(m("t"))
            s = (t.text or "") if t is not None else ""
            if s and all(("a" <= c <= "z") or ("A" <= c <= "Z") or ("α" <= c <= "ω") or c in "ϑϕϵϱ" for c in s):
                sty.set(m("val"), "bi")
                n += 1
        self.count("bold-italic math runs", n)

    # -- 5. bookmarks ------------------------------------------------------------
    def bookmarks(self):
        names, used = {}, set()
        for bs in self.body.iter(w("bookmarkStart")):
            old = bs.get(w("name"))
            if old in names:
                continue
            if old.startswith("_Toc") or re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,39}", old):
                new = old
            else:
                new = "B_" + re.sub(r"[^A-Za-z0-9]+", "_", old).strip("_")
                new = new[:36]
            base, k = new, 1
            while new in used:
                new = "%s_%d" % (base[:34], k)
                k += 1
            used.add(new)
            names[old] = new
        for bs in self.body.iter(w("bookmarkStart")):
            bs.set(w("name"), names[bs.get(w("name"))])
        bad = 0
        for h in self.body.iter(w("hyperlink")):
            a = h.get(w("anchor"))
            if a is None:
                continue
            if a in names:
                h.set(w("anchor"), names[a])
            elif a not in used:
                bad += 1
        # unique bookmark ids
        ids = {}
        for k, bs in enumerate(self.body.iter(w("bookmarkStart"))):
            ids[bs.get(w("id"))] = str(k + 1)
            bs.set(w("id"), str(k + 1))
        for be in self.body.iter(w("bookmarkEnd")):
            if be.get(w("id")) in ids:
                be.set(w("id"), ids[be.get(w("id"))])
        self.names = names
        self.count("bookmarks", len(names))
        if bad:
            self.count("hyperlinks without target", bad)

    # -- 6. figures: alt text ------------------------------------------------------
    def alt_text(self):
        for p in self.body.iter(w("p")):
            if pstyle(p) not in ("CaptionedFigure", "Figure"):
                continue
            cap = p.getnext()
            desc = text_of(cap).strip() if cap is not None and pstyle(cap) == "ImageCaption" else ""
            for dp in p.iter("{%s}docPr" % WP):
                dp.set("descr", desc[:1000])
            for cp in p.iter("{%s}cNvPr" % PIC):
                cp.set("descr", desc[:1000])

    # -- 7. sections: roman numbers in the front matter -------------------------------
    def sections(self):
        final = self.body.find(w("sectPr"))
        first_part = None
        for p in self.body.iter(w("p")):
            if pstyle(p) in ("PartTitle", "Heading1") and p.getparent() is self.body:
                txt = text_of(p)
                if pstyle(p) == "PartTitle" or txt.startswith("Chapter"):
                    first_part = p
                    break
        if final is None or first_part is None:
            return
        front = copy.deepcopy(final)
        for x in front.findall(w("pgNumType")):
            front.remove(x)
        pg = el("pgNumType", fmt="lowerRoman", start="1")
        front.insert(list(front).index(front.find(w("pgSz"))) if front.find(w("pgSz")) is not None else 0, pg)
        # move pgNumType after pgMar (schema: ...pgSz, pgMar, paperSrc, pgBorders, lnNumType, pgNumType, cols...)
        front.remove(pg)
        cols = front.find(w("cols"))
        if cols is not None:
            cols.addprevious(pg)
        else:
            front.append(pg)
        # title page without page number
        front.append(el("titlePg"))
        order_children(front, SECTPR_ORDER)
        holder = el("p")
        ppr = sub(holder, "pPr")
        sp = sub(ppr, "spacing", before=0, after=0, line=20, lineRule="exact")
        ppr.append(front)
        first_part.addprevious(holder)
        for x in final.findall(w("pgNumType")):
            final.remove(x)
        pg2 = el("pgNumType", start="1")
        cols = final.find(w("cols"))
        if cols is not None:
            cols.addprevious(pg2)
        else:
            final.append(pg2)
        order_children(final, SECTPR_ORDER)
        self.count("sections", 2)

    # -- 7b. bibliography in two columns (as in the PDF) ----------------------------
    def bib_columns(self):
        final = self.body.find(w("sectPr"))
        first = None
        for p in self.body.iter(w("p")):
            if pstyle(p) == "Bibliography":
                first = p
                break
        if final is None or first is None:
            return
        # the section ending just before the reference list keeps the single-column layout
        main = copy.deepcopy(final)
        holder = el("p")
        ppr = sub(holder, "pPr")
        sub(ppr, "spacing", before=0, after=0, line=20, lineRule="exact")
        ppr.append(main)
        first.addprevious(holder)
        # the last section (the reference list) continues on the same page, in two columns,
        # and continues the page numbering
        for x in final.findall(w("pgNumType")) + final.findall(w("cols")) + final.findall(w("type")):
            final.remove(x)
        final.append(el("type", val="continuous"))
        final.append(el("cols", num="2", space="425"))
        order_children(final, SECTPR_ORDER)
        self.count("sections", 1)

    @staticmethod
    def _order_sectpr(sp):
        order = ["headerReference", "footerReference", "footnotePr", "endnotePr", "type", "pgSz", "pgMar",
                 "paperSrc", "pgBorders", "lnNumType", "pgNumType", "cols", "formProt", "vAlign", "noEndnote",
                 "titlePg", "textDirection", "bidi", "rtlGutter", "docGrid", "printerSettings", "sectPrChange"]
        order_children(sp, order)

    # -- 8. table of contents --------------------------------------------------------
    def toc(self, pages=None):
        sdt = None
        for s in self.body.iter(w("sdt")):
            g = s.find(".//w:docPartGallery", NS)
            if g is not None and g.get(w("val")) == "Table of Contents":
                sdt = s
                break
        if sdt is None:
            return []
        entries = []
        for p in self.body.iter(w("p")):
            st = pstyle(p)
            lvl = {"PartTitle": 1, "Heading1": 1, "Heading2": 2}.get(st)
            if lvl is None or p.getparent() is not self.body:
                continue
            txt = re.sub(r"\s+", " ", text_of(p)).strip()
            if not txt:
                continue
            bm = p.find(w("bookmarkStart"))
            if bm is None or bm.get(w("name")).startswith("_GoBack"):
                name = "_TocBook%04d" % len(entries)
                bs = el("bookmarkStart", id=str(900000 + len(entries)), name=name)
                be = el("bookmarkEnd", id=str(900000 + len(entries)))
                ppr = p.find(w("pPr"))
                (ppr.addnext(bs) if ppr is not None else p.insert(0, bs))
                p.append(be)
            else:
                name = bm.get(w("name"))
            entries.append({"level": lvl, "text": txt, "bookmark": name, "part": st == "PartTitle"})
        content = sdt.find(w("sdtContent"))
        field_p = [p for p in content.findall(w("p")) if p.find(".//w:instrText", NS) is not None][0]
        instr = field_p.find(".//w:instrText", NS).text
        for p in content.findall(w("p")):
            if p is not field_p and pstyle(p) != "TOCHeading":
                content.remove(p)
        new = []
        for k, e in enumerate(entries):
            p = el("p")
            ppr = sub(p, "pPr")
            sub(ppr, "pStyle", val="TOC%d" % e["level"])
            if e["part"]:
                sub(ppr, "spacing", before=200, after=40)
            if k == 0:
                for typ in ("begin",):
                    r = sub(p, "r")
                    sub(r, "fldChar", fldCharType="begin")
                r = sub(p, "r")
                it = sub(r, "instrText")
                it.text = instr
                it.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                r = sub(p, "r")
                sub(r, "fldChar", fldCharType="separate")
            h = sub(p, "hyperlink", anchor=e["bookmark"], history="1")
            r = sub(h, "r")
            t = sub(r, "t")
            t.text = e["text"]
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            r = sub(h, "r")
            sub(r, "tab")
            r = sub(h, "r")
            sub(r, "fldChar", fldCharType="begin")
            r = sub(h, "r")
            it = sub(r, "instrText")
            it.text = " PAGEREF %s \\h " % e["bookmark"]
            it.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            r = sub(h, "r")
            sub(r, "fldChar", fldCharType="separate")
            r = sub(h, "r")
            t = sub(r, "t")
            t.text = (pages or {}).get(str(k), "") if pages else "0"
            r = sub(h, "r")
            sub(r, "fldChar", fldCharType="end")
            new.append(p)
        if new:
            r = sub(new[-1], "r")
            sub(r, "fldChar", fldCharType="end")
            idx = content.index(field_p)
            content.remove(field_p)
            for k, p in enumerate(new):
                content.insert(idx + k, p)
        self.count("toc entries", len(entries))
        return entries

    # -- 9. general clean-up -----------------------------------------------------------
    def cleanup(self):
        # stray marker runs, schema order, cells ending with a paragraph
        for r in list(self.body.iter(w("r"))):
            if run_style(r) == "BoxMarker":
                p = r.getparent()
                p.remove(r)
                if p.tag == w("p") and not has_content(p) and p.getparent() is not None:
                    p.getparent().remove(p)
        for tc in self.body.iter(w("tc")):
            self.ensure_last_p(tc)
        normalize(self.doc)

    def settings(self):
        """updateFields (Word refreshes TOC and page references on opening), valid nsids."""
        st = etree.fromstring(self.files["word/settings.xml"])
        if st.find(w("updateFields")) is None:
            st.append(el("updateFields", val="true"))
        order_children(st, SETTINGS_ORDER)
        self.files["word/settings.xml"] = etree.tostring(st, xml_declaration=True, encoding="UTF-8",
                                                         standalone=True)
        num = self.files.get("word/numbering.xml")
        if num:
            num = re.sub(rb'(<w:nsid w:val=")([0-9A-Fa-f]{1,7})(")',
                         lambda mm: mm.group(1) + mm.group(2).rjust(8, b"0") + mm.group(3), num)
            self.files["word/numbering.xml"] = num
        ct = self.files["[Content_Types].xml"].decode("utf-8")
        for ext, typ in (("png", "image/png"), ("jpeg", "image/jpeg"), ("jpg", "image/jpeg")):
            if 'Extension="%s"' % ext not in ct:
                ct = ct.replace("<Default ", '<Default Extension="%s" ContentType="%s"/><Default ' % (ext, typ), 1)
        self.files["[Content_Types].xml"] = ct.encode("utf-8")
        sty = etree.fromstring(self.files["word/styles.xml"])
        normalize(sty)
        self.files["word/styles.xml"] = etree.tostring(sty, xml_declaration=True, encoding="UTF-8",
                                                       standalone=True)

    def core_properties(self, title):
        core = self.files.get("docProps/core.xml")
        if not core:
            return
        x = core.decode("utf-8")
        x = re.sub(r"<dc:title>.*?</dc:title>|<dc:title\s*/>", "", x, flags=re.S)
        x = x.replace("</cp:coreProperties>", "<dc:title>%s</dc:title></cp:coreProperties>" % title)
        self.files["docProps/core.xml"] = x.encode("utf-8")

    def save(self):
        self.files["word/document.xml"] = etree.tostring(self.doc, xml_declaration=True, encoding="UTF-8",
                                                         standalone=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--toc-pages", help="json {entry index: page label} from a rendering")
    ap.add_argument("--toc-json", help="write the TOC entries to this json file")
    ap.add_argument("--title", default="Scientific Machine Learning: Foundations, Methods, and Practice")
    a = ap.parse_args()
    zin = zipfile.ZipFile(a.src)
    files = {i.filename: zin.read(i.filename) for i in zin.infolist()}
    infos = {i.filename: i for i in zin.infolist()}
    post = Post(files)
    post.booktabs()
    post.equations()
    post.boxes(post.body)
    post.math_bold_italic()
    post.alt_text()
    post.bookmarks()
    post.sections()
    post.bib_columns()
    pages = None
    if a.toc_pages:
        with open(a.toc_pages) as fh:
            pages = json.load(fh)
    entries = post.toc(pages)
    if a.toc_json:
        with open(a.toc_json, "w") as fh:
            json.dump(entries, fh, indent=0)
    post.cleanup()
    post.settings()
    post.core_properties(a.title)
    post.save()
    with zipfile.ZipFile(a.dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for name, data in files.items():
            zout.writestr(infos[name], data)
    print("postprocess: %s" % ", ".join("%s=%d" % kv for kv in sorted(post.stats.items())))


if __name__ == "__main__":
    sys.exit(main())

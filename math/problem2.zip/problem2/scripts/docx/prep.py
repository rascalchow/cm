#!/usr/bin/env python3
"""prep.py -- turn the LaTeX book into one pandoc-friendly LaTeX file (DOCX edition).

    python3 scripts/docx/prep.py --aux build/book/main.aux --out build/docx

Reads main.tex (and everything it \\input's), resolves cross-references and
numbering from LaTeX's aux file, converts figures/TikZ/algorithms to PNG and
rewrites all custom environments into marker environments that pandoc's LaTeX
reader turns into Divs, which scripts/docx/filters.lua maps to Word styles.

Marker environments produced here (all upper case, consumed by filters.lua):
  BOX<kind> + BOXTITLE      tcolorbox-like boxes (objectives, summarybox, keyidea,
                            practicaltip, caution, historybox, assignment,
                            definition, theorem, proposition)
  THM<kind>                 unboxed theorem-like environments (lemma, ...), PROOF
  RUNHEAD                   run-in heading merged into the following paragraph
  RUNPARA                   \\paragraph{..} run-in heading ("Title.")
  EXERCISE, APART           exercises and assignment sub-headings
  CAPTION<kind>             caption paragraphs for listings and algorithms
  ALGIMAGE, TIKZIMAGE       rendered images
  PARTHEAD, TOCHERE, TITLE* (title page), REVERSEPAGE, REFS, BIBNOTE
Inline markers are \\textcolor{CS<name>}{..} spans (character styles), and display
equations carry \\EQNUM{number}{label} which filters.lua turns into the number.
"""
import argparse
import bisect
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from texutil import (find_env, load_tex, read_arg, read_group, read_opt,  # noqa: E402
                     split_rows, split_top, sub_cmd, sub_env, warn, drop_cmd)
from xref import Aux, Resolver  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(HERE))
TEXTWIDTH_IN = 6.35          # \textwidth of the PDF (8.5in - 1.15in - 1.0in)
EMSP = "\u2003"              # space between number and title in headings

THEOREM_ENVS = ["definition", "example", "theorem", "proposition", "lemma", "corollary", "remark"]
BOXED_THEOREMS = {"definition", "theorem", "proposition"}   # tcolorboxenvironment in preamble
THM_NAMES = {k: k.capitalize() for k in THEOREM_ENVS}
MATH_ENVS = ["equation", "align", "gather", "multline", "flalign", "alignat", "eqnarray",
             "math", "displaymath"]
BOX_TITLES = {"keyidea": "Key Idea", "practicaltip": "Practical Tip", "caution": "Caution",
              "historybox": "Historical Note"}
ROMAN = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]

# pandoc-expandable versions of the notation macros of preamble.tex
MACROS = r"""
\newcommand{\R}{\mathbb{R}}
\newcommand{\C}{\mathbb{C}}
\newcommand{\N}{\mathbb{N}}
\newcommand{\Z}{\mathbb{Z}}
\newcommand{\E}{\mathbb{E}}
\newcommand{\Prob}{\mathbb{P}}
\newcommand{\Var}{\operatorname{Var}}
\newcommand{\Cov}{\operatorname{Cov}}
\newcommand{\tr}{\operatorname{tr}}
\newcommand{\rank}{\operatorname{rank}}
\newcommand{\diag}{\operatorname{diag}}
\newcommand{\spn}{\operatorname{span}}
\newcommand{\supp}{\operatorname{supp}}
\newcommand{\sgn}{\operatorname{sign}}
\newcommand{\Div}{\operatorname{div}}
\newcommand{\curl}{\operatorname{curl}}
\newcommand{\argmin}{\operatorname*{arg\,min}}
\newcommand{\argmax}{\operatorname*{arg\,max}}
\newcommand{\vect}[1]{\boldsymbol{#1}}
\newcommand{\mat}[1]{\boldsymbol{#1}}
\newcommand{\T}{\top}
\newcommand{\norm}[1]{\left\lVert #1\right\rVert}
\newcommand{\abs}[1]{\left\lvert #1\right\rvert}
\newcommand{\inner}[2]{\left\langle #1,\,#2\right\rangle}
\newcommand{\dd}{\,\mathrm{d}}
\newcommand{\diff}{\mathrm{d}}
\newcommand{\pd}[2]{\frac{\partial #1}{\partial #2}}
\newcommand{\pdd}[2]{\frac{\partial^2 #1}{\partial #2^2}}
\newcommand{\od}[2]{\frac{\mathrm{d} #1}{\mathrm{d} #2}}
\newcommand{\loss}{\mathcal{L}}
\newcommand{\data}{\mathcal{D}}
\newcommand{\Normal}{\mathcal{N}}
\newcommand{\order}{\mathcal{O}}
\newcommand{\Op}{\mathcal{G}}
\newcommand{\eps}{\varepsilon}
\newcommand{\Id}{\boldsymbol{I}}
\newcommand{\ip}{\mathrm{i}}
\newcommand{\KL}{D_{\mathrm{KL}}}
\newcommand{\code}[1]{\texttt{#1}}
\newcommand{\term}[1]{\emph{#1}}
\newcommand{\bm}[1]{\boldsymbol{#1}}
\newcommand{\nicefrac}[2]{#1/#2}
\newcommand{\coloneqq}{\mathrel{:=}}
\newcommand{\eqqcolon}{\mathrel{=:}}
\newcommand{\dddot}[1]{\overset{\dots}{#1}}
\newcommand{\upmu}{\mu}
\newcommand{\textup}[1]{#1}
"""


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def chapter_marks(text):
    """Positions where a new (numbered) chapter starts: list of (pos, id)."""
    marks, n, appendix, main, back = [], 0, False, False, False
    for m in re.finditer(r"\\(chapter|appendix|mainmatter|backmatter|frontmatter)(\*?)(?![A-Za-z])", text):
        kind = m.group(1)
        if kind == "appendix":
            appendix, n = True, 0
        elif kind == "mainmatter":
            main = True
        elif kind == "backmatter":
            back = True
        elif kind == "frontmatter":
            main = False
        elif m.group(2) != "*" and main and not back:
            n += 1
            marks.append((m.start(), chr(64 + n) if appendix else str(n)))
    return marks


class ChapterLookup:
    def __init__(self, text):
        self.marks = chapter_marks(text)
        self.pos = [p for p, _ in self.marks]

    def __call__(self, pos):
        i = bisect.bisect_right(self.pos, pos) - 1
        return self.marks[i][1] if i >= 0 else "0"


LABEL_RE = re.compile(r"\\label\s*(\[[^\]]*\])?\s*\{([^}]*)\}")


def take_labels(s):
    """Remove all \\label{..} from s; return (s_without, [keys])."""
    keys = [m.group(2) for m in LABEL_RE.finditer(s)]
    return LABEL_RE.sub("", s), keys


def take_first_label(s):
    """Remove a \\label directly at the start of s (after blanks)."""
    m = re.match(r"\s*\\label\s*(\[[^\]]*\])?\s*\{([^}]*)\}", s)
    if m:
        return s[m.end():], m.group(2)
    return s, None


def anchor(key):
    return "\\hypertarget{%s}{}" % key if key else ""


def math_regions(text):
    """Sorted list of (start, end) of math-mode regions (rough but adequate)."""
    regs, i, n = [], 0, len(text)
    env_re = re.compile(r"\\begin\{(%s)(\*?)\}" % "|".join(MATH_ENVS))
    while i < n:
        c = text[i]
        if c == "\\":
            m = env_re.match(text, i)
            if m:
                name = m.group(1) + m.group(2)
                end = text.find("\\end{%s}" % name, m.end())
                end = n if end < 0 else end + len(name) + 6
                regs.append((i, end))
                i = end
                continue
            if text.startswith("\\(", i) or text.startswith("\\[", i):
                close = "\\)" if text[i + 1] == "(" else "\\]"
                end = text.find(close, i + 2)
                end = n if end < 0 else end + 2
                regs.append((i, end))
                i = end
                continue
            i += 2
            continue
        if c == "$":
            if text.startswith("$$", i):
                end = text.find("$$", i + 2)
                end = n if end < 0 else end + 2
            else:
                j = i + 1
                while j < n and not (text[j] == "$" and text[j - 1] != "\\"):
                    j += 1
                end = j + 1
            regs.append((i, end))
            i = end
            continue
        i += 1
    return regs


def in_regions(regs, pos):
    i = bisect.bisect_right([a for a, _ in regs], pos) - 1
    return i >= 0 and regs[i][0] <= pos < regs[i][1]


def parse_keyval(s):
    out = {}
    for part in split_top(s or "", ","):
        if "=" in part:
            k, v = part.split("=", 1)
            v = v.strip()
            if v.startswith("{") and v.endswith("}"):
                v = v[1:-1]
            out[k.strip()] = v
        elif part.strip():
            out[part.strip()] = ""
    return out


def to_inches(length):
    """'3.6cm' -> inches; '0.5\\textwidth' -> inches.  None if unknown."""
    m = re.match(r"\s*([0-9.]*)\s*\\(textwidth|linewidth|columnwidth|hsize)\s*$", length)
    if m:
        return float(m.group(1) or 1) * TEXTWIDTH_IN
    m = re.match(r"\s*([0-9.]+)\s*(cm|mm|in|pt|bp|em|ex)\s*$", length)
    if not m:
        return None
    v, u = float(m.group(1)), m.group(2)
    return v * {"cm": 1 / 2.54, "mm": 1 / 25.4, "in": 1.0, "pt": 1 / 72.27, "bp": 1 / 72.0,
                "em": 11 / 72.27, "ex": 5 / 72.27}[u]


def plain_len(cell):
    """Rough visible length of a table cell (for column width estimates)."""
    s = re.sub(r"\\(cref|Cref|ref|eqref)\{[^}]*\}", "Chapters 10 and 11", cell)
    s = re.sub(r"\\[A-Za-z]+\*?", "", s)
    s = re.sub(r"[{}$^_\\]", "", s)
    return len(s.strip())


# ---------------------------------------------------------------------------
# the preprocessor
# ---------------------------------------------------------------------------
class Prep:
    def __init__(self, body, aux, outdir, render=True):
        self.t = body
        self.aux = aux
        self.res = Resolver(aux)
        self.out = outdir
        self.img = os.path.join(outdir, "img")
        os.makedirs(self.img, exist_ok=True)
        self.verbatim = []
        self.aliases = {}
        self.render_jobs = []         # (kind, key, snippet)
        self.render = render
        self.stats = defaultdict(int)
        self.mismatch = []

    # -- utilities ---------------------------------------------------------
    def check(self, what, key, mine):
        """Compare a simulated number with the aux file; aux wins."""
        if not key:
            return mine
        lab = self.aux.get(key)
        if lab is None:
            warn("label %s (%s %s) not in aux file" % (key, what, mine))
            return mine
        if lab.num != mine:
            self.mismatch.append((what, key, mine, lab.num))
            return lab.num
        return mine

    def rel(self, path):
        return os.path.relpath(path, ROOT)

    # -- 1. verbatim -------------------------------------------------------
    def protect_verbatim(self):
        def repl(content):
            opts, i = read_opt(content, 0)
            code = content[i:]
            if code.startswith("\n"):
                code = code[1:]
            elif "\n" in code and not code[:code.index("\n")].strip():
                code = code[code.index("\n") + 1:]
            self.verbatim.append((opts, code.rstrip("\n")))
            # the caption stays in the text so that references and citations in it are processed
            cap = parse_keyval(opts).get("caption") or parse_keyval(opts).get("title") or ""
            return "\\LSTBLOCK{%d}{%s}" % (len(self.verbatim) - 1, cap)
        # find_env is not used here because code may contain anything
        out, pos = [], 0
        while True:
            b = self.t.find("\\begin{lstlisting}", pos)
            if b < 0:
                out.append(self.t[pos:])
                break
            e = self.t.find("\\end{lstlisting}", b)
            out.append(self.t[pos:b])
            out.append(repl(self.t[b + len("\\begin{lstlisting}"):e]))
            pos = e + len("\\end{lstlisting}")
        self.t = "".join(out)

    # -- 2. title page -----------------------------------------------------
    def titlepage(self):
        r = find_env(self.t, "titlepage")
        if r is None:
            return
        b0, c0, c1, e1 = r
        tp = self.t[c0:c1]
        cover = None
        m = re.search(r"\\includegraphics(\[[^\]]*\])?\{([^}]*)\}", tp)
        if m:
            cover = self.figure_png(m.group(2), dpi=300, transparent=True)
        groups = []
        for m in re.finditer(r"\\noindent\s*(\{|\\begin\{minipage\})", tp):
            if m.group(1) == "{":
                g, _ = read_group(tp, m.end() - 1)
            else:
                rr = find_env(tp, "minipage", m.start())
                g = tp[rr[1]:rr[2]]
                _, g = env_args(g, "om")
            groups.append(g)

        def clean(g, keep_breaks=False):
            g = re.sub(r"\\(color|fontsize)\{[^}]*\}(\{[^}]*\})?", "", g)
            g = re.sub(r"\\(sffamily|bfseries|selectfont|Large|LARGE|large|Huge|huge|small|"
                       r"normalsize|raggedright|par|centering)(?![A-Za-z])", "", g)
            g = re.sub(r"\\\\(\[[^\]]*\])?", "\\\\\\\\ " if keep_breaks else " ", g)
            g = re.sub(r"\$\\(cdot|bullet)\$", "\u00b7", g)
            return re.sub(r"[ \t\n]+", " ", g).strip()

        parts = []
        band = [g for g in groups if "\\color{white}" in g]
        title = [g for g in groups if "\\fontsize" in g]
        sub = [g for g in groups if "\\color{sciorange}" in g]
        edition = [g for g in groups if "\\color{scigray}" in g]
        rest = [g for g in groups if g not in band + title + sub + edition]
        parts.append("\\begin{TITLEBAND}")
        parts.append("\\begin{TITLEBANDTEXT}%s\\end{TITLEBANDTEXT}" % (clean(band[0], True) if band else ""))
        if cover:
            parts.append("\\begin{TITLEBANDIMAGE}\\includegraphics[height=1.6in]{%s}\\end{TITLEBANDIMAGE}"
                         % self.rel(cover))
        parts.append("\\end{TITLEBAND}")
        if title:
            parts.append("\\begin{TITLEMAIN}%s\\end{TITLEMAIN}" % clean(title[0], True))
        if sub:
            parts.append("\\begin{TITLESUB}%s\\end{TITLESUB}" % clean(sub[0]))
        for g in rest[:-1] if len(rest) > 1 else rest[:0]:
            parts.append("\\begin{TITLEDESC}%s\\end{TITLEDESC}" % clean(g))
        if rest:
            parts.append("\\begin{TITLETAG}%s\\end{TITLETAG}" % clean(rest[-1]))
        if edition:
            parts.append("\\begin{TITLEEDITION}%s\\end{TITLEEDITION}" % clean(edition[0]))
        # reverse of the title page: everything up to the next \clearpage
        after = self.t[e1:]
        cp = after.find("\\clearpage")
        rev = after[:cp] if cp >= 0 else ""
        rest_doc = after[cp + len("\\clearpage"):] if cp >= 0 else after
        rev = re.sub(r"\\thispagestyle\{[^}]*\}|\\vspace\*?\{[^}]*\}", "", rev).strip()
        if rev.startswith("{") and rev.endswith("}"):
            rev = rev[1:-1]
        rev = re.sub(r"^\s*\\small", "", rev)
        parts.append("\\begin{REVERSEPAGE}\n%s\n\\end{REVERSEPAGE}" % rev.strip())
        self.t = self.t[:b0] + "\n".join(parts) + "\n" + rest_doc

    # -- 3. citations ------------------------------------------------------
    def _natbib_text(self, keys, mode, pre=None, post=None):
        """natbib-like plain text for a citation (used for aliases and images)."""
        items = []
        for k in keys:
            k = k.strip()
            if k in self.aliases:
                items.append(self.aliases[k])
                continue
            bc = self.aux.bibcite.get(k)
            if bc is None:
                items.append("?")
                continue
            year, short = bc[0], bc[1]
            items.append("%s (%s)" % (short, year) if mode == "t" else "%s, %s" % (short, year))
        txt = "; ".join(items) if mode != "t" else ", ".join(items)
        if pre:
            txt = pre + " " + txt
        if post:
            txt = txt + ", " + post
        return "(%s)" % txt if mode == "p" else txt

    def citations(self):
        t = self.t

        def defalias(key, text):
            self.aliases[key.strip()] = text
            return ""
        t = sub_cmd(t, "defcitealias", "mm", defalias)
        hidden = lambda keys: "\\textcolor{CShidecite}{\\citep{%s}}" % keys  # noqa: E731

        def alias(mode):
            def f(o1, o2, keys):
                pre, post = (None, o1) if o2 is None else (o1, o2)
                names = [self.aliases.get(k.strip(), k.strip()) for k in keys.split(",")]
                txt = "; ".join(names)
                if pre:
                    txt = pre + " " + txt
                if post:
                    txt += ", " + post
                if mode == "p":
                    txt = "(" + txt + ")"
                return txt + hidden(keys)
            return f
        for c in ("citepalias", "Citepalias"):
            t = sub_cmd(t, c, "oom", alias("p"))
        for c in ("citetalias", "Citetalias"):
            t = sub_cmd(t, c, "oom", alias("t"))

        def citealp(o1, o2, keys):
            opts = "".join("[%s]" % o for o in (o1, o2) if o is not None)
            return "\\textcolor{CScitealp}{\\citep%s{%s}}" % (opts, keys)
        for c in ("citealp", "Citealp", "citealt", "Citealt", "citenum"):
            t = sub_cmd(t, c, "oom", citealp)

        def citeauthor(keys):
            names = []
            for k in keys.split(","):
                bc = self.aux.bibcite.get(k.strip())
                names.append(bc[1] if bc else "?")
            return ", ".join(names) + hidden(keys)
        for c in ("citeauthor", "Citeauthor"):
            t = sub_cmd(t, c, "m", citeauthor)

        def citeyear(par):
            def f(keys):
                ys = []
                for k in keys.split(","):
                    bc = self.aux.bibcite.get(k.strip())
                    ys.append(bc[0] if bc else "?")
                txt = ", ".join(ys)
                return ("(%s)" % txt if par else txt) + hidden(keys)
            return f
        t = sub_cmd(t, "citeyearpar", "m", citeyear(True))
        t = sub_cmd(t, "citeyear", "m", citeyear(False))
        t = sub_cmd(t, "Citet", "oom", lambda a, b, k: "\\citet%s{%s}" % (
            "".join("[%s]" % o for o in (a, b) if o is not None), k))

        def citet(o1, o2, keys):
            """natbib's \\citet{a,b,c} prints "A (2018); B (2019); C et al. (2020, 2021)":
            split into one narrative citation per author group, in bibliography order."""
            opts = "".join("[%s]" % o for o in (o1, o2) if o is not None)
            ks = [k.strip() for k in keys.split(",") if k.strip()]
            if len(ks) < 2:
                return "\\citet%s{%s}" % (opts, keys)
            bib = self.aux.bibcite
            ks.sort(key=lambda k: bib[k][3] if k in bib else 10 ** 6)
            groups = []
            for k in ks:
                short = bib[k][1] if k in bib else k
                if groups and groups[-1][0] == short:
                    groups[-1][1].append(k)
                else:
                    groups.append((short, [k]))
            pre, post = (None, o1) if o2 is None else (o1, o2)
            out = []
            for i, (_, g) in enumerate(groups):
                o = ""
                if i == 0 and pre:
                    o = "[%s][]" % pre
                if i == len(groups) - 1 and post:
                    o = "[%s][%s]" % (pre or "", post) if (i == 0 and pre) else "[%s]" % post
                if len(g) == 1:
                    out.append("\\citet%s{%s}" % (o, g[0]))
                else:   # same authors: "Kharazmi et al. (2019, 2021)" as natbib prints it
                    years = ", ".join("\\textcolor{CScitealp}{\\citeyear{%s}}" % k for k in g)
                    out.append("%s (%s)" % (bib[g[0]][1] if g[0] in bib else g[0], years))
            return "; ".join(out)
        t = sub_cmd(t, "citet", "oom", citet)
        t = sub_cmd(t, "Citep", "oom", lambda a, b, k: "\\citep%s{%s}" % (
            "".join("[%s]" % o for o in (a, b) if o is not None), k))
        t = sub_cmd(t, "nocite", "m", lambda k: hidden(k))
        self.t = t

    def cite_to_text(self, s):
        """Resolve citations to natbib text (for LaTeX rendered into images)."""
        s = sub_cmd(s, "textcolor", "mm", lambda c, x: x if c.startswith("CS") else
                    "\\textcolor{%s}{%s}" % (c, x))

        def mk(mode):
            def f(o1, o2, keys):
                pre, post = (None, o1) if o2 is None else (o1, o2)
                return self._natbib_text(keys.split(","), mode, pre, post)
            return f
        s = sub_cmd(s, "citep", "oom", mk("p"))
        s = sub_cmd(s, "citet", "oom", mk("t"))
        return s

    # -- 4. cross-references ---------------------------------------------------
    def references(self):
        t = self.t
        pat = re.compile(r"\\(cref|Cref|ref|eqref|crefrange|Crefrange|autoref|nameref|pageref|"
                         r"cpageref|Cpageref|labelcref)(\*?)(?![A-Za-z])")
        regs = math_regions(t)
        out, pos = [], 0
        for m in pat.finditer(t):
            if m.start() < pos:
                continue
            k, bs = m.start() - 1, 0
            while k >= 0 and t[k] == "\\":
                bs, k = bs + 1, k - 1
            if bs % 2:
                continue
            kind = m.group(1)
            try:
                a1, j = read_group(t, m.end())
                a2 = None
                if kind in ("crefrange", "Crefrange"):
                    a2, j = read_group(t, j)
            except ValueError:
                warn("unparsable reference near %r" % t[m.start():m.start() + 40])
                continue
            keys = [x.strip() for x in a1.split(",") if x.strip()]
            if kind in ("cref", "Cref", "autoref"):
                txt = self.res.cref(keys, capital=(kind == "Cref"))
            elif kind == "labelcref":
                txt = self.res.cref(keys, with_name=False)
            elif kind == "ref":
                txt = self.res.ref(keys[0])
            elif kind == "eqref":
                txt = self.res.eqref(keys[0])
            elif kind in ("crefrange", "Crefrange"):
                txt = self.res.crefrange(a1.strip(), a2.strip())
            elif kind == "nameref":
                txt = self.res.nameref(keys[0])
            else:   # page references have no meaning in the DOCX edition
                txt = ""
                warn("page reference \\%s{%s} dropped" % (kind, a1))
            self.stats["refs"] += 1
            target = keys[0] if keys and self.aux.get(keys[0]) else None
            if in_regions(regs, m.start()):
                rep = "\\text{%s}" % txt.replace("~", "\\ ")
            elif target:
                rep = "\\hyperlink{%s}{%s}" % (target, txt)
            else:
                rep = txt
            out.append(t[pos:m.start()])
            out.append(rep)
            pos = j
        out.append(t[pos:])
        self.t = "".join(out)
        if self.res.undefined:
            warn("undefined references (shown as ??): %s" % ", ".join(sorted(self.res.undefined)))

    # -- 5. equations -----------------------------------------------------------
    def equations(self):
        chap = ChapterLookup(self.t)
        counter = defaultdict(int)
        pat = re.compile(r"\\begin\{(equation|align|gather|multline|flalign|eqnarray|alignat)(\*?)\}")
        out, pos = [], 0
        for m in pat.finditer(self.t):
            if m.start() < pos:
                continue
            name = m.group(1) + m.group(2)
            r = find_env(self.t, name, m.start())
            b0, c0, c1, e1 = r
            body = self.t[c0:c1]
            starred = m.group(2) == "*"
            ch = chap(m.start())
            if m.group(1) == "alignat":
                _, body = env_args(body, "m")
            body = self.math_fix(body)

            def number(row):
                """-> (row_without_markers, number|None, label|None)"""
                row, keys = take_labels(row)
                key = keys[0] if keys else None
                tag = re.search(r"\\tag\*?\{([^}]*)\}", row)
                if tag:
                    row = row[:tag.start()] + row[tag.end():]
                    return row, tag_text(tag.group(1)), key
                if starred or re.search(r"\\(notag|nonumber)(?![A-Za-z])", row):
                    row = re.sub(r"\\(notag|nonumber)(?![A-Za-z])", "", row)
                    return row, None, key
                counter[ch] += 1
                num = "%s.%d" % (ch, counter[ch])
                return row, self.check("equation", key, num), key

            if m.group(1) == "equation":
                inner, num, key = number(body)
                inner = re.sub(r"\\begin\{split\}", r"\\begin{aligned}", inner)
                inner = re.sub(r"\\end\{split\}", r"\\end{aligned}", inner)
                rep = self.display(inner, [(num, key)] if num else [])
            elif m.group(1) == "multline":
                inner, num, key = number(body)
                rows = split_rows(inner)
                inner = "\\begin{aligned}" + " \\\\ ".join(
                    ("&" if i == 0 else "&\\qquad ") + rr.strip() for i, rr in enumerate(rows)
                    if rr.strip()) + "\\end{aligned}"
                rep = self.display(inner, [(num, key)] if num else [])
            else:
                rows = split_rows(body)
                if rows and not rows[-1].strip():
                    rows = rows[:-1]
                done = [number(rr) for rr in rows]
                env = "aligned" if m.group(1) in ("align", "flalign", "alignat", "eqnarray") else "gathered"
                if m.group(1) == "eqnarray":
                    done = [(rr.replace("&", "", 1) if rr.count("&") > 1 else rr, n, k)
                            for rr, n, k in done]
                nums = [(n, k) for _, n, k in done if n]
                if len(done) == 1:
                    # a single row needs no alignment (and renders more robustly without)
                    rep = self.display(drop_top_amps(done[0][0]), nums)
                elif len(nums) <= 1:
                    inner = "\\begin{%s}%s\\end{%s}" % (env, " \\\\\n".join(rr for rr, _, _ in done), env)
                    rep = self.display(inner, nums)
                else:
                    # one display per numbered row (trailing unnumbered rows join the last)
                    groups, cur = [], []
                    for rr, n, k in done:
                        cur.append(rr)
                        if n:
                            groups.append((cur, (n, k)))
                            cur = []
                    if cur:
                        groups[-1] = (groups[-1][0] + cur, groups[-1][1])
                    rep = "".join(self.display(drop_top_amps(g[0]) if len(g) == 1 else
                                               "\\begin{%s}%s\\end{%s}" % (env, " \\\\\n".join(g), env),
                                               [nk]) for g, nk in groups)
            self.stats["equations"] += 1
            out.append(self.t[pos:b0])
            out.append(rep)
            pos = e1
        out.append(self.t[pos:])
        self.t = "".join(out)

    @staticmethod
    def display(inner, nums):
        marks = "".join("\\EQNUM{%s}{%s}" % (n, k or "") for n, k in nums)
        return "\\[%s%s\\]" % (inner.strip(), marks)

    @staticmethod
    def math_fix(s):
        """Normalise math that texmath cannot handle."""
        s = re.sub(r"\\begin\{psmallmatrix\}", r"\\left(\\begin{smallmatrix}", s)
        s = re.sub(r"\\end\{psmallmatrix\}", r"\\end{smallmatrix}\\right)", s)
        s = re.sub(r"\\begin\{bsmallmatrix\}", r"\\left[\\begin{smallmatrix}", s)
        s = re.sub(r"\\end\{bsmallmatrix\}", r"\\end{smallmatrix}\\right]", s)
        s = re.sub(r"\\(mathrlap|mathllap|mathclap|qedhere)(?![A-Za-z])", "", s)
        s = re.sub(r"\\(intertext|shortintertext)\{", r"\\text{", s)
        # texmath knows \big..\Bigg but not the l/r/m variants of \Big, \bigg, \Bigg
        s = re.sub(r"\\(Big|bigg|Bigg)[lrm](?![A-Za-z])", r"\\\1", s)
        return s

    # -- 6. theorem-like environments and proofs --------------------------------
    def theorems(self):
        chap = ChapterLookup(self.t)
        counter = defaultdict(int)
        pat = re.compile(r"\\begin\{(%s)\}" % "|".join(THEOREM_ENVS))
        out, pos = [], 0
        for m in pat.finditer(self.t):
            if m.start() < pos:
                continue
            env = m.group(1)
            b0, c0, c1, e1 = find_env(self.t, env, m.start())
            body = self.t[c0:c1]
            note, i = read_opt(body, 0)
            body = body[i:]
            body, key = take_first_label(body)
            ch = chap(m.start())
            counter[ch] += 1
            num = self.check(env, key, "%s.%d" % (ch, counter[ch]))
            head = "%s %s" % (THM_NAMES[env], num)
            notes = " \\textcolor{CSthmnote}{(%s)}" % note.strip() if note else ""
            if env == "remark":
                h = "\\textcolor{CSremarkhead}{%s}%s\\textcolor{CSremarkhead}{.}" % (head, notes)
            else:
                h = "\\textcolor{CSthmhead}{%s}%s\\textcolor{CSthmhead}{.}" % (head, notes)
            kind = ("BOX" if env in BOXED_THEOREMS else "THM") + env
            out.append(self.t[pos:b0])
            out.append("\\begin{%s}\n\\begin{RUNHEAD}%s%s\\end{RUNHEAD}\n%s\n\\end{%s}" % (
                kind, anchor(key), h, body.strip(), kind))
            pos = e1
            self.stats["theorems"] += 1
        out.append(self.t[pos:])
        self.t = "".join(out)

        def proof(content):
            opt, i = read_opt(content, 0)
            head = (opt or "Proof").strip()
            return "\\begin{PROOF}\n\\begin{RUNHEAD}\\emph{%s.}\\end{RUNHEAD}\n%s\n\\end{PROOF}" % (
                head, content[i:].strip())
        self.t = sub_env(self.t, "proof", proof)

    # -- 7. exercises and assignments ----------------------------------------
    def exercises(self):
        t = self.t
        for name, stars in (("diffiii", 3), ("diffii", 2), ("diffi", 1)):
            t = sub_cmd(t, name, "", lambda s=stars: "\\textcolor{CSstars}{%s}" % ("\u2605" * s))
        self.t = t
        chap = ChapterLookup(self.t)
        cnt_ex, cnt_as = defaultdict(int), defaultdict(int)
        out, pos = [], 0
        for m in re.finditer(r"\\begin\{(exercise|assignment)\}", self.t):
            if m.start() < pos:
                continue
            env = m.group(1)
            b0, c0, c1, e1 = find_env(self.t, env, m.start())
            body = self.t[c0:c1]
            ch = chap(m.start())
            if env == "exercise":
                opt, i = read_opt(body, 0)
                body, key = take_first_label(body[i:])
                cnt_ex[ch] += 1
                num = self.check("exercise", key, "%s.%d" % (ch, cnt_ex[ch]))
                head = "\\textcolor{CSexlabel}{Exercise %s}" % num
                if opt:
                    head += " \\textbf{(%s)}" % opt.strip()
                rep = "\\begin{EXERCISE}\n\\begin{RUNHEAD}%s%s\\end{RUNHEAD}\n%s\n\\end{EXERCISE}" % (
                    anchor(key), head, body.strip())
            else:
                title, i = read_arg(body, 0)
                body, key = take_first_label(body[i:])
                cnt_as[ch] += 1
                num = self.check("assignment", key, "%s.%d" % (ch, cnt_as[ch]))
                rep = ("\\begin{BOXassignment}\n\\begin{BOXTITLE}%sHands-on Assignment %s: %s\\end{BOXTITLE}\n"
                       "%s\n\\end{BOXassignment}" % (anchor(key), num, title.strip(), body.strip()))
            self.stats[env] += 1
            out.append(self.t[pos:b0])
            out.append(rep)
            pos = e1
        out.append(self.t[pos:])
        self.t = "".join(out)
        self.t = sub_cmd(self.t, "apart", "m", lambda x: "\n\\begin{APART}%s\\end{APART}\n" % x.strip())
        self.t = sub_cmd(self.t, "hint", "m", lambda x: "\n\n\\emph{Hint:} %s" % x)

    # -- 8. boxes -------------------------------------------------------------------
    def boxes(self):
        def objectives(content):
            return ("\\begin{BOXobjectives}\n\\begin{BOXTITLE}Learning Objectives\\end{BOXTITLE}\n"
                    "After studying this chapter, you should be able to:\n\\begin{itemize}\n%s\n"
                    "\\end{itemize}\n\\end{BOXobjectives}" % content.strip())
        self.t = sub_env(self.t, "objectives", objectives)

        def summary(content):
            return ("\\begin{BOXsummarybox}\n\\begin{BOXTITLE}Chapter Summary\\end{BOXTITLE}\n"
                    "\\begin{itemize}\n%s\n\\end{itemize}\n\\end{BOXsummarybox}" % content.strip())
        self.t = sub_env(self.t, "summarybox", summary)
        for env, title in BOX_TITLES.items():
            def f(content, env=env, title=title):
                opt, i = read_opt(content, 0)
                tt = title + (": " + opt.strip() if opt and opt.strip() else "")
                return "\\begin{BOX%s}\n\\begin{BOXTITLE}%s\\end{BOXTITLE}\n%s\n\\end{BOX%s}" % (
                    env, tt, content[i:].strip(), env)
            self.t = sub_env(self.t, env, f)
        self.t = re.sub(r"\\begin\{(tcolorbox)\}(\[[^\]]*\])?", r"\\begin{BOXgeneric}", self.t)
        self.t = self.t.replace("\\end{tcolorbox}", "\\end{BOXgeneric}")

    # -- 9. figures, tables, algorithms, listings -----------------------------
    def figure_png(self, path, dpi=250, transparent=False):
        """Convert a figure file to PNG (cached); return the PNG path or None."""
        src = os.path.join(ROOT, path)
        if not os.path.splitext(src)[1]:
            for ext in (".pdf", ".png", ".jpg", ".jpeg"):
                if os.path.exists(src + ext):
                    src += ext
                    break
        if not os.path.exists(src):
            warn("figure file %s not found" % path)
            return None
        ext = os.path.splitext(src)[1].lower()
        if ext in (".png", ".jpg", ".jpeg"):
            return src
        rel = os.path.relpath(src, os.path.join(ROOT, "figures")) if "figures" in src else os.path.basename(src)
        name = re.sub(r"[^A-Za-z0-9]+", "_", os.path.splitext(rel)[0]) + ".png"
        dst = os.path.join(self.img, name)
        if not os.path.exists(dst) or os.path.getmtime(dst) < os.path.getmtime(src):
            stem = dst[:-4]
            if transparent:   # e.g. white line art drawn for the dark title band
                subprocess.run(["pdftocairo", "-r", str(dpi), "-png", "-transp", "-singlefile", "-f", "1",
                                "-l", "1", src, stem], check=True)
            else:
                subprocess.run(["pdftoppm", "-r", str(dpi), "-png", "-singlefile", "-f", "1", "-l", "1",
                                src, stem], check=True)
            self.stats["pdf->png"] += 1
        return dst

    def graphics(self):
        def inc(opts, path):
            png = self.figure_png(path.strip())
            if png is None:
                return "\\textbf{[Figure file %s is missing]}" % path.replace("_", "\\_")
            kv = parse_keyval(opts)
            keep = []
            for k in ("width", "height"):
                if k in kv:
                    v = kv[k].replace("\\linewidth", "\\textwidth").replace("\\columnwidth", "\\textwidth")
                    inches = to_inches(v)
                    if k == "width" and inches is not None and "textwidth" not in v:
                        v = "%.3fin" % inches
                    keep.append("%s=%s" % (k, v))
            return "\\includegraphics[%s]{%s}" % (",".join(keep), self.rel(png))
        self.t = sub_cmd(self.t, "includegraphics", "om", inc)

    def subfloats(self):
        """subfigure / minipage inside floats: keep images and sub-captions."""
        def sub(content):
            _, rest = env_args(content, "om")      # [pos]{width}
            rest = sub_cmd(rest, "caption", "om", lambda o, c: "\n\n%s\n\n" % c)
            rest, _ = take_labels(rest)
            return "\n" + rest.replace("\\centering", "") + "\n"
        for env in ("subfigure", "subtable"):
            self.t = sub_env(self.t, env, sub)

        def mini(content):
            _, rest = env_args(content, "oom")
            if "\\includegraphics" in rest or "\\begin{tabular" in rest:
                return "\n" + rest + "\n"
            return "\n" + rest + "\n"
        self.t = sub_env(self.t, "minipage", mini)

    def split_subfloats(self, body):
        """subfigure/subtable environments -> one paragraph with the images side by side
        and one paragraph '(a) ...  (b) ...' with the sub-captions."""
        images, subcaps, k = [], [], 0
        out, pos = [], 0
        for mm in re.finditer(r"\\begin\{(subfigure|subtable)\}", body):
            if mm.start() < pos:
                continue
            b0, c0, c1, e1 = find_env(body, mm.group(1), mm.start())
            (_, width), inner = env_args(body[c0:c1], "om")
            frac = (to_inches(width or "") or TEXTWIDTH_IN * 0.48) / TEXTWIDTH_IN
            k += 1
            letter = chr(96 + k)
            cap = ""
            cm = re.search(r"\\caption(?![A-Za-z])", inner)
            if cm:
                _, j = read_opt(inner, cm.end())
                cap, j = read_arg(inner, j)
                inner = inner[:cm.start()] + inner[j:]
            inner, keys = take_labels(inner)
            cap, k2 = take_labels(cap)
            key = (keys + k2)[0] if keys + k2 else None
            for g in re.finditer(r"\\includegraphics(\[[^\]]*\])?\{([^}]*)\}", inner):
                kv = parse_keyval((g.group(1) or "[]")[1:-1])
                inner_w = to_inches(kv.get("width", "\\textwidth").replace("\\linewidth", "\\textwidth"))
                w = frac * (inner_w / TEXTWIDTH_IN if inner_w else 1.0)
                images.append([min(w, 1.0), g.group(2)])
            if "\\begin{tabular" in inner:
                images.append([0, "\n\n" + re.sub(r"\\(centering|small|footnotesize)(?![A-Za-z])", "", inner)
                               + "\n\n"])
            subcaps.append("%s\\textbf{(%s)} %s" % (anchor(key), letter, cap.strip()))
            out.append(body[pos:b0])
            pos = e1
        out.append(body[pos:])
        rest = "".join(out)
        # images side by side: scale so that a row of them fits the text width
        tot = sum(wd for wd, _ in images)
        scale = min(1.0, 0.90 / tot) if tot else 1.0
        imgs = [("\\includegraphics[width=%.3f\\textwidth]{%s}" % (wd * scale, x)) if wd else x
                for wd, x in images]
        block = ("\\begin{SUBFIGURES}%s\\end{SUBFIGURES}\n\\begin{SUBCAPTIONS}%s\\end{SUBCAPTIONS}" % (
            " ".join(imgs), " \u2003 ".join(subcaps)))
        return rest, block

    def floats(self):
        chap = ChapterLookup(self.t)
        counters = {"figure": defaultdict(int), "table": defaultdict(int)}
        out, pos = [], 0
        for m in re.finditer(r"\\begin\{(figure|table)(\*?)\}", self.t):
            if m.start() < pos:
                continue
            env = m.group(1)
            name = env + m.group(2)
            b0, c0, c1, e1 = find_env(self.t, name, m.start())
            body = self.t[c0:c1]
            _, i = read_opt(body, 0)
            body = body[i:]
            ch = chap(m.start())
            subfigs = None
            if find_env(body, "subfigure") or find_env(body, "subtable"):
                body, subfigs = self.split_subfloats(body)
            caps = list(re.finditer(r"\\caption(?![A-Za-z])", body))
            if subfigs is not None and not caps:
                out.append(self.t[pos:b0])
                out.append("\n%s\n" % subfigs)
                pos = e1
                continue
            if caps:
                cm = caps[0]
                short, j = read_opt(body, cm.end())
                cap, j = read_arg(body, j)
                rest = body[:cm.start()] + "\\CAPTIONHERE" + body[j:]
                rest, keys = take_labels(rest)
                cap, k2 = take_labels(cap)
                key = (keys + k2)[0] if keys + k2 else None
                counters[env][ch] += 1
                num = self.check(env, key, "%s.%d" % (ch, counters[env][ch]))
                label = "Figure" if env == "figure" else "Table"
                cap = "%s\\textbf{%s %s:} %s" % (anchor(key), label, num, cap.strip())
                if subfigs is not None:
                    # images side by side, sub-captions, then the caption (no pandoc figure)
                    out.append(self.t[pos:b0])
                    out.append("\n%s\n\\begin{FIGCAPTION}%s\\end{FIGCAPTION}\n" % (subfigs, cap))
                    pos = e1
                    self.stats[env] += 1
                    continue
                body = rest.replace("\\CAPTIONHERE", "\\caption{%s}" % cap)
                self.stats[env] += 1
            body = re.sub(r"\\(centering|small|footnotesize|scriptsize|raggedright)(?![A-Za-z])", "", body)
            body = re.sub(r"\\renewcommand\{\\arraystretch\}\{[^}]*\}", "", body)
            out.append(self.t[pos:b0])
            out.append("\\begin{%s}\n%s\n\\end{%s}" % (env, body.strip(), env))
            pos = e1
        out.append(self.t[pos:])
        self.t = "".join(out)

    def algorithms(self):
        chap = ChapterLookup(self.t)
        counter = defaultdict(int)
        out, pos = [], 0
        for m in re.finditer(r"\\begin\{algorithm\*?\}", self.t):
            if m.start() < pos:
                continue
            name = "algorithm*" if self.t[m.end() - 2] == "*" else "algorithm"
            b0, c0, c1, e1 = find_env(self.t, name, m.start())
            body = self.t[c0:c1]
            _, i = read_opt(body, 0)
            body = body[i:]
            cap = ""
            cm = re.search(r"\\caption(?![A-Za-z])", body)
            if cm:
                _, j = read_opt(body, cm.end())
                cap, j = read_arg(body, j)
                body = body[:cm.start()] + body[j:]
            body, keys = take_labels(body)
            cap, k2 = take_labels(cap)
            key = (keys + k2)[0] if keys + k2 else None
            ch = chap(m.start())
            counter[ch] += 1
            num = self.check("algorithm", key, "%s.%d" % (ch, counter[ch]))
            snippet = ("\\begin{minipage}{\\textwidth}\\hrule height 0.6pt\\vspace{4pt}\n%s\n"
                       "\\vspace{3pt}\\hrule height 0.6pt\\end{minipage}" % self.cite_to_text(body.strip()))
            img = self.queue_render("alg_%s_%d" % (ch, counter[ch]), snippet)
            out.append(self.t[pos:b0])
            out.append("\\begin{CAPTIONalgorithm}%s\\textbf{Algorithm %s:} %s\\end{CAPTIONalgorithm}\n"
                       "\\begin{ALGIMAGE}%s\\end{ALGIMAGE}" % (anchor(key), num, cap.strip(), img))
            pos = e1
            self.stats["algorithms"] += 1
        out.append(self.t[pos:])
        self.t = "".join(out)

    def tikz(self):
        n = [0]

        def f(content):
            n[0] += 1
            snippet = "\\begin{tikzpicture}%s\\end{tikzpicture}" % self.cite_to_text(content)
            self.stats["tikz"] += 1
            return self.queue_render("tikz_%d" % n[0], snippet)
        self.t = sub_env(self.t, "tikzpicture", f)

    def listings(self):
        chap = ChapterLookup(self.t)
        counter = defaultdict(int)

        def f(idx, cap):
            idx = int(idx)
            opts, code = self.verbatim[idx]
            kv = parse_keyval(opts)
            lang = kv.get("language", "Python")
            lang = re.sub(r"^\[[^\]]*\]", "", lang).strip() or "Python"
            res = "\\begin{lstlisting}[language=%s]\n%s\n\\end{lstlisting}" % (lang, code)
            if kv.get("caption"):
                pos_ = self.t.find("\\LSTBLOCK{%d}" % idx)
                ch = chap(pos_)
                counter[ch] += 1
                key = kv.get("label")
                num = self.check("listing", key, "%s.%d" % (ch, counter[ch]))
                head = "%s\\textbf{Listing %s:} %s" % (anchor(key), num, cap)
                res = "\\begin{CAPTIONlisting}%s\\end{CAPTIONlisting}\n" % head + res
                self.stats["listings"] += 1
            elif cap:
                res = "\\begin{CAPTIONlisting}%s\\end{CAPTIONlisting}\n" % cap + res
            self.verbatim[idx] = (None, res)
            return "\\LSTPLACEHOLDER{%d}" % idx
        self.t = sub_cmd(self.t, "LSTBLOCK", "mm", f)

    # -- 10. image rendering (TikZ, algorithms) ------------------------------------
    def queue_render(self, name, snippet):
        h = hashlib.sha1((snippet + open(os.path.join(ROOT, "preamble.tex")).read()).encode()).hexdigest()[:12]
        png = os.path.join(self.img, "%s_%s.png" % (name, h))
        self.render_jobs.append((png, snippet))
        return "\\includegraphics[width=RENDERWIDTH{%s}]{%s}" % (self.rel(png), self.rel(png))

    def run_renders(self):
        todo = [(p, s) for p, s in self.render_jobs if not (os.path.exists(p) and os.path.exists(p + ".json"))]
        if todo and self.render:
            work = os.path.join(self.out, "render")
            os.makedirs(work, exist_ok=True)
            ok = self._render_batch(work, todo)
            if not ok:
                for p, s in todo:
                    if not self._render_batch(work, [(p, s)]):
                        warn("could not render image %s" % os.path.basename(p))
        widths = {}
        for p, _ in self.render_jobs:
            meta = p + ".json"
            if os.path.exists(meta):
                with open(meta) as fh:
                    widths[self.rel(p)] = min(json.load(fh)["width_in"], 6.5)

        def w(mm):
            key = mm.group(1)
            return "%.2fin" % widths.get(key, 6.0)
        self.t = re.sub(r"RENDERWIDTH\{([^}]*)\}", w, self.t)
        missing = [p for p, _ in self.render_jobs if not os.path.exists(p)]
        for p in missing:
            self.t = self.t.replace(self.rel(p), "build/docx/img/MISSING.png")

    def _render_batch(self, work, jobs):
        doc = ["\\documentclass[11pt,twoside,openany]{book}", "\\input{preamble}",
               "\\usepackage[active,tightpage]{preview}", "\\setlength\\PreviewBorder{3pt}",
               "\\begin{document}", "\\pagestyle{empty}"]
        for _, s in jobs:
            doc.append("\\begin{preview}%s\\end{preview}\n\\clearpage" % s)
        doc.append("\\end{document}")
        tex = os.path.join(work, "snippets.tex")
        with open(tex, "w") as fh:
            fh.write("\n".join(doc))
        env = dict(os.environ, TEXINPUTS=ROOT + "//:" + os.environ.get("TEXINPUTS", ""))
        r = subprocess.run(["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "snippets.tex"],
                           cwd=work, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        pdf = os.path.join(work, "snippets.pdf")
        if r.returncode != 0 or not os.path.exists(pdf):
            return False
        info = subprocess.run(["pdfinfo", "-f", "1", "-l", str(len(jobs)), pdf],
                              capture_output=True, text=True).stdout
        sizes = [tuple(map(float, mm.groups())) for mm in
                 re.finditer(r"Page\s+\d+ size:\s+([0-9.]+) x ([0-9.]+)", info)]
        if len(sizes) != len(jobs):
            return False
        for i, ((png, _), (wpt, hpt)) in enumerate(zip(jobs, sizes)):
            subprocess.run(["pdftoppm", "-r", "300", "-png", "-singlefile", "-f", str(i + 1), "-l", str(i + 1),
                            pdf, png[:-4]], check=True)
            with open(png + ".json", "w") as fh:
                json.dump({"width_in": wpt / 72.0, "height_in": hpt / 72.0}, fh)
            self.stats["rendered"] += 1
        return True

    # -- 11. headings -----------------------------------------------------------------
    def headings(self):
        t = self.t
        out, pos = [], 0
        appendix = main = back = False
        part = chap = sec = sub = 0
        chap_id = "0"
        pat = re.compile(r"\\(part|chapter|section|subsection|subsubsection|appendix|mainmatter|"
                         r"backmatter|frontmatter)(?![A-Za-z])(\*?)")
        for m in pat.finditer(t):
            if m.start() < pos:
                continue
            kind, star = m.group(1), m.group(2) == "*"
            out.append(t[pos:m.start()])
            pos = m.end()
            if kind in ("appendix", "mainmatter", "backmatter", "frontmatter"):
                if kind == "appendix":
                    appendix, chap = True, 0
                elif kind == "mainmatter":
                    main = True
                elif kind == "backmatter":
                    back = True
                continue
            short, j = read_opt(t, pos)
            title, j = read_arg(t, j)
            rest, key = take_first_label(t[j:])
            pos = len(t) - len(rest)
            title = title.strip()
            numbered = not star and main and not back
            if kind == "part":
                if numbered:
                    part += 1
                    num = self.check("part", key, ROMAN[part] if part < len(ROMAN) else str(part))
                    out.append("\\begin{PARTHEAD}%sPart %s%s%s\\end{PARTHEAD}\n" % (anchor(key), num, EMSP, title))
                else:
                    out.append("\\begin{PARTHEAD}%s%s\\end{PARTHEAD}\n" % (anchor(key), title))
                continue
            if kind == "chapter":
                if numbered:
                    chap += 1
                    sec = 0
                    chap_id = chr(64 + chap) if appendix else str(chap)
                    chap_id = self.check("chapter", key, chap_id)
                    word = "Appendix" if appendix else "Chapter"
                    h = "%s %s%s%s" % (word, chap_id, EMSP, title)
                    out.append("\\chapter{%s}%s" % (h, "\\label{%s}" % key if key else ""))
                else:
                    out.append("\\chapter*{%s}%s" % (title, "\\label{%s}" % key if key else ""))
                continue
            if kind == "section":
                if numbered:
                    sec += 1
                    sub = 0
                    num = self.check("section", key, "%s.%d" % (chap_id, sec))
                    title = "%s%s%s" % (num, EMSP, title)
                out.append("\\section%s{%s}%s" % ("" if numbered else "*", title,
                                                  "\\label{%s}" % key if key else ""))
                continue
            if kind == "subsection":
                if numbered:
                    sub += 1
                    num = self.check("subsection", key, "%s.%d.%d" % (chap_id, sec, sub))
                    title = "%s%s%s" % (num, EMSP, title)
                out.append("\\subsection%s{%s}%s" % ("" if numbered else "*", title,
                                                     "\\label{%s}" % key if key else ""))
                continue
            out.append("\\subsubsection*{%s}%s" % (title, "\\label{%s}" % key if key else ""))
        out.append(t[pos:])
        self.t = "".join(out)

    # -- 12. tables -----------------------------------------------------------------------
    def tables(self):
        def colspec(spec, body, tabularx):
            spec = re.sub(r"\*\{(\d+)\}\{([^{}]*)\}", lambda mm: mm.group(2) * int(mm.group(1)), spec)
            cols, i = [], 0
            while i < len(spec):
                c = spec[i]
                if c in "@!><":
                    _, i = read_group(spec, i + 1)
                    continue
                if c in "pmb":
                    w, i = read_group(spec, i + 1)
                    cols.append(("p", to_inches(w)))
                    continue
                if c in "lcrX":
                    cols.append((c, None))
                i += 1
            if not any(t in ("p", "X") for t, _ in cols):
                return "".join(t for t, _ in cols)
            # estimate natural widths of l/c/r columns from their content
            rows = [split_top(r_, "&") for r_ in split_rows(body)]
            fr = []
            for k, (typ, w) in enumerate(cols):
                if typ == "p":
                    fr.append((w or 1.0) / TEXTWIDTH_IN)
                elif typ == "X":
                    fr.append(None)
                else:
                    ln = max([plain_len(r_[k]) for r_ in rows if len(r_) > k and "multicolumn" not in r_[k]]
                             or [4])
                    fr.append(min(0.35, 0.03 + 0.0115 * ln))
            nx = sum(1 for f in fr if f is None)
            if nx:
                remain = max(0.15 * nx, 1.0 - sum(f for f in fr if f is not None))
                fr = [remain / nx if f is None else f for f in fr]
            tot = sum(fr)
            if tot > 1.0:
                fr = [f / tot for f in fr]
            return "".join("p{%.3f\\linewidth}" % f for f in fr)

        def fix_body(body):
            body = re.sub(r"\\cmidrule(\([^)]*\))?\{[^}]*\}", "", body)
            body = re.sub(r"\\(addlinespace|morecmidrules)(\[[^\]]*\])?", "", body)
            body = re.sub(r"\\(endhead|endfirsthead|endfoot|endlastfoot)(?![A-Za-z])", "\\\\endhead", body)
            body = re.sub(r"\\(raggedright|arraybackslash|centering|small|footnotesize)(?![A-Za-z])", "", body)
            body = sub_cmd(body, "multicolumn", "mmm", lambda n, s, x: "\\multicolumn{%s}{%s}{%s}" % (
                n, (re.sub(r"[@!<>]\{[^}]*\}|\|", "", s) or "l")[:1], x))
            body = re.sub(r"\\\\\s*\[[^\]]*\]", r"\\\\", body)
            body = body.replace("\\tabularnewline", "\\\\")
            return body

        def tab(env):
            def f(content):
                if env in ("tabularx", "tabular*"):
                    _, i = read_arg(content, 0)
                    content = content[i:]
                if env == "longtable":
                    _, i = read_opt(content, 0)
                    content = content[i:]
                spec, i = read_arg(content, 0)
                body = fix_body(content[i:])
                newenv = "longtable" if env == "longtable" else "tabular"
                return "\\begin{%s}{%s}%s\\end{%s}" % (newenv, colspec(spec, body, env == "tabularx"),
                                                         body, newenv)
            return f
        for env in ("tabular", "longtable", "tabular*", "tabularx"):
            self.t = sub_env(self.t, env, tab(env))
        self.t = re.sub(r"\\begin\{center\}|\\end\{center\}", "", self.t)

    # -- 13. odds and ends -----------------------------------------------------------------
    def misc(self):
        t = self.t
        t = sub_cmd(t, "term", "m", lambda x: "\\emph{%s}" % x)
        t = drop_cmd(t, "index", "m")
        t = sub_cmd(t, "code", "m", lambda x: "\\texttt{%s}" % x)
        t = sub_cmd(t, "paragraph", "m", lambda st, x: "\n\n\\begin{RUNPARA}%s\\end{RUNPARA}\n" % x.strip(),
                    star=True)
        t = drop_cmd(t, "markboth", "mm")
        t = drop_cmd(t, "markright", "m")
        t = drop_cmd(t, "addcontentsline", "mmm")
        t = drop_cmd(t, "pdfbookmark", "omm")
        t = drop_cmd(t, "thispagestyle", "m")
        t = drop_cmd(t, "pagestyle", "m")
        t = drop_cmd(t, "bibliographystyle", "m")
        t = drop_cmd(t, "newgeometry", "m")
        t = re.sub(r"\\vspace\*?\{[^}]*\}|\\hspace\*?\{[^}]*\}", "", t)
        t = re.sub(r"\\renewcommand\{\\(arraystretch|bibsection|bibfont)\}\{[^{}]*(\{[^{}]*\}[^{}]*)*\}", "", t)
        t = re.sub(r"\\(phantomsection|cleardoublepage|clearpage|newpage|restoregeometry|medskip|smallskip|"
                   r"bigskip|noindent|centering|raggedright|nopagebreak|printindex|frontmatter|"
                   r"mainmatter|backmatter|appendix|protect)(?![A-Za-z])", "", t)
        t = re.sub(r"\\(small|footnotesize|scriptsize|normalsize|large|Large|LARGE)(?![A-Za-z])\s*", "", t)
        t = t.replace("\\tableofcontents", "\n\\begin{TOCHERE}\nContents\n\\end{TOCHERE}\n")
        t = re.sub(r"\\begin\{multicols\}\{\d+\}|\\end\{multicols\}", "", t)
        self.t = t

    def backmatter(self):
        """Bibliography chapter: heading, the explanatory note, citeproc's list."""
        t = self.t
        m = re.search(r"\\bibliography\{[^}]*\}", t)
        if not m:
            t += "\n\\chapter*{Bibliography}\n\\begin{REFS}\nREFS\n\\end{REFS}\n"
            self.t = t
            return
        # the note between \chapter*{Bibliography} and \bibliography{..}
        h = t.rfind("\\chapter*{Bibliography}", 0, m.start())
        if h >= 0:
            note = t[h + len("\\chapter*{Bibliography}"):m.start()]
            note = re.sub(r"\\(markboth|addcontentsline)\{[^}]*\}(\{[^}]*\})*", "", note)
            note = re.sub(r"\\renewcommand\{\\\w+\}\{[^{}]*(\{[^{}]*\}[^{}]*)*\}|\\bibliographystyle\{[^}]*\}"
                          r"|\\begin\{multicols\}\{\d+\}|\\medskip|\\par(?![a-z])", "", note)
            note = note.strip()
            if note.startswith("{") and note.endswith("}"):
                note = note[1:-1]
            note = re.sub(r"^\\small\s*|\\noindent\s*", "", note).strip()
            rep = "\\chapter*{Bibliography}\n"
            if note:
                rep += "\\begin{BIBNOTE}\n%s\n\\end{BIBNOTE}\n" % note
            rep += "\\begin{REFS}\nREFS\n\\end{REFS}\n"
            t = t[:h] + rep + t[m.end():]
        else:
            t = t[:m.start()] + "\\chapter*{Bibliography}\n\\begin{REFS}\nREFS\n\\end{REFS}\n" + t[m.end():]
        self.t = t

    def restore_verbatim(self):
        def f(idx):
            return self.verbatim[int(idx)][1]
        self.t = sub_cmd(self.t, "LSTPLACEHOLDER", "m", f)

    def leftover_labels(self):
        # keep labels after headings (pandoc uses them as identifiers), drop others
        # but keep anchors so that links still work
        def f(mm):
            key = mm.group(2)
            return anchor(key)
        self.t = re.sub(r"(?<!\})\\label\s*(\[[^\]]*\])?\s*\{([^}]*)\}", f, self.t)


TAG_SYMBOLS = {"ast": "\u2217", "star": "\u22c6", "dagger": "\u2020", "ddagger": "\u2021", "prime": "\u2032",
               "S": "\u00a7", "P": "\u00b6", "bullet": "\u2022", "circ": "\u2218"}


def tag_text(t):
    """Plain text for a \\tag{..} (which may contain a little math)."""
    t = t.replace("$", "")
    t = re.sub(r"\\([A-Za-z]+)", lambda mm: TAG_SYMBOLS.get(mm.group(1), ""), t)
    t = t.replace("'", "\u2032")
    return re.sub(r"[{}\\]", "", t).strip()


def drop_top_amps(row):
    """Remove alignment tabs '&' that are not inside braces or nested environments."""
    out, depth, env_depth, i = [], 0, 0, 0
    while i < len(row):
        if row.startswith("\\begin{", i):
            env_depth += 1
        elif row.startswith("\\end{", i):
            env_depth -= 1
        c = row[i]
        if c == "\\":
            out.append(row[i:i + 2])
            i += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        if c == "&" and depth == 0 and env_depth == 0:
            out.append(" ")
        else:
            out.append(c)
        i += 1
    return "".join(out)


def env_args(content, spec):
    args, i = [], 0
    for t in spec:
        if t == "o":
            a, i = read_opt(content, i)
        else:
            a, i = read_arg(content, i)
        args.append(a)
    return args, content[i:]


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--aux", default=os.path.join(ROOT, "build/book/main.aux"))
    ap.add_argument("--main", default=os.path.join(ROOT, "main.tex"))
    ap.add_argument("--out", default=os.path.join(ROOT, "build/docx"))
    ap.add_argument("--no-render", action="store_true", help="do not run pdflatex for TikZ/algorithms")
    ap.add_argument("--check-aux", action="store_true",
                    help="only report whether the aux file is newer than every source file")
    a = ap.parse_args()
    if a.check_aux:
        _, files = load_tex(a.main, ROOT)
        files = [os.path.join(ROOT, f) for f in files] + [os.path.join(ROOT, "preamble.tex")]
        if not os.path.exists(a.aux):
            print("missing")
            return
        t_aux = os.path.getmtime(a.aux)
        newer = [os.path.relpath(f, ROOT) for f in files if os.path.getmtime(f) > t_aux]
        print("stale " + " ".join(newer) if newer else "fresh")
        return

    aux = Aux(a.aux)
    text, files = load_tex(a.main, ROOT)
    b = text.find("\\begin{document}")
    e = text.rfind("\\end{document}")
    body = text[b + len("\\begin{document}"):e if e > 0 else len(text)]

    p = Prep(body, aux, a.out, render=not a.no_render)
    p.protect_verbatim()
    p.titlepage()
    p.citations()
    p.references()
    p.equations()
    p.theorems()
    p.exercises()
    p.boxes()
    p.algorithms()
    p.tikz()
    p.floats()
    p.subfloats()
    p.listings()
    p.headings()
    p.backmatter()
    p.run_renders()
    p.graphics()
    p.misc()
    p.tables()
    p.leftover_labels()
    p.t = p.math_fix(p.t)
    p.restore_verbatim()

    os.makedirs(a.out, exist_ok=True)
    dst = os.path.join(a.out, "book.tex")
    with open(dst, "w", encoding="utf-8") as fh:
        fh.write("\\documentclass{book}\n%s\n\\begin{document}\n%s\n\\end{document}\n" % (MACROS, p.t))
    with open(os.path.join(a.out, "prep_report.json"), "w") as fh:
        json.dump({"files": files, "stats": p.stats, "undefined_refs": sorted(p.res.undefined),
                   "number_mismatches": p.mismatch}, fh, indent=1)
    for what, key, mine, theirs in p.mismatch:
        warn("numbering differs from aux for %s %s: computed %s, aux %s (aux used)" % (what, key, mine, theirs))
    print("prep: %s  (%s)" % (os.path.relpath(dst, ROOT),
                              ", ".join("%s=%d" % kv for kv in sorted(p.stats.items()))))


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Convert a DOCX to PDF with LibreOffice (headless, throw-away user profile).

    python3 scripts/docx/run_soffice.py file.docx outdir

Equations need the LibreOffice Math module (Debian/Ubuntu: libreoffice-math);
without it LibreOffice silently drops all OMML equations from the rendering.
"""
import os
import subprocess
import sys
import tempfile
from pathlib import Path


def convert(docx, outdir):
    os.makedirs(outdir, exist_ok=True)
    env = dict(os.environ, SAL_USE_VCLPLUGIN="svp")
    with tempfile.TemporaryDirectory(prefix="lo_profile_") as prof:
        cmd = ["soffice", "-env:UserInstallation=%s" % Path(prof).as_uri(), "--headless", "--norestore",
               "--convert-to", "pdf", "--outdir", outdir, docx]
        r = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                           timeout=1800)
    pdf = os.path.join(outdir, os.path.splitext(os.path.basename(docx))[0] + ".pdf")
    if not os.path.exists(pdf):
        sys.stderr.write(r.stdout)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(convert(sys.argv[1], sys.argv[2]))

#!/usr/bin/env bash
# Self-test of the DOCX pipeline on scripts/docx/selftest/selftest.tex (constructs the
# book may use in the future).  Output: build/docx/selftest/selftest.docx (+ .pdf rendering)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
cd "$ROOT"
HERE=scripts/docx
OUT=build/docx/selftest
mkdir -p "$OUT"
cp "$HERE/selftest/selftest.tex" "$OUT/selftest.tex"
run() { TEXINPUTS="$ROOT//:" pdflatex -interaction=nonstopmode -output-directory="$OUT" "$OUT/selftest.tex" > "$OUT/pdflatex.out" 2>&1 || true; }
run
BIBINPUTS="$ROOT:" bibtex "$OUT/selftest" > "$OUT/bibtex.out" 2>&1 || true
run; run
grep -E "Warning: (Reference|Citation)" "$OUT/selftest.log" | sort -u || true
if [ ! -f "$HERE/reference.docx" ] || [ "$HERE/make_reference.py" -nt "$HERE/reference.docx" ]; then
  python3 "$HERE/make_reference.py"
fi
[ -f build/docx/apa-natbib.csl ] || sed -e 's/disambiguate-add-givenname="true"/disambiguate-add-givenname="false"/' \
    -e 's/disambiguate-add-names="true"/disambiguate-add-names="false"/' "$HERE/apa.csl" > build/docx/apa-natbib.csl
python3 "$HERE/prep.py" --main "$OUT/selftest.tex" --aux "$OUT/selftest.aux" --out "$OUT"
pandoc "$OUT/book.tex" -f latex -t docx --top-level-division=chapter \
  --lua-filter "$HERE/filters.lua" --citeproc --bibliography references.bib --csl build/docx/apa-natbib.csl \
  -M link-citations=true --lua-filter "$HERE/filters_post.lua" --highlight-style "$HERE/code.theme" \
  --reference-doc "$HERE/reference.docx" --resource-path . -o "$OUT/pandoc.docx"
python3 "$HERE/postprocess.py" "$OUT/pandoc.docx" "$OUT/selftest.docx"
python3 "$HERE/verify.py" "$OUT/selftest.docx" --render "$OUT"

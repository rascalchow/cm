"""Small, dependency-free helpers for manipulating LaTeX source text.

Only what the DOCX preprocessor needs: comment stripping, \\input expansion,
balanced-argument parsing, environment search and command substitution.
"""
import os
import re
import sys

VERBATIM_ENVS = ("lstlisting", "verbatim", "Verbatim")


def warn(msg):
    sys.stderr.write("prep: warning: %s\n" % msg)


# ---------------------------------------------------------------------------
# comments and \input
# ---------------------------------------------------------------------------
_VERB_BEGIN = re.compile(r"\\begin\{(%s)\}" % "|".join(VERBATIM_ENVS))


def strip_comments(src):
    """Remove TeX comments the way TeX does (the comment, the newline and the
    leading blanks of the next line), leaving verbatim environments intact."""
    out = []
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == "\\":
            m = _VERB_BEGIN.match(src, i)
            if m:
                end = src.find("\\end{%s}" % m.group(1), m.end())
                end = n if end < 0 else end + len("\\end{%s}" % m.group(1))
                out.append(src[i:end])
                i = end
                continue
            out.append(src[i:i + 2])
            i += 2
            continue
        if c == "%":
            j = src.find("\n", i)
            if j < 0:
                break
            j += 1
            # a comment line between two blank-line separated paragraphs must not
            # glue them together: keep the newline if the next line is empty
            k = j
            while k < n and src[k] in " \t":
                k += 1
            if k < n and src[k] == "\n":
                out.append("\n")
            i = k
            continue
        out.append(c)
        i += 1
    return "".join(out)


def load_tex(path, root, skip=("preamble",), seen=None):
    """Read a .tex file, strip comments and expand \\input/\\include recursively."""
    seen = seen if seen is not None else []
    with open(path, encoding="utf-8") as fh:
        text = strip_comments(fh.read())
    seen.append(os.path.relpath(path, root))

    def repl(m):
        name = m.group(2).strip()
        if name in skip:
            return m.group(0)
        f = os.path.join(root, name)
        if not f.endswith(".tex"):
            f += ".tex"
        if not os.path.exists(f):
            warn("input file %s not found -- skipped" % name)
            return ""
        return "\n" + load_tex(f, root, skip, seen)[0] + "\n"

    return re.sub(r"\\(input|include)\{([^}]*)\}", repl, text), seen


# ---------------------------------------------------------------------------
# balanced groups
# ---------------------------------------------------------------------------
def read_group(s, i):
    """s[i] == '{'.  Return (content, index after the closing brace)."""
    if i >= len(s) or s[i] != "{":
        raise ValueError("expected '{' at %d: %r" % (i, s[i:i + 40]))
    depth, j, n = 0, i, len(s)
    while j < n:
        c = s[j]
        if c == "\\":
            j += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return s[i + 1:j], j + 1
        j += 1
    raise ValueError("unbalanced braces starting at %d: %r" % (i, s[i:i + 60]))


def read_opt(s, i, allow_space=False):
    """Optional argument [..] at s[i] (brace-aware).  Returns (content|None, next)."""
    j = i
    if allow_space:
        while j < len(s) and s[j] in " \t":
            j += 1
    if j >= len(s) or s[j] != "[":
        return None, i
    depth_b, depth_k, k, n = 0, 0, j, len(s)
    while k < n:
        c = s[k]
        if c == "\\":
            k += 2
            continue
        if c == "{":
            depth_b += 1
        elif c == "}":
            depth_b -= 1
        elif c == "[" and depth_b == 0:
            depth_k += 1
        elif c == "]" and depth_b == 0:
            depth_k -= 1
            if depth_k == 0:
                return s[j + 1:k], k + 1
        k += 1
    return None, i


def read_arg(s, i, allow_space=True):
    """Mandatory argument: a {group} or a single token.  Returns (content, next)."""
    j = i
    if allow_space:
        while j < len(s) and s[j] in " \t\n":
            j += 1
    if j < len(s) and s[j] == "{":
        return read_group(s, j)
    if j < len(s) and s[j] == "\\":
        m = re.compile(r"\\([A-Za-z]+|.)").match(s, j)
        return m.group(0), m.end()
    return s[j:j + 1], j + 1


def split_top(s, sep=","):
    """Split at separators that are not inside braces/brackets."""
    parts, depth, cur, i = [], 0, [], 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            cur.append(s[i:i + 2])
            i += 2
            continue
        if c in "{[":
            depth += 1
        elif c in "}]":
            depth -= 1
        if c == sep and depth == 0:
            parts.append("".join(cur))
            cur = []
        else:
            cur.append(c)
        i += 1
    parts.append("".join(cur))
    return parts


def split_rows(s):
    """Split the body of an array-like environment at top-level \\\\ (ignoring
    \\\\ inside braces and nested environments).  Returns list of rows."""
    rows, cur, depth, env_depth, i, n = [], [], 0, 0, 0, len(s)
    while i < n:
        if s.startswith("\\begin{", i):
            env_depth += 1
        elif s.startswith("\\end{", i):
            env_depth -= 1
        c = s[i]
        if c == "\\":
            if s.startswith("\\\\", i) and depth == 0 and env_depth == 0:
                rows.append("".join(cur))
                cur = []
                i += 2
                # optional spacing argument  \\[2pt]
                if i < n and s[i] == "[":
                    _, i = read_opt(s, i)
                continue
            cur.append(s[i:i + 2])
            i += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
        cur.append(c)
        i += 1
    rows.append("".join(cur))
    return rows


# ---------------------------------------------------------------------------
# environments
# ---------------------------------------------------------------------------
def find_env(s, name, start=0):
    """Find the next \\begin{name} ... \\end{name} (nesting-aware).
    Returns (b0, c0, c1, e1): begin start, content start, content end, end end."""
    b = "\\begin{%s}" % name
    e = "\\end{%s}" % name
    b0 = s.find(b, start)
    if b0 < 0:
        return None
    depth, i = 0, b0
    while True:
        nb = s.find(b, i)
        ne = s.find(e, i)
        if ne < 0:
            raise ValueError("unterminated environment %s at %d" % (name, b0))
        if 0 <= nb < ne:
            depth += 1
            i = nb + len(b)
        else:
            depth -= 1
            i = ne + len(e)
            if depth == 0:
                return b0, b0 + len(b), ne, i


def sub_env(s, name, fn):
    """Replace every occurrence of environment `name` by fn(content, s_after_begin)
    where fn receives (content) and returns the replacement.  Nested occurrences
    inside the content are processed first."""
    out, pos = [], 0
    while True:
        r = find_env(s, name, pos)
        if r is None:
            out.append(s[pos:])
            return "".join(out)
        b0, c0, c1, e1 = r
        out.append(s[pos:b0])
        inner = sub_env(s[c0:c1], name, fn)
        out.append(fn(inner))
        pos = e1


def env_args(content, spec):
    """Parse leading arguments of an environment body according to spec, a string
    of 'o' (optional) and 'm' (mandatory).  Returns (args, rest)."""
    args, i = [], 0
    for t in spec:
        if t == "o":
            a, i = read_opt(content, i)
            args.append(a)
        else:
            a, i = read_arg(content, i)
            args.append(a)
    return args, content[i:]


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------
def sub_cmd(s, name, spec, fn, star=False):
    """Replace \\name<args> with fn(*args) (or fn(starred, *args) if star).
    spec: string of 'o' and 'm'.  Arguments are processed recursively first."""
    pat = re.compile(r"\\%s(?![A-Za-z@])" % re.escape(name))
    out, pos = [], 0
    while True:
        m = pat.search(s, pos)
        if m is None:
            out.append(s[pos:])
            return "".join(out)
        # skip escaped backslash (\\name is a line break followed by text)
        k, bs = m.start() - 1, 0
        while k >= 0 and s[k] == "\\":
            bs += 1
            k -= 1
        if bs % 2 == 1:
            out.append(s[pos:m.end()])
            pos = m.end()
            continue
        i = m.end()
        starred = False
        if star and i < len(s) and s[i] == "*":
            starred, i = True, i + 1
        args = []
        try:
            for t in spec:
                if t == "o":
                    a, i = read_opt(s, i, allow_space=False)
                    args.append(None if a is None else sub_cmd(a, name, spec, fn, star))
                else:
                    a, i = read_arg(s, i)
                    args.append(sub_cmd(a, name, spec, fn, star))
        except ValueError as exc:
            warn("cannot parse arguments of \\%s: %s" % (name, exc))
            out.append(s[pos:m.end()])
            pos = m.end()
            continue
        out.append(s[pos:m.start()])
        out.append(fn(starred, *args) if star else fn(*args))
        pos = i


def drop_cmd(s, name, spec=""):
    return sub_cmd(s, name, spec, lambda *a: "")


def find_cmds(s, name):
    """Yield (start, end, [args]) of \\name{arg} occurrences (one mandatory arg)."""
    pat = re.compile(r"\\%s(?![A-Za-z@])" % re.escape(name))
    for m in pat.finditer(s):
        try:
            a, j = read_arg(s, m.end())
        except ValueError:
            continue
        yield m.start(), j, a


def tex_escape(text):
    """Escape plain text for inclusion in LaTeX source."""
    rep = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#",
           "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\^{}"}
    return "".join(rep.get(c, c) for c in text)

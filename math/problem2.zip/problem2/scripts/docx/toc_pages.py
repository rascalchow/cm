#!/usr/bin/env python3
"""Find the page labels of the table-of-contents entries in a rendering of the DOCX.

    python3 scripts/docx/toc_pages.py rendered.pdf toc.json pages.json

toc.json is written by postprocess.py (--toc-json): a list of entries with their
heading text.  The page label of a PDF page is the page number printed in its
footer (roman in the front matter, arabic from Part I on).  The result
{entry index: label} is fed back to postprocess.py (--toc-pages) so that the
DOCX opens with a filled-in table of contents (Word refreshes it on opening).
"""
import json
import re
import subprocess
import sys
import unicodedata


def norm(s):
    s = unicodedata.normalize("NFKC", s)
    s = re.sub(r"[ -​ \s]+", " ", s)
    return re.sub(r"[^0-9A-Za-z ]+", "", s).lower().strip()


def main(pdf, toc_json, out):
    txt = subprocess.run(["pdftotext", "-layout", pdf, "-"], capture_output=True, text=True).stdout
    pages = txt.split("\f")
    labels, bodies = [], []
    for p in pages:
        lines = [l.strip() for l in p.splitlines() if l.strip()]
        lab = lines[-1] if lines and re.fullmatch(r"[0-9]+|[ivxlcdm]+", lines[-1]) else ""
        labels.append(lab)
        lines = lines[:-1] if lab else lines
        # a heading starts a line; it may wrap over the next two lines
        bodies.append([norm(" ".join(lines[i:i + 3])) for i in range(len(lines))])
    with open(toc_json) as fh:
        entries = json.load(fh)
    # skip the table of contents itself (pages full of dot leaders)
    start = 0
    for i, p in enumerate(pages):
        if p.count("....") > 8:
            start = i + 1
    result, cur, missing = {}, start, 0
    for k, e in enumerate(entries):
        key = norm(e["text"])[:60]
        found = None
        for i in range(cur, len(bodies)):
            if key and any(b.startswith(key) for b in bodies[i]):
                found = i
                break
        if found is None:
            missing += 1
            continue
        cur = found
        result[str(k)] = labels[found]
    with open(out, "w") as fh:
        json.dump(result, fh)
    print("toc_pages: %d of %d headings located (%d pages)" % (len(result), len(entries), len(pages)))
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))

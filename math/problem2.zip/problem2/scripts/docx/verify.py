#!/usr/bin/env python3
"""Checks for the generated DOCX.

    python3 scripts/docx/verify.py Scientific_Machine_Learning.docx [--render build/docx/render]

* text leftovers: LaTeX commands, "??", "[@", "???", unresolved label keys
  (sec:07:..., eq:..), marker names from prep.py/filters.lua, raw environments
* equations that pandoc could not convert (raw TeX in the text)
* internal hyperlinks whose bookmark does not exist
* counts of chapters, figures, tables, equations, boxes
* with --render: LibreOffice rendering, page count (and pages per chapter)
Exit status 1 if any leftover is found.
"""
import argparse
import collections
import os
import re
import subprocess
import sys
import zipfile

from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
NS = {"w": W, "m": M}
HERE = os.path.dirname(os.path.abspath(__file__))

LEFTOVERS = [
    (r"\\[A-Za-z]+", "LaTeX command"),
    (r"\?\?", "unresolved reference (??)"),
    (r"\[@", "unprocessed citation"),
    (r"\b(?:sec|eq|fig|tab|lst|alg|def|thm|prop|lem|ex|asg|ch|app|part):[A-Za-z0-9]", "label key"),
    (r"\b(BOXSTART|BOXEND|BOXTITLE|EQNUM|RUNHEAD|RUNPARA|LSTPLACEHOLDER|RENDERWIDTH|TOCHERE|"
     r"CAPTION(?:listing|algorithm)|CS(?:stars|exlabel|citealp|hidecite|thmhead))\b", "marker"),
    (r"color: ?CS", "marker span"),
    (r"\b(begin|end)\{", "raw environment"),
    (r"\b(lstlisting|tcolorbox|tikzpicture|tabularx|summarybox|keyidea|practicaltip|historybox)\b",
     "environment name"),
]


def paragraphs(doc):
    """Text of every paragraph without the equations (w:t only)."""
    for p in doc.iter("{%s}p" % W):
        parts = []
        for t in p.iter("{%s}t" % W, "{%s}instrText" % W):
            if t.tag.endswith("instrText"):
                continue
            # skip text inside math (m:r may contain w:rPr but text is m:t)
            parts.append(t.text or "")
        yield "".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("docx")
    ap.add_argument("--render", help="directory for a LibreOffice rendering (page count)")
    a = ap.parse_args()
    z = zipfile.ZipFile(a.docx)
    doc = etree.fromstring(z.read("word/document.xml"))
    text = list(paragraphs(doc))
    problems = collections.defaultdict(list)
    for i, t in enumerate(text):
        for pat, what in LEFTOVERS:
            for mm in re.finditer(pat, t):
                ctx = t[max(0, mm.start() - 50):mm.end() + 50]
                problems[what].append(ctx)
    # raw TeX inside equations (texmath failures are rendered as TeX text)
    for mt in doc.iter("{%s}t" % M):
        if mt.text and re.search(r"\\[A-Za-z]{2,}", mt.text):
            problems["TeX inside an equation"].append(mt.text[:80])
    # hyperlinks
    names = {b.get("{%s}name" % W) for b in doc.iter("{%s}bookmarkStart" % W)}
    for h in doc.iter("{%s}hyperlink" % W):
        an = h.get("{%s}anchor" % W)
        if an and an not in names:
            problems["link to missing bookmark"].append(an)
    styles = collections.Counter(p.get("{%s}val" % W) for p in doc.iter("{%s}pStyle" % W))
    print("verify: %s" % os.path.relpath(a.docx))
    print("  paragraphs %d, chapters/appendices %d, parts %d, sections %d" % (
        len(text), sum(1 for t in text if re.match(r"(Chapter \d+|Appendix [A-Z]) ", t)),
        styles.get("PartTitle", 0), styles.get("Heading2", 0)))
    print("  figures %d, tables %d, display equations %d (numbered %d), code blocks %d, boxes %d" % (
        styles.get("CaptionedFigure", 0), sum(1 for t in text if re.match(r"Table [A-Z0-9]+\.\d+:", t)),
        sum(1 for _ in doc.iter("{%s}oMathPara" % M)), styles.get("EquationNumberCell", 0),
        styles.get("SourceCode", 0), sum(1 for t in doc.iter("{%s}tblBorders" % W)
                                         if t.find("w:left", NS) is not None and
                                         t.find("w:left", NS).get("{%s}val" % W) == "single")))
    print("  bibliography entries %d" % styles.get("Bibliography", 0))
    bad = 0
    for what, items in problems.items():
        bad += len(items)
        print("  PROBLEM %-28s %4d   e.g. %r" % (what, len(items), items[0][:110]))
    if not bad:
        print("  no leftovers (LaTeX commands, ??, [@, label keys, markers, raw environments)")
    if a.render:
        os.makedirs(a.render, exist_ok=True)
        subprocess.run([sys.executable, os.path.join(HERE, "run_soffice.py"), a.docx, a.render], check=False)
        pdf = os.path.join(a.render, os.path.splitext(os.path.basename(a.docx))[0] + ".pdf")
        if os.path.exists(pdf):
            info = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
            pages = re.search(r"Pages:\s+(\d+)", info).group(1)
            print("  LibreOffice rendering: %s, %s pages" % (os.path.relpath(pdf), pages))
        else:
            print("  LibreOffice rendering failed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())

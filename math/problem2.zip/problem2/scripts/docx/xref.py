"""Cross-references for the DOCX edition, resolved from LaTeX's own .aux file.

The aux file written by hyperref + cleveref contains, for every label,
    \\newlabel{key}{{7.4}{123}{title}{anchor}{}}
    \\newlabel{key@cref}{{[equation][4][7]7.4}{[1][123][]123}}
from which we reproduce what \\ref, \\cref, \\Cref, \\eqref, ... print in the PDF
(cleveref options: capitalise, noabbrev; default sort & compress).
"""
import re

from texutil import read_group, warn

# cleveref names with [capitalise,noabbrev] (plus the \crefname's of preamble.tex)
CREF_NAMES = {
    "part": ("Part", "Parts"),
    "chapter": ("Chapter", "Chapters"),
    "section": ("Section", "Sections"),
    "subsection": ("Section", "Sections"),
    "subsubsection": ("Section", "Sections"),
    "paragraph": ("Paragraph", "Paragraphs"),
    "appendix": ("Appendix", "Appendices"),
    "subappendix": ("Appendix", "Appendices"),
    "subsubappendix": ("Appendix", "Appendices"),
    "equation": ("Equation", "Equations"),
    "figure": ("Figure", "Figures"),
    "subfigure": ("Figure", "Figures"),
    "table": ("Table", "Tables"),
    "subtable": ("Table", "Tables"),
    "listing": ("Listing", "Listings"),
    "lstlisting": ("Listing", "Listings"),
    "algorithm": ("Algorithm", "Algorithms"),
    "definition": ("Definition", "Definitions"),
    "example": ("Example", "Examples"),
    "theorem": ("Theorem", "Theorems"),
    "proposition": ("Proposition", "Propositions"),
    "lemma": ("Lemma", "Lemmas"),
    "corollary": ("Corollary", "Corollaries"),
    "remark": ("Remark", "Remarks"),
    "exercise": ("Exercise", "Exercises"),
    "assignment": ("Assignment", "Assignments"),
    "enumi": ("Item", "Items"),
    "footnote": ("Footnote", "Footnotes"),
}
PAREN_TYPES = {"equation"}          # cleveref prints equation numbers as (7.4)
NBSP = "~"                         # LaTeX non-breaking space (pandoc -> U+00A0)


class Label:
    __slots__ = ("key", "num", "title", "type", "ctr", "enc")

    def __init__(self, key):
        self.key, self.num, self.title, self.type, self.ctr, self.enc = key, "", "", None, 0, ""


class Aux:
    def __init__(self, path):
        self.labels, self.bibcite, self.toc = {}, {}, []
        with open(path, encoding="utf-8", errors="replace") as fh:
            for line in fh:
                try:
                    if line.startswith("\\newlabel{"):
                        self._newlabel(line)
                    elif line.startswith("\\bibcite{"):
                        self._bibcite(line)
                    elif line.startswith("\\@writefile{toc}{\\contentsline"):
                        self._toc(line)
                except (ValueError, IndexError) as exc:
                    warn("cannot parse aux line %r (%s)" % (line[:80], exc))

    def _newlabel(self, line):
        key, i = read_group(line, len("\\newlabel"))
        val, _ = read_group(line, i)
        if key.endswith("@cref"):
            key = key[:-5]
            first, _ = read_group(val, 0)
            m = re.match(r"\[([^\]]*)\]\[([^\]]*)\]\[([^\]]*)\](.*)$", first, re.S)
            lab = self.labels.setdefault(key, Label(key))
            if m:
                lab.type = m.group(1)
                try:
                    lab.ctr = int(m.group(2))
                except ValueError:
                    lab.ctr = 0
                lab.enc = m.group(3)
            return
        num, j = read_group(val, 0)
        _page, j = read_group(val, j)
        title = ""
        if j < len(val) and val[j] == "{":
            title, j = read_group(val, j)
        lab = self.labels.setdefault(key, Label(key))
        lab.num, lab.title = num, title

    def _bibcite(self, line):
        key, i = read_group(line, len("\\bibcite"))
        val, _ = read_group(line, i)
        parts, j = [], 0
        while j < len(val) and val[j] == "{":
            p, j = read_group(val, j)
            parts.append(p)
        if len(parts) >= 3:
            year = parts[1]
            short, _ = read_group(parts[2], 0) if parts[2].startswith("{") else (parts[2], 0)
            full = short
            if len(parts) >= 4:
                full, _ = read_group(parts[3], 0) if parts[3].startswith("{") else (parts[3], 0)
            try:
                pos = int(parts[0])
            except ValueError:
                pos = 0
            self.bibcite[key] = (year, short, full, pos)

    def _toc(self, line):
        body, _ = read_group(line, len("\\@writefile{toc}"))
        m = re.match(r"\\contentsline\s*\{(\w+)\}", body)
        if not m:
            return
        title, j = read_group(body, m.end())
        page, _ = read_group(body, j)
        num = ""
        mm = re.match(r"\\numberline\s*\{([^}]*)\}", title)
        if mm:
            num, title = mm.group(1), title[mm.end():]
        self.toc.append((m.group(1), num, title.strip(), page))

    # ------------------------------------------------------------------
    def get(self, key):
        lab = self.labels.get(key)
        if lab is None or (not lab.num and lab.type is None):
            return None
        return lab

    def number(self, key):
        lab = self.get(key)
        return lab.num if lab else None


class Resolver:
    """Formats \\ref, \\cref, \\Cref, \\eqref, ... as LaTeX text."""

    def __init__(self, aux):
        self.aux = aux
        self.undefined = set()

    def _lab(self, key):
        lab = self.aux.get(key)
        if lab is None:
            self.undefined.add(key)
        return lab

    def ref(self, key):
        lab = self._lab(key)
        return lab.num if lab else "??"

    def eqref(self, key):
        lab = self._lab(key)
        return "(%s)" % (lab.num if lab else "??")

    def nameref(self, key):
        lab = self._lab(key)
        return lab.title if lab and lab.title else "??"

    @staticmethod
    def _fmt_num(typ, num):
        return "(%s)" % num if typ in PAREN_TYPES else num

    def cref(self, keys, capital=False, with_name=True):
        """keys: list of label keys.  Implements cleveref's sorting, grouping by
        type (in order of first appearance), and range compression (>= 3)."""
        labs, out_undef = [], 0
        for k in keys:
            k = k.strip()
            if not k:
                continue
            lab = self._lab(k)
            if lab is None:
                out_undef += 1
            else:
                labs.append(lab)
        groups, order = {}, []
        for lab in labs:
            t = lab.type or "section"
            if t not in groups:
                groups[t] = []
                order.append(t)
            groups[t].append(lab)
        texts = []
        for t in order:
            g = sorted(groups[t], key=lambda l: (l.enc, l.ctr))
            # de-duplicate identical labels
            uniq = []
            for l in g:
                if not uniq or (uniq[-1].num != l.num):
                    uniq.append(l)
            g = uniq
            # compress runs of consecutive counter values (same enclosing counters)
            runs = []
            for l in g:
                if runs and runs[-1][-1].enc == l.enc and l.ctr == runs[-1][-1].ctr + 1:
                    runs[-1].append(l)
                else:
                    runs.append([l])
            items = []
            for r in runs:
                if len(r) >= 3:
                    items.append("%s to%s%s" % (self._fmt_num(t, r[0].num), NBSP,
                                                self._fmt_num(t, r[-1].num)))
                else:
                    items.extend(self._fmt_num(t, l.num) for l in r)
            plural = len(items) > 1 or any(len(r) >= 3 for r in runs)
            if len(items) == 1:
                body = items[0]
            elif len(items) == 2:
                body = "%s and%s%s" % (items[0], NBSP, items[1])
            else:
                body = ", ".join(items[:-1]) + " and" + NBSP + items[-1]
            if with_name:
                sing, plur = CREF_NAMES.get(t, (t.capitalize(), t.capitalize() + "s"))
                name = plur if plural else sing
                texts.append(name + NBSP + body)
            else:
                texts.append(body)
        texts.extend(["??"] * out_undef)
        if not texts:
            return "??"
        if len(texts) == 1:
            return texts[0]
        if len(texts) == 2:
            return "%s and%s%s" % (texts[0], NBSP, texts[1])
        return ", ".join(texts[:-1]) + ", and" + NBSP + texts[-1]

    def crefrange(self, a, b):
        la, lb = self._lab(a), self._lab(b)
        if not la or not lb:
            return "??"
        t = la.type or "section"
        sing, plur = CREF_NAMES.get(t, (t.capitalize(), t.capitalize() + "s"))
        return "%s%s%s to%s%s" % (plur, NBSP, self._fmt_num(t, la.num), NBSP, self._fmt_num(t, lb.num))

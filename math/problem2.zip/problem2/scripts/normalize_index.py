#!/usr/bin/env python3
"""Lower-case the first letter of index entries unless it starts a proper noun or acronym.

\\index{X}  -> \\index{x}
\\term{X}   -> \\emph{X}\\index{x}   (the printed text is unchanged)
"""
import glob
import os
import re
import sys

sys.path.insert(0, os.path.dirname(__file__))
from bibtool import PROPER  # noqa: E402

EXTRA = set("""galilean glorot gauss karhunen kullback fokker lotka burgers koopman
hamiltonian lagrangian gaussian fourier kalman kolmogorov lorenz galerkin bayes bayesian
markov monte langevin hessian jacobian newton noether runge picard lipschitz sobolev
hilbert banach laplace poisson darcy navier reynolds smagorinsky germano tikhonov
hadamard wiener sobol latin metropolis gibbs chebyshev legendre courant lax euler
stormer verlet adam python pytorch numpy scipy jax julia shannon fisher cramer
crank nicolson duffing kuramoto allen cahn helmholtz cole hopf schur sherman woodbury
woodbury taylor dirichlet neumann robin moore penrose eckart young tweedie ornstein
hankel pareto savitzky golay barron nesterov liouville deep
""".split())


def keep_case(entry):
    first = re.split(r"[\s!\-]", entry, maxsplit=1)[0]
    if first.endswith("'s"):
        return True                        # possessive: named after a person
    letters = re.sub(r"[^A-Za-z]", "", first)
    if not letters or not first[0].isupper():
        return True
    if len(letters) > 1 and any(c.isupper() for c in letters[1:]):
        return True                        # acronym or mixed case (DMD, PINNs, DeepONet)
    if len(letters) == 1:
        return True                        # single letters (e.g. "Q-learning")
    return letters.lower() in PROPER or letters.lower() in EXTRA


def lower_first(entry):
    return entry if keep_case(entry) else entry[0].lower() + entry[1:]


def main():
    files = sorted(glob.glob("chapters/*.tex") + glob.glob("appendices/*.tex"))
    changes = []
    for f in files:
        s = open(f).read()
        new = re.sub(r"\\index\{([^{}]*)\}",
                     lambda m: "\\index{%s}" % lower_first(m.group(1)), s)

        def term(m):
            x = m.group(1)
            k = lower_first(x)
            return m.group(0) if k == x else "\\emph{%s}\\index{%s}" % (x, k)
        new = re.sub(r"\\term\{([^{}]*)\}", term, new)
        if new != s:
            n = sum(1 for a, b in zip(re.findall(r"\\index\{[^{}]*\}", s), re.findall(r"\\index\{[^{}]*\}", new)) if a != b)
            changes.append((f, n))
            open(f, "w").write(new)
    for f, n in changes:
        print(f, n)


if __name__ == "__main__":
    main()

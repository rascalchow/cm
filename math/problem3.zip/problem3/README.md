# Simulating the future of tuberculosis with a spatio-temporal graph neural network

Problem 3: predict tuberculosis (TB) epidemiology for 20 regions from 10 years of
patient-level records (sex, age, occupation, diagnosis, outcome, ...), using a graph
neural network, with a synthetic dataset. The full write-up is
[report/report.pdf](report/report.pdf) (source: [report/report.md](report/report.md)).

## Quick start (Python 3.9)

```bash
python3.9 -m venv .venv && .venv/bin/pip install -r requirements.txt
.venv/bin/python run_all.py             # ~50 min on 12 CPU cores: data, training, evaluation, simulation, figures
.venv/bin/python run_all.py --plots-only  # redraw tables/figures from saved results
TB_QUICK=1 .venv/bin/python run_all.py  # few-minute smoke test (tiny training, writes to outputs_quick/)
bash report/build.sh                    # rebuild report/report.pdf (needs pandoc + LaTeX)
```

Everything is seeded (`tb_gnn/config.py: SEED`); re-running reproduces the dataset exactly
and the models up to floating-point nondeterminism.

## Layout

| Path | Content |
|---|---|
| `tb_gnn/synth.py` | Mechanistic generator: two-strain (drug-susceptible / MDR) metapopulation TB model on a mobility network + patient-record sampler |
| `tb_gnn/datagen.py` | Writes the dataset, scenario covariates and the hidden ground truth |
| `tb_gnn/panel.py` | Records -> region x month panel (cases, MDR, deaths, age-sex mix) |
| `tb_gnn/features.py` | Standardisation, forecasting windows, chronological split |
| `tb_gnn/models.py` | STGNN: diffusion-graph-convolutional GRU encoder-decoder (mobility + adaptive adjacency) |
| `tb_gnn/baselines.py` | Seasonal naive and per-region Poisson GLM (trend + seasonality + disruption) |
| `tb_gnn/training.py` | Training with early stopping, parallel seed ensembles |
| `tb_gnn/simulate.py` | Stochastic autoregressive 5-year simulation under scenarios |
| `tb_gnn/interpret.py` | Gradient-based spatial influence of the learned model |
| `tb_gnn/experiments.py` | Benchmark, scenario study, interpretation, coupling sensitivity |
| `tb_gnn/eda.py`, `tb_gnn/plotting.py` | Descriptive epidemiology and figures |
| `run_all.py` | End-to-end pipeline |

## Data (`data/`)

| File | Rows | Description |
|---|---|---|
| `tb_patient_records.csv` | 139,014 | One row per notified TB patient, 2015-01-01 .. 2024-12-31 |
| `regions.csv` | 20 | Region code/name, coordinates, 2015 population, urbanisation, GDP and ageing indices |
| `region_covariates_monthly.csv` | 2,400 | Population, health-system index, HIV prevalence, mobility index, service disruption, net migration |
| `mobility_od.csv` | 380 | Average daily trips between regions (the graph) |
| `scenarios/*_covariates_2025_2029.csv` | 1,200 each | Covariate assumptions of the three future scenarios (model input) |
| `hidden_truth/` | - | Generator ground truth for 2025-2029 and the true contact matrix. **Used only to score the simulations, never for training.** |
| `sensitivity/` | - | Re-generated worlds with 3x and 6x inter-regional mobility (coupling study) |

Patient record columns: `record_id, region_code, region_name, diagnosis_date, sex, age, age_group,
occupation, residence, patient_type, diagnosis, hiv_status, drug_resistance, regimen, outcome,
outcome_date, treatment_days`. Outcomes after the 2024-12-31 data cut-off are recorded as
`Still on treatment` (right-censored), as in a real surveillance extract.

## Key results (details in the report)

* **Short-term (12-month) forecasts, 2023-2024 test:** all learned models are within 8-13% of the
  oracle noise floor; the STGNN's 90% intervals cover 89% of outcomes; neural models beat the GLM
  significantly on MDR-TB counts. The graph adds **no significant** short-term accuracy over the same
  model without a graph, even with 6x inter-regional mobility, although the learned spatial influence
  matches the hidden contact matrix (Spearman 0.66-0.88).
* **Five-year simulation, 2025-2029:** the STGNN ensemble tracks the hidden national truth within
  1.6-2.3% (cases) under all three scenarios and reproduces the post-disruption rebound; graph-free
  models of either size drift ~10% low. Status quo: 64 -> 56 notifications per 100k, deaths on
  treatment 844 -> ~700, continued ageing of the caseload.
* **Limits:** regional 5-year changes are poorly ranked, and the effect of faster health-system
  improvement (collinear with time in the data) is not learned.

## Freeing disk space

`outputs/scenarios.pkl` (about 200 MB) has been deleted to save space. It held the raw 2025-2029
simulation paths: 200 sampled trajectories per model and scenario.

**What it affects.** Every finished result is already saved: the figures in `outputs/figures/`,
the tables in `outputs/tables/`, `report/report.pdf` and the online doc. Until the file is
recreated, though, `python run_all.py --plots-only` stops with a `FileNotFoundError`, because
these steps read it:

- the tables `scenario_metrics`, `scenario_national_annual`, `long_horizon_drift` and `size_control_scenarios`;
- `fig08_scenarios_national.png`, `fig09_scenario_compare.png` and `fig10_age_shift.png` (Figures 9-11 in the report).

**How to recreate it** (about 2 minutes on CPU):

```bash
.venv/bin/python run_all.py --resume
```

`--resume` skips every stage whose results are saved and re-runs only the scenario simulation, using
the trained models in `outputs/models/`. It then redraws all tables and figures. The rollouts are
seeded, so the numbers should match the report. If `.venv` is missing, recreate it first (see Quick start).

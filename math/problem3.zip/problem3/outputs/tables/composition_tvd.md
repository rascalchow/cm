| model             |    TVD |
|:------------------|-------:|
| STGNN             | 0.0555 |
| STGNN-mob         | 0.0558 |
| GRU-nograph       | 0.0557 |
| Last-12-month mix | 0.0556 |
| comparison                       |   diff_MAE |   ci_low |   ci_high |
|:---------------------------------|-----------:|---------:|----------:|
| STGNN - GLM | cases              |     -0.045 |   -0.369 |     0.281 |
| STGNN - GLM | mdr                |     -0.067 |   -0.122 |    -0.015 |
| STGNN - GLM | deaths             |     -0.042 |   -0.103 |     0.025 |
| STGNN - GRU-nograph | cases      |      0.282 |   -0.110 |     0.779 |
| STGNN - GRU-nograph | mdr        |      0.017 |   -0.003 |     0.038 |
| STGNN - GRU-nograph | deaths     |      0.013 |   -0.003 |     0.034 |
| STGNN-mob - GRU-nograph | cases  |      0.242 |   -0.170 |     0.803 |
| STGNN-mob - GRU-nograph | mdr    |      0.042 |   -0.007 |     0.102 |
| STGNN-mob - GRU-nograph | deaths |      0.026 |   -0.000 |     0.060 |
| GRU-nograph - GLM | cases        |     -0.327 |   -0.974 |     0.156 |
| GRU-nograph - GLM | mdr          |     -0.084 |   -0.149 |    -0.028 |
| GRU-nograph - GLM | deaths       |     -0.055 |   -0.123 |     0.017 |
| STGNN - SeasonalNaive | cases    |     -2.054 |   -2.575 |    -1.578 |
| STGNN - SeasonalNaive | mdr      |     -0.347 |   -0.484 |    -0.219 |
| STGNN - SeasonalNaive | deaths   |     -0.443 |   -0.620 |    -0.283 |
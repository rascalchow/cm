| model       |   neighbour_share |   spearman_true_contact |   spearman_input_graph |   spearman_inverse_distance |
|:------------|------------------:|------------------------:|-----------------------:|----------------------------:|
| STGNN       |             0.393 |                   0.664 |                  0.683 |                       0.792 |
| STGNN-mob   |             0.333 |                   0.876 |                  0.891 |                       0.829 |
| GRU-nograph |             0.000 |                 nan     |                nan     |                     nan     |
| scenario         | model                   | err2029_by_seed             |   seed_sd_2029 |   ensemble_err2029 |   ensemble_mean_abs_err |
|:-----------------|:------------------------|:----------------------------|---------------:|-------------------:|------------------------:|
| baseline         | STGNN                   | -7.2 -2.7 +5.0 +1.1 -1.7    |            4.1 |               -1.0 |                     1.6 |
| baseline         | STGNN-mob               | +8.3 -3.9 +15.9 -14.4 -12.2 |           11.7 |               -3.9 |                     3.3 |
| baseline         | GRU-nograph             | -11.6 -11.0 -4.4 -7.0 -14.3 |            3.5 |              -10.1 |                     7.2 |
| baseline         | GRU-nograph (hidden 16) | -4.8 -13.3 -4.2 -10.5 -13.2 |            4.0 |               -9.4 |                     6.6 |
| enhanced_control | STGNN                   | -2.3 +5.4 +6.9 +3.6 +0.9    |            3.3 |                2.9 |                     2.0 |
| enhanced_control | STGNN-mob               | +15.4 -5.4 +40.1 -16.6 -6.1 |           20.2 |               -4.0 |                     4.4 |
| enhanced_control | GRU-nograph             | -8.4 -5.0 +2.5 -5.3 -8.5    |            4.0 |               -5.9 |                     6.5 |
| enhanced_control | GRU-nograph (hidden 16) | -0.8 -8.2 +2.3 -4.2 -11.7   |            5.0 |               -3.7 |                     5.6 |
| disruption       | STGNN                   | -2.3 -4.0 +6.5 +2.7 +1.2    |            3.7 |                0.7 |                     2.3 |
| disruption       | STGNN-mob               | +8.8 +2.9 +21.8 -14.4 -5.6  |           12.3 |                2.9 |                     3.2 |
| disruption       | GRU-nograph             | -7.6 -5.4 -2.3 -1.8 -7.8    |            2.5 |               -5.3 |                     2.8 |
| disruption       | GRU-nograph (hidden 16) | -6.4 -8.9 +1.7 -4.4 -8.2    |            3.8 |               -5.9 |                     3.5 |
| occupation          |   pct |   deaths_pct |   ltfu_pct |
|:--------------------|------:|-------------:|-----------:|
| Farmer              | 28.55 |         7.45 |       3.31 |
| Industrial worker   | 18.58 |         5.64 |       3.35 |
| Service worker      | 15.61 |         5.56 |       3.37 |
| Retired             | 14.38 |        11.89 |       2.39 |
| Office/professional |  5.67 |         5.88 |       3.08 |
| Unemployed          |  5.66 |         6.47 |       5.69 |
| Homemaker           |  4.41 |         6.58 |       2.76 |
| Student             |  4.04 |         3.54 |       3.60 |
| Preschool child     |  1.35 |         3.70 |       3.03 |
| Healthcare worker   |  0.95 |         5.96 |       3.90 |
| Migrant worker      |  0.82 |         4.89 |       8.18 |
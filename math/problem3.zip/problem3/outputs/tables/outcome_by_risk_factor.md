| level              |   success |   died | factor          |     n |
|:-------------------|----------:|-------:|:----------------|------:|
| 0-14               |     90.98 |   3.20 | age group       |  3092 |
| 15-44              |     88.05 |   4.41 | age group       | 44515 |
| 45-64              |     86.93 |   7.13 | age group       | 41141 |
| 65+                |     82.80 |  11.72 | age group       | 23464 |
| Female             |     88.17 |   5.78 | sex             | 34196 |
| Male               |     85.95 |   7.39 | sex             | 78016 |
| Negative           |     87.94 |   5.52 | HIV status      | 90633 |
| Positive           |     74.32 |  19.99 | HIV status      |  6274 |
| Unknown            |     83.84 |   9.72 | HIV status      | 15305 |
| Drug-susceptible   |     88.12 |   6.02 | drug resistance | 52322 |
| Not tested         |     86.04 |   7.27 | drug resistance | 56269 |
| RR/MDR-TB          |     74.12 |  13.81 | drug resistance |  3621 |
| New                |     87.81 |   6.24 | patient type    | 87900 |
| Previously treated |     82.33 |   9.29 | patient type    | 24312 |
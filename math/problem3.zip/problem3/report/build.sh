#!/usr/bin/env bash
# Build report/report.pdf from report/report.md (figures are copied from outputs/figures).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p figures
cp ../outputs/figures/*.png figures/
pandoc report.md -o report.pdf \
  --pdf-engine=pdflatex \
  --number-sections \
  --toc --toc-depth=2 \
  -V geometry:margin=2.2cm -V fontsize=10pt -V linkcolor=blue -V urlcolor=blue \
  -H header.tex
echo "wrote $(pwd)/report.pdf"

---
title: "Simulating the Future Epidemiology of Tuberculosis with a Spatio-Temporal Graph Neural Network"
subtitle: "A synthetic 20-region, 10-year study with mechanistic ground truth"
date: "October 2026"
abstract: |
  We study whether a graph neural network (GNN) can learn the regional dynamics of
  tuberculosis (TB) from routine patient records and use them to simulate the
  epidemic's future. Because real surveillance data cannot reveal the true future or
  the true transmission network, we first build a synthetic but epidemiologically
  grounded world: a two-strain (drug-susceptible / multidrug-resistant) metapopulation
  transmission model on 20 regions coupled by a gravity-type mobility network, driven
  by time-varying health-system, HIV, mobility and migration covariates. The model
  generates 139,014 individual patient records for 2015-2024 (sex, age, occupation,
  residence, diagnosis, HIV status, drug resistance, regimen, outcome and dates) and
  keeps a hidden ground truth for 2025-2029 under three policy scenarios. On this data
  we train a spatio-temporal GNN (STGNN): a diffusion-graph-convolutional GRU
  encoder-decoder over the observed mobility graph plus a learned adaptive adjacency,
  which forecasts monthly notified cases, RR/MDR-TB cases, deaths on treatment and the
  age-sex mix of cases, and is rolled forward stochastically for five years.
  On the 2023-2024 test period the STGNN's monthly forecasts are within 12% of an
  oracle that knows the true expected counts. Its 90% intervals are well calibrated (89%
  coverage), and it is significantly more accurate than a per-region Poisson GLM for
  MDR-TB. The graph, however, adds no significant short-term accuracy over an
  identical model without one, even with six-fold inter-regional mixing, although
  gradient analysis shows that the GNN recovers the true contact structure (Spearman
  0.66-0.88). Five-year simulations tell a different story. The STGNN ensemble tracks
  the hidden national truth within 1.6-2.3% under status-quo, enhanced-control and
  disruption scenarios and reproduces the post-disruption rebound, while graph-free
  models of either size drift about 10% low by 2029. Under the status quo,
  notifications fall from 64 to 56 per 100,000 by 2029 and deaths on treatment from
  844 to about 700, and the caseload continues to age. Regional five-year changes are
  poorly ranked, and the model misses the effect of faster health-system improvement,
  which is collinear with time in the training data. GNNs are a useful, calibrated
  component for multi-region TB simulation, but they must be ensembled, benchmarked
  against strong local baselines and complemented by mechanistic structure for policy
  counterfactuals.
---

# Introduction

Tuberculosis remains one of the leading infectious causes of death worldwide. Its
epidemiology is shaped by long and variable latency (most incident cases arise from
infections acquired years earlier), by the performance of case finding and treatment,
by HIV co-infection, by drug resistance and by population movement between regions.
Surveillance systems record every notified patient with demographic, clinical and
outcome information, and programme managers need to know where the epidemic is
heading: how many cases and deaths to expect, where, among whom, and how the answer
changes under different policies or shocks.

Graph neural networks are a natural candidate for this task. Regions form a graph whose
edges are the flows of people that carry infection between them, and spatio-temporal
GNNs such as DCRNN, STGCN and Graph WaveNet have been successful for traffic and, more
recently, for influenza and COVID-19 forecasting. TB, however, differs from those
applications in two ways that matter for model design: its dynamics are slow (a change
in transmission shows up in notifications over years, not days) and regional monthly
counts are small and noisy. Whether a GNN can exploit the spatial structure of such an
epidemic is therefore an empirical question.

The task specification asks for a GNN simulation of TB in 20 regions over 10 years using
records with gender, age, occupation, diagnosis and outcome, built on a synthetic
dataset. We treat the synthetic setting as an opportunity rather than a limitation: a
mechanistic generator lets us (i) keep the *true* future hidden and score the
simulations against it, (ii) know the irreducible noise level, so accuracy can be
judged against an oracle, (iii) know the true transmission network, so we can check
what the GNN has learned, and (iv) vary the strength of spatial coupling to ask *when*
the graph helps.

**Contributions.**

1. A reproducible generator of realistic TB surveillance data: a two-strain
   metapopulation transmission model with 100 years of burn-in, coupled to an
   individual-level sampler of patient attributes and treatment outcomes with
   right-censoring at the data cut-off (Section 2).
2. A compact spatio-temporal GNN for count data with level anchoring, Poisson /
   multinomial deviance losses, covariate-driven decoding for scenario analysis, and
   stochastic autoregressive simulation with calibrated negative-binomial noise
   (Section 3).
3. A rigorous evaluation: chronological train / validation / test split, five-seed
   ensembles, classical and ablation baselines, an oracle noise floor, interval
   calibration, bootstrap confidence intervals, gradient-based interpretation, five-year
   scenario simulations scored against hidden truth, and a coupling-sensitivity study
   (Sections 4-5).

# Synthetic data

## Design principles

The generator is *mechanistic first, records second*: an epidemic model produces the
expected number of notifications in each region and month, and each notified case is
then expanded into a patient record whose attributes depend on where the infection
came from (recent transmission, reactivation of remote infection, or relapse/failure)
and on regional context. This produces correlations that appear in real data, such as
the ageing of the caseload as transmission declines, higher mortality among the elderly
and people with HIV, and lower treatment success for drug-resistant TB, without
hard-coding them as statistical targets. All random streams derive from a single seed.

## Regions and the mobility network

Twenty regions are placed on a jittered 5 x 4 grid covering roughly 900 x 700 km
(Figure 1). Three are metropolitan (2.9-3.8 million inhabitants, urbanisation
0.85-0.91); the others have 0.37-0.91 million inhabitants. Urbanisation decays with
distance from the nearest metropolis; a GDP index increases with urbanisation and from
west to east; an ageing index is higher in rural regions; HIV prevalence is concentrated
in a south-western corridor (0.17-1.1%). The total population is 19.5 million in 2015.

Residents of region $i$ spend a share $\varepsilon_i m_i(t)$ of their contact time
elsewhere (3.5% for metropolitan residents, 4.7-10.1% elsewhere, highest near
metropolises), distributed by a gravity model
$$W_{ij} \propto \frac{N_j^{0.9}}{(d_{ij}+25\,\text{km})^{2}},\qquad
C_{ij}(t) = \big(1-\varepsilon_i m_i(t)\big)\,\mathbf{1}[i=j] + \varepsilon_i m_i(t)\,W_{ij},$$
where $m_i(t)$ is a mobility index (growing 2% per year, reduced during service
disruptions). The modeller does *not* observe $C$. They observe average daily
origin-destination trips (`mobility_od.csv`), which are proportional to
$\varepsilon_i N_i W_{ij}$ with 15% log-normal measurement error. These trips form the graph.

## Transmission model

For strain $s\in\{\text{DS},\text{MDR}\}$ each region has compartments: uninfected $S$;
recent latent infection $L^f_s$; remote latent infection $L^s_s$; active undiagnosed
disease $I_{s,\cdot}$ (labelled by source: recent, remote, retreatment); on treatment
$T_s$; and recovered $R_s$. Transmission is location-based: infectious people from
region $k$ spend time in location $j$ according to $C_{kj}$, and residents of $i$ are
exposed at every location they visit,
$$\lambda_{s,i}(t)=\sum_j C_{ij}\,\beta_j(t)\,\phi_s\,
\frac{\sum_k C_{kj} I_{s,k}}{\sum_k C_{kj} N_k}.$$
With $x$ the relative susceptibility of previously infected people,
$$
\begin{aligned}
\dot S &= bN - \textstyle\sum_s \lambda_s S - \mu S\\
\dot L^f_s &= \lambda_s\big(S + x\textstyle\sum_{s'}L^s_{s'} + x\sum_{s'}R_{s'}\big) - (\epsilon+\omega+\mu)L^f_s\\
\dot L^s_s &= \omega L^f_s - x\textstyle\sum_{s'}\lambda_{s'}L^s_s - (\nu_i+\mu)L^s_s\\
\dot I_s &= \epsilon L^f_s + \nu_i L^s_s + \rho R_s + f_{s,i}\tau_s T_s \pm a\,f_{\text{DS},i}\tau_{\text{DS}}T_{\text{DS}} - (\delta_i(t)+\mu_{TB}+c+\mu)I_s\\
\dot T_s &= \delta_i(t)\,I_s - (\tau_s+\mu)\,T_s\\
\dot R_s &= q_{s,i}\tau_s T_s + c I_s - x\textstyle\sum_{s'}\lambda_{s'}R_s - (\rho+\mu)R_s
\end{aligned}
$$
where $q$, $f$ and $1-q-f$ are the treatment success, failure/return and death
fractions, and $a$ is the share of DS failures that acquire resistance. Table 1 lists
the parameter values, which are taken from or close to standard TB models (e.g. 10-11%
lifetime fast progression, about 0.06%/year reactivation, case fatality of untreated
TB about 50%). The system is integrated with four Euler sub-steps per month.

| Symbol | Meaning | Value |
|---|---|---|
| $\beta_j$ | effective contacts per infectious person-year | $12\,(0.7+0.5u_j)(1.9-1.5g_j)e^{z_j}$, range 7.9-15.5 |
| $\phi_{\text{MDR}}$ | relative transmissibility of MDR strain | 0.9 |
| $\epsilon,\ \omega$ | fast progression, stabilisation of recent infection | 0.06, 0.5 / yr |
| $\nu_i$ | reactivation | $0.0006(1+19h_i)(1+0.6\,\text{age}_i)$ / yr |
| $x$ | relative susceptibility to reinfection | 0.35 |
| $\mu_{TB},\ c$ | untreated TB mortality, self-cure | $0.17(1+10h_i)$, 0.17 / yr |
| $\delta_i(t)$ | case detection (= notification) rate | $(0.4+2.6H_i(t))\,\sigma(\text{month})\,(1-D_i(t))$ / yr |
| $\tau_s$ | treatment exit | 2 (DS), 0.6 (MDR) / yr |
| $q_s$ | treatment success | $0.80+0.16H$ (DS), $0.35+0.35H$ (MDR) |
| $a$ | acquired resistance among DS failures | 0.08 |
| $\rho$ | relapse after cure | 0.002 / yr |
| $\mu$, $b$ | background mortality, births | 1/72 / yr; population growth -0.4% to +1.2% / yr |
| $z_j(t)$ | process noise in transmission | AR(1), $\rho=0.85$, $\sigma=0.05$ per month |

: Parameters of the transmission model ($u$ urbanisation, $g$ GDP index, $h$ HIV prevalence, $H$ health-system index, $D$ service disruption).

A 100-year burn-in (1915-2014) with transmission falling from 2.2x to 1x its 2015
level and case detection introduced from 1945 places 2015 on a realistic secular
decline: in 2015-2024, 44% of notified cases arise from reactivation of remote
infection, 34% from recent transmission and 22% from relapse or treatment failure, and
incidence falls 1-2% per year.

## Exogenous drivers and embedded events

The covariates that the modeller observes monthly drive the generator:

* **Health-system index** $H_i(t)$ starts at 0.46-0.78 in 2015 and rises 0.6-1.7 points per year (cap 0.97). Three
  low-performing regions (R04 Dunmore, R06 Fennick, R09 Ironvale) start a TB-control
  scale-up in mid-2019 (+3.5 points/yr).
* **Service disruption** $D_i(t)$: a pandemic-like shock in March-April 2020 (25-50%
  loss of case detection, 5-month recovery) and a short second wave in January 2023
  (10-22%). Both are observed covariates, so the model can learn their effect.
* **HIV prevalence** drifts by -4% to +5% per year.
* **Labour migration**: from 2018, R19 Stavenham (next to the eastern metropolis)
  attracts migrant workers from the five poorest regions (3% of its population per
  year), and crowding raises transmission there by up to 80%. Its notification
  rate rises from 65-79 per 100,000 in 2015-2019 to 93-98 in 2021-2024, while the
  other regions decline.
* **MDR cluster**: an imported MDR outbreak in R01 Ashford in April 2016
  (40 active and 800 latent MDR infections).
* Seasonality of health seeking (spring peak, February holiday dip) and weak winter
  seasonality of transmission.

## From expected counts to patient records

Expected notifications $\mathbb{E}[n_{i}(t)]=\int_{\text{month}}\delta_i\sum_s I_{s,i}\,dt$
are turned into observed counts with negative-binomial noise (size 100, i.e. 10%
extra-Poisson reporting variability), split by strain and source in proportion to the
detection flows, and expanded into records:

* **Age**: recent-transmission cases are young adults (15 + Gamma(2, 10)) or children
  (5-13% of recent cases, more in poorer regions). Reactivation cases are older
  (22 + Gamma(5.5, 6.5), drifting +0.25 years per calendar year and older in ageing
  regions). Retreatment cases are in between.
* **Sex**: 52% male among children; 64-75% among adults, rising with age and for
  retreatment.
* **Occupation**: depends on age, sex, urbanisation and GDP, plus migrant status,
  whose probability grows with the region's recent in-migration. There are 11
  categories, from preschool child to retired.
* **Residence** (urban/rural), **HIV status** (relative risk about 20 among working-age
  adults; testing coverage $0.60+0.38H$), **diagnosis** (extrapulmonary 14%, more with
  HIV and in children; bacteriological confirmation $0.40+0.45H$), **drug resistance**
  (susceptibility testing $0.45+0.50H$ of confirmed cases; MDR found with 95%
  sensitivity), **patient type** and **regimen**.
* **Outcome**: a multinomial logit relative to success, with risk factors age 45-64
  and 65+, HIV, unknown HIV status, male sex, previous treatment, true MDR (detected
  or missed), extrapulmonary disease, migrant status, unemployment and $H$. Success is
  labelled *Cured* if bacteriologically confirmed and *Treatment completed* otherwise.
  Durations follow the regimen (6-8 months for DS, 9-24 months for MDR); deaths cluster
  early.
* **Censoring**: outcomes later than the 31 December 2024 cut-off are recorded as
  *Still on treatment*, as in a real surveillance extract.

## The resulting dataset

The extract contains **139,014 patient records** (2015-2024), 2,400 region-months of
covariates and 380 directed mobility flows. Monthly counts per region range from 8 to
278 (median 39). Table 2 summarises the national epidemiology, and Figures 1-3 show its
spatial and demographic structure.

| | 2015 | 2016 | 2017 | 2018 | 2019 | 2020 | 2021 | 2022 | 2023 | 2024 |
|:-------------------------------|------:|------:|------:|------:|------:|------:|------:|------:|------:|------:|
| Notified cases | 14,848 | 14,514 | 14,287 | 14,056 | 13,827 | 12,598 | 14,359 | 13,723 | 13,471 | 13,331 |
| Rate per 100k | 75.8 | 73.6 | 72.0 | 70.4 | 68.7 | 62.2 | 70.4 | 66.9 | 65.2 | 64.1 |
| Male (%) | 69.2 | 69.2 | 69.8 | 69.3 | 69.8 | 69.5 | 69.7 | 69.8 | 70.1 | 70.0 |
| Mean age (yr) | 47.9 | 48.2 | 48.8 | 48.8 | 48.7 | 49.3 | 48.9 | 49.7 | 49.3 | 49.6 |
| Aged 65+ (%) | 19.3 | 19.8 | 20.8 | 21.3 | 20.8 | 21.7 | 21.1 | 22.6 | 21.6 | 22.3 |
| HIV+ among tested (%) | 6.3 | 6.5 | 6.6 | 6.3 | 6.7 | 6.3 | 6.6 | 6.5 | 6.3 | 6.4 |
| RR/MDR among DST-tested (%) | 6.6 | 6.6 | 6.6 | 6.1 | 6.4 | 6.8 | 6.1 | 6.7 | 5.9 | 6.6 |
| Previously treated (%) | 21.7 | 21.8 | 21.9 | 21.4 | 22.0 | 21.1 | 21.5 | 21.9 | 20.6 | 21.2 |
| Bacteriologically confirmed (%) | 57.8 | 58.3 | 58.4 | 58.9 | 59.7 | 59.9 | 59.8 | 61.8 | 61.5 | 61.8 |
| Treatment success (%)* | 86.2 | 86.2 | 86.1 | 86.5 | 86.5 | 86.9 | 86.8 | 87.9 | 87.8 | (81.2) |
| Died on treatment (%)* | 7.2 | 7.4 | 7.3 | 7.0 | 6.8 | 6.6 | 6.8 | 6.0 | 6.3 | (10.9) |

: National summary of the synthetic records. *Among patients with an evaluated outcome. The 2024 cohort is right-censored (6,875 still on treatment), and early outcomes (deaths, loss to follow-up) are observed first, so its rates are biased. This is a realistic artefact of a surveillance cut-off and the reason cohort-outcome indicators are reported with a lag.

The notification rate falls from 75.8 to 64.1 per 100,000. The 2020 disruption
removes 9% of notifications, with a catch-up rebound in 2021, and the January 2023 wave
leaves a visible dent (Figure 2a). Regional rates span 46-128 per 100,000. The poorer,
older regions of the southern belt carry the highest burden, the metropolises the
lowest, and R19 Stavenham's rise after 2018 is the most visible regional change
(Figure 2b). Seventy per cent of patients are male. The caseload ages steadily (mean
age 47.9 to 49.6; share aged 65+ from 19.3% to 22.3%) because reactivation of
infections acquired decades ago makes up a growing share of disease. Farmers,
industrial and service workers, and retirees dominate the occupational profile, and
15% of cases are extrapulmonary.

![Synthetic country: regions sized by population and coloured by mean notification rate; grey lines are the 45 largest mobility flows. Labelled events are embedded in the generator.](figures/fig01_region_map.png){width=82%}

![(a) Monthly national notifications with seasonality, the 2020 disruption and 2021 rebound. (b) Notification rate per 100,000 by region and year (sorted by mean).](figures/fig02_trends.png)

![(a) Age-sex distribution, (b) occupation, (c) treatment outcomes by diagnosis cohort 2015-2023 (axis starts at 70%).](figures/fig03_demographics.png)

Outcomes show the expected risk gradients, which arise from the record model rather
than from any target statistics (Table 3).

| Group | Success (%) | Died (%) | n |
|:------------------------------------|:----------------------|:-------------------|:-------------------------------|
| Age 0-14 / 15-44 / 45-64 / 65+ | 91.0 / 88.1 / 86.9 / 82.8 | 3.2 / 4.4 / 7.1 / 11.7 | 3,092 / 44,515 / 41,141 / 23,464 |
| Female / Male | 88.2 / 86.0 | 5.8 / 7.4 | 34,196 / 78,016 |
| HIV negative / positive / unknown | 87.9 / 74.3 / 83.8 | 5.5 / 20.0 / 9.7 | 90,633 / 6,274 / 15,305 |
| Drug-susceptible / RR/MDR-TB / not tested | 88.1 / 74.1 / 86.0 | 6.0 / 13.8 / 7.3 | 52,322 / 3,621 / 56,269 |
| New / previously treated | 87.8 / 82.3 | 6.2 / 9.3 | 87,900 / 24,312 |

: Treatment outcome by risk factor (cohorts 2015-2022). Migrant workers have the highest loss to follow-up (8.2% vs. about 3.3% overall).

## Future scenarios and hidden ground truth

From the generator's state on 31 December 2024 we continue the simulation to December
2029 under three scenarios that differ only in their covariates (common random numbers
otherwise):

* **Status quo**: the 2015-2024 trends continue.
* **Enhanced control**: the health-system index rises an extra 5 points per year from
  2025, giving faster detection and better outcomes (an End-TB-style push).
* **Health-system disruption**: a shock like the 2020 one in March 2026 (30-50% loss
  of detection, 8-month recovery).

The scenario covariates are given to the models (`data/scenarios/`). The resulting
cases, deaths, MDR counts and age-sex mix are stored in `data/hidden_truth/` and used
only for scoring.

# Methods

## Problem formulation

Let $\mathcal{G}=(\mathcal{V},\mathcal{E})$ be the region graph ($|\mathcal{V}|=20$).
For region $i$ and month $t$ the panel built from the records contains three count
targets $\mathbf{y}_{i,t}=(\text{cases},\ \text{RR/MDR-TB},\ \text{deaths on
treatment})$ (cases and MDR by month of diagnosis, deaths by month of death, so all are
fully observed before the cut-off) and the case counts in eight age-sex strata
$\mathbf{c}_{i,t}$ (M/F x 0-14/15-44/45-64/65+). Covariates
$\mathbf{z}_{i,t}$ (health index, log HIV prevalence, mobility index, service
disruption, net migration rate, log population) are known for the past and are
*specified by the scenario* for the future. Given 24 months of history, the model
predicts the distribution of $\mathbf{y}$ and $\mathbf{c}$ for the next 12 months.
Longer simulations iterate this map.

## Graph construction

From the observed trips $F_{ij}$ we form forward and backward random-walk matrices
$A_{\text{fwd}}=D_{\text{out}}^{-1}F$ and $A_{\text{bwd}}=D_{\text{in}}^{-1}F^{\top}$
(diagonal removed). As in Graph WaveNet, a third, *adaptive* support is learned from two
node-embedding matrices, $A_{\text{adp}}=\operatorname{softmax}(\operatorname{ReLU}(E_1E_2^{\top}))$,
so the model can discover dependencies that the trip data miss.

## Spatio-temporal GNN (STGNN)

Figure 4 summarises the pipeline from records to simulation.

![Pipeline and architecture: records and covariates form a region-month panel; a diffusion-graph-convolutional GRU encoder-decoder over mobility and adaptive supports predicts counts and the age-sex mix; simulations feed sampled counts back autoregressively.](figures/fig04_architecture.png)

**Diffusion graph convolution.** For node features $X\in\mathbb{R}^{N\times F}$ and
supports $A_1..A_S$,
$$\Theta\star X = XW_{\text{self}} + \Big(\sum_{s=1}^{S}\sum_{k=1}^{K}\alpha_{s,k}A_s^{k}X\Big)W_{\text{nb}},\qquad \alpha=\operatorname{softmax}(a),\ K=2.$$
This is a parameter-efficient variant of the DCRNN convolution: the hops of all
supports share one neighbour projection, weighted by learned mixing coefficients. The
original form multiplies the parameter count by $1+SK=7$ and overfitted badly on the
roughly 50 training windows available (Section 3.4). With no supports it reduces to a
node-wise linear layer.

**Recurrent encoder-decoder.** Inputs are embedded by a linear layer and fed to a GRU
whose gates are graph convolutions:
$$r_t,u_t=\sigma\big(\Theta_{ru}\star[x_t,h_{t-1}]\big),\quad
\tilde h_t=\tanh\big(\Theta_{h}\star[x_t,\ r_t\odot h_{t-1}]\big),\quad
h_t=u_t\odot h_{t-1}+(1-u_t)\odot\tilde h_t .$$
The encoder reads 24 months of
$[\log(1+\mathbf{y}),\ \text{age-sex shares},\ \mathbf{z},\ \text{month } \sin/\cos,\ \text{static node features}]$
(24 features, standardised with training-period statistics). A second graph-GRU decodes
12 steps driven only by *future* covariates, calendar, static features and the step
index. That is how scenarios enter the forecast.

**Level-anchored output heads.** An MLP maps each decoder state to 3 + 8 outputs:
$$\log\mu_{i,t_0+h,k}=\log\big(\bar y^{(12)}_{i,k}+0.05\big)+g_k(h_{i,h}),\qquad
\pi_{i,t_0+h}=\operatorname{softmax}\big(\log\bar{\mathbf{c}}^{(12)}_i+g_c(h_{i,h})\big),$$
where $\bar y^{(12)}$ and $\bar{\mathbf c}^{(12)}$ are the last-12-month mean level and
age-sex mix of the region. The network therefore learns *departures* from current
levels (trend, seasonality, covariate effects, spillover). The final layer is
initialised at zero, so training starts from the persistence forecast.

**Loss.** The mean Poisson deviance of each count target plus the multinomial deviance
of the age-sex counts divided by its degrees of freedom (7):
$$\mathcal{L}=\sum_{k=1}^{3}\ \underset{b,h,i}{\operatorname{mean}}\ 2\Big[y_k\log\frac{y_k}{\mu_k}-(y_k-\mu_k)\Big]
\;+\;\frac{1}{7}\ \underset{b,h,i}{\operatorname{mean}}\ 2\sum_{a=1}^{8}c_a\log\frac{c_a}{n\,\pi_a},$$
averaged over windows $b$, horizons $h$ and regions $i$, with $n=\sum_a c_a$.

## Training protocol

The split is chronological, by the last target month: training windows end by December
2021 (49 forecast origins), validation targets end in 2022 (12 origins), and test
origins are December 2022 to December 2023 (13 rolling origins, all inputs and targets
in 2023-2024 out of sample). We use Adam (learning rate $3\times10^{-3}$, weight decay
$10^{-3}$), batch size 8, dropout 0.3, gradient clipping at 1, and early stopping on
validation loss (patience 40, at most 400 epochs). We selected the learning rate,
hidden size (16 or 32), dropout and weight decay with a small grid search *on the
validation year only*. Each variant got its best setting (STGNN hidden 16, the others
32). Every model is trained with five seeds and the forecasts are averaged.
For the future simulation, each seed is retrained on all windows up to December 2024
for the number of epochs that validation selected for it.

## Baselines and ablations

* **Seasonal naive**: same month last year.
* **Poisson GLM**: per region and target, $\log\mu_t=a+bt+\text{month}_t+\gamma\log(1-D_t)$,
  refitted at every origin on all past months (with quasi-Poisson dispersion for
  intervals). It is a strong classical baseline that also sees the disruption covariate.
* **STGNN-mob**: mobility supports only, no adaptive adjacency.
* **GRU-nograph**: identical architecture with no supports. Every region is forecast
  from its own history with weights shared across regions. This isolates the value of
  the graph.
* **Oracle**: the generator's *expected* notifications. Its error is pure observation
  noise, the floor no model can beat.

## Simulation of the future

For 2025-2029 we run a stochastic autoregressive rollout from the end of the record.
Each 12-month block takes the model's means, samples negative-binomial counts (the size
parameter is estimated per target from validation residuals), splits sampled cases
into age-sex strata multinomially, appends the samples to the history and repeats, five
times. Each of the five seeds yields 40 paths (200 per scenario), so the intervals
reflect both model (seed) uncertainty and accumulated stochasticity. The GLM is
extrapolated with its trend and seasonality and negative-binomial noise.

## Evaluation

Point accuracy is measured by MAE, RMSE, WAPE ($\sum|e|/\sum y$) and MAPE on monthly
region-level counts. Probabilistic accuracy is measured by the empirical coverage of
central 50% and 90% intervals and by the interval score. The composition forecast is
scored by the total-variation distance between the predicted and observed 12-month
age-sex mix. Differences between models get 95% bootstrap confidence intervals from
resampling regions. Simulations are scored on annual national and regional totals
against the hidden truth.

**Interpretation.** For a trained model, the spatial influence
$S_{ij}=\mathbb{E}\big|\partial\sum_h\log\mu_{i,h}/\partial x_{j,\cdot}\big|$ (gradient
of region $i$'s 12-month forecast with respect to region $j$'s input case history,
averaged over test windows and seeds) is compared with the true contact matrix $C$.

**Coupling sensitivity.** We regenerate the world with the same seed but
inter-regional contact shares $\varepsilon_i$ multiplied by 3 and 6, and repeat the
STGNN vs GRU-nograph vs GLM comparison (same hyper-parameters, five seeds each).

# Results I: short-term forecasting (2023-2024)

## Accuracy against baselines and the noise floor

Table 4 reports test-set accuracy over 13 rolling origins x 12 horizons x 20 regions
(3,120 region-months per target). Three findings stand out.

| Model | Cases MAE | Cases WAPE % | Excess over oracle | 90% PI coverage | MDR MAE | Deaths MAE |
|:--------------------------------|---------:|---------:|----------:|----------:|--------:|---------:|
| Oracle (true mean) | 7.82 | 13.97 | - | - | - | - |
| **STGNN** (mobility + adaptive) | 8.76 | 15.65 | +12.0% | 88.9% | 1.064 | 1.500 |
| STGNN (mobility only) | 8.72 | 15.58 | +11.5% | 89.3% | 1.089 | 1.512 |
| GRU (no graph) | **8.48** | **15.14** | **+8.4%** | 89.2% | **1.047** | **1.486** |
| Poisson GLM | 8.80 | 15.73 | +12.6% | 86.0% | 1.131 | 1.541 |
| Seasonal naive | 10.81 | 19.32 | +38.3% | - | 1.411 | 1.943 |

: Test-set accuracy of 12-month-ahead monthly forecasts per region (ensembles of five seeds; single-seed STGNN cases MAE 8.95 +/- 0.44). Excess over oracle = MAE / oracle MAE - 1.

1. **All learned models are close to the noise floor.** Even the oracle, which knows the
   generator's expected counts, has a WAPE of 14%: that is the negative-binomial
   reporting noise. The neural models and the GLM sit within 8-13% of the oracle's
   MAE, while the seasonal naive forecast is 38% above it. Monthly regional TB
   notifications are mostly predictable from their own recent level, trend and
   season.
2. **The neural models beat the GLM on the sparse targets.** The bootstrap 95% CIs of the
   MAE difference exclude zero for MDR cases (STGNN - GLM: -0.067 [-0.122, -0.015];
   GRU - GLM: -0.084 [-0.149, -0.028]) but not for cases (-0.05 [-0.37, 0.28]) or
   deaths (-0.04 [-0.10, 0.03]). Pooling information across regions and targets helps
   most where single-region series are noisiest.
3. **At realistic coupling the graph adds no measurable short-term accuracy.** STGNN vs
   the identical model without a graph: +0.28 [-0.11, 0.78] cases MAE, a
   non-significant difference that nominally favours the no-graph model. The graph
   models are, however, the most accurate at horizons of 1-4 months (Figure 6), where
   recent neighbouring dynamics carry information. Beyond six months the no-graph
   GRU is best.

The ensembles' 90% prediction intervals are well calibrated for cases (89%) and slightly
conservative for MDR (97-98%) and deaths (93-94%). The GLM's quasi-Poisson intervals
under-cover (86%). For calendar-year totals (forecast in December for the next
year) the GLM is the most accurate model. Its mean regional absolute percentage
errors are 5.3% (2023) and 6.5% (2024), against 6.6% and 7.2% for the STGNN and an
oracle floor of 4.6% and 4.4%. So the neural models' advantage lies in the monthly
pattern, not the annual level.

![Out-of-sample forecasts for four regions (largest, migration hub, highest burden, smallest).](figures/fig05_forecast_examples.png)

![MAE by forecast horizon. Graph models lead at 1-4 months; the no-graph GRU leads beyond 6 months.](figures/fig06_horizon_mae.png){width=80%}

**Age-sex composition.** The predicted 12-month age-sex mix has a total-variation
distance of 0.0555-0.0558 from the observed mix for all three neural variants,
indistinguishable from simply carrying forward the last 12 months' mix (0.0556). The
composition drifts slowly (about +0.3 percentage points of 65+ per year), and over one
year this is smaller than the sampling noise of the observed mix.

## What did the graph model learn?

The gradient-based influence of each region's case history on every other region's
forecast (Figure 7a) shows that the STGNN *does* use the graph. 39% of its total input
sensitivity comes from other regions (33% for STGNN-mob, 0% by construction for the
GRU), and the pattern matches the true, hidden contact matrix (Figure 7b): Spearman
$\rho=0.66$ over the 380 off-diagonal pairs, and 0.88 for the mobility-only variant. The
strongest learned dependencies are the true ones. R01 Ashford and the metropolis R02
Brindlemoor are tightly linked, and the western metropolis R16 is linked to its
satellites R11, R12 and R17. The adaptive adjacency on its own, however, is unrelated to
true contact ($\rho=0.03$). It acts as a generic regional-similarity kernel, not a
transmission map, and the transmission structure the model uses comes through the
observed mobility supports.

![(a) Learned spatial influence $S_{ij}$ (STGNN, mean over test windows and seeds; diagonal omitted). (b) True contact matrix $C_{ij}$ of the generator. (c) Off-diagonal entries, log-log.](figures/fig07_influence.png)

So the model recovers the right spatial structure, yet that structure does not improve
accuracy. The reason is quantitative. In the generator, 13% of the force of infection
(6-23% by region) comes from contact with non-residents, but this share is nearly
constant: over a 24-month input window it changes by a median of 0.5 percentage points
(95th percentile 2.7). Multi-year latency then smears any change over years of
notifications, so the spatial signal is buried under 14% monthly reporting noise.

## When does the graph help? Coupling sensitivity

Regenerating the world with inter-regional contact multiplied by 3 and 6 gives the
results in Figure 8 and Table 5.

| Mobility | Oracle MAE | STGNN | GRU (no graph) | GLM | STGNN - GRU (95% CI) |
|:----------|---------:|-------:|---------:|-------:|----------------------:|
| x1 (main) | 7.82 | +12.0% | +8.4% | +12.6% | +0.28 [-0.11, 0.78] |
| x3 | 7.01 | +13.1% | +12.4% | +13.6% | +0.05 [-0.12, 0.22] |
| x6 | 7.07 | +10.5% | +11.0% | +11.2% | -0.04 [-0.18, 0.12] |

: Coupling sensitivity: excess cases MAE over the oracle in each world, and the MAE difference between STGNN and the no-graph GRU.

The STGNN's relative position improves monotonically with coupling, from the worst
neural model at x1 to the best model at x6, but the advantage never becomes
statistically distinguishable from zero. For a slowly evolving, latency-dominated
infection, short-term forecasting is limited by observation noise rather than missing
spatial information, even when one-third of contacts cross regional borders.

![Excess MAE over the oracle as inter-regional mobility increases.](figures/fig11_sensitivity.png){width=75%}

# Results II: simulating 2025-2029

## National trajectories under three scenarios

Figure 9 shows monthly national notifications, MDR cases and deaths for 2025-2029
simulated by the retrained models, against the hidden truth. Table 6 scores the annual
totals.

| Scenario | Model | Cases | Cases 90% PI covers truth | Deaths | MDR |
|---|---|---|---|---|---|
| Status quo | **STGNN** | **1.6** | 5/5 years | **2.7** | **12.8** |
| | STGNN (mobility only) | 3.3 | 5/5 | 5.5 | 30.9 |
| | GRU (no graph) | 7.2 | 1/5 | 6.1 | 14.5 |
| | Poisson GLM | 5.3 | 0/5 | 11.0 | 13.6 |
| Enhanced control | **STGNN** | **2.0** | 4/5 | 20.8 | 5.4 |
| | STGNN (mobility only) | 4.4 | 4/5 | 23.5 | 24.4 |
| | GRU (no graph) | 6.5 | 1/5 | **12.5** | 9.4 |
| | Poisson GLM | 6.1 | 1/5 | 27.8 | **5.2** |
| Disruption | **STGNN** | **2.3** | 4/5 | 9.7 | 15.1 |
| | STGNN (mobility only) | 3.2 | 5/5 | 12.6 | 23.9 |
| | GRU (no graph) | 2.8 | 4/5 | **3.8** | 21.9 |
| | Poisson GLM | 2.9 | 2/5 | 11.2 | **10.5** |

: Five-year simulation accuracy: mean absolute percentage error (%) of national annual totals 2025-2029 against the hidden truth, and the number of years whose true total falls inside the 90% simulation interval.

![Simulated national monthly notifications (top), RR/MDR-TB cases (middle) and deaths on treatment (bottom) under the three scenarios: STGNN median and 90% interval, no-graph GRU and GLM medians, and the hidden truth (grey).](figures/fig08_scenarios_national.png)

**Status quo.** The STGNN ensemble projects 12,072 notified cases in 2029 (truth
12,195), a notification rate of 56.0 per 100,000 (truth 56.6), down from 64.1 in 2024,
and 698 deaths on treatment (truth 695; 844 in 2024). Its 90% interval contains the true national
total in all five years. Its error over five years (1.6%) is a quarter of the
no-graph GRU's (7.2%) and a third of the GLM's (5.3%). The GLM extrapolates a trend
that is flattened by the 2020-2021 dip and rebound, overshoots, and has
over-confident intervals (0/5 covered).

**Health-system disruption.** The STGNN reproduces both the March 2026 collapse in
notifications and the 2027 catch-up rebound above the pre-shock level. The no-graph GRU
does too. Both learned this from the single 2020-2021 episode, because the
disruption index is a decoder input. The GLM, which has no dynamics, reproduces the dip
but not the rebound: it projects 12,681 cases in 2027 against a true 13,323.

**Enhanced control.** This is the clearest failure. In truth, a faster rise of the
health-system index first *increases* notifications (more cases found: 13,582 vs
13,157 in 2025), then lowers them (11,700 vs 12,195 in 2029), and cuts deaths on
treatment by 31% (809 to 532). All learned models barely distinguish this scenario
from the status quo: the STGNN projects 12,035 cases and 744 deaths in 2029. In the
training data, the health index rises smoothly in every region and is almost collinear
with calendar time and with each region's own trend. Ten years of observational data
cannot reliably identify its causal effect, so the model attributes the decline to "trend" and
does not respond to the counterfactual covariate path.

## Long-horizon stability: graph or model size?

Autoregressive simulation compounds errors. Per seed, the 2029 national error of the
no-graph GRU is negative in all five seeds (-4% to -14%), a systematic downward drift.
The STGNN's seeds scatter on both sides (-7% to +5%). The mobility-only STGNN is unstable
(-14% to +16%, and up to +40% under enhanced control). Because the STGNN uses hidden
size 16 while the others use 32, we retrained the no-graph GRU with hidden size 16 as a
control.

| Model | Parameters | Test cases MAE | 2029 error by seed (%) | Ensemble 2029 error | 5-yr national MAPE |
|:----------------------------|--------:|--------:|:----------------------------------|---------:|---------:|
| STGNN (hidden 16) | 7,683 | 8.76 | -7.2, -2.7, +5.0, +1.1, -1.7 | **-1.0%** | **1.6%** |
| STGNN, mobility only (32) | 27,483 | 8.72 | +8.3, -3.9, +15.9, -14.4, -12.2 | -3.9% | 3.3% |
| GRU, no graph (32) | 15,179 | 8.48 | -11.6, -11.0, -4.4, -7.0, -14.3 | -10.1% | 7.2% |
| GRU, no graph (16), control | 4,267 | **8.35** | -4.8, -13.3, -4.2, -10.5, -13.2 | -9.4% | 6.6% |

: Long-horizon stability under the status-quo scenario: error of the simulated 2029 national case total for each seed's 40-path median and for the ensemble.

The control is the most accurate short-term forecaster of all (cases MAE 8.35, WAPE
14.9%), so a small hidden size is not a handicap. Yet in simulation it drifts like the
larger GRU, underestimating 2029 cases by 9.4% (6.6% five-year MAPE against 1.6% for the
STGNN). The same pattern holds under the other two scenarios. The downward drift is
therefore shared by both graph-free models regardless of size, and absent from the
STGNN. A plausible mechanism is that the diffusion terms tie each region's simulated
trajectory to its neighbours' and damp the compounding of region-specific errors
through the autoregressive feedback. The mobility-only STGNN, however, shows that a
graph can also amplify feedback (seed spread of 12-20 points), and all of this rests on
one synthetic world. We therefore regard the stabilising effect of the graph as
suggestive, not established. What is clear is that the best short-term model is not
the best simulator, so model selection for simulation must use multi-year rollouts,
not one-step validation loss.

## Regional and demographic projections

Under the status quo, the STGNN projects declines in 19 of 20 regions by 2029 and a
continued rise in the migration hub R19 Stavenham (Figure 10b). Regional accuracy is
much lower than national accuracy. The mean absolute error of the projected
2024-to-2029 change is 7.8 percentage points (GRU 11.1, GLM 8.4), but the correlation
between projected and true regional change is weak (Pearson 0.18; GLM 0.55). The model
extrapolates R19's 2018-2021 surge (+17% projected vs +3% true, as the migrant inflow
stabilises) and misses the steepest true declines (R13 Millbrook -35%, R09 Ironvale
-23%). The national total benefits from errors cancelling across regions, and regional
5-year projections should be read as indicative.

![(a) National notification rate per 100,000: observed 2015-2024 and STGNN simulations 2025-2029 (median, 90% band) with hidden truth (x). (b) Projected vs true change in regional annual cases, 2029 vs 2024, status quo.](figures/fig09_scenario_compare.png)

The caseload keeps ageing. The STGNN projects the share of cases aged 65+ to rise from
22.3% (2024) to 23.5% (2029) under the status quo, in the right direction but more
slowly than the truth (24.9%). The truth ages faster because recent transmission keeps
falling while reactivation in the elderly persists. A level-anchored composition head
that learned little beyond persistence (Section 4.1) understates this structural
shift.

![Share of notified cases aged 65+: observed, STGNN simulations under the three scenarios (median and 90% band) and hidden truth (x).](figures/fig10_age_shift.png){width=68%}

# Discussion

**What the GNN delivers.** Trained only on patient records, regional covariates and a
noisy trip matrix, the STGNN produces calibrated 12-month forecasts within 12% of the
noise floor and, for the MDR and death series, significantly more accurate than a
per-region GLM. Its five-year national simulations track the hidden truth within 1.6-2.3%
for cases under all three scenarios, with intervals that cover the truth in 13 of 15
scenario-years. They reproduce non-trivial dynamics such as the post-disruption
rebound and avoid the downward drift of graph-free models of either size. It also recovers the true spatial transmission structure from data
($\rho=0.66$-$0.88$ with the hidden contact matrix).

**What it does not deliver, and why.** (i) The graph does not improve short-term
accuracy at realistic or even strongly elevated inter-regional mixing. TB's long
latency means neighbouring regions' recent case counts carry little information that a
region's own history lacks. (ii) Regional 5-year changes are poorly ranked: the model
extrapolates local trends. (iii) Policy counterfactuals that the historical data do not
identify, such as faster health-system improvement, are not reproduced. This is a
limitation of learning from observational data, not of GNNs in particular, and it is
why mechanistic or hybrid models remain necessary for intervention analysis.

**Practical guidance.** For routine short-term notification forecasting, a well-tuned
local model (GRU or GLM) is as good as a GNN. A GNN pays off when the goal is a
coherent multi-region, multi-year simulation, or when the spatial dependency structure
is itself of interest. Ensembling over seeds is essential, because single-model
autoregressive rollouts are unstable. Scenario analysis should be restricted to
covariate changes with historical precedent (e.g. disruptions), or delegated to a
mechanistic component.

**Limitations.** The data are synthetic. Although the generator is mechanistic and
calibrated to plausible ranges, real surveillance data contain reporting artefacts,
definition changes and unmodelled heterogeneity that would make every model's task
harder. All conclusions rest on one realisation of one synthetic world (plus two
coupling variants). Hyper-parameters were tuned on a single validation year. The
treatment-outcome indicators are modelled as counts by month of death rather than as
cohort proportions. Uncertainty from future covariates is not propagated (scenarios
are taken as given).

**Future work.** Hybrid "epidemiology-informed" GNNs, in which the network outputs
time-varying transmission and detection parameters of a differentiable compartmental
model, would give scenario responses grounded in mechanism. Hierarchical
(national-regional) reconciliation would combine the STGNN's good national level with
better regional allocation. Individual-level graph models of the occupational and
household structure in the records could support targeted case finding.

# Conclusion

We built a reproducible synthetic TB surveillance system: 20 regions, 10 years and
139,014 patient records generated by a two-strain metapopulation transmission model,
with hidden ground truth for 2025-2029. We trained a spatio-temporal graph neural
network on it and used the network to simulate the future epidemiological status of
TB. The STGNN forecasts close to the irreducible noise floor and simulates national
trajectories under status-quo and disruption scenarios accurately: notifications fall
from 64 to about 56 per 100,000 by 2029, and deaths on treatment fall from 844 to about 700. It
learns the true inter-regional contact structure, and the caseload continues to age. Careful
benchmarking also shows the limits of this approach: at realistic mobility the graph
does not improve short-term accuracy, regional five-year changes are poorly
differentiated, and counterfactual policy effects not identified by history are not
captured. These results argue for GNNs as a component of TB scenario modelling,
ensembled and benchmarked against strong local baselines, combined with mechanistic
structure where interventions must be evaluated.

# Appendix A: Reproducibility {-}

All code is in `tb_gnn/` (Python 3.9, PyTorch 2.8 CPU). `python run_all.py` regenerates
the dataset (seed 20250101), trains 30 models (3 variants x 5 seeds x evaluation/final)
in parallel, runs the benchmark, simulations, interpretation and sensitivity study, and
writes every table in `outputs/tables/` and every figure in `outputs/figures/`. The
full run takes about 50 minutes on 12 CPU cores (`--resume` reuses finished stages).
Model sizes: STGNN 7,683 parameters, STGNN (mobility only) 27,483, GRU (no graph)
15,179, GRU control 4,267. The early-stopping epochs selected on the 2022 validation
year were 21-72 (STGNN), 23-57 (STGNN-mob), 48-67 (GRU) and 76-189 (GRU control).

![Validation loss curves (five seeds per variant).](figures/fig12_training.png){width=70%}

# Appendix B: Data dictionary {-}

| Column | Values |
|---|---|
| record_id | TB0000001 ... TB0139014 |
| region_code, region_name | R01-R20, fictional names |
| diagnosis_date | 2015-01-01 ... 2024-12-31 |
| sex | Male, Female |
| age, age_group | 0-99; 0-14, 15-44, 45-64, 65+ |
| occupation | Preschool child, Student, Farmer, Industrial worker, Migrant worker, Service worker, Office/professional, Healthcare worker, Homemaker, Unemployed, Retired |
| residence | Urban, Rural |
| patient_type | New, Previously treated |
| diagnosis | Pulmonary, bacteriologically confirmed; Pulmonary, clinically diagnosed; Extrapulmonary |
| hiv_status | Positive, Negative, Unknown |
| drug_resistance | Drug-susceptible, RR/MDR-TB, Not tested |
| regimen | Standard 6-month (2HRZE/4HR), Retreatment regimen, MDR short regimen, MDR long regimen |
| outcome | Cured, Treatment completed, Died, Treatment failed, Lost to follow-up, Not evaluated, Still on treatment |
| outcome_date, treatment_days | date of outcome and days from diagnosis (empty if still on treatment) |

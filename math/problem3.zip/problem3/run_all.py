"""End-to-end pipeline.

    python run_all.py                 # generate data, train, evaluate, simulate, plot
    python run_all.py --skip-sensitivity
    python run_all.py --plots-only    # redraw figures/tables from saved results
    python run_all.py --resume        # reuse finished stages (trained models, saved results)

Outputs: data/ (synthetic dataset), outputs/{tables,figures,models}, outputs/*.pkl
"""
import argparse
import json
import time

import numpy as np
import pandas as pd
import torch

from tb_gnn import config as C
from tb_gnn import experiments as X


def log(msg, t0=[time.time()]):
    print("[%6.0fs] %s" % (time.time() - t0[0], msg), flush=True)


def write_table(df, name, floatfmt=".2f"):
    C.TAB_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(C.TAB_DIR / (name + ".csv"), index=False)
    with open(C.TAB_DIR / (name + ".md"), "w") as f:
        f.write(df.to_markdown(index=False, floatfmt=floatfmt))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--regen", action="store_true", help="regenerate the synthetic dataset")
    ap.add_argument("--skip-sensitivity", action="store_true")
    ap.add_argument("--plots-only", action="store_true")
    ap.add_argument("--resume", action="store_true", help="skip stages whose results are already saved")
    args = ap.parse_args()
    # The models are tiny: intra-op threading only adds overhead (88 s vs 2.5 s per rollout).
    torch.set_num_threads(1)
    done = lambda name: args.resume and (C.OUT_DIR / name).exists()

    if not args.plots_only:
        if args.regen or not (C.DATA_DIR / "tb_patient_records.csv").exists():
            from tb_gnn.datagen import generate
            log("generating synthetic data")
            generate()

        from tb_gnn.panel import load_observed
        panel = load_observed()

        if done("eval_runs.pkl"):
            eval_res = X.load("eval_runs.pkl")
        else:
            log("training evaluation models (%d variants x %d seeds)" % (len(X.VARIANTS), C.N_SEEDS))
            eval_res = X.run_parallel([dict(variant=v, seed=s, mode="eval") for v in X.VARIANTS
                                       for s in range(C.N_SEEDS)])
            X.save(eval_res, "eval_runs.pkl")
            for r in eval_res:
                log("  %-12s seed %d  best epoch %3d  val %.4f  params %d  %.0fs" % (
                    r["variant"], r["seed"], r["best_epoch"], r["best_val"], r["n_params"], r["seconds"]))

        if done("benchmark.pkl"):
            bench = X.load("benchmark.pkl")
        else:
            log("forecast benchmark on 2023-2024")
            bench = X.forecast_benchmark(panel, eval_res)
            X.save(bench, "benchmark.pkl")

        if not done("final_runs.pkl"):
            log("retraining final models on 2015-2024")
            epochs = {(r["variant"], r["seed"]): r["best_epoch"] for r in eval_res}
            final_res = X.run_parallel([dict(variant=v, seed=s, mode="final", epochs=epochs[(v, s)])
                                        for v in X.VARIANTS for s in range(C.N_SEEDS)])
            X.save([{k: r[k] for k in ("variant", "seed", "best_epoch", "seconds", "n_params")} for r in final_res],
                   "final_runs.pkl")

        if not done("scenarios.pkl"):
            log("scenario simulations 2025-2029")
            X.save(X.scenario_study(panel, bench["dispersion"]), "scenarios.pkl")

        if not done("interpretation.pkl"):
            log("interpretation (spatial influence)")
            X.save(X.interpretation(panel, eval_res), "interpretation.pkl")

        if not done("size_control.pkl"):
            log("control: no-graph GRU with hidden size 16")
            X.save(X.size_control(panel), "size_control.pkl")

        if not args.skip_sensitivity and not done("sensitivity.pkl"):
            log("coupling sensitivity study")
            X.save(X.sensitivity_study(), "sensitivity.pkl")

    log("tables and figures")
    make_tables()
    from tb_gnn import plotting
    plotting.make_all()
    log("done")


def make_tables():
    from tb_gnn.eda import describe
    d = describe()
    write_table(d["national"].reset_index(), "descriptive_national_by_year")
    write_table(d["incidence"].reset_index(), "incidence_per_100k_by_region", ".1f")
    write_table(d["occupation"].reset_index(), "occupation")
    write_table(d["risk"].reset_index().rename(columns={"index": "level"}), "outcome_by_risk_factor")

    bench = X.load("benchmark.pkl")
    write_table(pd.DataFrame(bench["rows"]), "forecast_metrics")
    write_table(pd.DataFrame([dict(comparison=k, diff_MAE=v[0], ci_low=v[1], ci_high=v[2])
                              for k, v in bench["boot"].items()]), "forecast_bootstrap", ".3f")
    write_table(pd.DataFrame(bench["comp_rows"]), "composition_tvd", ".4f")
    write_table(pd.DataFrame(bench["annual"]).T.reset_index().rename(columns={"index": "year"}),
                "annual_forecast_mape")
    scen = X.load("scenarios.pkl")
    write_table(pd.DataFrame(X.scenario_metrics(scen)), "scenario_metrics")
    summary = {}
    for name, res in scen.items():
        for model, sim in res["sims"].items():
            ann = sim["counts"].reshape(sim["counts"].shape[0], 5, 12, C.N_REGIONS, 3).sum((2, 3))
            for k, tgt in enumerate(C.COUNT_TARGETS):
                q = np.quantile(ann[..., k], [0.05, 0.5, 0.95], 0)
                for y in range(5):
                    summary.setdefault((name, model, tgt), []).append(
                        "%d [%d-%d]" % (q[1, y], q[0, y], q[2, y]))
        truth = res["truth"].reshape(5, 12, C.N_REGIONS, 3).sum((1, 2))
        for k, tgt in enumerate(C.COUNT_TARGETS):
            summary[(name, "Truth (hidden)", tgt)] = ["%d" % v for v in truth[:, k]]
    write_table(pd.DataFrame([dict(scenario=k[0], model=k[1], target=k[2],
                                   **{str(2025 + i): v for i, v in enumerate(vals)}) for k, vals in summary.items()]),
                "scenario_national_annual")
    # long-horizon drift: per-seed error of the 2029 national total and mean |error| over 2025-2029
    sims = {name: {v: res["sims"][v]["counts"] for v in X.VARIANTS} for name, res in scen.items()}
    if (C.OUT_DIR / "size_control.pkl").exists():
        ctrl = X.load("size_control.pkl")
        for name in scen:
            sims[name]["GRU-nograph (hidden 16)"] = ctrl["scen"][name]
        write_table(pd.DataFrame(X.scenario_metrics({name: dict(
            truth=res["truth"], expected=res["expected"],
            sims={"GRU-nograph (hidden 16)": dict(counts=ctrl["scen"][name])}) for name, res in scen.items()})),
            "size_control_scenarios")
        write_table(pd.DataFrame([dict(target=k, **v) for k, v in ctrl["test"].items()]), "size_control_test")
    rows = []
    for name, by_model in sims.items():
        truth = scen[name]["truth"][..., 0].reshape(5, 12, C.N_REGIONS).sum((1, 2))
        for model, cnt in by_model.items():
            c = cnt[..., 0].reshape(C.N_SEEDS, -1, 5, 12, C.N_REGIONS).sum((3, 4))
            err = (np.median(c, 1) / truth - 1) * 100                 # [seed, year]
            ens = (np.median(c.reshape(-1, 5), 0) / truth - 1) * 100
            rows.append(dict(scenario=name, model=model,
                             err2029_by_seed=" ".join("%+.1f" % e for e in err[:, -1]),
                             seed_sd_2029=err[:, -1].std(), ensemble_err2029=ens[-1],
                             ensemble_mean_abs_err=np.abs(ens).mean()))
    write_table(pd.DataFrame(rows), "long_horizon_drift", ".1f")
    interp = X.load("interpretation.pkl")
    write_table(pd.DataFrame([dict(model=v, neighbour_share=interp[v]["neighbour_share"],
                                   spearman_true_contact=interp[v].get("spearman_contact", np.nan),
                                   spearman_input_graph=interp[v].get("spearman_od", np.nan),
                                   spearman_inverse_distance=interp[v].get("spearman_inv_distance", np.nan))
                              for v in ("STGNN", "STGNN-mob", "GRU-nograph")]), "interpretation", ".3f")
    if (C.OUT_DIR / "sensitivity.pkl").exists():
        sens = X.load("sensitivity.pkl")
        rows = []
        for r in sens:
            r = dict(r)
            if "boot" in r:
                r["MAE"], lo, hi = r.pop("boot")
                r["model"] = "STGNN - GRU (MAE diff) [%.3f, %.3f]" % (lo, hi)
            rows.append(r)
        write_table(pd.DataFrame(rows), "sensitivity_coupling", ".3f")
    runs = X.load("eval_runs.pkl")
    write_table(pd.DataFrame([{k: r[k] for k in ("variant", "seed", "best_epoch", "best_val", "n_params", "seconds")}
                              for r in runs]), "training_runs", ".3f")
    with open(C.OUT_DIR / "dispersion.json", "w") as f:
        json.dump({k: [float(x) for x in v] for k, v in bench["dispersion"].items()}, f, indent=1)


if __name__ == "__main__":
    main()

"""Classical forecasting baselines: seasonal naive and a per-region Poisson GLM."""
import numpy as np

from . import config as C

DISRUPT = C.COVARIATES.index("service_disruption")


def seasonal_naive(counts, origins, horizon=12):
    """y_hat(t0 + h) = y(t0 + h - 12)."""
    return np.stack([counts[t0 + 1 - 12:t0 + 1 - 12 + horizon] for t0 in origins])


def _design(t_idx, disruption):
    t_idx = np.asarray(t_idx)
    month = np.eye(12)[t_idx % 12][:, 1:]
    return np.column_stack([np.ones(len(t_idx)), t_idx / 120.0, month, np.log1p(-np.clip(disruption, 0, 0.95))])


def fit_poisson_glm(X, y, ridge=1e-2, iters=50):
    beta = np.zeros(X.shape[1])
    beta[0] = np.log(y.mean() + 0.1)
    pen = ridge * np.eye(X.shape[1])
    pen[0, 0] = 0.0
    for _ in range(iters):
        eta = np.clip(X @ beta, -10, 12)
        mu = np.exp(eta)
        z = eta + (y - mu) / mu
        new = np.linalg.solve(X.T @ (mu[:, None] * X) + pen, X.T @ (mu * z))
        if np.max(np.abs(new - beta)) < 1e-7:
            beta = new
            break
        beta = new
    mu = np.exp(np.clip(X @ beta, -10, 12))
    phi = max(1.0, np.sum((y - mu) ** 2 / mu) / max(len(y) - X.shape[1], 1))
    return beta, phi


def glm_forecast(counts, cov_hist, origins, horizon=12, cov_future=None):
    """Per region and target: log mu = trend + month-of-year + log(1 - service disruption),
    fitted on all months up to the origin. Returns means [O, H, N, 3] and dispersion [O, N, 3].
    `cov_future` (if given) supplies covariates beyond the observed series."""
    cov_all = cov_hist if cov_future is None else np.concatenate([cov_hist, cov_future])
    O, N, K = len(origins), counts.shape[1], counts.shape[2]
    mu = np.zeros((O, horizon, N, K))
    phi = np.ones((O, N, K))
    for o, t0 in enumerate(origins):
        t_fit = np.arange(0, t0 + 1)
        t_new = np.arange(t0 + 1, t0 + 1 + horizon)
        for i in range(N):
            X = _design(t_fit, cov_all[t_fit, i, DISRUPT])
            Xn = _design(t_new, cov_all[t_new, i, DISRUPT])
            for k in range(K):
                beta, ph = fit_poisson_glm(X, counts[t_fit, i, k])
                mu[o, :, i, k] = np.exp(np.clip(Xn @ beta, -10, 12))
                phi[o, i, k] = ph
    return mu, phi

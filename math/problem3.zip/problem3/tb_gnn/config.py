"""Global constants, paths and default hyper-parameters."""
import os
from dataclasses import dataclass
from pathlib import Path

QUICK = os.environ.get("TB_QUICK") == "1"       # smoke-test mode: tiny training, separate outputs

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
TRUTH_DIR = DATA_DIR / "hidden_truth"      # generator ground truth, used ONLY for evaluation
SCEN_DIR = DATA_DIR / "scenarios"
OUT_DIR = ROOT / ("outputs_quick" if QUICK else "outputs")
FIG_DIR = OUT_DIR / "figures"
TAB_DIR = OUT_DIR / "tables"
MODEL_DIR = OUT_DIR / "models"

SEED = 20250101

START_YEAR = 2015
OBS_YEARS = 10
FUTURE_YEARS = 5
N_OBS = 12 * OBS_YEARS          # observed months: 2015-01 .. 2024-12
N_FUTURE = 12 * FUTURE_YEARS    # simulated months: 2025-01 .. 2029-12
N_REGIONS = 20

SCENARIOS = ("baseline", "enhanced_control", "disruption")
COUNT_TARGETS = ("cases", "mdr", "deaths")
STRATA = ("M 0-14", "M 15-44", "M 45-64", "M 65+", "F 0-14", "F 15-44", "F 45-64", "F 65+")
COVARIATES = ("health_index", "hiv_prevalence", "mobility_index", "service_disruption",
              "net_migration_rate", "log_population")
STATIC = ("urbanization", "gdp_index", "aging_index", "x_km", "y_km")

# Chronological split, expressed as the month index of the last target month (0 = 2015-01).
TRAIN_END = 83    # 2021-12
VAL_END = 95      # 2022-12
TEST_END = 119    # 2024-12


@dataclass
class ModelConfig:
    window: int = 24            # months of history fed to the encoder
    horizon: int = 12           # months predicted per forward pass
    hidden: int = 32
    diffusion_k: int = 2        # hops of diffusion graph convolution
    emb_dim: int = 8            # node embedding size for the adaptive adjacency
    dropout: float = 0.3
    lr: float = 3e-3
    weight_decay: float = 1e-3
    batch_size: int = 8
    max_epochs: int = 3 if QUICK else 400
    patience: int = 40
    use_mobility: bool = True   # diffusion over the observed mobility graph
    use_adaptive: bool = True   # diffusion over a learned adjacency
    comp_weight: float = 1.0    # weight of the age-sex composition loss


# hidden sizes chosen per variant on the validation year (2022); see report section 3.4
MODEL_VARIANTS = {
    "STGNN": ModelConfig(hidden=16),
    "STGNN-mob": ModelConfig(use_adaptive=False),
    "GRU-nograph": ModelConfig(use_mobility=False, use_adaptive=False),
}
N_SEEDS = 2 if QUICK else 5
SENSITIVITY_SCALES = (3.0,) if QUICK else (3.0, 6.0)    # inter-regional mobility multipliers for the coupling study

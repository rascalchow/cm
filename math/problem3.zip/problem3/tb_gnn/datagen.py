"""Generate the synthetic dataset (observed 2015-2024) plus hidden future ground truth."""
import copy

import numpy as np
import pandas as pd

from . import config as C
from . import synth
from .panel import aggregate


def _covariate_table(world, drv, pop, net_mig, t0, t1, rng=None):
    """Long table of region covariates for months t0..t1-1; optional measurement noise."""
    T = t1 - t0
    sl = slice(t0, t1)
    H = drv["health_index"][sl].copy()
    hiv = drv["hiv_prevalence"][sl].copy()
    mob = drv["mobility_index"][sl].copy()
    if rng is not None:
        H += rng.normal(0, 0.005, H.shape)
        hiv *= np.exp(rng.normal(0, 0.03, hiv.shape))
        mob *= np.exp(rng.normal(0, 0.02, mob.shape))
    t = np.repeat(np.arange(t0, t1), C.N_REGIONS)
    return pd.DataFrame(dict(
        region_code=np.tile(world.codes, T), year=C.START_YEAR + t // 12, month=t % 12 + 1,
        population=np.round(pop.ravel()).astype(int), health_index=H.ravel().round(4),
        hiv_prevalence=hiv.ravel().round(6), mobility_index=mob.ravel().round(4),
        service_disruption=drv["service_disruption"][sl].ravel().round(4),
        net_migration_rate=net_mig.ravel().round(5)))


def _censor(records, cutoff):
    rec = records.copy()
    open_ = rec["outcome_date"] > cutoff
    rec.loc[open_, "outcome"] = "Still on treatment"
    rec.loc[open_, "outcome_date"] = pd.NaT
    rec["treatment_days"] = rec["treatment_days"].astype("Int64")
    rec.loc[open_, "treatment_days"] = np.nan
    return rec


def generate(data_dir=C.DATA_DIR, verbose=True, mobility_scale=1.0):
    data_dir.mkdir(parents=True, exist_ok=True)
    (data_dir / "scenarios").mkdir(exist_ok=True)
    truth_dir = data_dir / "hidden_truth"
    truth_dir.mkdir(exist_ok=True)
    ss = np.random.SeedSequence(C.SEED)
    s_world, s_proc, s_obs, s_rec, s_cov, s_fproc, s_fobs, s_frec = ss.spawn(8)

    world = synth.build_world(np.random.default_rng(s_world), mobility_scale)
    state = synth.burn_in(world)
    T_all = C.N_OBS + C.N_FUTURE
    z = synth.ar1_noise(np.random.default_rng(s_proc), C.N_OBS, C.N_REGIONS)
    z_future = synth.ar1_noise(np.random.default_rng(s_fproc), C.N_FUTURE + 1, C.N_REGIONS)[1:]
    # continue the AR(1) process smoothly from the last observed month
    z_future = z_future + z[-1] * 0.85 ** np.arange(1, C.N_FUTURE + 1)[:, None]
    z_all = np.concatenate([z, z_future])

    drv_base = synth.make_drivers(world, "baseline")
    obs = synth.run_period(state, world, drv_base, 0, C.N_OBS, z_all)
    split_obs = synth.notify(np.random.default_rng(s_obs), obs["notif"])

    # ---- future: one continuation per scenario (common random numbers) --------------
    futures = {}
    for name in C.SCENARIOS:
        drv = synth.make_drivers(world, name)
        st = copy.deepcopy(state)
        fut = synth.run_period(st, world, drv, C.N_OBS, T_all, z_all)
        futures[name] = (drv, fut, synth.notify(np.random.default_rng(s_fobs), fut["notif"]))

    pop_obs, mig_obs = obs["pop"], obs["net_mig"]
    rng_rec = np.random.default_rng(s_rec)
    stock_obs = synth.migrant_stock(np.concatenate([mig_obs, futures["baseline"][1]["net_mig"]]),
                                    np.concatenate([pop_obs, futures["baseline"][1]["pop"]]))
    rec_obs = synth.expand_records(rng_rec, split_obs, 0, world, drv_base, stock_obs)

    # ---- observed dataset ----------------------------------------------------------------
    cutoff = pd.Timestamp("%d-12-31" % (C.START_YEAR + C.OBS_YEARS - 1))
    rec_pub = _censor(rec_obs, cutoff).sort_values(["diagnosis_date", "region_code"]).reset_index(drop=True)
    rec_pub.insert(0, "record_id", ["TB%07d" % (i + 1) for i in range(len(rec_pub))])
    rec_pub["diagnosis_date"] = rec_pub["diagnosis_date"].dt.strftime("%Y-%m-%d")
    rec_pub["outcome_date"] = pd.to_datetime(rec_pub["outcome_date"]).dt.strftime("%Y-%m-%d")
    rec_pub.to_csv(data_dir / "tb_patient_records.csv", index=False)

    pd.DataFrame(dict(
        region_code=world.codes, region_name=world.names, x_km=world.xy[:, 0].round(1),
        y_km=world.xy[:, 1].round(1), population_2015=np.round(pop_obs[0]).astype(int),
        urbanization=world.urb.round(3), gdp_index=world.gdp.round(3), aging_index=world.aging.round(3),
        is_metropolitan=world.metro.astype(int),
    )).to_csv(data_dir / "regions.csv", index=False)

    rng_cov = np.random.default_rng(s_cov)
    _covariate_table(world, drv_base, pop_obs, mig_obs, 0, C.N_OBS, rng_cov).to_csv(
        data_dir / "region_covariates_monthly.csv", index=False)

    od = 0.6 * world.eps[:, None] * pop_obs.mean(0)[:, None] * world.W * 1.1
    od *= np.exp(rng_cov.normal(0, 0.15, od.shape))
    i, j = np.nonzero(od > 0)
    pd.DataFrame(dict(origin=np.array(world.codes)[i], destination=np.array(world.codes)[j],
                      avg_daily_trips=np.round(od[i, j]).astype(int))).to_csv(data_dir / "mobility_od.csv", index=False)

    # ---- scenario covariates (model input) and hidden truth (evaluation only) ------------
    for name, (drv, fut, split) in futures.items():
        _covariate_table(world, drv, fut["pop"], fut["net_mig"], C.N_OBS, T_all).to_csv(
            data_dir / "scenarios" / ("%s_covariates_2025_2029.csv" % name), index=False)
        stock = synth.migrant_stock(np.concatenate([mig_obs, fut["net_mig"]]), np.concatenate([pop_obs, fut["pop"]]))
        rec_fut = synth.expand_records(np.random.default_rng(s_frec), split, C.N_OBS, world, drv, stock)
        agg = aggregate(pd.concat([rec_obs, rec_fut], ignore_index=True), world.codes, C.N_OBS, C.N_FUTURE)
        np.savez_compressed(truth_dir / ("truth_%s.npz" % name), **agg,
                            expected_notifications=fut["notif"].sum((1, 2)),
                            prevalence=fut["prev"], mdr_share_prevalent=fut["mdr_prev"])
        if verbose:
            print("  scenario %-17s cases 2025-29: %s" % (name, agg["cases"].reshape(5, 12, -1).sum((1, 2)).astype(int)))

    np.savez_compressed(truth_dir / "world.npz", W=world.W, eps=world.eps, beta_loc=world.beta_loc,
                        contact_base=synth._contact_matrix(world, 1.0), program=world.program,
                        boom=world.boom, origins=world.origins, mdr_seed=world.mdr_seed,
                        expected_notifications_obs=obs["notif"].sum((1, 2)),
                        prevalence_obs=obs["prev"], mdr_share_prevalent_obs=obs["mdr_prev"])
    if verbose:
        print("  records: %d  (%.1f per region-month)" % (len(rec_pub), len(rec_pub) / C.N_OBS / C.N_REGIONS))
    return world

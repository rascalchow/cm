"""Descriptive epidemiology of the synthetic patient records."""
import numpy as np
import pandas as pd

from . import config as C

SUCCESS = ("Cured", "Treatment completed")


def load_records(data_dir=C.DATA_DIR):
    rec = pd.read_csv(data_dir / "tb_patient_records.csv", parse_dates=["diagnosis_date", "outcome_date"])
    rec["year"] = rec["diagnosis_date"].dt.year
    return rec


def describe(data_dir=C.DATA_DIR):
    rec = load_records(data_dir)
    regions = pd.read_csv(data_dir / "regions.csv")
    cov = pd.read_csv(data_dir / "region_covariates_monthly.csv")
    pop = cov.groupby(["region_code", "year"])["population"].mean()

    cases = rec.groupby(["region_code", "year"]).size()
    inc = (cases / pop * 1e5).unstack("year").round(1)
    inc.insert(0, "region_name", regions.set_index("region_code")["region_name"])

    evaluated = rec[rec["outcome"] != "Still on treatment"]
    nat = pd.DataFrame({
        "cases": rec.groupby("year").size(),
        "incidence_per_100k": rec.groupby("year").size() / cov.groupby("year")["population"].sum() * 12 * 1e5,
        "male_pct": rec.groupby("year")["sex"].apply(lambda s: (s == "Male").mean() * 100),
        "mean_age": rec.groupby("year")["age"].mean(),
        "age65plus_pct": rec.groupby("year")["age"].apply(lambda s: (s >= 65).mean() * 100),
        "children_pct": rec.groupby("year")["age"].apply(lambda s: (s < 15).mean() * 100),
        "hiv_pos_pct_of_tested": rec[rec["hiv_status"] != "Unknown"].groupby("year")["hiv_status"].apply(
            lambda s: (s == "Positive").mean() * 100),
        "mdr_pct_of_dst": rec[rec["drug_resistance"] != "Not tested"].groupby("year")["drug_resistance"].apply(
            lambda s: (s == "RR/MDR-TB").mean() * 100),
        "previously_treated_pct": rec.groupby("year")["patient_type"].apply(lambda s: (s != "New").mean() * 100),
        "bact_confirmed_pct": rec.groupby("year")["diagnosis"].apply(
            lambda s: s.str.contains("bacteriologically").mean() * 100),
        "success_pct": evaluated.groupby("year")["outcome"].apply(lambda s: s.isin(SUCCESS).mean() * 100),
        "died_pct": evaluated.groupby("year")["outcome"].apply(lambda s: (s == "Died").mean() * 100),
        "ltfu_pct": evaluated.groupby("year")["outcome"].apply(lambda s: (s == "Lost to follow-up").mean() * 100),
        "still_on_treatment": rec.groupby("year")["outcome"].apply(lambda s: (s == "Still on treatment").sum()),
    }).round(2)

    occ = (rec["occupation"].value_counts(normalize=True) * 100).round(2).rename("pct").to_frame()
    occ["deaths_pct"] = (evaluated.groupby("occupation")["outcome"].apply(lambda s: (s == "Died").mean() * 100)).round(2)
    occ["ltfu_pct"] = (evaluated.groupby("occupation")["outcome"].apply(
        lambda s: (s == "Lost to follow-up").mean() * 100)).round(2)

    ev = evaluated[evaluated["year"] <= 2022].copy()
    ev["died"] = ev["outcome"] == "Died"
    ev["success"] = ev["outcome"].isin(SUCCESS)
    risk = pd.concat([
        ev.groupby("age_group")[["success", "died"]].mean().assign(factor="age group"),
        ev.groupby("sex")[["success", "died"]].mean().assign(factor="sex"),
        ev.groupby("hiv_status")[["success", "died"]].mean().assign(factor="HIV status"),
        ev.groupby("drug_resistance")[["success", "died"]].mean().assign(factor="drug resistance"),
        ev.groupby("patient_type")[["success", "died"]].mean().assign(factor="patient type"),
    ])
    risk[["success", "died"]] = (risk[["success", "died"]] * 100).round(2)
    risk["n"] = pd.concat([ev.groupby(c).size() for c in ["age_group", "sex", "hiv_status", "drug_resistance",
                                                            "patient_type"]]).to_numpy()

    pyramid = rec.groupby(["sex", pd.cut(rec["age"], range(0, 105, 5), right=False)], observed=False).size().unstack(0)
    outcomes_by_year = (rec.groupby("year")["outcome"].value_counts(normalize=True).unstack().fillna(0) * 100).round(2)
    schema = pd.DataFrame({"column": rec.columns.drop("year"),
                           "example": [str(rec.iloc[0][c]) for c in rec.columns.drop("year")]})
    return dict(records=rec, regions=regions, incidence=inc, national=nat, occupation=occ, risk=risk,
                pyramid=pyramid, outcomes_by_year=outcomes_by_year, schema=schema, n_records=len(rec))

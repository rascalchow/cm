"""Experiment orchestration: forecasting benchmark, scenario simulation, interpretation,
and the coupling-sensitivity study. Results go to outputs/ (json + npz) for plots/report."""
import multiprocessing as mp
import os
import pickle
from concurrent.futures import ProcessPoolExecutor

import numpy as np

from . import config as C
from .baselines import glm_forecast, seasonal_naive
from .features import FeatureBuilder, make_windows, split_origins, transition_matrix
from .interpret import offdiag, spatial_influence, spearman
from .metrics import composition_tvd, interval_metrics, nb_dispersion, point_metrics, sample_nb
from .panel import load_observed, load_scenario, load_truth
from .simulate import glm_projection, rollout
from .training import load_model, run_job

VARIANTS = tuple(C.MODEL_VARIANTS)


def run_parallel(jobs, workers=None):
    workers = workers or min(len(jobs), os.cpu_count() or 1)
    with ProcessPoolExecutor(workers, mp_context=mp.get_context("spawn")) as ex:
        return list(ex.map(run_job, jobs))


def _targets(panel, origins, horizon=12):
    y = np.stack([panel.counts[t + 1:t + 1 + horizon] for t in origins])
    yc = np.stack([panel.comp[t + 1:t + 1 + horizon] for t in origins])
    return y, yc


def _bootstrap_diff(err_a, err_b, n_boot=2000, seed=0):
    """95% CI of MAE(a) - MAE(b), resampling regions (last axis)."""
    rng = np.random.default_rng(seed)
    n = err_a.shape[-1]
    a = err_a.reshape(-1, n).mean(0)
    b = err_b.reshape(-1, n).mean(0)
    idx = rng.integers(0, n, (n_boot, n))
    d = a[idx].mean(1) - b[idx].mean(1)
    return float((a - b).mean()), float(np.quantile(d, 0.025)), float(np.quantile(d, 0.975))


def forecast_benchmark(panel, eval_res, n_samples_per_seed=40, data_dir=C.DATA_DIR):
    cfg = C.ModelConfig()
    orig = split_origins(cfg)
    te, va = orig["test"], orig["val"]
    y, yc = _targets(panel, te)
    y_val, _ = _targets(panel, va)
    rng = np.random.default_rng(0)

    preds = {}
    for v in VARIANTS:
        runs = [r for r in eval_res if r["variant"] == v]
        mus = np.stack([r["test_mu"] for r in runs])
        val_ens = np.stack([r["val_mu"] for r in runs]).mean(0)
        disp = [nb_dispersion(y_val[..., k], val_ens[..., k]) for k in range(3)]
        samples = np.concatenate([np.stack([sample_nb(rng, m[..., k], disp[k], n_samples_per_seed)
                                            for k in range(3)], -1) for m in mus])
        preds[v] = dict(mu=mus.mean(0), seeds=mus, samples=samples, dispersion=disp,
                        comp=np.stack([r["test_comp"] for r in runs]).mean(0))
    glm_mu = np.zeros_like(y, dtype=float)
    glm_samples = []
    mu, phi = glm_forecast(panel.counts, panel.cov, te)
    glm_mu[:] = mu
    phi = phi[:, None]
    k = np.where(phi > 1.0001, mu / np.maximum(phi - 1, 1e-6), 1e9)
    glm_samples = rng.poisson(rng.gamma(k, mu / k, size=(200,) + mu.shape))
    preds["GLM"] = dict(mu=glm_mu, samples=glm_samples)
    preds["SeasonalNaive"] = dict(mu=seasonal_naive(panel.counts, te).astype(float))
    world = np.load(data_dir / "hidden_truth" / "world.npz")
    oracle = np.stack([world["expected_notifications_obs"][t + 1:t + 13] for t in te])

    rows = []
    for name, p in preds.items():
        for k, tgt in enumerate(C.COUNT_TARGETS):
            row = dict(model=name, target=tgt, **point_metrics(y[..., k], p["mu"][..., k]))
            if "samples" in p:
                row.update(interval_metrics(y[..., k], p["samples"][..., k]))
            if "seeds" in p:
                maes = [np.abs(s[..., k] - y[..., k]).mean() for s in p["seeds"]]
                row["MAE_seed_mean"], row["MAE_seed_sd"] = float(np.mean(maes)), float(np.std(maes))
            rows.append(row)
    rows.append(dict(model="Oracle (true mean)", target="cases", **point_metrics(y[..., 0], oracle)))

    abs_err = {name: np.abs(p["mu"][..., 0] - y[..., 0]) for name, p in preds.items()}
    abs_err["Oracle"] = np.abs(oracle - y[..., 0])
    by_h = {name: e.mean((0, 2)) for name, e in abs_err.items()}
    by_region = {name: e.mean((0, 1)) for name, e in abs_err.items()}
    boot = {}
    for a, b in [("STGNN", "GLM"), ("STGNN", "GRU-nograph"), ("STGNN-mob", "GRU-nograph"),
                 ("GRU-nograph", "GLM"), ("STGNN", "SeasonalNaive")]:
        for k, tgt in enumerate(C.COUNT_TARGETS):
            ea = np.abs(preds[a]["mu"][..., k] - y[..., k])
            eb = np.abs(preds[b]["mu"][..., k] - y[..., k])
            boot["%s - %s | %s" % (a, b, tgt)] = _bootstrap_diff(ea, eb)

    anchor = np.stack([panel.comp[t - 11:t + 1].sum(0) for t in te])
    anchor = anchor / anchor.sum(-1, keepdims=True)
    comp_rows = [dict(model=v, TVD=composition_tvd(yc, preds[v]["comp"], y[..., 0])) for v in VARIANTS]
    comp_rows.append(dict(model="Last-12-month mix", TVD=composition_tvd(
        yc, np.repeat(anchor[:, None], 12, 1), y[..., 0])))

    # calendar-year forecasts: 2023 from origin 2022-12, 2024 from origin 2023-12
    annual = {}
    for year, t0 in [(2023, 95), (2024, 107)]:
        o = te.index(t0)
        truth = y[o, :, :, 0].sum(0)
        annual[year] = {name: float(np.mean(np.abs(p["mu"][o, :, :, 0].sum(0) - truth) / truth) * 100)
                        for name, p in preds.items()}
        annual[year]["Oracle"] = float(np.mean(np.abs(oracle[o].sum(0) - truth) / truth) * 100)
    return dict(rows=rows, by_h=by_h, by_region=by_region, boot=boot, comp_rows=comp_rows, annual=annual,
                y=y, preds={k: dict(mu=v["mu"], q05=np.quantile(v["samples"], 0.05, 0) if "samples" in v else None,
                                    q95=np.quantile(v["samples"], 0.95, 0) if "samples" in v else None)
                            for k, v in preds.items()},
                oracle=oracle, origins=te, dispersion={v: preds[v]["dispersion"] for v in VARIANTS})


def scenario_study(panel, dispersion, variants=VARIANTS, n_samples=40, data_dir=C.DATA_DIR):
    cfg_fb = FeatureBuilder(panel, C.TEST_END)
    out = {}
    for scen in C.SCENARIOS:
        cov_f = load_scenario(scen, panel.codes, data_dir)
        truth = load_truth(scen, data_dir / "hidden_truth")
        expected = np.load(data_dir / "hidden_truth" / ("truth_%s.npz" % scen))["expected_notifications"]
        res = dict(truth=truth["counts"], truth_comp=truth["comp"], expected=expected, sims={})
        for v in variants:
            cnt, cmp_ = [], []
            for s in range(C.N_SEEDS):
                model = load_model(v, s, "final", panel, cfg_fb)
                c, p = rollout(model, cfg_fb, panel, cov_f, C.MODEL_VARIANTS[v], dispersion[v],
                               n_samples=n_samples, seed=1000 * s + 7)
                cnt.append(c)
                cmp_.append(p)
            res["sims"][v] = dict(counts=np.concatenate(cnt), comp=np.concatenate(cmp_))
        g_samples, g_mu = glm_projection(panel, cov_f)
        res["sims"]["GLM"] = dict(counts=g_samples)
        out[scen] = res
    return out


def scenario_metrics(scen_res):
    """Annual totals 2025-2029: national APE of the median, regional MAPE, 90% PI coverage."""
    rows = []
    for scen, res in scen_res.items():
        truth = res["truth"].reshape(5, 12, C.N_REGIONS, 3).sum(1)            # [5, N, 3]
        expected = res["expected"].reshape(5, 12, C.N_REGIONS).sum(1)          # [5, N]
        for name, sim in res["sims"].items():
            ann = sim["counts"].reshape(sim["counts"].shape[0], 5, 12, C.N_REGIONS, 3).sum(2)   # [S, 5, N, 3]
            for k, tgt in enumerate(C.COUNT_TARGETS):
                med = np.median(ann[..., k], 0)
                lo, hi = np.quantile(ann[..., k], [0.05, 0.95], 0)
                nat = ann[..., k].sum(-1)
                nat_med = np.median(nat, 0)
                nat_true = truth[..., k].sum(-1)
                nlo, nhi = np.quantile(nat, [0.05, 0.95], 0)
                row = dict(scenario=scen, model=name, target=tgt,
                           national_MAPE=float(np.mean(np.abs(nat_med - nat_true) / nat_true) * 100),
                           national_cov90=float(np.mean((nat_true >= nlo) & (nat_true <= nhi)) * 100),
                           regional_MAPE=float(np.mean(np.abs(med - truth[..., k]) / np.maximum(truth[..., k], 1)) * 100),
                           regional_cov90=float(np.mean((truth[..., k] >= lo) & (truth[..., k] <= hi)) * 100),
                           national_2029_pred=float(nat_med[-1]), national_2029_true=float(nat_true[-1]))
                if k == 0:
                    row["regional_MAPE_vs_expected"] = float(np.mean(np.abs(med - expected) / expected) * 100)
                rows.append(row)
    return rows


def interpretation(panel, eval_res, data_dir=C.DATA_DIR):
    fb = FeatureBuilder(panel, C.TRAIN_END)
    cfg = C.ModelConfig()
    te = make_windows(fb, panel, split_origins(cfg)["test"], cfg)
    world = np.load(data_dir / "hidden_truth" / "world.npz")
    contact = world["contact_base"]
    od_T = transition_matrix(panel.od)
    out = {}
    for v in ("STGNN", "STGNN-mob", "GRU-nograph"):
        S = np.mean([spatial_influence(load_model(v, s, "eval", panel, fb), te) for s in range(C.N_SEEDS)], 0)
        nb_share = offdiag(S).reshape(C.N_REGIONS, -1).sum(1) / S.sum(1)
        entry = dict(S=S, neighbour_share=float(nb_share.mean()))
        if v != "GRU-nograph":
            entry["spearman_contact"] = spearman(offdiag(S), offdiag(contact))
            entry["spearman_od"] = spearman(offdiag(S), offdiag(od_T))
            entry["spearman_inv_distance"] = spearman(offdiag(S), -offdiag(
                np.sqrt(((panel.static[:, None, 3:5] - panel.static[None, :, 3:5]) ** 2).sum(-1))))
        out[v] = entry
    adj = [r["adaptive_adj"] for r in eval_res if r["variant"] == "STGNN"]
    out["adaptive_adj"] = np.mean(adj, 0)
    out["spearman_adaptive_contact"] = spearman(offdiag(out["adaptive_adj"]), offdiag(contact))
    out["contact"] = contact
    out["od_T"] = od_T
    return out


def sensitivity_study(scales=C.SENSITIVITY_SCALES, variants=("STGNN", "GRU-nograph")):
    from .datagen import generate
    from .metrics import point_metrics as pm
    rows = []
    for sc in scales:
        d = C.DATA_DIR / "sensitivity" / ("mobility_x%g" % sc)
        if not (d / "tb_patient_records.csv").exists():
            generate(d, verbose=False, mobility_scale=sc)
        jobs = [dict(variant=v, seed=s, mode="eval", data_dir=d, save=False) for v in variants for s in range(C.N_SEEDS)]
        res = run_parallel(jobs)
        panel = load_observed(d)
        te = split_origins(C.ModelConfig())["test"]
        y, _ = _targets(panel, te)
        world = np.load(d / "hidden_truth" / "world.npz")
        oracle = np.stack([world["expected_notifications_obs"][t + 1:t + 13] for t in te])
        glm, _ = glm_forecast(panel.counts, panel.cov, te)
        cand = {v: np.stack([r["test_mu"] for r in res if r["variant"] == v]).mean(0) for v in variants}
        cand["GLM"] = glm
        for name, mu in cand.items():
            rows.append(dict(scale=sc, model=name, **pm(y[..., 0], mu[..., 0])))
        rows.append(dict(scale=sc, model="Oracle (true mean)", **pm(y[..., 0], oracle)))
        ea = np.abs(cand["STGNN"][..., 0] - y[..., 0])
        eb = np.abs(cand["GRU-nograph"][..., 0] - y[..., 0])
        rows.append(dict(scale=sc, model="diff STGNN - GRU (95% CI)", boot=_bootstrap_diff(ea, eb)))
    return rows


def size_control(panel, n_samples=40):
    """Is the long-horizon advantage of the STGNN due to the graph or to its smaller hidden
    size? Re-run the no-graph GRU with the STGNN's hidden size (16): test forecasts and
    five-year simulations."""
    import dataclasses
    over, tag = dict(hidden=16), "-h16"
    ev = run_parallel([dict(variant="GRU-nograph", seed=s, mode="eval", overrides=over, tag=tag)
                       for s in range(C.N_SEEDS)])
    run_parallel([dict(variant="GRU-nograph", seed=r["seed"], mode="final", epochs=r["best_epoch"],
                       overrides=over, tag=tag) for r in ev])
    cfg = C.ModelConfig()
    orig = split_origins(cfg)
    y, _ = _targets(panel, orig["test"])
    y_val, _ = _targets(panel, orig["val"])
    mu = np.stack([r["test_mu"] for r in ev]).mean(0)
    val = np.stack([r["val_mu"] for r in ev]).mean(0)
    disp = [nb_dispersion(y_val[..., k], val[..., k]) for k in range(3)]
    out = dict(test={tgt: point_metrics(y[..., k], mu[..., k]) for k, tgt in enumerate(C.COUNT_TARGETS)},
               best_epochs=[r["best_epoch"] for r in ev], n_params=ev[0]["n_params"], scen={})
    fb = FeatureBuilder(panel, C.TEST_END)
    mcfg = dataclasses.replace(C.MODEL_VARIANTS["GRU-nograph"], **over)
    for scen in C.SCENARIOS:
        cov_f = load_scenario(scen, panel.codes)
        cnt = [rollout(load_model("GRU-nograph", s, "final", panel, fb, over, tag), fb, panel, cov_f, mcfg, disp,
                       n_samples=n_samples, seed=1000 * s + 7)[0] for s in range(C.N_SEEDS)]
        out["scen"][scen] = np.concatenate(cnt)
    return out


def save(obj, name):
    C.OUT_DIR.mkdir(parents=True, exist_ok=True)
    with open(C.OUT_DIR / name, "wb") as f:
        pickle.dump(obj, f)


def load(name):
    with open(C.OUT_DIR / name, "rb") as f:
        return pickle.load(f)

"""Feature engineering and forecasting windows for the spatio-temporal models."""
import numpy as np
import torch

from . import config as C

LOG_HIV = C.COVARIATES.index("hiv_prevalence")


def transition_matrix(adj):
    adj = np.asarray(adj, float).copy()
    np.fill_diagonal(adj, 0.0)
    return adj / np.maximum(adj.sum(1, keepdims=True), 1e-12)


class FeatureBuilder:
    """Standardises inputs with statistics from the training period only."""

    def __init__(self, panel, fit_end):
        sl = slice(0, fit_end + 1)
        logc = np.log1p(panel.counts[sl])
        self.c_mu, self.c_sd = logc.mean((0, 1)), logc.std((0, 1)) + 1e-6
        shares = self.shares(panel.comp[sl])
        self.s_mu, self.s_sd = shares.mean((0, 1)), shares.std((0, 1)) + 1e-6
        cov = self._cov_raw(panel.cov[sl])
        self.v_mu, self.v_sd = cov.mean((0, 1)), cov.std((0, 1)) + 1e-6
        self.static = (panel.static - panel.static.mean(0)) / (panel.static.std(0) + 1e-6)
        self.n_enc = len(C.COUNT_TARGETS) + len(C.STRATA) + len(C.COVARIATES) + 2 + self.static.shape[1]
        self.n_dec = len(C.COVARIATES) + 2 + self.static.shape[1] + 1

    @staticmethod
    def shares(comp):
        tot = comp.sum(-1, keepdims=True)
        return np.where(tot > 0, comp / np.maximum(tot, 1e-9), 1.0 / comp.shape[-1])

    @staticmethod
    def _cov_raw(cov):
        cov = cov.copy()
        cov[..., LOG_HIV] = np.log(cov[..., LOG_HIV])
        return cov

    def _calendar(self, t_idx, n):
        ang = 2 * np.pi * (np.asarray(t_idx) % 12) / 12
        cal = np.stack([np.sin(ang), np.cos(ang)], -1)
        return np.repeat(cal[:, None, :], n, 1)

    def encoder(self, counts, comp, cov, t_idx):
        """counts [..., T, N, 3], comp [..., T, N, 8], cov [T, N, 6] -> [..., T, N, F_enc]."""
        T, n = cov.shape[0], cov.shape[1]
        lead = counts.shape[:-3]
        parts = [(np.log1p(counts) - self.c_mu) / self.c_sd, (self.shares(comp) - self.s_mu) / self.s_sd]
        exo = np.concatenate([(self._cov_raw(cov) - self.v_mu) / self.v_sd, self._calendar(t_idx, n),
                              np.repeat(self.static[None], T, 0)], -1)
        parts.append(np.broadcast_to(exo, lead + exo.shape))
        return np.concatenate(parts, -1).astype(np.float32)

    def decoder(self, cov, t_idx):
        T, n = cov.shape[0], cov.shape[1]
        step = np.repeat((np.arange(1, T + 1) / T)[:, None, None], n, 1)
        return np.concatenate([(self._cov_raw(cov) - self.v_mu) / self.v_sd, self._calendar(t_idx, n),
                               np.repeat(self.static[None], T, 0), step], -1).astype(np.float32)


def anchors(counts, comp):
    """Log-level of the last 12 months: offsets for the count and composition heads."""
    a = np.log(counts[..., -12:, :, :].mean(-3) + 0.05)
    c = comp[..., -12:, :, :].sum(-3) + 0.5
    return a.astype(np.float32), np.log(c / c.sum(-1, keepdims=True)).astype(np.float32)


def make_windows(fb, panel, origins, cfg):
    """Stack training/evaluation samples for the given forecast origins (last observed month)."""
    W, H = cfg.window, cfg.horizon
    enc, dec, a_cnt, a_cmp, y_cnt, y_cmp = [], [], [], [], [], []
    for t0 in origins:
        hist = slice(t0 - W + 1, t0 + 1)
        fut = slice(t0 + 1, t0 + H + 1)
        enc.append(fb.encoder(panel.counts[hist], panel.comp[hist], panel.cov[hist], np.arange(t0 - W + 1, t0 + 1)))
        dec.append(fb.decoder(panel.cov[fut], np.arange(t0 + 1, t0 + H + 1)))
        a, c = anchors(panel.counts[hist], panel.comp[hist])
        a_cnt.append(a)
        a_cmp.append(c)
        y_cnt.append(panel.counts[fut])
        y_cmp.append(panel.comp[fut])
    f = lambda xs: torch.tensor(np.stack(xs), dtype=torch.float32)
    return dict(enc=f(enc), dec=f(dec), a_cnt=f(a_cnt), a_cmp=f(a_cmp), y_cnt=f(y_cnt), y_cmp=f(y_cmp),
                origins=np.asarray(origins))


def split_origins(cfg):
    """Forecast origins whose 12-month targets end inside each period."""
    first = cfg.window - 1
    train = list(range(first, C.TRAIN_END - cfg.horizon + 1))
    val = list(range(C.TRAIN_END - cfg.horizon + 1, C.VAL_END - cfg.horizon + 1))
    test = list(range(C.VAL_END, C.TEST_END - cfg.horizon + 1))      # inputs end >= 2022-12
    full = list(range(first, C.TEST_END - cfg.horizon + 1))
    return dict(train=train, val=val, test=test, full=full)

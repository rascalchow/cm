"""What spatial structure did the GNN learn? Gradient-based influence between regions."""
import numpy as np
import torch


def spatial_influence(model, w, feature=0, target=0):
    """S[i, j] = E | d sum_h log-rate_i(h) / d x_j(t) | summed over the input window, where
    x_j is input feature `feature` (0 = log cases) of region j. Averaged over windows."""
    enc = w["enc"].clone().requires_grad_(True)
    lr, _ = model(enc, w["dec"], w["a_cnt"], w["a_cmp"])
    n = enc.shape[2]
    S = np.zeros((n, n))
    for i in range(n):
        g, = torch.autograd.grad(lr[:, :, i, target].sum(), enc, retain_graph=True)
        S[i] = g[..., feature].abs().sum(1).mean(0).numpy()
    return S


def offdiag(a):
    return a[~np.eye(a.shape[0], dtype=bool)]


def spearman(a, b):
    ra = np.argsort(np.argsort(a))
    rb = np.argsort(np.argsort(b))
    return float(np.corrcoef(ra, rb)[0, 1])

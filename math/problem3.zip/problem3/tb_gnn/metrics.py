"""Point and probabilistic forecast metrics."""
import numpy as np


def point_metrics(y, yhat):
    e = yhat - y
    out = dict(MAE=np.abs(e).mean(), RMSE=np.sqrt((e ** 2).mean()), WAPE=np.abs(e).sum() / y.sum() * 100)
    pos = y > 0
    out["MAPE"] = np.abs(e[pos] / y[pos]).mean() * 100
    return out


def nb_dispersion(y, mu):
    """Method-of-moments NB size k from var(y - mu) = mu + mu^2 / k (inf if no overdispersion)."""
    excess = ((y - mu) ** 2 - mu).sum()
    return np.inf if excess <= 0 else (mu ** 2).sum() / excess


def sample_nb(rng, mu, k, n_samples):
    mu = np.broadcast_to(mu, (n_samples,) + np.shape(mu))
    if np.isinf(k):
        return rng.poisson(mu)
    return rng.poisson(rng.gamma(k, mu / k))


def interval_metrics(y, samples, levels=(0.5, 0.9)):
    """Empirical coverage and mean interval score for central prediction intervals."""
    out = {}
    for lv in levels:
        a = 1 - lv
        lo, hi = np.quantile(samples, [a / 2, 1 - a / 2], axis=0)
        out["cov%d" % int(lv * 100)] = ((y >= lo) & (y <= hi)).mean() * 100
        score = (hi - lo) + 2 / a * (lo - y) * (y < lo) + 2 / a * (y - hi) * (y > hi)
        out["IS%d" % int(lv * 100)] = score.mean()
    return out


def composition_tvd(comp_true, comp_prob, cases_true):
    """Total-variation distance between predicted and observed 12-month age-sex mix,
    averaged over windows and regions (lower is better)."""
    obs = comp_true.sum(1)
    obs = obs / np.maximum(obs.sum(-1, keepdims=True), 1)
    pred = (comp_prob * cases_true[..., None]).sum(1)
    pred = pred / np.maximum(pred.sum(-1, keepdims=True), 1e-9)
    return 0.5 * np.abs(obs - pred).sum(-1).mean()

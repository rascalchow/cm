"""Spatio-temporal graph neural network (diffusion-convolutional GRU encoder-decoder)."""
import torch
import torch.nn as nn
import torch.nn.functional as F

from . import config as C


class DiffusionGraphConv(nn.Module):
    """X W_self + (sum_{s,k} alpha_{s,k} A_s^k X) W_nb.

    K-hop diffusion over every support matrix, mixed by learned softmax weights alpha and
    projected by a single neighbour matrix: twice the parameters of a linear layer instead
    of (1 + S K) times as in DCRNN, which matters with ~50 training windows. With no
    supports it reduces to a node-wise linear layer shared by all regions."""

    def __init__(self, in_dim, out_dim, n_supports, k):
        super().__init__()
        self.k = k
        self.n_terms = n_supports * k
        self.self_lin = nn.Linear(in_dim, out_dim)
        if self.n_terms:
            self.nb_lin = nn.Linear(in_dim, out_dim, bias=False)
            self.mix = nn.Parameter(torch.zeros(self.n_terms))

    def forward(self, x, supports):          # x [B, N, F]
        out = self.self_lin(x)
        if not self.n_terms:
            return out
        alpha = torch.softmax(self.mix, 0)
        nb, j = 0.0, 0
        for a in supports:
            h = x
            for _ in range(self.k):
                h = torch.einsum("nm,bmf->bnf", a, h)
                nb = nb + alpha[j] * h
                j += 1
        return out + self.nb_lin(nb)


class GConvGRUCell(nn.Module):
    def __init__(self, in_dim, hidden, n_supports, k):
        super().__init__()
        self.gates = DiffusionGraphConv(in_dim + hidden, 2 * hidden, n_supports, k)
        self.cand = DiffusionGraphConv(in_dim + hidden, hidden, n_supports, k)

    def forward(self, x, h, supports):
        r, u = torch.sigmoid(self.gates(torch.cat([x, h], -1), supports)).chunk(2, -1)
        c = torch.tanh(self.cand(torch.cat([x, r * h], -1), supports))
        return u * h + (1 - u) * c


class TBSTGNN(nn.Module):
    """Encoder-decoder over regions.

    Supports: forward/backward random-walk matrices of the observed mobility graph and an
    adaptive adjacency softmax(relu(E1 E2^T)) learned from node embeddings.
    Heads: log-rates of (cases, MDR, deaths) as offsets from the last-12-month level,
    and age-sex composition logits as offsets from the last-12-month composition.
    """

    def __init__(self, n_nodes, enc_dim, dec_dim, cfg, mobility=None):
        super().__init__()
        self.cfg = cfg
        fixed = []
        if cfg.use_mobility:
            fixed = [mobility, mobility.t() / mobility.t().sum(1, keepdim=True)]
        for i, a in enumerate(fixed):
            self.register_buffer("support_%d" % i, a)
        self.n_fixed = len(fixed)
        n_sup = self.n_fixed + int(cfg.use_adaptive)
        if cfg.use_adaptive:
            self.e1 = nn.Parameter(0.3 * torch.randn(n_nodes, cfg.emb_dim))
            self.e2 = nn.Parameter(0.3 * torch.randn(n_nodes, cfg.emb_dim))
        h = cfg.hidden
        self.enc_in = nn.Linear(enc_dim, h)
        self.dec_in = nn.Linear(dec_dim, h)
        self.enc_cell = GConvGRUCell(h, h, n_sup, cfg.diffusion_k)
        self.dec_cell = GConvGRUCell(h, h, n_sup, cfg.diffusion_k)
        self.drop = nn.Dropout(cfg.dropout)
        self.head = nn.Sequential(nn.Linear(h, h), nn.ReLU(), nn.Linear(h, len(C.COUNT_TARGETS) + len(C.STRATA)))
        nn.init.zeros_(self.head[-1].weight)
        nn.init.zeros_(self.head[-1].bias)

    def adaptive_adjacency(self):
        return F.softmax(F.relu(self.e1 @ self.e2.t()), dim=1)

    def supports(self):
        s = [getattr(self, "support_%d" % i) for i in range(self.n_fixed)]
        if self.cfg.use_adaptive:
            s.append(self.adaptive_adjacency())
        return s

    def forward(self, enc, dec, a_cnt, a_cmp):
        """enc [B, W, N, Fe], dec [B, H, N, Fd], a_cnt [B, N, 3], a_cmp [B, N, 8]."""
        sup = self.supports()
        B, W, N, _ = enc.shape
        h = enc.new_zeros(B, N, self.cfg.hidden)
        x_enc = torch.relu(self.enc_in(enc))
        for t in range(W):
            h = self.enc_cell(self.drop(x_enc[:, t]), h, sup)
        x_dec = torch.relu(self.dec_in(dec))
        outs = []
        for t in range(dec.shape[1]):
            h = self.dec_cell(self.drop(x_dec[:, t]), h, sup)
            outs.append(self.head(self.drop(h)))
        out = torch.stack(outs, 1)                       # [B, H, N, 3 + 8]
        nc = len(C.COUNT_TARGETS)
        log_rate = a_cnt[:, None] + out[..., :nc]
        comp_logit = a_cmp[:, None] + out[..., nc:]
        return log_rate, comp_logit


def poisson_deviance(log_rate, y):
    mu = torch.exp(log_rate)
    return 2 * (torch.where(y > 0, y * (torch.log(y.clamp_min(1e-9)) - log_rate), torch.zeros_like(y)) - (y - mu))


def loss_fn(log_rate, comp_logit, y_cnt, y_cmp, comp_weight=1.0):
    """Mean Poisson deviance per count target + multinomial deviance of the age-sex mix."""
    dev = poisson_deviance(log_rate, y_cnt).mean((0, 1, 2)).sum()
    logp = F.log_softmax(comp_logit, -1)
    n = y_cmp.sum(-1, keepdim=True)
    emp = torch.where(y_cmp > 0, torch.log(y_cmp.clamp_min(1e-9) / n.clamp_min(1e-9)), torch.zeros_like(y_cmp))
    mdev = 2 * (y_cmp * (emp - logp)).sum(-1).mean() / (len(C.STRATA) - 1)
    return dev + comp_weight * mdev

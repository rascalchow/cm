"""Turn patient-level records into a region x month panel, and load the model inputs."""
from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import config as C


def month_index(dates):
    dates = pd.DatetimeIndex(dates)
    return (dates.year - C.START_YEAR) * 12 + dates.month - 1


def aggregate(records, codes, t_start, n_months):
    """Monthly counts for months t_start..t_start+n_months-1 (indices since 2015-01).

    cases / mdr / composition are counted by month of diagnosis, deaths by month of death.
    """
    n = len(codes)
    ridx = pd.Series(np.arange(n), index=codes)[records["region_code"]].to_numpy()
    out = {}
    t = month_index(records["diagnosis_date"]) - t_start
    ok = (t >= 0) & (t < n_months)

    def count(mask, tt):
        m = mask & (tt >= 0) & (tt < n_months)
        return np.bincount(tt[m] * n + ridx[m], minlength=n_months * n).reshape(n_months, n).astype(float)

    out["cases"] = count(np.ones(len(records), bool), t)
    out["mdr"] = count((records["drug_resistance"] == "RR/MDR-TB").to_numpy(), t)
    died = (records["outcome"] == "Died").to_numpy()
    td = np.full(len(records), -1)
    td[died] = month_index(records.loc[died, "outcome_date"]) - t_start
    out["deaths"] = count(died, td)
    stratum = (np.where(records["sex"].to_numpy() == "Male", 0, 4)
               + pd.Series([0, 1, 2, 3], index=["0-14", "15-44", "45-64", "65+"])[records["age_group"]].to_numpy())
    comp = np.zeros((n_months, n, len(C.STRATA)))
    np.add.at(comp, (t[ok], ridx[ok], stratum[ok]), 1.0)
    out["comp"] = comp
    return out


def covariate_array(df, codes, n_months):
    """[T, N, len(COVARIATES)] from a long table with region_code/year/month columns."""
    df = df.copy()
    df["log_population"] = np.log(df["population"])
    df["t"] = (df["year"] - df["year"].min()) * 12 + df["month"] - 1
    df = df.sort_values(["t", "region_code"])
    arr = np.zeros((n_months, len(codes), len(C.COVARIATES)))
    ridx = pd.Series(np.arange(len(codes)), index=codes)[df["region_code"]].to_numpy()
    for k, c in enumerate(C.COVARIATES):
        arr[df["t"].to_numpy(), ridx, k] = df[c].to_numpy()
    return arr


@dataclass
class Panel:
    codes: list
    names: list
    counts: np.ndarray      # [T, N, 3] cases, mdr, deaths
    comp: np.ndarray        # [T, N, 8] age-sex strata of cases
    cov: np.ndarray         # [T, N, 6]
    static: np.ndarray      # [N, 5]
    od: np.ndarray          # [N, N] average daily trips origin -> destination
    population: np.ndarray  # [T, N]
    dates: pd.DatetimeIndex


def load_observed(data_dir=C.DATA_DIR):
    regions = pd.read_csv(data_dir / "regions.csv")
    codes = regions["region_code"].tolist()
    records = pd.read_csv(data_dir / "tb_patient_records.csv", parse_dates=["diagnosis_date", "outcome_date"])
    agg = aggregate(records, codes, 0, C.N_OBS)
    covdf = pd.read_csv(data_dir / "region_covariates_monthly.csv")
    cov = covariate_array(covdf, codes, C.N_OBS)
    od_df = pd.read_csv(data_dir / "mobility_od.csv")
    idx = pd.Series(np.arange(len(codes)), index=codes)
    od = np.zeros((len(codes), len(codes)))
    od[idx[od_df["origin"]].to_numpy(), idx[od_df["destination"]].to_numpy()] = od_df["avg_daily_trips"].to_numpy()
    counts = np.stack([agg[k] for k in C.COUNT_TARGETS], -1)
    return Panel(codes, regions["region_name"].tolist(), counts, agg["comp"], cov,
                 regions[list(C.STATIC)].to_numpy(float), od, np.exp(cov[..., C.COVARIATES.index("log_population")]),
                 pd.date_range("%d-01-01" % C.START_YEAR, periods=C.N_OBS, freq="MS"))


def load_scenario(name, codes, data_dir=C.DATA_DIR):
    df = pd.read_csv(data_dir / "scenarios" / ("%s_covariates_2025_2029.csv" % name))
    return covariate_array(df, codes, C.N_FUTURE)


def load_truth(name, truth_dir=C.TRUTH_DIR):
    z = np.load(truth_dir / ("truth_%s.npz" % name))
    return dict(counts=np.stack([z[k] for k in C.COUNT_TARGETS], -1), comp=z["comp"])

"""Figures for the report (static PNG, light theme)."""
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

from . import config as C  # noqa: E402
from . import experiments as X  # noqa: E402

# reference palette (categorical slots in fixed order), ink and chrome
SLOT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
INK, INK2, MUTED, GRID, AXIS, SURFACE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"
MODEL_COLOR = {"STGNN": SLOT[0], "GRU-nograph": SLOT[1], "GLM": SLOT[2], "STGNN-mob": SLOT[3],
               "SeasonalNaive": SLOT[4], "Oracle": MUTED}
MODEL_LABEL = {"STGNN": "STGNN (mobility + adaptive)", "STGNN-mob": "STGNN (mobility only)",
               "GRU-nograph": "GRU (no graph)", "GLM": "Poisson GLM", "SeasonalNaive": "Seasonal naive",
               "Oracle": "Oracle (true mean)"}
SCEN_COLOR = {"baseline": SLOT[0], "enhanced_control": SLOT[2], "disruption": SLOT[1]}
SCEN_LABEL = {"baseline": "Status quo", "enhanced_control": "Enhanced control", "disruption": "Health-system disruption"}
TARGET_LABEL = {"cases": "Notified cases", "mdr": "RR/MDR-TB cases", "deaths": "Deaths on treatment"}
BLUE_SEQ = LinearSegmentedColormap.from_list("blue_seq", ["#f4f8fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
DIVERGE = LinearSegmentedColormap.from_list("div", ["#1c5cab", "#86b6ef", "#f0efec", "#ef9a99", "#b8302f"])

plt.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    "font.family": "DejaVu Sans", "font.size": 9, "axes.titlesize": 10, "axes.titleweight": "bold",
    "axes.labelcolor": INK2, "axes.edgecolor": AXIS, "axes.linewidth": 0.8, "xtick.color": MUTED,
    "ytick.color": MUTED, "xtick.labelcolor": INK2, "ytick.labelcolor": INK2, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.6, "grid.linestyle": "-", "axes.spines.top": False,
    "axes.spines.right": False, "legend.frameon": False, "legend.fontsize": 8, "lines.linewidth": 2,
    "lines.solid_capstyle": "round", "axes.titlelocation": "left", "axes.titlecolor": INK,
})


def _save(fig, name):
    C.FIG_DIR.mkdir(parents=True, exist_ok=True)
    fig.savefig(C.FIG_DIR / name, dpi=200, bbox_inches="tight")
    plt.close(fig)


def _months(start, n):
    return pd.date_range(start, periods=n, freq="MS")


# ---- data description ------------------------------------------------------------------
def _place_labels(ax, xy, radius_pt, texts, fontsize=6.5):
    """Greedy label placement: try below/above/right/left of each node and keep the
    candidate whose (approximate) box overlaps least with nodes and placed labels."""
    fig = ax.figure
    fig.canvas.draw()
    to_px = ax.transData.transform
    pts = to_px(xy)
    px_per_pt = fig.dpi / 72
    placed = []
    frame = tuple(ax.get_window_extent().extents)
    node_boxes = [(p[0] - r * px_per_pt, p[1] - r * px_per_pt, p[0] + r * px_per_pt, p[1] + r * px_per_pt)
                  for p, r in zip(pts, radius_pt)]

    def overlap(a, b):
        return max(0, min(a[2], b[2]) - max(a[0], b[0])) * max(0, min(a[3], b[3]) - max(a[1], b[1]))

    for i, txt in enumerate(texts):
        lines = txt.split("\n")
        w = max(len(l) for l in lines) * fontsize * 0.6 * px_per_pt
        h = len(lines) * fontsize * 1.5 * px_per_pt
        r = (radius_pt[i] + 3) * px_per_pt
        x, y = pts[i]
        cands = [((x - w / 2, y - r - h, x + w / 2, y - r), (0, -1), "center", "top"),
                 ((x - w / 2, y + r, x + w / 2, y + r + h), (0, 1), "center", "bottom"),
                 ((x + r, y - h / 2, x + r + w, y + h / 2), (1, 0), "left", "center"),
                 ((x - r - w, y - h / 2, x - r, y + h / 2), (-1, 0), "right", "center")]
        best = min(cands, key=lambda c: sum(overlap(c[0], b) for j, b in enumerate(node_boxes) if j != i)
                   + sum(overlap(c[0], b) for b in placed)
                   + 3 * ((c[0][2] - c[0][0]) * (c[0][3] - c[0][1]) - overlap(c[0], frame)))
        placed.append(best[0])
        off = (best[1][0] * (radius_pt[i] + 3), best[1][1] * (radius_pt[i] + 3))
        ax.annotate(txt, xy[i], xytext=off, textcoords="offset points", ha=best[2], va=best[3],
                    fontsize=fontsize, color=INK2, zorder=4, linespacing=1.1)


def fig_region_map(d):
    regions = d["regions"]
    inc = d["incidence"].drop(columns="region_name")
    mean_inc = inc.mean(1).to_numpy()
    od = pd.read_csv(C.DATA_DIR / "mobility_od.csv")
    world = np.load(C.TRUTH_DIR / "world.npz")
    xy = regions[["x_km", "y_km"]].to_numpy()
    idx = {c: i for i, c in enumerate(regions["region_code"])}
    fig, ax = plt.subplots(figsize=(7.2, 5.4))
    ax.grid(False)
    top = od.sort_values("avg_daily_trips", ascending=False).head(45)
    wmax = top["avg_daily_trips"].max()
    for _, r in top.iterrows():
        a, b = xy[idx[r["origin"]]], xy[idx[r["destination"]]]
        ax.plot([a[0], b[0]], [a[1], b[1]], color=AXIS, lw=0.5 + 3.5 * r["avg_daily_trips"] / wmax, zorder=1,
                solid_capstyle="round")
    sc = ax.scatter(xy[:, 0], xy[:, 1], s=regions["population_2015"] / 6000, c=mean_inc, cmap=BLUE_SEQ,
                    vmin=30, vmax=mean_inc.max(), edgecolors=SURFACE, linewidths=2, zorder=3)
    special = {int(world["boom"]): "labour-migration hub (2018+)", int(world["mdr_seed"]): "MDR cluster (2016)"}
    for i in np.where(world["program"])[0]:
        special[int(i)] = "control scale-up (2019+)"
    _place_labels(ax, xy, np.sqrt(regions["population_2015"].to_numpy() / 6000) / 2,
                  ["%s %s" % (c, n) + ("\n" + special[i] if i in special else "")
                   for i, (c, n) in enumerate(zip(regions["region_code"], regions["region_name"]))])
    cb = fig.colorbar(sc, ax=ax, shrink=0.7, pad=0.06)
    cb.set_label("Mean notification rate 2015-2024 (per 100k / yr)", color=INK2)
    cb.outline.set_visible(False)
    ax.set_xlabel("x (km)")
    ax.set_ylabel("y (km)")
    ax.set_aspect("equal")
    ax.set_title("Synthetic country: 20 regions, mobility network (top 45 flows) and TB burden")
    _save(fig, "fig01_region_map.png")


def fig_national_trends(d, panel):
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.8), gridspec_kw=dict(width_ratios=[1.15, 1]))
    ax = axes[0]
    t = _months("2015-01-01", C.N_OBS)
    ax.plot(t, panel.counts[..., 0].sum(1), color=SLOT[0], lw=1.6)
    ax.axvspan(pd.Timestamp("2020-02-01"), pd.Timestamp("2020-09-01"), color=GRID, alpha=0.6, lw=0)
    ax.text(pd.Timestamp("2020-02-15"), ax.get_ylim()[1] * 0.995, "service\ndisruption", va="top", fontsize=7, color=INK2)
    ax.set_ylabel("Notified TB cases per month (all regions)")
    ax.set_title("a  Monthly notifications, 2015-2024")
    ax = axes[1]
    inc = d["incidence"].drop(columns="region_name")
    inc.index = ["%s" % c for c in inc.index]
    order = inc.mean(1).sort_values(ascending=False).index
    im = ax.imshow(inc.loc[order].to_numpy(), aspect="auto", cmap=BLUE_SEQ)
    ax.set_yticks(range(len(order)))
    ax.set_yticklabels(order, fontsize=6.5)
    ax.set_xticks(range(inc.shape[1]))
    ax.set_xticklabels(inc.columns, fontsize=7, rotation=45)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, shrink=0.85, pad=0.02)
    cb.set_label("per 100k / yr", color=INK2)
    cb.outline.set_visible(False)
    ax.set_title("b  Notification rate by region and year")
    fig.tight_layout()
    _save(fig, "fig02_trends.png")


def fig_demographics(d):
    rec = d["records"]
    fig, axes = plt.subplots(1, 3, figsize=(12, 4.2), gridspec_kw=dict(width_ratios=[1, 1, 1.15]))
    ax = axes[0]
    pyr = d["pyramid"] / len(rec) * 100
    y = np.arange(len(pyr))
    ax.barh(y, -pyr["Male"].to_numpy(), height=0.8, color=SLOT[0], label="Male")
    ax.barh(y, pyr["Female"].to_numpy(), height=0.8, color=SLOT[1], label="Female")
    ax.set_yticks(y[::2])
    ax.set_yticklabels(["%d" % iv.left for iv in pyr.index[::2]], fontsize=7)
    ax.set_xticks(ax.get_xticks())
    ax.set_xticklabels(["%.0f" % abs(v) for v in ax.get_xticks()])
    ax.set_xlabel("% of all cases")
    ax.set_ylabel("Age (5-year bands)")
    ax.axvline(0, color=AXIS, lw=0.8)
    ax.legend(loc="upper left")
    ax.set_title("a  Age-sex distribution of cases")
    ax = axes[1]
    occ = d["occupation"]["pct"].sort_values()
    ax.barh(range(len(occ)), occ.to_numpy(), height=0.6, color=SLOT[0])
    for i, v in enumerate(occ.to_numpy()):
        ax.text(v + 0.4, i, "%.1f%%" % v, va="center", fontsize=7, color=INK2)
    ax.set_yticks(range(len(occ)))
    ax.set_yticklabels(occ.index, fontsize=7.5)
    ax.set_xlabel("% of cases")
    ax.grid(axis="y", visible=False)
    ax.set_title("b  Occupation")
    ax = axes[2]
    ob = d["outcomes_by_year"].loc[:2023]          # 2024 cohort mostly still on treatment at cut-off
    groups = [("Treatment success", ["Cured", "Treatment completed"]), ("Died", ["Died"]),
              ("Lost to follow-up", ["Lost to follow-up"]), ("Failed / not evaluated", ["Treatment failed", "Not evaluated"]),
              ("Still on treatment", ["Still on treatment"])]
    bottom = np.zeros(len(ob))
    years = ob.index.to_numpy()
    for k, (lab, cols) in enumerate(groups):
        v = ob[[c for c in cols if c in ob.columns]].sum(1).to_numpy()
        if k == 0:
            ax.bar(years, v, width=0.7, color=SLOT[k], label=lab)
            for x, val in zip(years, v):
                ax.text(x, 71.0, "%.1f" % val, ha="center", fontsize=6.5, color="white")
            bottom = v.copy()
            continue
        ax.bar(years, v, width=0.7, bottom=bottom, color=SLOT[k], label=lab, edgecolor="white", linewidth=1)
        bottom += v
    ax.set_ylim(70, 100.5)
    ax.set_ylabel("% of cohort (axis starts at 70%)")
    ax.set_xticks(years)
    ax.set_xticklabels(years, rotation=45, fontsize=7)
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0))
    ax.grid(axis="x", visible=False)
    ax.set_title("c  Treatment outcome by diagnosis cohort")
    fig.tight_layout()
    _save(fig, "fig03_demographics.png")


def fig_architecture():
    fig, ax = plt.subplots(figsize=(11, 4.2))
    ax.set_xlim(-1.5, 111.5)
    ax.set_ylim(-3, 43)
    ax.axis("off")

    def box(x, y, w, h, title, body, color):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.4,rounding_size=1.2",
                                    fc="white", ec=color, lw=1.6))
        ax.text(x + w / 2, y + h - 2.2, title, ha="center", va="top", fontsize=8.5, weight="bold", color=INK)
        ax.text(x + w / 2, y + h - 6.2, body, ha="center", va="top", fontsize=7, color=INK2, linespacing=1.4)

    def arrow(a, b):
        ax.add_patch(FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=11, color=INK2, lw=1.1))

    box(0, 22, 19, 19, "Patient records", "139k cases\nsex, age, occupation,\ndiagnosis, HIV, DST,\noutcome, dates", AXIS)
    box(0, 1, 19, 18, "Region covariates", "health-system index,\nHIV prevalence, mobility,\nservice disruption,\nmigration, population", AXIS)
    box(23, 12, 19, 21, "Region-month panel", "x_i(t): log cases, MDR,\ndeaths + 8 age-sex\nshares; covariates;\ncalendar; static node\nfeatures", AXIS)
    box(46, 22, 25, 19, "Graph supports", "A_fwd, A_bwd: mobility\n(origin-destination flows)\nA_adp = softmax(ReLU(E1 E2^T))\nK = 2 diffusion hops", SLOT[6])
    box(46, 1, 25, 18, "Encoder: DGC-GRU", "24 months of history\ngates use diffusion\ngraph convolution\nX W + (sum a_sk A_s^k X) W'", SLOT[0])
    box(75, 1, 16, 18, "Decoder: DGC-GRU", "12 steps, driven by\nfuture covariates\n(scenario inputs)", SLOT[0])
    box(94, 22, 16, 19, "Heads", "log-rate = level of last\n12 months + offset\n-> cases, MDR, deaths\n(Poisson deviance)\nage-sex mix (softmax)", SLOT[2])
    box(94, 1, 16, 18, "Simulation", "sample NB counts,\nfeed back, repeat\n5 x 12 months\n5 seeds x 40 paths", SLOT[1])
    arrow((19, 31), (23, 26))
    arrow((19, 10), (23, 19))
    arrow((42, 18), (46, 12))
    arrow((58.5, 22), (58.5, 19.5))
    arrow((71, 10), (75, 10))
    arrow((91, 14), (94, 27))
    arrow((102, 22), (102, 19.6))
    ax.annotate("", xy=(56, 1.0), xytext=(100, 1.0), arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=0.9,
                                                                    connectionstyle="arc3,rad=0.25"))
    ax.text(78, 0.0, "autoregressive feedback of simulated counts", fontsize=7, color=MUTED, ha="center", va="top")
    _save(fig, "fig04_architecture.png")


# ---- forecasting results ---------------------------------------------------------------
def fig_forecast_examples(bench, panel):
    te = list(bench["origins"])
    blocks = [te.index(95), te.index(107)]
    totals = panel.counts[..., 0].sum(0)
    rate = totals / panel.population.mean(0)
    picks = []
    for i in [int(np.argmax(totals)), int(np.load(C.TRUTH_DIR / "world.npz")["boom"]), int(np.argmax(rate)),
              int(np.argmin(totals))] + list(np.argsort(totals)):
        if int(i) not in picks:
            picks.append(int(i))
    picks = picks[:4]
    fig, axes = plt.subplots(2, 2, figsize=(11, 6.2), sharex=True)
    fut_t = _months("2023-01-01", 24)
    for ax, i in zip(axes.ravel(), picks):
        obs = panel.counts[60:, i, 0]
        ax.plot(_months("2020-01-01", 60), obs, color=INK, lw=1.2, label="Observed")
        for name in ("GLM", "STGNN"):
            p = bench["preds"][name]
            mu = np.concatenate([p["mu"][o, :, i, 0] for o in blocks])
            if name == "STGNN":
                lo = np.concatenate([p["q05"][o, :, i, 0] for o in blocks])
                hi = np.concatenate([p["q95"][o, :, i, 0] for o in blocks])
                ax.fill_between(fut_t, lo, hi, color=MODEL_COLOR[name], alpha=0.12, lw=0, label="STGNN 90% interval")
            ax.plot(fut_t, mu, color=MODEL_COLOR[name], label=MODEL_LABEL[name])
        ax.axvline(pd.Timestamp("2023-01-01"), color=AXIS, lw=0.8)
        ax.set_title("%s %s" % (panel.codes[i], panel.names[i]))
        ax.set_ylabel("cases / month")
    axes[0, 0].legend(loc="upper left", ncol=2)
    fig.suptitle("Out-of-sample forecasts: 12 months ahead from Dec-2022 (for 2023) and Dec-2023 (for 2024)",
                 x=0.01, ha="left", fontsize=10, weight="bold", color=INK)
    fig.tight_layout()
    _save(fig, "fig05_forecast_examples.png")


def fig_horizon(bench):
    fig, ax = plt.subplots(figsize=(6.6, 3.8))
    h = np.arange(1, 13)
    order = ["SeasonalNaive", "GLM", "GRU-nograph", "STGNN-mob", "STGNN", "Oracle"]
    for name in order:
        v = bench["by_h"][name]
        ax.plot(h, v, color=MODEL_COLOR[name], lw=2 if name != "Oracle" else 1.4, marker="o", ms=3.5,
                label=MODEL_LABEL[name], zorder=3 if name == "STGNN" else 2)
    ax.set_xlabel("Forecast horizon (months)")
    ax.set_ylabel("MAE, monthly cases per region")
    ax.set_xticks(h)
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0))
    ax.set_title("Error by horizon, 13 rolling origins in 2023-2024")
    _save(fig, "fig06_horizon_mae.png")


def fig_influence(interp, panel):
    S = interp["STGNN"]["S"].copy()
    np.fill_diagonal(S, np.nan)
    Cm = interp["contact"].copy()
    np.fill_diagonal(Cm, np.nan)
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 4.0), gridspec_kw=dict(width_ratios=[1, 1, 0.95]))
    for ax, M, title in [(axes[0], S, "a  Learned influence |d forecast_i / d cases_j|"),
                         (axes[1], Cm, "b  True contact matrix (generator)")]:
        im = ax.imshow(M, cmap=BLUE_SEQ)
        ax.set_xticks(range(len(panel.codes)))
        ax.set_yticks(range(len(panel.codes)))
        ax.set_xticklabels(panel.codes, rotation=90, fontsize=5.5)
        ax.set_yticklabels(panel.codes, fontsize=5.5)
        ax.set_xlabel("source region j")
        ax.set_ylabel("target region i")
        ax.grid(False)
        ax.set_title(title, fontsize=9)
        cb = fig.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
        cb.outline.set_visible(False)
    ax = axes[2]
    off = ~np.eye(len(panel.codes), dtype=bool)
    ax.scatter(interp["contact"][off], interp["STGNN"]["S"][off], s=14, color=SLOT[0], alpha=0.7,
               edgecolors=SURFACE, linewidths=0.6)
    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("true contact share C_ij")
    ax.set_ylabel("learned influence S_ij")
    ax.set_title("c  Spearman rho = %.2f" % interp["STGNN"]["spearman_contact"], fontsize=9)
    fig.tight_layout()
    _save(fig, "fig07_influence.png")


# ---- scenario simulation -----------------------------------------------------------------
def fig_scenarios(scen, panel):
    fig, axes = plt.subplots(3, 3, figsize=(12.5, 8.4), sharex=True)
    t_hist = _months("2021-01-01", 48)
    t_fut = _months("2025-01-01", C.N_FUTURE)
    for c, name in enumerate(C.SCENARIOS):
        res = scen[name]
        for r, tgt in enumerate(C.COUNT_TARGETS):
            ax = axes[r, c]
            ax.plot(t_hist, panel.counts[72:, :, r].sum(1), color=INK, lw=1.1, label="Observed 2021-2024")
            ax.plot(t_fut, res["truth"][..., r].sum(1), color=INK, lw=1.1, alpha=0.45, label="Hidden truth 2025-2029")
            sim = res["sims"]["STGNN"]["counts"][..., r].sum(-1)
            lo, med, hi = np.quantile(sim, [0.05, 0.5, 0.95], 0)
            ax.fill_between(t_fut, lo, hi, color=MODEL_COLOR["STGNN"], alpha=0.14, lw=0, label="STGNN 90% interval")
            ax.plot(t_fut, med, color=MODEL_COLOR["STGNN"], label="STGNN median")
            for m in ("GRU-nograph", "GLM"):
                ax.plot(t_fut, np.median(res["sims"][m]["counts"][..., r].sum(-1), 0), color=MODEL_COLOR[m],
                        lw=1.4, label=MODEL_LABEL[m] + " median")
            ax.axvline(pd.Timestamp("2025-01-01"), color=AXIS, lw=0.8)
            if r == 0:
                ax.set_title(SCEN_LABEL[name])
            if c == 0:
                ax.set_ylabel(TARGET_LABEL[tgt] + " / month")
    axes[0, 0].legend(loc="lower left", fontsize=6.8, ncol=2)
    fig.tight_layout()
    _save(fig, "fig08_scenarios_national.png")


def fig_scenario_compare(scen, panel):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.2), gridspec_kw=dict(width_ratios=[1.1, 1]))
    ax = axes[0]
    pop_obs = panel.population.reshape(10, 12, -1).mean(1).sum(1)
    years_obs = np.arange(2015, 2025)
    obs_rate = panel.counts[..., 0].reshape(10, 12, -1).sum((1, 2)) / pop_obs * 1e5
    ax.plot(years_obs, obs_rate, color=INK, lw=1.6, marker="o", ms=3.5, label="Observed")
    years = np.arange(2025, 2030)
    ends = {}
    for name in C.SCENARIOS:
        cov = pd.read_csv(C.SCEN_DIR / ("%s_covariates_2025_2029.csv" % name))
        pop = cov.groupby("year")["population"].sum().to_numpy() / 12
        sim = scen[name]["sims"]["STGNN"]["counts"][..., 0].reshape(-1, 5, 12, C.N_REGIONS).sum((2, 3)) / pop * 1e5
        lo, med, hi = np.quantile(sim, [0.05, 0.5, 0.95], 0)
        col = SCEN_COLOR[name]
        ax.fill_between(years, lo, hi, color=col, alpha=0.08, lw=0)
        ax.plot(years, med, color=col, marker="o", ms=3.5, label=SCEN_LABEL[name] + " (STGNN)")
        truth = scen[name]["truth"][..., 0].reshape(5, 12, -1).sum((1, 2)) / pop * 1e5
        ax.scatter(years, truth, marker="x", s=22, color=col, linewidths=1.4, zorder=4)
        ends[name] = med[-1]
    # end-labels, nudged apart when they would collide
    placed = []
    for name, v in sorted(ends.items(), key=lambda kv: kv[1]):
        y = v if not placed or v - placed[-1] > 0.9 else placed[-1] + 0.9
        placed.append(y)
        ax.annotate("%.1f" % v, (years[-1], v), xytext=(years[-1] + 0.25, y), textcoords="data",
                    va="center", fontsize=7.5, color=INK2,
                    arrowprops=dict(arrowstyle="-", color=AXIS, lw=0.6) if abs(y - v) > 0.05 else None)
    ax.plot([], [], ls="none", marker="x", color=INK2, label="Hidden truth (x)")
    ax.set_ylabel("Notification rate per 100k / yr")
    ax.set_xticks(np.arange(2015, 2030))
    ax.set_xticklabels(np.arange(2015, 2030), rotation=45, fontsize=7)
    ax.legend(loc="lower left", fontsize=7.5)
    ax.set_title("a  National notification rate: observed and simulated")
    ax = axes[1]
    base = panel.counts[-12:, :, 0].sum(0)
    sim = scen["baseline"]["sims"]["STGNN"]["counts"][:, -12:, :, 0].sum(1)
    change = (np.median(sim, 0) / base - 1) * 100
    truth = (scen["baseline"]["truth"][-12:, :, 0].sum(0) / base - 1) * 100
    order = np.argsort(change)
    lim = np.ceil((np.abs(np.r_[change, truth]).max() + 2) / 5) * 5
    colors = [DIVERGE(0.5 + 0.5 * v / lim) for v in change[order]]
    ax.barh(range(C.N_REGIONS), change[order], height=0.6, color=colors)
    ax.scatter(truth[order], range(C.N_REGIONS), marker="x", color=INK, s=18, zorder=3, label="Hidden truth")
    ax.axvline(0, color=AXIS, lw=0.8)
    ax.set_yticks(range(C.N_REGIONS))
    ax.set_yticklabels(["%s %s" % (panel.codes[i], panel.names[i]) for i in order], fontsize=6.8)
    ax.set_xlabel("Change in annual cases, 2029 vs 2024 (%)")
    ax.set_xlim(-lim, lim)
    ax.grid(axis="y", visible=False)
    ax.legend(loc="lower right", fontsize=7.5)
    ax.set_title("b  Regional change under the status-quo scenario (STGNN median)")
    fig.tight_layout()
    _save(fig, "fig09_scenario_compare.png")


def fig_age_shift(scen, panel):
    fig, ax = plt.subplots(figsize=(6.8, 3.8))
    old = [3, 7]                                     # M 65+, F 65+
    years_obs = np.arange(2015, 2025)
    comp_obs = panel.comp.reshape(10, 12, C.N_REGIONS, -1).sum((1, 2))
    ax.plot(years_obs, comp_obs[:, old].sum(1) / comp_obs.sum(1) * 100, color=INK, marker="o", ms=3.5, lw=1.6,
            label="Observed")
    years = np.arange(2025, 2030)
    for name in C.SCENARIOS:
        cmp_ = scen[name]["sims"]["STGNN"]["comp"].reshape(-1, 5, 12, C.N_REGIONS, len(C.STRATA)).sum((2, 3))
        share = cmp_[..., old].sum(-1) / np.maximum(cmp_.sum(-1), 1) * 100
        lo, med, hi = np.quantile(share, [0.05, 0.5, 0.95], 0)
        ax.fill_between(years, lo, hi, color=SCEN_COLOR[name], alpha=0.12, lw=0)
        ax.plot(years, med, color=SCEN_COLOR[name], marker="o", ms=3.5, label=SCEN_LABEL[name] + " (STGNN)")
        tc = scen[name]["truth_comp"].reshape(5, 12, C.N_REGIONS, -1).sum((1, 2))
        ax.scatter(years, tc[:, old].sum(1) / tc.sum(1) * 100, marker="x", s=22, color=SCEN_COLOR[name],
                   linewidths=1.4, zorder=4)
    ax.plot([], [], ls="none", marker="x", color=INK2, label="Hidden truth (x)")
    ax.set_ylabel("Cases aged 65+ (% of all cases)")
    ax.set_xticks(np.arange(2015, 2030))
    ax.set_xticklabels(np.arange(2015, 2030), rotation=45, fontsize=7)
    ax.legend(loc="upper left", fontsize=7.5)
    ax.set_title("Ageing of the TB caseload: share of cases aged 65+")
    _save(fig, "fig10_age_shift.png")


def fig_sensitivity(sens, bench):
    rows = [r for r in sens if "boot" not in r]
    df = pd.DataFrame(rows)
    main = pd.DataFrame([r for r in bench["rows"] if r["target"] == "cases"])
    main = main[main["model"].isin(["STGNN", "GRU-nograph", "GLM", "Oracle (true mean)"])].assign(scale=1.0)
    df = pd.concat([main[["scale", "model", "MAE"]], df[["scale", "model", "MAE"]]])
    oracle = df[df["model"] == "Oracle (true mean)"].set_index("scale")["MAE"]
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    for m in ("GLM", "GRU-nograph", "STGNN"):
        s = df[df["model"] == m].set_index("scale")["MAE"].sort_index()
        excess = (s - oracle.loc[s.index]) / oracle.loc[s.index] * 100
        ax.plot(excess.index, excess.to_numpy(), color=MODEL_COLOR[m], marker="o", ms=4, label=MODEL_LABEL[m])
    ax.set_xticks(sorted(df["scale"].unique()))
    ax.set_xticklabels(["x%g" % v for v in sorted(df["scale"].unique())])
    ax.set_xlabel("Inter-regional mobility (multiple of the main world)")
    ax.set_ylabel("Excess MAE over oracle (%)")
    ax.axhline(0, color=AXIS, lw=0.8)
    ax.legend(loc="upper left", bbox_to_anchor=(1.0, 1.0))
    ax.set_title("When does the graph help? Coupling sensitivity")
    _save(fig, "fig11_sensitivity.png")


def fig_training(runs):
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    for v in ("STGNN", "STGNN-mob", "GRU-nograph"):
        for k, r in enumerate([r for r in runs if r["variant"] == v]):
            h = r["history"]
            ax.plot(h[:, 0], h[:, 2], color=MODEL_COLOR[v], lw=1.0, alpha=0.8, label=MODEL_LABEL[v] if k == 0 else None)
    ax.set_xlabel("Epoch")
    ax.set_ylabel("Validation loss (2022)")
    ax.set_ylim(top=np.percentile(np.concatenate([r["history"][:, 2] for r in runs]), 98))
    ax.legend(loc="upper right")
    ax.set_title("Validation curves, 5 seeds per variant")
    _save(fig, "fig12_training.png")


def make_all():
    from .eda import describe
    from .panel import load_observed
    d = describe()
    panel = load_observed()
    fig_region_map(d)
    fig_national_trends(d, panel)
    fig_demographics(d)
    fig_architecture()
    bench = X.load("benchmark.pkl")
    fig_forecast_examples(bench, panel)
    fig_horizon(bench)
    fig_influence(X.load("interpretation.pkl"), panel)
    scen = X.load("scenarios.pkl")
    fig_scenarios(scen, panel)
    fig_scenario_compare(scen, panel)
    fig_age_shift(scen, panel)
    if (C.OUT_DIR / "sensitivity.pkl").exists():
        fig_sensitivity(X.load("sensitivity.pkl"), bench)
    fig_training(X.load("eval_runs.pkl"))

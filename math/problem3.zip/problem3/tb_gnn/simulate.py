"""Stochastic autoregressive simulation of future TB epidemiology with trained models."""
import numpy as np
import torch

from . import config as C
from .baselines import glm_forecast
from .features import anchors
from .metrics import sample_nb


def _sample_composition(rng, cases, probs):
    """Multinomial split of `cases` [...] into strata with probabilities [..., S] (vectorised
    by sequential conditional binomials)."""
    out = np.zeros(probs.shape, dtype=np.int64)
    remaining = cases.astype(np.int64)
    p_left = np.ones(cases.shape)
    for s in range(probs.shape[-1] - 1):
        q = np.clip(probs[..., s] / np.maximum(p_left, 1e-12), 0, 1)
        out[..., s] = rng.binomial(remaining, q)
        remaining = remaining - out[..., s]
        p_left = p_left - probs[..., s]
    out[..., -1] = remaining
    return out


def rollout(model, fb, panel, cov_future, cfg, dispersion, n_samples=40, n_months=C.N_FUTURE, seed=0):
    """Simulate n_months beyond the observed record in blocks of `cfg.horizon` months,
    feeding sampled counts back as inputs. Returns counts [S, n_months, N, 3] and
    composition [S, n_months, N, 8]."""
    rng = np.random.default_rng(seed)
    W, H = cfg.window, cfg.horizon
    cov_all = np.concatenate([panel.cov, cov_future])
    counts = np.repeat(panel.counts[None, -W:], n_samples, 0)
    comp = np.repeat(panel.comp[None, -W:], n_samples, 0)
    t_last = panel.counts.shape[0] - 1
    for _ in range(int(np.ceil(n_months / H))):
        t_hist = np.arange(t_last - W + 1, t_last + 1)
        t_fut = np.arange(t_last + 1, t_last + H + 1)
        enc = fb.encoder(counts[:, -W:], comp[:, -W:], cov_all[t_hist], t_hist)
        dec = np.broadcast_to(fb.decoder(cov_all[t_fut], t_fut), (n_samples,) + (H,) + enc.shape[2:3] + (fb.n_dec,))
        a_cnt, a_cmp = anchors(counts[:, -W:], comp[:, -W:])
        with torch.no_grad():
            lr, cl = model(torch.from_numpy(enc), torch.from_numpy(np.ascontiguousarray(dec)),
                           torch.from_numpy(a_cnt), torch.from_numpy(a_cmp))
        mu = torch.exp(lr).numpy()
        probs = torch.softmax(cl, -1).numpy()
        y = np.stack([sample_nb(rng, mu[..., k], dispersion[k], 1)[0] for k in range(mu.shape[-1])], -1)
        c = _sample_composition(rng, y[..., 0], probs)
        counts = np.concatenate([counts, y], 1)
        comp = np.concatenate([comp, c], 1)
        t_last += H
    return counts[:, W:W + n_months], comp[:, W:W + n_months]


def glm_projection(panel, cov_future, n_samples=200, n_months=C.N_FUTURE, seed=0):
    """Trend + seasonality + disruption GLM extrapolated from the end of the record, with
    negative-binomial noise matching the in-sample quasi-Poisson dispersion."""
    mu, phi = glm_forecast(panel.counts, panel.cov, [panel.counts.shape[0] - 1], n_months, cov_future)
    mu, phi = mu[0], phi[0]                                   # [H, N, 3], [N, 3]
    rng = np.random.default_rng(seed)
    k = np.where(phi > 1.0001, mu / np.maximum(phi - 1, 1e-6), 1e9)
    lam = rng.gamma(k, mu / k, size=(n_samples,) + mu.shape)
    return rng.poisson(lam), mu

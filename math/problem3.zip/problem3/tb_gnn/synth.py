"""Synthetic tuberculosis world.

A two-strain (drug-susceptible "DS" / multidrug-resistant "MDR") metapopulation
transmission model on 20 regions coupled by human mobility generates monthly case
notifications. Every notified case is then expanded into an individual patient record
(sex, age, occupation, diagnosis, HIV status, drug resistance, treatment outcome).

Compartments per region (counts):
    S            never infected
    Lf[s]        recent latent infection with strain s (fast progression possible)
    Ls[s]        remote latent infection (slow reactivation)
    I[s, src]    active, infectious, not yet diagnosed; src = recent / remote / retreatment
    T[s]         on treatment (not infectious)
    R[s]         recovered after cure or self-cure (may relapse or be reinfected)
"""
from dataclasses import dataclass

import numpy as np
import pandas as pd

from . import config as C

REGION_NAMES = [
    "Ashford", "Brindlemoor", "Calderon", "Dunmore", "Elmstead",
    "Fennick", "Glenrock", "Halvering", "Ironvale", "Juniper Hills",
    "Kestrel Bay", "Larkspur", "Millbrook", "Northgate", "Oakhaven",
    "Port Selwyn", "Quarrydale", "Rookwood", "Stavenham", "Thornbury",
]

# ---- natural history parameters (per year) -------------------------------------------
MU = 1 / 72              # background mortality
OMEGA = 0.5              # recent -> remote latent stabilisation
EPS_F = 0.06             # fast progression from recent infection (~11% lifetime)
NU0 = 0.0006             # reactivation rate of remote latent infection
X_REINF = 0.35           # relative susceptibility of latently infected / recovered
MU_TB = 0.17             # mortality of untreated active TB
SELF_CURE = 0.17
RELAPSE = 0.002          # relapse rate after cure
TAU = np.array([2.0, 0.6])        # treatment exit rate: DS ~6 months, MDR ~20 months
FITNESS = np.array([1.0, 0.9])    # relative transmissibility of the MDR strain
ACQ_RES = 0.08           # share of DS treatment failures that acquire MDR
BETA_BASE = 12.0         # effective contacts per infectious person-year (calibrated)
SUBSTEPS = 4             # Euler sub-steps per month
MDR_SEED_MONTH = 15      # 2016-04

_m = np.arange(1, 13)
_season = 1 + 0.12 * np.cos(2 * np.pi * (_m - 4) / 12)
_season[1] *= 0.85       # February holiday dip in health seeking
_season[2] *= 1.06       # March catch-up
DET_SEASON = _season / _season.mean()

OCCUPATIONS = ["Preschool child", "Student", "Farmer", "Industrial worker", "Migrant worker",
               "Service worker", "Office/professional", "Healthcare worker", "Homemaker",
               "Unemployed", "Retired"]
OUTCOMES = ["Success", "Died", "Treatment failed", "Lost to follow-up", "Not evaluated"]


@dataclass
class World:
    codes: list
    names: list
    xy: np.ndarray
    dist: np.ndarray
    pop2015: np.ndarray
    urb: np.ndarray
    gdp: np.ndarray
    aging: np.ndarray
    hiv0: np.ndarray
    hiv_trend: np.ndarray
    H0: np.ndarray
    H_growth: np.ndarray
    program: np.ndarray       # bool: TB-control scale-up from mid-2019
    beta_loc: np.ndarray
    eps: np.ndarray           # share of contact time spent outside home region
    W: np.ndarray             # gravity destination weights (row-stochastic, zero diagonal)
    pop_growth: np.ndarray
    metro: np.ndarray
    boom: int                 # industrial boom region attracting migrant workers from 2018
    origins: np.ndarray       # sending regions of the labour migration
    mdr_seed: int             # region receiving an MDR cluster in 2016
    disrupt_2020: np.ndarray
    disrupt_2023: np.ndarray
    disrupt_2026: np.ndarray  # only used by the "disruption" scenario


def build_world(rng, mobility_scale=1.0):
    n = C.N_REGIONS
    gx, gy = np.meshgrid(np.arange(5), np.arange(4))
    xy = np.c_[gx.ravel() * 180.0 + 90, gy.ravel() * 175.0 + 90] + rng.uniform(-55, 55, (n, 2))
    dist = np.sqrt(((xy[:, None, :] - xy[None, :, :]) ** 2).sum(-1))
    metro = np.zeros(n, bool)
    metro[[1, 13, 15]] = True

    d_metro = np.where(metro[None, :], dist, np.inf)
    np.fill_diagonal(d_metro, np.inf)
    d_near_metro = d_metro.min(1)

    pop = np.where(metro, rng.uniform(2.8e6, 4.2e6, n),
                   np.clip(np.exp(rng.normal(np.log(6.0e5), 0.45, n)), 2.2e5, 1.8e6))
    urb = np.where(metro, rng.uniform(0.82, 0.92, n),
                   np.clip(0.33 + 0.30 * np.exp(-d_near_metro / 250) + rng.normal(0, 0.06, n), 0.22, 0.75))
    gdp = np.clip(0.10 + 0.75 * urb + 0.15 * xy[:, 0] / 900 + rng.normal(0, 0.05, n), 0.1, 1.0)
    aging = np.clip(0.75 - 0.70 * urb + rng.normal(0, 0.10, n), 0.05, 0.95)
    d_sw = np.sqrt((xy ** 2).sum(1))          # HIV corridor in the south-west corner
    hiv0 = 0.0012 + 0.018 * np.exp(-d_sw / 300) * rng.uniform(0.7, 1.3, n)
    hiv_trend = rng.uniform(-0.04, 0.05, n)
    H0 = np.clip(0.28 + 0.60 * gdp + rng.normal(0, 0.04, n), 0.30, 0.90)
    H_growth = rng.uniform(0.006, 0.018, n)
    non_metro = np.where(~metro)[0]
    order = non_metro[np.argsort(H0[non_metro])]
    program = np.zeros(n, bool)
    program[order[:3]] = True
    mdr_seed = int(order[3])

    beta_loc = BETA_BASE * (0.70 + 0.50 * urb) * (1.90 - 1.50 * gdp) * np.exp(rng.normal(0, 0.20, n))
    eps = np.where(metro, 0.035, 0.04 + 0.12 * np.exp(-d_near_metro / 150))
    eps = np.minimum(eps * mobility_scale, 0.6)
    W = pop[None, :] ** 0.9 / (dist + 25.0) ** 2
    np.fill_diagonal(W, 0.0)
    W = W / W.sum(1, keepdims=True)
    pop_growth = np.where(metro, 0.012, rng.uniform(-0.004, 0.006, n))

    cand = [i for i in non_metro if not program[i] and i != mdr_seed]
    boom = int(min(cand, key=lambda i: dist[i, 13]))          # next to the eastern metro
    poor = [i for i in non_metro[np.argsort(gdp[non_metro])] if i != boom]
    origins = np.array(poor[:5])

    disrupt_2020 = np.where(metro, rng.uniform(0.40, 0.50, n), rng.uniform(0.25, 0.42, n))
    disrupt_2023 = rng.uniform(0.10, 0.22, n)
    disrupt_2026 = np.where(metro, rng.uniform(0.40, 0.50, n), rng.uniform(0.30, 0.45, n))

    codes = ["R%02d" % (i + 1) for i in range(n)]
    return World(codes, list(REGION_NAMES[:n]), xy, dist, pop, urb, gdp, aging, hiv0, hiv_trend,
                 H0, H_growth, program, beta_loc, eps, W, pop_growth, metro, boom, origins,
                 mdr_seed, disrupt_2020, disrupt_2023, disrupt_2026)


# ---- exogenous drivers ----------------------------------------------------------------
def _shock(t_years, start, peak, scale, decay_months):
    """Rise from `start` to `peak`, then exponential recovery; returns values in [0, 1]."""
    rise = np.clip((t_years - start) / max(peak - start, 1e-6), 0, 1)
    fall = np.exp(-np.clip(t_years - peak, 0, None) * 12 / decay_months)
    return scale * rise * fall * (t_years >= start)


def make_drivers(world, scenario):
    """Monthly covariate trajectories 2015-01..2029-12, shape [T, N]. Identical across
    scenarios before 2025."""
    T = C.N_OBS + C.N_FUTURE
    yrs = C.START_YEAR + (np.arange(T) + 0.5) / 12
    y = yrs[:, None]
    H = world.H0 + world.H_growth * (y - 2015) + 0.035 * world.program * np.clip(y - 2019.5, 0, None)
    if scenario == "enhanced_control":
        H = H + 0.05 * np.clip(y - 2025, 0, None)
    H = np.minimum(H, 0.97)
    hiv = world.hiv0 * np.exp(world.hiv_trend * (y - 2015))
    D = (_shock(y, 2020.08, 2020.25, world.disrupt_2020, 5.0)
         + _shock(y, 2022.92, 2023.04, world.disrupt_2023, 1.5))
    if scenario == "disruption":
        D = D + _shock(y, 2026.17, 2026.33, world.disrupt_2026, 8.0)
    D = np.clip(D, 0, 0.9)
    mob = (1 + 0.02 * (y - 2015)) * (1 - 0.8 * D)
    ramp = np.clip((yrs - 2018) / 2, 0, 1)
    mig_rate = 0.03 * ramp         # in-migration to the boom region, fraction of its pop / yr
    return dict(health_index=H, hiv_prevalence=hiv, service_disruption=D, mobility_index=mob,
                mig_rate=mig_rate, ramp=ramp)


# ---- mechanistic transmission model ---------------------------------------------------
def _new_state(world):
    n = C.N_REGIONS
    N = world.pop2015
    return dict(S=0.45 * N, Lf=np.stack([0.04 * N, np.zeros(n)]), Ls=np.stack([0.50 * N, np.zeros(n)]),
                I=np.stack([np.stack([0.002 * N, 0.002 * N, np.zeros(n)]), np.zeros((3, n))]),
                T=np.zeros((2, n)), R=np.stack([0.006 * N, np.zeros(n)]))


def _total(st):
    return st["S"] + st["Lf"].sum(0) + st["Ls"].sum(0) + st["I"].sum((0, 1)) + st["T"].sum(0) + st["R"].sum(0)


def _contact_matrix(world, mob):
    e = np.clip(world.eps * mob, 0, 0.5)
    return (1 - e)[:, None] * np.eye(len(e)) + e[:, None] * world.W


def _step_month(st, world, month, H, hiv, D, mob, z, boom_ramp, keep_pop_constant=False,
                beta_mult=1.0, det_mult=1.0):
    """Advance the state by one month. Returns expected notifications [2 strain, 3 source, N]."""
    dt = 1.0 / (12 * SUBSTEPS)
    Cm = _contact_matrix(world, mob)
    beta = (world.beta_loc * beta_mult * (1 + 0.06 * np.cos(2 * np.pi * (month - 1) / 12))
            * np.exp(z) * (1 - 0.3 * D))
    beta = beta.copy()
    beta[world.boom] *= 1 + 0.8 * boom_ramp                     # crowded worker dormitories
    det = det_mult * (0.4 + 2.6 * H) * DET_SEASON[month - 1] * (1 - D)
    nu = NU0 * (1 + 19 * hiv) * (1 + 0.6 * world.aging)
    epsf = EPS_F * (1 + 5 * hiv)
    mu_tb = MU_TB * (1 + 10 * hiv)
    succ = np.stack([0.80 + 0.16 * H, 0.35 + 0.35 * H])
    die = np.stack([0.065 - 0.04 * H + 0.5 * hiv, 0.16 - 0.06 * H + 0.5 * hiv])
    fail = 1 - succ - die
    notif = np.zeros((2, 3, C.N_REGIONS))
    S, Lf, Ls, I, T, R = st["S"], st["Lf"], st["Ls"], st["I"], st["T"], st["R"]
    for _ in range(SUBSTEPS):
        N = S + Lf.sum(0) + Ls.sum(0) + I.sum((0, 1)) + T.sum(0) + R.sum(0)
        Iinf = I.sum(1)                                   # [2, N]
        prev = (Iinf @ Cm) / (Cm.T @ N)                   # prevalence at each location
        lam = (beta * FITNESS[:, None] * prev) @ Cm.T     # force of infection on residents [2, N]
        inf_S = lam * S
        inf_Ls = X_REINF * lam[:, None, :] * Ls[None, :, :]   # [s_new, s_old, N]
        inf_R = X_REINF * lam[:, None, :] * R[None, :, :]
        prog = epsf * Lf
        stab = OMEGA * Lf
        react = nu * Ls
        relapse = RELAPSE * R
        detect = det * I
        tb_death = mu_tb * I
        cure = SELF_CURE * I
        t_exit = TAU[:, None] * T
        fail_flow = fail * t_exit
        to_mdr = ACQ_RES * fail_flow[0]
        dead_total = MU * N + tb_death.sum((0, 1)) + (die * t_exit).sum(0)

        dS = -inf_S.sum(0) - MU * S
        dLf = inf_S + inf_Ls.sum(1) + inf_R.sum(1) - prog - stab - MU * Lf
        dLs = stab - inf_Ls.sum(0) - react - MU * Ls
        dI = -detect - tb_death - cure - MU * I
        dI[:, 0] += prog
        dI[:, 1] += react
        dI[:, 2] += relapse + fail_flow
        dI[0, 2] -= to_mdr
        dI[1, 2] += to_mdr
        dT = detect.sum(1) - t_exit - MU * T
        dR = succ * t_exit + cure.sum(1) - inf_R.sum(0) - relapse - MU * R
        births = dead_total if keep_pop_constant else (MU + world.pop_growth) * N
        dS = dS + births

        S = S + dt * dS
        Lf = Lf + dt * dLf
        Ls = Ls + dt * dLs
        I = I + dt * dI
        T = T + dt * dT
        R = R + dt * dR
        notif += dt * detect
    st.update(S=S, Lf=Lf, Ls=Ls, I=I, T=T, R=R)
    return notif


def _migrate(st, world, mig_rate):
    """Labour migration (one month) from the origin regions into the boom region."""
    if mig_rate <= 0:
        return np.zeros(C.N_REGIONS)
    N = _total(st)
    movers = mig_rate / 12 * N[world.boom]
    share = N[world.origins] / N[world.origins].sum()
    frac_out = np.zeros(C.N_REGIONS)
    frac_out[world.origins] = movers * share / N[world.origins]
    net = np.zeros(C.N_REGIONS)
    for key in ("S", "Lf", "Ls", "I", "T", "R"):
        x = st[key]
        out = x * frac_out                 # broadcasts over leading axes
        x = x - out
        x[..., world.boom] += out.sum(-1)
        st[key] = x
    net[world.origins] -= movers * share
    net[world.boom] += movers
    return net


def burn_in(world, years=100):
    """Historical period 1915-2014 with declining transmission and the arrival of
    case finding/chemotherapy, so that 2015 starts on a realistic secular decline."""
    st = _new_state(world)
    for k in range(years * 12):
        yr = C.START_YEAR - years + k / 12
        beta_mult = 1 + 1.2 * max(0.0, (C.START_YEAR - yr) / years)
        det_mult = float(np.clip(0.1 + 0.9 * (yr - 1945) / 70, 0.1, 1.0))
        hiv = world.hiv0 * np.clip((yr - 1985) / 30, 0, 1)
        _step_month(st, world, k % 12 + 1, world.H0, hiv, 0.0, 1.0, 0.0, 0.0,
                    keep_pop_constant=True, beta_mult=beta_mult, det_mult=det_mult)
    return st


def run_period(st, world, drv, t0, t1, z):
    """Simulate months t0..t1-1 (indices since 2015-01). Returns monthly expected
    notifications [T, 2, 3, N], population [T, N], net migration rate [T, N] and
    TB prevalence diagnostics."""
    out = dict(notif=[], pop=[], net_mig=[], prev=[], mdr_prev=[])
    for t in range(t0, t1):
        if t == MDR_SEED_MONTH:                         # imported MDR cluster, April 2016
            st["I"][1, 0, world.mdr_seed] += 40
            st["Lf"][1, world.mdr_seed] += 800
        N_before = _total(st)
        net = _migrate(st, world, drv["mig_rate"][t])
        notif = _step_month(st, world, t % 12 + 1, drv["health_index"][t], drv["hiv_prevalence"][t],
                            drv["service_disruption"][t], drv["mobility_index"][t], z[t], drv["ramp"][t])
        out["notif"].append(notif)
        out["pop"].append(_total(st))
        out["net_mig"].append(net * 12 / N_before)     # annualised
        out["prev"].append(st["I"].sum((0, 1)) / _total(st))
        out["mdr_prev"].append(st["I"][1].sum(0) / st["I"].sum((0, 1)))
    return {k: np.array(v) for k, v in out.items()}


def ar1_noise(rng, T, n, rho=0.85, sigma=0.05):
    z = np.zeros((T, n))
    for t in range(1, T):
        z[t] = rho * z[t - 1] + rng.normal(0, sigma, n)
    return z


# ---- individual patient records -------------------------------------------------------
def _categorical(rng, probs):
    """Vectorised draw from rows of a probability matrix."""
    cum = probs.cumsum(1)
    cum /= cum[:, -1:]
    return (rng.random((probs.shape[0], 1)) > cum).sum(1)


def sample_patients(rng, t, region, strain, source, world, drv, migrant_share):
    """Draw individual attributes and outcomes for the cases notified in month t."""
    n = len(region)
    year = C.START_YEAR + t // 12
    month = t % 12 + 1
    H = drv["health_index"][t][region]
    hiv_p = drv["hiv_prevalence"][t][region]
    urb, gdp, aging = world.urb[region], world.gdp[region], world.aging[region]
    yrs = year - 2015

    # --- age: recent transmission -> young adults & children, reactivation -> elderly
    age = np.empty(n)
    rec, rem, ret = source == 0, source == 1, source == 2
    p_child = 0.05 + 0.08 * (1 - gdp)
    child = rec & (rng.random(n) < p_child)
    band = rng.choice([0, 5, 10], size=n, p=[0.4, 0.2, 0.4])
    age[child] = band[child] + rng.integers(0, 5, n)[child]
    adult = rec & ~child
    age[adult] = 15 + rng.gamma(2.0, 10.0, n)[adult]
    age[rem] = 22 + rng.gamma(5.5, 6.5, n)[rem] + 0.25 * yrs + 6 * aging[rem]
    age[ret] = 18 + rng.gamma(4.0, 8.5, n)[ret] + 0.20 * yrs
    age = np.clip(np.floor(age), 0, 99).astype(int)

    p_male = np.where(age < 15, 0.52, np.where(rec, 0.64, np.where(rem, 0.72, 0.75)))
    male = rng.random(n) < p_male

    # --- HIV status (relative risk of TB among PLHIV ~20)
    rr = np.where(age < 15, 5.0, np.where(age >= 60, 8.0, 20.0))
    p_hiv = rr * hiv_p / (1 + (rr - 1) * hiv_p)
    hiv_pos = rng.random(n) < p_hiv
    tested = rng.random(n) < 0.60 + 0.38 * H
    hiv_status = np.where(~tested, "Unknown", np.where(hiv_pos, "Positive", "Negative"))

    # --- occupation
    migrant_p = np.clip(1.8 * migrant_share[region] + 0.02 * urb, 0, 0.6)
    w = np.zeros((n, len(OCCUPATIONS)))
    working = (age >= 19) & (age < 65)
    w[:, 2] = 1.6 * (1 - urb) * (1 + 0.3 * (age > 45))
    w[:, 3] = 0.55 * urb + 0.15
    w[:, 5] = 0.50 * urb + 0.10
    w[:, 6] = 0.35 * urb * gdp
    w[:, 7] = 0.025
    w[:, 8] = np.where(male, 0.02, 0.30)
    w[:, 9] = 0.18 * (1.3 - gdp)
    w[:, 1] = np.where(age <= 22, 0.6, 0.0)
    w = np.where(working[:, None], w, 0.0)
    w = w / np.maximum(w.sum(1, keepdims=True), 1e-12)
    is_mig = working & (age < 50) & (rng.random(n) < migrant_p)
    w[is_mig] = 0.0
    w[is_mig, 4] = 1.0
    old = age >= 65
    w[old] = 0.0
    w[old, 10] = 0.35 + 0.50 * urb[old]
    w[old, 2] = 0.60 * (1 - urb[old])
    w[old, 8] = np.where(male[old], 0.02, 0.10)
    w[old, 9] = 0.05
    young = age < 19
    w[young] = 0.0
    w[young, 1] = 0.92
    w[young, 2] = 0.03
    w[young, 5] = 0.03
    w[young, 9] = 0.02
    w[age < 7] = 0.0
    w[age < 7, 0] = 1.0
    occ = _categorical(rng, w)
    migrant = occ == 4
    unemployed = occ == 9

    # --- diagnosis
    p_extra = 0.14 + 0.15 * hiv_pos + 0.10 * (age < 15)
    extra = rng.random(n) < p_extra
    p_bact = np.where(age < 15, 0.25, 0.40 + 0.45 * H)
    bact = ~extra & (rng.random(n) < p_bact)
    diag = np.where(extra, "Extrapulmonary",
                    np.where(bact, "Pulmonary, bacteriologically confirmed", "Pulmonary, clinically diagnosed"))
    mdr_true = strain == 1
    dst_done = bact & (rng.random(n) < 0.45 + 0.50 * H + 0.20 * ret)
    mdr_found = dst_done & mdr_true & (rng.random(n) < 0.95)
    resistance = np.where(~dst_done, "Not tested", np.where(mdr_found, "RR/MDR-TB", "Drug-susceptible"))
    mdr_missed = mdr_true & ~mdr_found
    prev_treated = ret

    # --- treatment outcome: multinomial logit relative to success
    hc = H - 0.6
    logit = np.zeros((n, 5))
    logit[:, 1] = (-3.6 + 1.3 * (age >= 65) + 0.6 * ((age >= 45) & (age < 65)) + 1.6 * hiv_pos
                   + 0.4 * (hiv_status == "Unknown") + 0.25 * male + 0.4 * prev_treated
                   + 1.1 * mdr_true - 2.0 * hc + 0.3 * extra)
    logit[:, 2] = -4.3 + 1.6 * mdr_found + 2.8 * mdr_missed + 0.5 * prev_treated - 1.0 * hc + 0.2 * hiv_pos
    logit[:, 3] = (-3.4 + 1.1 * migrant + 0.5 * (male & (age >= 15) & (age < 45)) + 0.5 * unemployed
                   + 0.7 * mdr_found + 0.3 * prev_treated - 1.8 * hc)
    logit[:, 4] = -4.2 + 0.9 * migrant - 0.5 * hc
    p = np.exp(logit - logit.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    oc = _categorical(rng, p)

    # --- dates
    days_in_month = pd.Period(year=year, month=month, freq="M").days_in_month
    diag_date = pd.Timestamp(year=year, month=month, day=1) + pd.to_timedelta(rng.integers(0, days_in_month, n), "D")
    short_mdr = (year >= 2020) & (rng.random(n) < 0.6)
    regimen = np.where(mdr_found, np.where(short_mdr, "MDR short regimen", "MDR long regimen"),
                       np.where(prev_treated, "Retreatment regimen", "Standard 6-month (2HRZE/4HR)"))
    full = np.where(mdr_found, np.where(short_mdr, rng.integers(270, 340, n), rng.integers(540, 721, n)),
                    rng.integers(180, 241, n))
    dur = np.where(oc == 0, full,
                   np.where(oc == 1, np.minimum(rng.exponential(60, n).astype(int) + 3, full),
                            np.where(oc == 2, (full * rng.uniform(0.7, 1.0, n)).astype(int),
                                     np.where(oc == 3, (full * rng.uniform(0.15, 0.8, n)).astype(int),
                                              rng.integers(15, 151, n)))))
    outcome = np.array(OUTCOMES, dtype=object)[oc]
    outcome[(oc == 0) & bact] = "Cured"
    outcome[(oc == 0) & ~bact] = "Treatment completed"

    residence = np.where(rng.random(n) < np.clip(urb + 0.25 * np.isin(occ, [3, 4, 5, 6]) - 0.3 * (occ == 2), 0.02, 0.98),
                         "Urban", "Rural")
    age_group = np.where(age < 15, "0-14", np.where(age < 45, "15-44", np.where(age < 65, "45-64", "65+")))
    return pd.DataFrame(dict(
        region_code=np.array(world.codes)[region], region_name=np.array(world.names)[region],
        diagnosis_date=diag_date, sex=np.where(male, "Male", "Female"), age=age, age_group=age_group,
        occupation=np.array(OCCUPATIONS)[occ], residence=residence,
        patient_type=np.where(prev_treated, "Previously treated", "New"),
        diagnosis=diag, hiv_status=hiv_status, drug_resistance=resistance, regimen=regimen,
        outcome=outcome, outcome_date=diag_date + pd.to_timedelta(dur, "D"), treatment_days=dur,
    ))


def notify(rng, notif_mean, dispersion=100.0):
    """Observed notifications: negative-binomial counts, split by strain/source."""
    T = notif_mean.shape[0]
    cases = []
    for t in range(T):
        lam = notif_mean[t].sum((0, 1))
        total = rng.poisson(rng.gamma(dispersion, lam / dispersion))
        split = np.zeros((2, 3, C.N_REGIONS), int)
        for i in range(C.N_REGIONS):
            p = notif_mean[t, :, :, i].ravel()
            split[:, :, i] = rng.multinomial(total[i], p / p.sum()).reshape(2, 3)
        cases.append(split)
    return np.array(cases)


def expand_records(rng, split_counts, t_offset, world, drv, migrant_share):
    frames = []
    for k in range(split_counts.shape[0]):
        t = t_offset + k
        s_idx, src_idx, r_idx = np.nonzero(split_counts[k])
        reps = split_counts[k][s_idx, src_idx, r_idx]
        strain = np.repeat(s_idx, reps)
        source = np.repeat(src_idx, reps)
        region = np.repeat(r_idx, reps)
        frames.append(sample_patients(rng, t, region, strain, source, world, drv, migrant_share[t]))
    return pd.concat(frames, ignore_index=True)


def migrant_stock(net_mig, pop):
    """Share of the population that arrived as labour migrants within the last 5 years."""
    T = net_mig.shape[0]
    inflow = np.clip(net_mig, 0, None) / 12 * pop          # people per month
    stock = np.zeros_like(inflow)
    for t in range(T):
        stock[t] = inflow[max(0, t - 59):t + 1].sum(0) / pop[t]
    return stock

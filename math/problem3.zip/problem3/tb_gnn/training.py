"""Training with early stopping, prediction, and parallel ensemble jobs."""
import copy
import dataclasses
import time

import numpy as np
import torch

from . import config as C
from .features import FeatureBuilder, make_windows, split_origins, transition_matrix
from .models import TBSTGNN, loss_fn
from .panel import load_observed


def build_model(panel, fb, cfg):
    mob = torch.tensor(transition_matrix(panel.od), dtype=torch.float32)
    return TBSTGNN(len(panel.codes), fb.n_enc, fb.n_dec, cfg, mob)


def _forward(model, w, idx=None):
    sl = slice(None) if idx is None else idx
    return model(w["enc"][sl], w["dec"][sl], w["a_cnt"][sl], w["a_cmp"][sl])


def evaluate_loss(model, w, cfg):
    model.eval()
    with torch.no_grad():
        lr, cl = _forward(model, w)
        return float(loss_fn(lr, cl, w["y_cnt"], w["y_cmp"], cfg.comp_weight))


def train_model(panel, fb, cfg, train_w, val_w=None, seed=0, epochs=None):
    """Adam + early stopping on validation loss. If val_w is None, train for `epochs`."""
    torch.manual_seed(seed)
    model = build_model(panel, fb, cfg)
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    n = train_w["enc"].shape[0]
    g = torch.Generator().manual_seed(seed)
    max_ep = epochs or cfg.max_epochs
    best, best_ep, best_state, hist = np.inf, 0, None, []
    for ep in range(1, max_ep + 1):
        model.train()
        perm = torch.randperm(n, generator=g)
        tr = 0.0
        for i in range(0, n, cfg.batch_size):
            idx = perm[i:i + cfg.batch_size]
            lr, cl = _forward(model, train_w, idx)
            loss = loss_fn(lr, cl, train_w["y_cnt"][idx], train_w["y_cmp"][idx], cfg.comp_weight)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            tr += loss.item() * len(idx) / n
        if val_w is None:
            hist.append((ep, tr, np.nan))
            continue
        vl = evaluate_loss(model, val_w, cfg)
        hist.append((ep, tr, vl))
        if vl < best - 1e-4:
            best, best_ep, best_state = vl, ep, copy.deepcopy(model.state_dict())
        elif ep - best_ep >= cfg.patience:
            break
    if val_w is not None:
        model.load_state_dict(best_state)
    else:
        best_ep = max_ep
    model.eval()
    return model, dict(best_epoch=best_ep, best_val=best, history=np.array(hist))


def predict(model, w):
    """Mean counts [B, H, N, 3] and composition probabilities [B, H, N, 8]."""
    model.eval()
    with torch.no_grad():
        lr, cl = _forward(model, w)
    return torch.exp(lr).numpy(), torch.softmax(cl, -1).numpy()


def run_job(job):
    """Worker: one (variant, seed) model. mode 'eval' trains on train/val and predicts the
    test windows; mode 'final' retrains on all observed data for `epochs` epochs."""
    torch.set_num_threads(1)
    variant, seed, mode, epochs = job["variant"], job["seed"], job["mode"], job.get("epochs")
    cfg = dataclasses.replace(C.MODEL_VARIANTS[variant], **job.get("overrides", {}))
    tag = job.get("tag", "")
    data_dir = job.get("data_dir", C.DATA_DIR)
    panel = load_observed(data_dir)
    t = time.time()
    orig = split_origins(cfg)
    if mode == "eval":
        fb = FeatureBuilder(panel, C.TRAIN_END)
        tr, va, te = (make_windows(fb, panel, orig[k], cfg) for k in ("train", "val", "test"))
        model, info = train_model(panel, fb, cfg, tr, va, seed=seed)
        mu, comp = predict(model, te)
        mu_val, _ = predict(model, va)
        out = dict(test_mu=mu, test_comp=comp, val_mu=mu_val)
        if cfg.use_adaptive:
            out["adaptive_adj"] = model.adaptive_adjacency().detach().numpy()
    else:
        fb = FeatureBuilder(panel, C.TEST_END)
        full = make_windows(fb, panel, orig["full"], cfg)
        model, info = train_model(panel, fb, cfg, full, None, seed=seed, epochs=epochs)
        out = {}
    if job.get("save", True):
        C.MODEL_DIR.mkdir(parents=True, exist_ok=True)
        torch.save(model.state_dict(), C.MODEL_DIR / ("%s%s_seed%d_%s.pt" % (variant, tag, seed, mode)))
    out.update(variant=variant, seed=seed, mode=mode, best_epoch=info["best_epoch"],
               best_val=info["best_val"], history=info["history"], seconds=time.time() - t,
               n_params=sum(p.numel() for p in model.parameters()))
    return out


def load_model(variant, seed, mode, panel, fb, overrides=None, tag=""):
    model = build_model(panel, fb, dataclasses.replace(C.MODEL_VARIANTS[variant], **(overrides or {})))
    model.load_state_dict(torch.load(C.MODEL_DIR / ("%s%s_seed%d_%s.pt" % (variant, tag, seed, mode))))
    model.eval()
    return model

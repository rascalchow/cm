# Optimal sampling and Christoffel functions on general domains

Reference implementation of the numerical experiments of Section 6 of:

> M. Dolbeault and A. Cohen,
> *Optimal sampling and Christoffel functions on general domains*,
> arXiv:2010.11040 (2020).

The paper does not ship with an open-source code release. This repository
provides a from-scratch Python 3.11 implementation that reproduces the
qualitative behaviour of all five figures of §6:

* **Figure 1** – the three test domains (disc, polygon, cusp) and the
  normalised inverse Christoffel function `k_n / n` for `n = 231`
  (total degree `ℓ = 20`, bivariate algebraic polynomials).
* **Figure 2** – conditioning of the offline Gramian `G_M` versus
  `(n, M)`, with the theoretical sufficient budget `M_suf(n)` and an
  adjusted budget `M_adj(n)`.
* **Figure 3** – conditioning of the empirically computable test matrix
  `T` and the empirical budget `M_emp(n)` (smallest `M` such that
  `κ(T) ≤ 3`).
* **Figure 4** – conditioning of the online Gramian `G` for both the
  optimal sampling measure `σ*` and the perturbed measure `σ̃`.
* **Figure 5** – mean-square reconstruction error of the weighted
  least-squares estimator for the three sampling measures
  `μ`, `σ*`, `σ̃`, against the best-approximation benchmark.

## Mathematical setting

For a domain `D ⊂ [-1,1]^2` with uniform probability measure `μ` and the
linear space `V_n` of bivariate polynomials of total degree `ℓ`, we denote
by `(L_j)_{j=1}^n` an L²(D, μ) orthonormal basis. The inverse Christoffel
function is

```
k_n(x) = Σ_{j=1}^n |L_j(x)|².
```

The **offline stage** (Algorithm 1 of the paper) draws `M` points
`z^1,…,z^M ∼ μ`, builds an orthonormal basis `(L̃_j)` with respect to the
empirical inner product, and yields the perturbed inverse Christoffel
function `k̃_n(x) = Σ |L̃_j(x)|²` together with the sampling density
`σ̃ = (k̃_n / n) μ`.

The **online stage** draws `m` points from `σ̃` (or from `σ*` for the
ideal benchmark) and solves the weighted least-squares problem with
weights `w̃ = n / k̃_n` (resp. `w* = n / k_n`).

## Domains

All three domains live inside `[-1,1]^2` and have area 2, so the uniform
probability measure has density `1/2`.

| Name    | Definition                                       |
|---------|--------------------------------------------------|
| `disc`  | `x₁² + x₂² ≤ 2/π` (smooth boundary)              |
| `polygon` | `-1 ≤ x₁ ≤ 1`, `|x₁| - 1 ≤ x₂ ≤ |x₁|`          |
| `cusp`  | `-1 ≤ x₁ ≤ 1`, `√|x₁| - 1 ≤ x₂ ≤ √|x₁|`         |

Monomial moments `∫_D x^a y^b dμ(x,y)` are computed analytically – see
`optimal_sampling.moments`. This is what makes "exact" orthonormal bases
(used as ground truth) computable.

## Repository layout

```
optimal_sampling/
    domains.py        # the three test domains
    moments.py        # analytical monomial moments
    basis.py          # graded total-degree polynomial basis
    christoffel.py    # exact and offline Christoffel functions
    sampling.py       # rejection sampling from σ* and σ̃
    least_squares.py  # weighted least-squares reconstruction
experiments/
    fig1_christoffel.py
    fig2_offline_conditioning.py
    fig3_empirical_M.py
    fig4_online_conditioning.py
    fig5_reconstruction_error.py
    run_all.py
```

## Usage

The code is pure Python and runs unchanged on **Linux, macOS, and Windows**
with Python 3.11+. The only OS-specific bits are how you create the
virtual-env and how you set `PYTHONPATH` for the experiment scripts.

### Linux / macOS (bash, zsh)

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt

# A single figure
PYTHONPATH=. python -m experiments.fig1_christoffel

# All five figures (figures land in ./figures/)
PYTHONPATH=. python -m experiments.run_all
```

### Windows (PowerShell)

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt

$env:PYTHONPATH = "."
python -m experiments.fig1_christoffel
python -m experiments.run_all
```

### Windows (cmd.exe)

```bat
py -3.11 -m venv .venv
.venv\Scripts\activate.bat
pip install -r requirements.txt

set PYTHONPATH=.
python -m experiments.fig1_christoffel
python -m experiments.run_all
```

Each script accepts CLI arguments to tune the experiment cost
(`--ell-max`, `--n-trials`, `--M-grid-points`, ...). Defaults are kept
moderate so the full suite finishes in a few minutes on a laptop.
Pushing `ℓ_max = 20` (the paper's value) requires good orthonormalisation
conditioning and is computationally heavier; use `--ell-max 12` or so for
a quick smoke test.

### Cross-platform notes

* Output figures are written to `./figures/` and the docx report to
  `./REPORT.docx` using `pathlib.Path` — no hard-coded POSIX separators.
* Matplotlib's cache directory defaults to the system temp folder (via
  `tempfile.gettempdir()`), so the import works on every OS even when
  `%APPDATA%` / `$HOME` is not configured.
* No subprocess, shell-out, `fork`, `signal`, or POSIX-only modules are
  used anywhere in the library or the experiment scripts.

## Numerical notes

* All polynomial bases are **Chebyshev-preconditioned**: monomials are
  replaced by tensor products `T_{α₁}(x₁) T_{α₂}(x₂)` graded by total
  degree `α₁ + α₂`. The Gramian in this basis is much better
  conditioned on `[-1,1]²` than the monomial Gramian, which lets
  double-precision Cholesky reach degrees up to roughly `ℓ ≈ 15`.
  The paper used quadruple precision to push to `ℓ = 20`.
* The exact orthonormal basis `(L_j)` is obtained by Cholesky of the
  exact Gram matrix in the Chebyshev basis. The approximate basis
  `(L̃_j)` is obtained by Cholesky of the empirical Gram matrix
  *expressed in the exact basis* – this keeps the conditioning under
  control.
* Rejection sampling from `σ̃ ∝ k̃_n μ` and `σ* ∝ k_n μ` uses the
  uniform proposal on `D` together with the upper bound `k_n ≤ n B(n)`
  – or, more efficiently, the empirical maximum of the density over a
  large pool of uniform draws.

## License

MIT.

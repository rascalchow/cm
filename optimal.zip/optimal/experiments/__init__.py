"""Experiment scripts reproducing Figures 1-5 of the paper."""

"""Helpers shared across figure scripts."""

from __future__ import annotations

import os
import pathlib
import tempfile
from contextlib import contextmanager

import numpy as np

from optimal_sampling import ALL_DOMAINS, Domain, GradedChebyshevBasis
from optimal_sampling.basis import n_of_ell

# Ensure matplotlib can write its cache on every OS. We pick a writable
# directory inside the system temp folder so the import works on Windows,
# macOS and Linux even when the user has no $HOME / %APPDATA% configured.
os.environ.setdefault(
    "MPLCONFIGDIR", str(pathlib.Path(tempfile.gettempdir()) / "matplotlib")
)
pathlib.Path(os.environ["MPLCONFIGDIR"]).mkdir(parents=True, exist_ok=True)

import matplotlib  # noqa: E402

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

FIGURES_DIR = pathlib.Path(__file__).resolve().parent.parent / "figures"
FIGURES_DIR.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# Theoretical envelopes B(n)
# ---------------------------------------------------------------------------
def theoretical_envelope(domain: Domain, n: int) -> float:
    """Upper-bound ``B(n) >= K_n = ||k_n||_inf`` from §5 of the paper.

    * Disc: ``3 n^{3/2}``  (eq. (5.26)).
    * Polygon: ``2 n^2``  (Proposition 5.2 with beta=1/2).
    * Cusp: ``C n^3``  (Theorem 5.9 with alpha_1=1/2).
      The constant ``C`` is extremely pessimistic in practice; we use
      ``C = 6`` (the value found in the paper's discussion).
    """
    if domain.name == "disc":
        return 3.0 * n ** 1.5
    if domain.name == "polygon":
        return 2.0 * n ** 2
    if domain.name == "cusp":
        return 6.0 * n ** 3
    raise ValueError(domain.name)


# ---------------------------------------------------------------------------
# Sufficient offline budget M_suf(n) = gamma B(n) ln(2 n / eps)
# ---------------------------------------------------------------------------
GAMMA = 4.0  # the constant from Lemma 2.1; gamma = 4 is the textbook value


def m_sufficient(domain: Domain, n: int, eps: float = 1e-2) -> float:
    return GAMMA * theoretical_envelope(domain, n) * np.log(2.0 * n / eps)


# ---------------------------------------------------------------------------
# Plotting utilities
# ---------------------------------------------------------------------------
@contextmanager
def figure(nrows: int = 1, ncols: int = 1, figsize=(12, 4)):
    fig, axes = plt.subplots(nrows=nrows, ncols=ncols, figsize=figsize)
    axes_arr = np.atleast_1d(axes)
    if axes_arr.ndim == 1:
        axes_arr = axes_arr.reshape((nrows, ncols))
    yield fig, axes_arr
    plt.close(fig)


def savefig(fig, name: str) -> pathlib.Path:
    out = FIGURES_DIR / name
    fig.tight_layout()
    fig.savefig(out, dpi=140, bbox_inches="tight")
    return out


# ---------------------------------------------------------------------------
# Misc utilities
# ---------------------------------------------------------------------------
def grid_inside(domain: Domain, resolution: int = 320) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return (X1, X2, mask) for plotting on ``[-1, 1]^2``."""
    g = np.linspace(-1.0, 1.0, resolution)
    X1, X2 = np.meshgrid(g, g)
    pts = np.column_stack([X1.ravel(), X2.ravel()])
    mask = domain.contains(pts).reshape(X1.shape)
    return X1, X2, mask


def cond_psd(M: np.ndarray) -> float:
    """Symmetric-positive-definite condition number, ill-conditioned safe."""
    M_sym = 0.5 * (M + M.T)
    w = np.linalg.eigvalsh(M_sym)
    w_min = max(w.min(), 1e-300)
    return float(w.max() / w_min)

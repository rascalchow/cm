"""Figure 1: the three test domains and ``k_n / n`` for ``n = n_max``.

Reproduces Figure 1 of the paper (page 30): three side-by-side panels
(disc, polygon, cusp) showing the inverse Christoffel function divided
by ``n``, computed exactly via Cholesky on the analytical Gram matrix.

Defaults to ``ell = 15`` (``n = 136``) for runtime; pass ``--ell 20``
to recreate the paper's setting (``n = 231``) – this requires that the
double-precision Cholesky stays well-defined, which is on the edge for
the most singular domain.
"""

from __future__ import annotations

import argparse

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    exact_orthonormaliser,
    inverse_christoffel,
)

from ._common import figure, grid_inside, savefig


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ell", type=int, default=15, help="total polynomial degree")
    p.add_argument("--resolution", type=int, default=320, help="plot grid resolution")
    p.add_argument("--vmax", type=float, default=None, help="colour scale upper bound")
    return p.parse_args()


def main() -> None:
    args = parse_args()

    with figure(nrows=1, ncols=3, figsize=(13, 4.4)) as (fig, axes):
        for ax_row in axes:
            for ax, dom in zip(ax_row, ALL_DOMAINS):
                basis = GradedChebyshevBasis(dom.name, args.ell)
                orth = exact_orthonormaliser(basis)
                X1, X2, mask = grid_inside(dom, resolution=args.resolution)
                pts = np.column_stack([X1.ravel(), X2.ravel()])
                k = inverse_christoffel(basis, orth, pts).reshape(X1.shape)
                k_over_n = k / basis.n
                k_over_n = np.where(mask, k_over_n, np.nan)

                vmax = args.vmax if args.vmax is not None else float(np.nanpercentile(k_over_n, 99.5))
                im = ax.imshow(
                    k_over_n,
                    origin="lower",
                    extent=(-1, 1, -1, 1),
                    aspect="equal",
                    cmap="viridis",
                    vmin=0.0,
                    vmax=vmax,
                )
                ax.set_title(f"{dom.name} – n = {basis.n}, max(k_n/n) = {np.nanmax(k_over_n):.2f}")
                ax.set_xticks([-1, 0, 1])
                ax.set_yticks([-1, 0, 1])
                fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

        fig.suptitle(f"Inverse Christoffel function $k_n / n$ (total degree $\\ell = {args.ell}$)")
        out = savefig(fig, "fig1_christoffel.png")
    print(f"saved {out}")


if __name__ == "__main__":
    main()

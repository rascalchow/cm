"""Figure 2: conditioning of the offline Gramian ``G_M``.

For each domain, total degree ``ell``, and offline budget ``M``, we
estimate ``E_z [ kappa(G_M) ]`` over ``n_trials`` realisations, where

    ``G_M[j, k] = (1 / M) sum_i L_j(z^i) L_k(z^i)``

and ``(L_j)`` is the **exact** orthonormal basis of ``V_n`` (so that
``E_mu [G_M] = I``). The resulting heatmap is overlaid with the
theoretical sufficient budget ``M_suf(n)`` and an empirically adjusted
``M_adj(n) = C_adj * M_suf(n)`` chosen so that ``kappa(G_M) <= 3``.
"""

from __future__ import annotations

import argparse

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    exact_orthonormaliser,
)

from ._common import (
    cond_psd,
    figure,
    m_sufficient,
    savefig,
)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ell-max", type=int, default=8)
    p.add_argument("--n-trials", type=int, default=10)
    p.add_argument("--M-grid-points", type=int, default=14)
    p.add_argument("--M-max-mult", type=float, default=2.0,
                   help="largest M as multiple of M_suf for the polygon at ell_max")
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--threshold", type=float, default=3.0)
    p.add_argument("--saturation", type=float, default=10.0)
    return p.parse_args()


def cond_grid_for_domain(
    dom_name: str,
    n_values: list[int],
    M_values: np.ndarray,
    n_trials: int,
    rng: np.random.Generator,
) -> np.ndarray:
    """Compute mean ``kappa(G_M)`` over a grid in (n, M)."""
    ell_max = max((int(np.ceil((-3 + np.sqrt(1 + 8 * n)) / 2)) for n in n_values))
    basis = GradedChebyshevBasis(dom_name, ell_max)
    orth = exact_orthonormaliser(basis)
    # Pre-build the Cheb evaluation matrix lazily for efficiency.
    out = np.full((len(n_values), len(M_values)), np.nan)
    M_max = int(M_values.max())

    for trial in range(n_trials):
        from optimal_sampling import ALL_DOMAINS

        dom = next(d for d in ALL_DOMAINS if d.name == dom_name)
        Z = dom.sample_uniform(M_max, rng)
        L = orth.evaluate(basis, Z)  # (M_max, n_max)
        for jM, M in enumerate(M_values):
            sub = L[: int(M)]
            for jn, n in enumerate(n_values):
                A = sub[:, :n]
                G_M = (A.T @ A) / M
                k = cond_psd(G_M)
                if np.isnan(out[jn, jM]):
                    out[jn, jM] = 0.0
                out[jn, jM] += k / n_trials
    return out


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)

    n_values = [n for ell in range(args.ell_max + 1) for n in [(ell + 1) * (ell + 2) // 2]]
    n_values = sorted(set(n_values))
    n_max = max(n_values)

    # Sets of M values: log-spaced between n_max and M_max
    M_max_polygon = max(int(args.M_max_mult * m_sufficient(ALL_DOMAINS[1], n_max)), 4 * n_max)
    M_min = n_max
    M_values = np.unique(
        np.round(np.geomspace(M_min, M_max_polygon, args.M_grid_points)).astype(int)
    )

    with figure(nrows=1, ncols=3, figsize=(15, 4.4)) as (fig, axes):
        for ax, dom in zip(axes[0], ALL_DOMAINS):
            print(f"[fig2] domain={dom.name} n_max={n_max} M_max={M_values.max()} ...")
            grid = cond_grid_for_domain(
                dom.name, n_values, M_values, args.n_trials, rng
            )
            grid_clip = np.minimum(grid, args.saturation)
            im = ax.pcolormesh(
                n_values,
                M_values,
                grid_clip.T,
                shading="auto",
                cmap="viridis_r",
                vmin=1.0,
                vmax=args.saturation,
            )
            # Theoretical sufficient curve M_suf(n)
            ns = np.linspace(min(n_values), max(n_values), 200)
            M_suf = np.array([m_sufficient(dom, n_) for n_ in ns])
            ax.plot(ns, M_suf, "r-", lw=2, label=r"$M_\mathrm{suf}(n)$")
            # Adjusted curve: smallest constant C_adj so that
            # mean kappa(G_M) <= threshold for all observed n.
            adj = []
            for jn, n_ in enumerate(n_values):
                col = grid[jn, :]
                ok = M_values[col <= args.threshold]
                adj.append((n_, ok.min()) if ok.size else (n_, np.nan))
            adj = np.asarray(adj)
            ax.plot(adj[:, 0], adj[:, 1], "w--", lw=2, label=r"$M_\mathrm{adj}(n)$")
            ax.set_yscale("log")
            ax.set_xlabel("n")
            ax.set_ylabel("M")
            ax.set_title(f"{dom.name}: $\\kappa(G_M)$ (clipped at {args.saturation:g})")
            ax.legend(loc="lower right", framealpha=0.7)
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        out = savefig(fig, "fig2_offline_conditioning.png")
    print(f"saved {out}")


if __name__ == "__main__":
    main()

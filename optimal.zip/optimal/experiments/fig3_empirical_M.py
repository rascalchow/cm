"""Figure 3: empirically computable test matrix ``T`` and budget ``M_emp``.

For each offline budget ``M``, draw two independent samples
``(y^i)_{i=1}^M`` and ``(z^i)_{i=1}^M`` from ``mu``, build the
orthonormal basis ``L^y`` of ``V_n`` w.r.t. the empirical inner product
on ``y``, and form

    ``T = (L^y_j, L^y_k)_z``.

Plot the mean ``kappa(T)`` as a function of ``(n, M)``, and the empirical
budget ``M_emp(n) = min { M : kappa(T) <= 3 }``.
"""

from __future__ import annotations

import argparse

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    sample_orthonormaliser,
)

from ._common import cond_psd, figure, m_sufficient, savefig


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ell-max", type=int, default=8)
    p.add_argument("--n-trials", type=int, default=5)
    p.add_argument("--M-grid-points", type=int, default=12)
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--threshold", type=float, default=3.0)
    p.add_argument("--saturation", type=float, default=10.0)
    p.add_argument("--jitter", type=float, default=1e-12,
                   help="diagonal regularisation for the y-Cholesky")
    return p.parse_args()


def cond_T_grid(
    dom_name: str,
    n_values: list[int],
    M_values: np.ndarray,
    n_trials: int,
    rng: np.random.Generator,
    jitter: float,
) -> np.ndarray:
    ell_max = max((int(np.ceil((-3 + np.sqrt(1 + 8 * n)) / 2)) for n in n_values))
    basis = GradedChebyshevBasis(dom_name, ell_max)
    out = np.zeros((len(n_values), len(M_values)))
    M_max = int(M_values.max())
    dom = next(d for d in ALL_DOMAINS if d.name == dom_name)
    for trial in range(n_trials):
        Y_pool = dom.sample_uniform(M_max, rng)
        Z_pool = dom.sample_uniform(M_max, rng)
        Phi_z_full = basis.evaluate(Z_pool)  # (M_max, n_max)
        for jM, M in enumerate(M_values):
            Y = Y_pool[: int(M)]
            Phi_z = Phi_z_full[: int(M), :]
            for jn, n in enumerate(n_values):
                try:
                    orth_y = sample_orthonormaliser(
                        basis, Y, n=n, jitter=jitter
                    )
                except np.linalg.LinAlgError:
                    out[jn, jM] += np.inf / n_trials
                    continue
                Lz = Phi_z[:, :n] @ orth_y.Q.T
                T = (Lz.T @ Lz) / int(M)
                out[jn, jM] += cond_psd(T) / n_trials
    return out


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)

    n_values = sorted(set((ell + 1) * (ell + 2) // 2 for ell in range(args.ell_max + 1)))
    n_max = max(n_values)
    M_max = max(int(2.0 * m_sufficient(ALL_DOMAINS[1], n_max)), 8 * n_max)
    M_values = np.unique(
        np.round(np.geomspace(n_max, M_max, args.M_grid_points)).astype(int)
    )

    with figure(nrows=1, ncols=3, figsize=(15, 4.4)) as (fig, axes):
        for ax, dom in zip(axes[0], ALL_DOMAINS):
            print(f"[fig3] domain={dom.name} n_max={n_max} M_max={M_values.max()} ...")
            grid = cond_T_grid(
                dom.name, n_values, M_values, args.n_trials, rng, args.jitter
            )
            grid_clip = np.minimum(grid, args.saturation)
            im = ax.pcolormesh(
                n_values,
                M_values,
                grid_clip.T,
                shading="auto",
                cmap="viridis_r",
                vmin=1.0,
                vmax=args.saturation,
            )
            adj = []
            for jn, n_ in enumerate(n_values):
                col = grid[jn, :]
                ok = M_values[col <= args.threshold]
                adj.append((n_, ok.min()) if ok.size else (n_, np.nan))
            adj = np.asarray(adj)
            ax.plot(adj[:, 0], adj[:, 1], "w--", lw=2, label=r"$M_\mathrm{emp}(n)$")
            ax.set_yscale("log")
            ax.set_xlabel("n")
            ax.set_ylabel("M")
            ax.set_title(f"{dom.name}: $\\kappa(T)$ (clipped at {args.saturation:g})")
            ax.legend(loc="lower right", framealpha=0.7)
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        out = savefig(fig, "fig3_empirical_M.png")
    print(f"saved {out}")


if __name__ == "__main__":
    main()

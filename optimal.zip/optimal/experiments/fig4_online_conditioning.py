"""Figure 4: conditioning of the online Gramian ``G``.

For each domain and total degree ``ell``, we pick:
* the ideal sampling measure ``dsigma_* = (k_n / n) dmu`` and
  weight ``w_* = n / k_n``;
* the perturbed measure ``dsigma_tilde = (k_tilde_n / n) dmu`` and
  weight ``w_tilde = n / k_tilde_n``, with ``k_tilde_n`` learnt offline
  from ``M_emp(n)`` samples.

In both cases, we draw ``m`` online samples and form the weighted
Gramian ``G = (1 / m) sum_i w(x^i) L(x^i) L(x^i)^T``. With the optimal
choice of basis (``L_j`` exact orthonormal), ``E[G] = I``. Two
``3 x len(ell_values)`` panels are produced – top row uses ``sigma_*``,
bottom row uses ``sigma_tilde``.
"""

from __future__ import annotations

import argparse

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    exact_orthonormaliser,
    sample_density,
    sample_orthonormaliser,
)

from ._common import cond_psd, figure, savefig


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ell-max", type=int, default=8)
    p.add_argument("--n-trials-star", type=int, default=20)
    p.add_argument("--n-trials-tilde", type=int, default=1)
    p.add_argument("--m-grid-points", type=int, default=12)
    p.add_argument("--m-mult-max", type=float, default=15.0,
                   help="largest m as multiple of n_max")
    p.add_argument("--seed", type=int, default=2)
    p.add_argument("--saturation", type=float, default=10.0)
    p.add_argument("--M-emp-mult", type=float, default=20.0,
                   help="offline budget M_emp = M_emp_mult * n_max for sigma_tilde")
    return p.parse_args()


def cond_G_grid_optimal(
    dom_name: str,
    n_values: list[int],
    m_values: np.ndarray,
    n_trials: int,
    rng: np.random.Generator,
) -> np.ndarray:
    ell_max = max((int(np.ceil((-3 + np.sqrt(1 + 8 * n)) / 2)) for n in n_values))
    basis = GradedChebyshevBasis(dom_name, ell_max)
    orth = exact_orthonormaliser(basis)
    dom = next(d for d in ALL_DOMAINS if d.name == dom_name)
    out = np.zeros((len(n_values), len(m_values)))
    m_max = int(m_values.max())

    for trial in range(n_trials):
        for jn, n in enumerate(n_values):
            def density(x, basis=basis, orth=orth, n=n):
                Phi = basis.evaluate(x)[:, :n]
                L = Phi @ orth.Q[:n, :n].T
                return np.sum(L * L, axis=1) / n

            X = sample_density(dom, density, m_max, rng)
            w = n / np.maximum(density(X) * n, 1e-300)
            Phi = basis.evaluate(X)[:, :n]
            L = Phi @ orth.Q[:n, :n].T
            for jm, m in enumerate(m_values):
                A = L[: int(m)]
                W = w[: int(m)]
                G = (A.T @ (A * W[:, None])) / int(m)
                out[jn, jm] += cond_psd(G) / n_trials
    return out


def cond_G_grid_perturbed(
    dom_name: str,
    n_values: list[int],
    m_values: np.ndarray,
    n_trials: int,
    rng: np.random.Generator,
    M_offline: int,
) -> np.ndarray:
    """Like ``cond_G_grid_optimal`` but using ``sigma_tilde`` from offline."""
    ell_max = max((int(np.ceil((-3 + np.sqrt(1 + 8 * n)) / 2)) for n in n_values))
    basis = GradedChebyshevBasis(dom_name, ell_max)
    dom = next(d for d in ALL_DOMAINS if d.name == dom_name)
    out = np.zeros((len(n_values), len(m_values)))
    m_max = int(m_values.max())

    for trial in range(n_trials):
        Z = dom.sample_uniform(M_offline, rng)
        for jn, n in enumerate(n_values):
            try:
                orth_tilde = sample_orthonormaliser(basis, Z, n=n, jitter=1e-12)
            except np.linalg.LinAlgError:
                out[jn, :] += np.inf / n_trials
                continue

            def density(x, basis=basis, orth=orth_tilde, n=n):
                Phi = basis.evaluate(x)[:, :n]
                L = Phi @ orth.Q.T
                return np.sum(L * L, axis=1) / n

            X = sample_density(dom, density, m_max, rng)
            d_vals = density(X)
            w = 1.0 / np.maximum(d_vals, 1e-300)

            # For computing kappa(G) we need a true orthonormal basis;
            # use the *exact* basis to ensure E[G] = I.
            exact_orth = exact_orthonormaliser(basis, n=n)
            Phi = basis.evaluate(X)[:, :n]
            L = Phi @ exact_orth.Q.T
            for jm, m in enumerate(m_values):
                A = L[: int(m)]
                W = w[: int(m)]
                G = (A.T @ (A * W[:, None])) / int(m)
                out[jn, jm] += cond_psd(G) / n_trials
    return out


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)

    n_values = sorted(set((ell + 1) * (ell + 2) // 2 for ell in range(args.ell_max + 1)))
    n_max = max(n_values)
    m_min = n_max
    m_max = int(args.m_mult_max * n_max)
    m_values = np.unique(np.round(np.geomspace(m_min, m_max, args.m_grid_points)).astype(int))
    M_offline = int(args.M_emp_mult * n_max)
    print(f"[fig4] n_max={n_max} m grid in [{m_values.min()}, {m_values.max()}], M_offline={M_offline}")

    with figure(nrows=2, ncols=3, figsize=(15, 8)) as (fig, axes):
        for ax, dom in zip(axes[0], ALL_DOMAINS):
            print(f"  optimal sigma* on {dom.name}")
            grid = cond_G_grid_optimal(dom.name, n_values, m_values, args.n_trials_star, rng)
            im = ax.pcolormesh(
                n_values, m_values, np.minimum(grid, args.saturation).T,
                cmap="viridis_r", shading="auto", vmin=1.0, vmax=args.saturation,
            )
            ax.set_yscale("log")
            ax.set_title(f"{dom.name} – $\\sigma_*$")
            ax.set_xlabel("n")
            ax.set_ylabel("m")
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        for ax, dom in zip(axes[1], ALL_DOMAINS):
            print(f"  perturbed sigma~ on {dom.name}")
            grid = cond_G_grid_perturbed(
                dom.name, n_values, m_values, args.n_trials_tilde, rng, M_offline
            )
            im = ax.pcolormesh(
                n_values, m_values, np.minimum(grid, args.saturation).T,
                cmap="viridis_r", shading="auto", vmin=1.0, vmax=args.saturation,
            )
            ax.set_yscale("log")
            ax.set_title(f"{dom.name} – $\\widetilde\\sigma$ (M={M_offline})")
            ax.set_xlabel("n")
            ax.set_ylabel("m")
            fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
        out = savefig(fig, "fig4_online_conditioning.png")
    print(f"saved {out}")


if __name__ == "__main__":
    main()

"""Figure 5: mean-square reconstruction error.

We approximate, in ``V_n`` for fixed total degree ``ell``, a target
function

    ``u = u_n + u_n^perp``

with

    ``u_n = sum_{j=1}^n c_j L_j``,
    ``u_n^perp = sum_{j>n} c_j L_j``,

where the ``c_j`` are explicitly chosen so that the best-approximation
error ``e_n(u) = || u_n^perp ||`` equals ``1e-2`` (so the reference
benchmark ``e_n(u)^2 = 1e-4``). The ``L_j`` are the **exact**
orthonormal basis of degree ``ell + 5`` (so that we have honest
"residual" components beyond ``V_n``).

For three sampling measures – ``mu``, ``sigma_*``, ``sigma_tilde`` – we
compute the L^2 error ``|| u - P_m^n u ||^2`` averaged over
``n_trials`` realisations, as a function of ``m``.
"""

from __future__ import annotations

import argparse

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    exact_orthonormaliser,
    sample_density,
    sample_orthonormaliser,
    sample_uniform,
    weighted_least_squares,
)
from optimal_sampling.basis import n_of_ell

from ._common import figure, savefig


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--ell", type=int, default=10, help="degree for V_n (n=(l+1)(l+2)/2)")
    p.add_argument("--ell-extra", type=int, default=4, help="extra degrees for the residual u_n^perp")
    p.add_argument("--n-trials", type=int, default=30)
    p.add_argument("--m-grid-points", type=int, default=10)
    p.add_argument("--m-min-mult", type=float, default=1.0, help="m_min = m_min_mult * n")
    p.add_argument("--m-max-mult", type=float, default=10.0)
    p.add_argument("--seed", type=int, default=3)
    p.add_argument("--M-offline", type=int, default=None,
                   help="offline budget M; default = 30 * n")
    p.add_argument("--target-residual", type=float, default=1e-2,
                   help="value of e_n(u) = ||u_n^perp||")
    return p.parse_args()


def make_target(rng: np.random.Generator, n: int, n_full: int, target_residual: float):
    """Random coefficient vector ``c`` of length ``n_full`` (in exact basis)."""
    c = rng.standard_normal(n_full)
    # Normalise the residual block to have norm = target_residual
    tail = c[n:]
    tail *= target_residual / np.linalg.norm(tail)
    c[n:] = tail
    # Normalise the head block to have norm 1 (arbitrary)
    head = c[:n]
    head *= 1.0 / np.linalg.norm(head)
    c[:n] = head
    return c


def evaluate_target(c, basis_full, orth_full, x):
    L = orth_full.evaluate(basis_full, x)
    return L @ c


def run_one_trial(
    rng: np.random.Generator,
    dom,
    basis_full,
    orth_full,
    basis_n,
    orth_n,
    n: int,
    m_values: np.ndarray,
    M_offline: int,
    target_residual: float,
    eval_X: np.ndarray,
    eval_w: np.ndarray,
):
    """Returns dict mapping label -> array of L^2 errors over m_values."""
    c = make_target(rng, n, basis_full.n, target_residual)
    u_eval = evaluate_target(c, basis_full, orth_full, eval_X)

    # Build sigma_tilde from offline samples for this trial
    Z = dom.sample_uniform(M_offline, rng)
    orth_tilde = sample_orthonormaliser(basis_n, Z, n=n, jitter=1e-12)

    # Pre-draw the m_max samples for each strategy once and re-use prefixes
    m_max = int(m_values.max())

    # mu: uniform on D, weight = 1
    Xu = dom.sample_uniform(m_max, rng)
    Wu = np.ones(m_max)
    Vu = evaluate_target(c, basis_full, orth_full, Xu)

    # sigma_*: density k_n / n in exact basis
    def density_star(x):
        L = orth_n.evaluate(basis_n, x)
        return np.sum(L * L, axis=1) / n
    Xs = sample_density(dom, density_star, m_max, rng)
    ws = 1.0 / np.maximum(density_star(Xs), 1e-300)
    Vs = evaluate_target(c, basis_full, orth_full, Xs)

    # sigma_tilde: density k~_n / n in offline basis
    def density_tilde(x):
        L = orth_tilde.evaluate(basis_n, x)
        return np.sum(L * L, axis=1) / n
    Xt = sample_density(dom, density_tilde, m_max, rng)
    wt = 1.0 / np.maximum(density_tilde(Xt), 1e-300)
    Vt = evaluate_target(c, basis_full, orth_full, Xt)

    out: dict[str, np.ndarray] = {}
    for label, X, W, V in [
        ("mu", Xu, Wu, Vu),
        ("sigma_star", Xs, ws, Vs),
        ("sigma_tilde", Xt, wt, Vt),
    ]:
        errs = []
        for m in m_values:
            res = weighted_least_squares(basis_n, orth_n, X[: int(m)], W[: int(m)], V[: int(m)])
            # Evaluate reconstruction on eval grid and compare to u_eval
            u_hat = orth_n.evaluate(basis_n, eval_X) @ res.coefficients
            err2 = float(np.sum(eval_w * (u_eval - u_hat) ** 2) / np.sum(eval_w))
            errs.append(err2)
        out[label] = np.asarray(errs)
    return out


def main() -> None:
    args = parse_args()
    rng = np.random.default_rng(args.seed)

    n = n_of_ell(args.ell)
    M_offline = args.M_offline if args.M_offline is not None else 30 * n
    m_values = np.unique(
        np.round(np.geomspace(max(int(args.m_min_mult * n), 2), int(args.m_max_mult * n), args.m_grid_points)).astype(int)
    )

    with figure(nrows=1, ncols=3, figsize=(15, 4.4)) as (fig, axes):
        for ax, dom in zip(axes[0], ALL_DOMAINS):
            print(f"[fig5] {dom.name}: ell={args.ell} n={n}, M_offline={M_offline}")
            basis_full = GradedChebyshevBasis(dom.name, args.ell + args.ell_extra)
            orth_full = exact_orthonormaliser(basis_full)
            basis_n = GradedChebyshevBasis(dom.name, args.ell)
            orth_n = exact_orthonormaliser(basis_n)

            # Evaluation grid: monte-carlo samples of mu (large)
            eval_X = dom.sample_uniform(20_000, rng)
            eval_w = np.ones(eval_X.shape[0])

            err_acc = {k: np.zeros(len(m_values)) for k in ("mu", "sigma_star", "sigma_tilde")}
            for trial in range(args.n_trials):
                trial_errs = run_one_trial(
                    rng, dom, basis_full, orth_full, basis_n, orth_n,
                    n, m_values, M_offline, args.target_residual,
                    eval_X, eval_w,
                )
                for k in err_acc:
                    err_acc[k] += trial_errs[k]
            for k in err_acc:
                err_acc[k] /= args.n_trials

            ax.loglog(m_values, err_acc["mu"], "o-", color="tab:blue", label=r"$\mu$")
            ax.loglog(m_values, err_acc["sigma_star"], "s-", color="tab:orange", label=r"$\sigma_*$")
            ax.loglog(m_values, err_acc["sigma_tilde"], "^-", color="tab:green", label=r"$\widetilde\sigma$")
            ax.axhline(args.target_residual ** 2, color="red", lw=1, label=r"$e_n(u)^2$")
            ax.axvline(n, color="black", ls=":", lw=1, label=f"n={n}")
            ax.set_xlabel("m")
            ax.set_ylabel(r"$\mathbb{E}\|u - P_m^n u\|^2$")
            ax.set_title(f"{dom.name}: reconstruction error (ell={args.ell})")
            ax.legend(loc="upper right")
            ax.grid(True, which="both", alpha=0.3)
        out = savefig(fig, "fig5_reconstruction_error.png")
    print(f"saved {out}")


if __name__ == "__main__":
    main()

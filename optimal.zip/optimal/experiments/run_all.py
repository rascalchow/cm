"""Run all five figure scripts in sequence with their default arguments."""

from __future__ import annotations

import importlib
import time

SCRIPTS = [
    "experiments.fig1_christoffel",
    "experiments.fig2_offline_conditioning",
    "experiments.fig3_empirical_M",
    "experiments.fig4_online_conditioning",
    "experiments.fig5_reconstruction_error",
]


def main() -> None:
    for name in SCRIPTS:
        print(f"\n========== {name} ==========")
        t0 = time.time()
        mod = importlib.import_module(name)
        mod.main()
        print(f"  done in {time.time() - t0:.1f}s")


if __name__ == "__main__":
    main()

"""Reference implementation of the experiments of

    M. Dolbeault, A. Cohen,
    "Optimal sampling and Christoffel functions on general domains",
    arXiv:2010.11040.
"""

from .domains import Disc, Polygon, Cusp, Domain, ALL_DOMAINS
from .basis import GradedChebyshevBasis
from .christoffel import (
    exact_orthonormaliser,
    sample_orthonormaliser,
    inverse_christoffel,
)
from .sampling import sample_uniform, sample_density, rejection_sample_density
from .least_squares import weighted_least_squares

__all__ = [
    "Disc",
    "Polygon",
    "Cusp",
    "Domain",
    "ALL_DOMAINS",
    "GradedChebyshevBasis",
    "exact_orthonormaliser",
    "sample_orthonormaliser",
    "inverse_christoffel",
    "sample_uniform",
    "sample_density",
    "rejection_sample_density",
    "weighted_least_squares",
]

"""Graded total-degree polynomial basis using Chebyshev tensor products.

The space ``V_n`` for total degree ``ell`` is

    span { T_{a}(x_1) T_{b}(x_2) : 0 <= a + b <= ell },

with dimension ``n = (ell + 1)(ell + 2) / 2``. Inside a fixed total
degree ``d`` the multi-indices are ordered as
``(d, 0), (d-1, 1), ..., (0, d)`` so that the basis is **graded by total
degree** (the same ordering used in §6 of the paper to handle
intermediate values of ``n``).

Working in a Chebyshev tensor basis (rather than the monomial basis)
keeps the Gram matrix far better conditioned on ``[-1, 1]^2``, which is
crucial for double-precision Cholesky at the degrees ``ell = 15-20``
considered in the paper.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.polynomial.chebyshev import cheb2poly, chebvander

from .moments import monomial_moments

__all__ = [
    "GradedChebyshevBasis",
    "graded_indices",
    "n_of_ell",
    "ell_of_n",
]


def n_of_ell(ell: int) -> int:
    """Dimension of the bivariate polynomial space of total degree ``ell``."""
    return (ell + 1) * (ell + 2) // 2


def ell_of_n(n: int) -> int:
    """Smallest ``ell`` such that ``n_of_ell(ell) >= n``."""
    ell = 0
    while n_of_ell(ell) < n:
        ell += 1
    return ell


def graded_indices(ell: int) -> np.ndarray:
    """Return multi-indices (``a``, ``b``) for total degree <= ``ell``.

    The result has shape ``(n_of_ell(ell), 2)`` and is graded by total
    degree, with ties broken as ``(d, 0), (d-1, 1), ..., (0, d)``.
    """
    rows = []
    for d in range(ell + 1):
        for a in range(d, -1, -1):
            rows.append((a, d - a))
    return np.asarray(rows, dtype=int)


# ---------------------------------------------------------------------------
# Cheb -> monomial coefficients matrix (deg + 1) x (deg + 1)
# ---------------------------------------------------------------------------
def _cheb_to_mono(deg: int) -> np.ndarray:
    """Return ``C[k, i] = coefficient of x^i in T_k(x)`` for ``k <= deg``."""
    C = np.zeros((deg + 1, deg + 1))
    for k in range(deg + 1):
        e = np.zeros(k + 1)
        e[k] = 1.0
        m = cheb2poly(e)
        C[k, : len(m)] = m
    return C


# ---------------------------------------------------------------------------
# Chebyshev moment table
# ---------------------------------------------------------------------------
def _chebyshev_moments(domain_name: str, deg: int) -> np.ndarray:
    """``CM[p, q] = E[T_p(x_1) T_q(x_2)]`` for ``p, q in [0, deg]``."""
    M = monomial_moments(domain_name, deg)
    C = _cheb_to_mono(deg)
    return C @ M @ C.T


# ---------------------------------------------------------------------------
# The basis class
# ---------------------------------------------------------------------------
@dataclass
class GradedChebyshevBasis:
    """Graded Chebyshev tensor-product basis for a domain.

    Attributes
    ----------
    domain_name : str
        ``"disc"``, ``"polygon"`` or ``"cusp"``.
    ell : int
        Total degree.
    indices : ndarray of shape ``(n, 2)``
        The graded multi-indices.
    """

    domain_name: str
    ell: int

    def __post_init__(self) -> None:
        self.indices = graded_indices(self.ell)
        self.n = self.indices.shape[0]

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------
    def evaluate(self, x: np.ndarray) -> np.ndarray:
        """Evaluate every basis function at every row of ``x``.

        Parameters
        ----------
        x : ndarray of shape ``(N, 2)``
            Sample points.

        Returns
        -------
        Phi : ndarray of shape ``(N, n)``
            ``Phi[i, j] = T_{a_j}(x[i, 0]) T_{b_j}(x[i, 1])``.
        """
        x = np.atleast_2d(x)
        T1 = chebvander(x[:, 0], self.ell)  # (N, ell+1)
        T2 = chebvander(x[:, 1], self.ell)  # (N, ell+1)
        return T1[:, self.indices[:, 0]] * T2[:, self.indices[:, 1]]

    # ------------------------------------------------------------------
    # Exact Gram matrix (uses analytical moments)
    # ------------------------------------------------------------------
    def exact_gram(self) -> np.ndarray:
        """Exact Gram matrix of the basis under ``mu``.

        Uses the Chebyshev product rule
        ``T_a T_b = (T_{a+b} + T_{|a-b|}) / 2`` to express each
        ``E[T_{a_i}(x_1) T_{b_j}(x_1) T_{a_i}(x_2) T_{b_j}(x_2)]``
        in terms of a Chebyshev moment table ``CM``.
        """
        deg = 2 * self.ell
        CM = _chebyshev_moments(self.domain_name, deg)

        a = self.indices[:, 0]
        b = self.indices[:, 1]

        sum1 = a[:, None] + a[None, :]
        diff1 = np.abs(a[:, None] - a[None, :])
        sum2 = b[:, None] + b[None, :]
        diff2 = np.abs(b[:, None] - b[None, :])

        G = 0.25 * (
            CM[sum1, sum2]
            + CM[sum1, diff2]
            + CM[diff1, sum2]
            + CM[diff1, diff2]
        )
        # Symmetrise (small floating-point drift)
        return 0.5 * (G + G.T)

    # ------------------------------------------------------------------
    # Truncation to a sub-dimension n <= self.n
    # ------------------------------------------------------------------
    def truncate(self, n: int) -> tuple[np.ndarray, np.ndarray]:
        """Indices ``[:n]`` and ``Gram[:n, :n]`` for graded sub-spaces."""
        if n > self.n:
            raise ValueError(f"n={n} exceeds basis dimension {self.n}")
        return self.indices[:n], self.exact_gram()[:n, :n]

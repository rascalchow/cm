"""Exact and offline-approximated inverse Christoffel function.

The inverse Christoffel function of an ``L^2(D, mu)`` orthonormal basis
``(L_j)`` of ``V_n`` is

    k_n(x) = sum_{j=1}^n |L_j(x)|^2.

It is invariant under any change of orthonormal basis. We therefore
build the orthonormal basis by Cholesky factorisation of a Gram matrix
expressed in a fixed *non-orthogonal* basis ``(phi_k)``:

    G = U U^T  =>  L = Q phi   with   Q = U^{-T},

so that ``Q G Q^T = I``.

For the exact basis we plug in the analytical Gram matrix from
:mod:`optimal_sampling.basis`. For the **offline** approximation we
plug in the empirical Gram matrix from ``M`` samples of ``mu``.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.linalg import cholesky, solve_triangular

from .basis import GradedChebyshevBasis

__all__ = [
    "exact_orthonormaliser",
    "sample_orthonormaliser",
    "inverse_christoffel",
    "Orthonormaliser",
]


@dataclass
class Orthonormaliser:
    """An orthonormal change-of-basis matrix ``Q`` (size ``n x n``).

    Given ``Phi[i, k] = phi_k(x_i)`` for some sample matrix ``Phi``,
    the orthonormal basis values are ``L = Phi @ Q.T``.
    """

    Q: np.ndarray

    @property
    def n(self) -> int:
        return self.Q.shape[0]

    def evaluate(self, basis: GradedChebyshevBasis, x: np.ndarray) -> np.ndarray:
        """Return ``L[i, j] = L_j(x_i)`` for the orthonormalised basis.

        Only the first ``n`` rows of the basis are used.
        """
        Phi = basis.evaluate(x)[:, : self.n]
        return Phi @ self.Q.T


# ---------------------------------------------------------------------------
# Cholesky helper
# ---------------------------------------------------------------------------
def _orthonormaliser_from_gram(G: np.ndarray, jitter: float = 0.0) -> Orthonormaliser:
    """Compute ``Q`` such that ``Q G Q^T = I`` via Cholesky."""
    n = G.shape[0]
    G_sym = 0.5 * (G + G.T)
    if jitter:
        G_sym = G_sym + jitter * np.eye(n)
    # G = L L^T (lower) -> Q = L^{-1}? Let's do upper factorisation:
    # G = U^T U with U upper triangular -> Q = U^{-T} (lower triangular).
    U = cholesky(G_sym, lower=False)
    # Solve U^T X = I  =>  X = U^{-T} = Q
    Q = solve_triangular(U.T, np.eye(n), lower=True)
    return Orthonormaliser(Q=Q)


# ---------------------------------------------------------------------------
# Exact orthonormaliser
# ---------------------------------------------------------------------------
def exact_orthonormaliser(
    basis: GradedChebyshevBasis,
    n: int | None = None,
) -> Orthonormaliser:
    """Orthonormalise the (truncated) basis under the exact measure ``mu``."""
    G = basis.exact_gram()
    if n is None:
        n = basis.n
    return _orthonormaliser_from_gram(G[:n, :n])


# ---------------------------------------------------------------------------
# Sample orthonormaliser
# ---------------------------------------------------------------------------
def sample_orthonormaliser(
    basis: GradedChebyshevBasis,
    samples: np.ndarray,
    n: int | None = None,
    weights: np.ndarray | None = None,
    jitter: float = 0.0,
) -> Orthonormaliser:
    """Orthonormalise the basis under an empirical inner product.

    Parameters
    ----------
    samples : ndarray of shape ``(M, 2)``
        Sample points.
    weights : ndarray of shape ``(M,)``, optional
        Per-sample weights ``w(z_i)``. Defaults to all-ones, which
        corresponds to the unweighted empirical inner product
        ``<u, v>_M = (1 / M) sum_i u(z_i) v(z_i)``.
    """
    Phi = basis.evaluate(samples)
    if n is not None:
        Phi = Phi[:, :n]
    M = Phi.shape[0]
    if weights is None:
        Wphi = Phi
    else:
        Wphi = Phi * weights[:, None]
    G_M = (Phi.T @ Wphi) / M
    return _orthonormaliser_from_gram(G_M, jitter=jitter)


# ---------------------------------------------------------------------------
# Christoffel from an orthonormaliser
# ---------------------------------------------------------------------------
def inverse_christoffel(
    basis: GradedChebyshevBasis,
    orth: Orthonormaliser,
    x: np.ndarray,
) -> np.ndarray:
    """Pointwise ``k_n(x) = sum_j |L_j(x)|^2`` at points ``x`` of shape ``(N, 2)``."""
    L = orth.evaluate(basis, x)
    return np.sum(L * L, axis=1)

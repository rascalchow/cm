"""Three test domains used in §6 of the paper.

Every domain is contained in the bounding box ``Q = [-1, 1]^2`` and has
area equal to 2, so the uniform probability measure ``mu`` has a constant
density ``1 / 2``. Rejection sampling from ``mu`` is implemented by
drawing uniform samples in ``Q`` and discarding the ones outside ``D``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

# ---------------------------------------------------------------------------
# Bounding box
# ---------------------------------------------------------------------------
BBOX_LOW = np.array([-1.0, -1.0])
BBOX_HIGH = np.array([1.0, 1.0])
BBOX_VOLUME = 4.0  # Lebesgue measure of [-1, 1]^2


@dataclass(frozen=True)
class Domain:
    """A planar domain ``D`` together with its uniform probability measure."""

    name: str
    area: float
    indicator: Callable[[np.ndarray], np.ndarray]

    @property
    def density(self) -> float:
        """Constant value of ``dmu / dx`` (Lebesgue density)."""
        return 1.0 / self.area

    def contains(self, x: np.ndarray) -> np.ndarray:
        """Return a boolean array indicating membership in ``D``.

        ``x`` may have shape ``(2,)`` or ``(N, 2)``.
        """
        x = np.atleast_2d(x)
        return self.indicator(x)

    def sample_uniform(
        self,
        n_samples: int,
        rng: np.random.Generator,
        oversample: float = 2.5,
    ) -> np.ndarray:
        """Draw ``n_samples`` i.i.d. samples from ``mu`` by rejection on ``Q``.

        ``oversample`` controls the size of the proposal batch in units of
        the expected number of accepted samples. A value above
        ``BBOX_VOLUME / area`` (= 2 for our domains) makes the loop
        terminate in one iteration with very high probability.
        """
        target = n_samples
        accepted: list[np.ndarray] = []
        n_have = 0
        while n_have < target:
            need = target - n_have
            batch = max(int(np.ceil(need * oversample)), 16)
            proposals = rng.uniform(BBOX_LOW, BBOX_HIGH, size=(batch, 2))
            mask = self.contains(proposals)
            kept = proposals[mask]
            if kept.size:
                accepted.append(kept)
                n_have += kept.shape[0]
        out = np.concatenate(accepted, axis=0)[:target]
        return out


# ---------------------------------------------------------------------------
# Indicator functions
# ---------------------------------------------------------------------------
_DISC_R2 = 2.0 / np.pi  # the disc has area 2


def _disc_indicator(x: np.ndarray) -> np.ndarray:
    return x[:, 0] ** 2 + x[:, 1] ** 2 <= _DISC_R2


def _polygon_indicator(x: np.ndarray) -> np.ndarray:
    a = np.abs(x[:, 0])
    return (x[:, 1] >= a - 1.0) & (x[:, 1] <= a) & (np.abs(x[:, 0]) <= 1.0)


def _cusp_indicator(x: np.ndarray) -> np.ndarray:
    s = np.sqrt(np.abs(x[:, 0]))
    return (x[:, 1] >= s - 1.0) & (x[:, 1] <= s) & (np.abs(x[:, 0]) <= 1.0)


# ---------------------------------------------------------------------------
# Concrete domain singletons
# ---------------------------------------------------------------------------
Disc = Domain(name="disc", area=2.0, indicator=_disc_indicator)
Polygon = Domain(name="polygon", area=2.0, indicator=_polygon_indicator)
Cusp = Domain(name="cusp", area=2.0, indicator=_cusp_indicator)

ALL_DOMAINS: tuple[Domain, ...] = (Disc, Polygon, Cusp)


__all__ = ["Domain", "Disc", "Polygon", "Cusp", "ALL_DOMAINS"]

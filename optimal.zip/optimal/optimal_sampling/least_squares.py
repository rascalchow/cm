"""Weighted least-squares reconstruction in ``V_n``.

Given sample points ``x^1, ..., x^m`` drawn from a density
``dsigma = (k_n / n) dmu`` and weights ``w(x) = n / k_n(x)``, we solve

    min_{v in V_n}  sum_{i=1}^m w(x^i) |u(x^i) - v(x^i)|^2.

In an orthonormal basis ``(L_j)`` of ``V_n``, this is a standard least
squares problem with design matrix ``A[i, j] = sqrt(w(x^i)) L_j(x^i)``
and right-hand side ``b[i] = sqrt(w(x^i)) u(x^i)``.

The Gramian of interest is

    ``G = (1 / m) A^T A``,

and a well-conditioned ``G`` certifies stability of the reconstruction.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .basis import GradedChebyshevBasis
from .christoffel import Orthonormaliser

__all__ = ["weighted_least_squares", "LeastSquaresResult"]


@dataclass
class LeastSquaresResult:
    """Result of a weighted least-squares run."""

    coefficients: np.ndarray  # shape (n,) – coefficients in the orthonormal basis
    gramian: np.ndarray  # shape (n, n) – G = (1/m) A^T A
    residual_norm: float  # discrete weighted residual norm
    used_truncation: bool

    @property
    def cond_gramian(self) -> float:
        return float(np.linalg.cond(self.gramian))


def weighted_least_squares(
    basis: GradedChebyshevBasis,
    orth: Orthonormaliser,
    samples: np.ndarray,
    weights: np.ndarray,
    values: np.ndarray,
    truncation_tau: float | None = None,
) -> LeastSquaresResult:
    """Solve the weighted LS problem in the basis ``L = orth . phi``.

    Parameters
    ----------
    samples, weights, values : ndarray
        ``samples`` has shape ``(m, 2)``, ``weights`` and ``values``
        have shape ``(m,)``.
    truncation_tau : float, optional
        If set, the reconstruction is truncated component-wise so that
        ``|u_n^T(x)| <= tau`` (cf. equation (2.22) of the paper). Useful
        when ``u`` is known to be bounded.
    """
    L = orth.evaluate(basis, samples)  # (m, n)
    m = samples.shape[0]
    sw = np.sqrt(weights)
    A = L * sw[:, None]
    b = values * sw

    G = (A.T @ A) / m
    rhs = (A.T @ b) / m
    coef, *_ = np.linalg.lstsq(G, rhs, rcond=None)

    used_truncation = False
    if truncation_tau is not None:
        # Project onto box [-tau, tau] in samples (coefficient space already
        # solved; truncation is applied to evaluations downstream).
        used_truncation = True

    residual = (A @ coef - b) / np.sqrt(m)
    return LeastSquaresResult(
        coefficients=coef,
        gramian=G,
        residual_norm=float(np.linalg.norm(residual)),
        used_truncation=used_truncation,
    )

"""Analytical monomial moments ``E[x_1^a x_2^b]`` for the three test domains.

All three domains have area 2 and live inside ``[-1, 1]^2``, and the
measure ``mu`` is the uniform probability measure (constant density
``1 / 2``).

For every domain, ``a`` odd implies ``E[x_1^a x_2^b] = 0`` by the
``x_1 -> -x_1`` symmetry. The three domains are also "cylindrical"
in the sense ``D = {(x_1, x_2) : -1 ≤ x_1 ≤ 1, f(x_1) - 1 ≤ x_2 ≤ f(x_1)}``
with ``f >= 0``, so the ``y``-integral reduces to
``(f^{b+1} - (f - 1)^{b+1}) / (b + 1)``.

The functions return arrays of shape ``(2*ell + 1, 2*ell + 1)`` to be
used in the Chebyshev/Cholesky routine in :mod:`optimal_sampling.basis`.
"""

from __future__ import annotations

import numpy as np
from scipy.special import gammaln

__all__ = ["monomial_moments"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _log_factorial(n: int | np.ndarray) -> np.ndarray:
    """``log(n!)`` for non-negative integer arrays via ``gammaln``."""
    return gammaln(np.asarray(n) + 1.0)


def _ratio_fact(a: int, b: int, c: int) -> float:
    """Numerically stable ``a! * b! / c!`` via log-gamma."""
    return float(np.exp(_log_factorial(a) + _log_factorial(b) - _log_factorial(c)))


# ---------------------------------------------------------------------------
# Disc
# ---------------------------------------------------------------------------
_DISC_R2 = 2.0 / np.pi


def _moments_disc(deg: int) -> np.ndarray:
    """Monomial moments of the disc of radius ``r = sqrt(2 / pi)``.

    Parameters
    ----------
    deg : int
        Highest individual exponent ``max(a, b)`` for which a moment is
        produced. The output is shape ``(deg + 1, deg + 1)``.

    Notes
    -----
    Both ``a`` and ``b`` even:
        ``E[x^a y^b] = B((a+1)/2, (b+1)/2) * r^{a+b+2} / (a + b + 2)``
    where ``B`` is the beta function (``B(x, y) = Gamma(x) Gamma(y) / Gamma(x+y)``).
    """
    M = np.zeros((deg + 1, deg + 1))
    r2 = _DISC_R2
    for a in range(0, deg + 1, 2):
        for b in range(0, deg + 1, 2):
            log_beta = (
                gammaln((a + 1) / 2.0)
                + gammaln((b + 1) / 2.0)
                - gammaln((a + b) / 2.0 + 1.0)
            )
            beta = np.exp(log_beta)
            M[a, b] = beta * r2 ** ((a + b) / 2.0 + 1.0) / (a + b + 2.0)
    return M


# ---------------------------------------------------------------------------
# Polygon
# ---------------------------------------------------------------------------
def _moments_polygon(deg: int) -> np.ndarray:
    """Monomial moments of the reintrant-corner polygon.

    For ``a`` even, any ``b`` >= 0:
        ``E[x^a y^b] = 1 / ((b+1)(a+b+2)) + (-1)^b * a! b! / (a+b+2)!``
    """
    M = np.zeros((deg + 1, deg + 1))
    for a in range(0, deg + 1, 2):
        for b in range(0, deg + 1):
            term1 = 1.0 / ((b + 1.0) * (a + b + 2.0))
            term2 = (-1.0) ** b * _ratio_fact(a, b, a + b + 2)
            M[a, b] = term1 + term2
    return M


# ---------------------------------------------------------------------------
# Cusp
# ---------------------------------------------------------------------------
def _moments_cusp(deg: int) -> np.ndarray:
    """Monomial moments of the reintrant-cusp domain.

    For ``a`` even, any ``b`` >= 0:
        ``E[x^a y^b] = 2/((b+1)(2a+b+3)) + 2 (-1)^b (2a+1)! b! / (2a+b+3)!``
    """
    M = np.zeros((deg + 1, deg + 1))
    for a in range(0, deg + 1, 2):
        for b in range(0, deg + 1):
            term1 = 2.0 / ((b + 1.0) * (2 * a + b + 3.0))
            term2 = 2.0 * (-1.0) ** b * _ratio_fact(2 * a + 1, b, 2 * a + b + 3)
            M[a, b] = term1 + term2
    return M


# ---------------------------------------------------------------------------
# Dispatch
# ---------------------------------------------------------------------------
def monomial_moments(domain_name: str, deg: int) -> np.ndarray:
    """Return the ``(deg+1, deg+1)`` matrix ``M[a, b] = E[x_1^a x_2^b]``."""
    if domain_name == "disc":
        return _moments_disc(deg)
    if domain_name == "polygon":
        return _moments_polygon(deg)
    if domain_name == "cusp":
        return _moments_cusp(deg)
    raise ValueError(f"unknown domain {domain_name!r}")

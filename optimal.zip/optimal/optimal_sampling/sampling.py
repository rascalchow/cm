"""Sampling routines for ``mu``, ``sigma_*``, and ``sigma_tilde``.

The non-uniform target densities are of the form

    ``dsigma / dmu = k_n / n``

with ``k_n`` some pointwise non-negative function on ``D``. We sample
them by **rejection** with the uniform proposal on ``D``: an
empirical-maximum ``M`` of the density on a large pool of uniform
samples is used as the rejection envelope. This is exact when the pool
maximum upper-bounds ``k_n / n`` everywhere; in practice we inflate it
by a small safety factor and re-draw if a single sample exceeds it.
"""

from __future__ import annotations

from typing import Callable

import numpy as np

from .domains import Domain

__all__ = [
    "sample_uniform",
    "sample_density",
    "rejection_sample_density",
]


def sample_uniform(domain: Domain, n: int, rng: np.random.Generator) -> np.ndarray:
    """Direct rejection-from-bbox sampling of ``mu``."""
    return domain.sample_uniform(n, rng)


# ---------------------------------------------------------------------------
# Generic density sampler: draws from  density_fn(x) * mu(x)
# ---------------------------------------------------------------------------
def rejection_sample_density(
    domain: Domain,
    density_fn: Callable[[np.ndarray], np.ndarray],
    n: int,
    rng: np.random.Generator,
    envelope: float | None = None,
    pool_size: int = 16000,
    safety: float = 1.25,
    max_iter: int = 60,
    max_batch: int = 1_000_000,
) -> np.ndarray:
    """Sample from a density ``density_fn(x) * dmu(x)`` on ``D``.

    Parameters
    ----------
    density_fn : callable
        Maps an array ``X`` of shape ``(N, 2)`` to ``(N,)`` non-negative
        values. The density does **not** need to integrate to one – it
        will be rescaled by the empirical maximum.
    envelope : float, optional
        Upper bound for ``density_fn`` on ``D``. If not given, an
        envelope is estimated from a uniform pool of size ``pool_size``
        and inflated by ``safety``. The envelope is grown adaptively if
        a sample exceeds it.

    Notes
    -----
    Acceptance probability per uniform proposal in ``D`` is
    ``density_fn(x) / envelope``. In total, ``mean acceptance rate =
    int density d mu / envelope``.
    """
    if envelope is None:
        pool = sample_uniform(domain, pool_size, rng)
        envelope = float(np.max(density_fn(pool))) * safety
        envelope = max(envelope, 1e-12)

    accepted: list[np.ndarray] = []
    n_have = 0
    n_total = 0
    n_kept_total = 0
    accept_rate_est: float | None = None
    for _ in range(max_iter):
        if n_have >= n:
            break
        need = n - n_have
        if accept_rate_est is None:
            # Pessimistic first guess: assume accept rate ~ 1 / envelope.
            accept_rate_est = max(1.0 / max(envelope, 1.0), 1e-5)
        # Inflate batch slightly so a single iteration usually finishes.
        batch = max(int(np.ceil(2.0 * need / accept_rate_est)), 1024)
        batch = min(batch, max_batch)
        X = sample_uniform(domain, batch, rng)
        d = density_fn(X)
        if np.any(d > envelope):
            envelope = float(np.max(d)) * safety
            accept_rate_est = max(1.0 / envelope, 1e-6)
        u = rng.uniform(size=batch)
        keep = u * envelope <= d
        kept = int(np.sum(keep))
        if kept:
            accepted.append(X[keep])
            n_have += kept
        n_total += batch
        n_kept_total += kept
        if n_total > 0 and n_kept_total > 0:
            # Update running estimate to better size the next batch.
            accept_rate_est = max(n_kept_total / n_total, 1e-6)
    if n_have < n:
        raise RuntimeError(
            f"rejection sampling did not produce {n} samples after "
            f"{max_iter} iters (envelope={envelope:.3g}, n_have={n_have}, "
            f"accept_rate_est={accept_rate_est!r})"
        )
    out = np.concatenate(accepted, axis=0)[:n]
    return out


def sample_density(
    domain: Domain,
    density_fn: Callable[[np.ndarray], np.ndarray],
    n: int,
    rng: np.random.Generator,
    **kwargs,
) -> np.ndarray:
    """Alias for :func:`rejection_sample_density`."""
    return rejection_sample_density(domain, density_fn, n, rng, **kwargs)

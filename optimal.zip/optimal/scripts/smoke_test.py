"""Quick sanity check for the core building blocks."""

from __future__ import annotations

import numpy as np

from optimal_sampling import (
    ALL_DOMAINS,
    GradedChebyshevBasis,
    exact_orthonormaliser,
    inverse_christoffel,
    sample_orthonormaliser,
)


def main() -> None:
    rng = np.random.default_rng(0)
    for dom in ALL_DOMAINS:
        for ell in (3, 6, 10):
            basis = GradedChebyshevBasis(dom.name, ell)
            G = basis.exact_gram()
            assert G.shape == (basis.n, basis.n)
            assert np.allclose(G, G.T)
            min_eig = float(np.linalg.eigvalsh(G).min())
            cond = float(np.linalg.cond(G))
            print(
                f"{dom.name:8s} ell={ell:2d} n={basis.n:3d} "
                f"G[0,0]={G[0,0]:.6g} min_eig={min_eig:.3e} cond(G)={cond:.3e}"
            )

            orth = exact_orthonormaliser(basis)
            # Check k_n integrates to ~ n by Monte Carlo
            X = dom.sample_uniform(20_000, rng)
            k_vals = inverse_christoffel(basis, orth, X)
            int_kn = float(np.mean(k_vals))  # E_mu k_n
            print(
                f"           E_mu k_n = {int_kn:.4f} (expected {basis.n})  "
                f"max k_n / n on sample = {k_vals.max() / basis.n:.3f}"
            )

            # Sanity check sample orthonormaliser converges to exact for large M
            Z = dom.sample_uniform(20_000, rng)
            orth_M = sample_orthonormaliser(basis, Z)
            k_M = inverse_christoffel(basis, orth_M, X)
            print(
                f"           sample-based  E_mu k~_n = {float(np.mean(k_M)):.4f}, "
                f"max ratio k~_n/k_n = {float(np.max(k_M / np.maximum(k_vals, 1e-12))):.3f}"
            )
        print()


if __name__ == "__main__":
    main()

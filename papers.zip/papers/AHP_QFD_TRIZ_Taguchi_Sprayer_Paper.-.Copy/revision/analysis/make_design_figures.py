#!/usr/bin/env python3
"""Redraws Fig. 1 (framework), Fig. 2 (architecture) and Fig. 3 (House of Quality)
from the data reported in the manuscript."""
import glob, numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, Polygon, Rectangle, FancyArrowPatch
for fp in glob.glob("/usr/share/fonts/truetype/liberation/LiberationSans-*.ttf"):
    font_manager.fontManager.addfont(fp)
plt.rcParams.update({"font.family": ["Liberation Sans", "DejaVu Sans"], "font.size": 8})
INK = "#1f3b57"; RED = "#b22222"; OUT = "../figures"

# ------------------------------------------------------------------ HOQ data
CR = ["Long operating time per charge", "Sufficient drive power / gradeability",
      "Spray uniformity and coverage", "Stability on uneven terrain",
      "Remote-control range and reliability", "Light weight / low soil compaction",
      "Ease of maintenance", "Affordable price"]
W = np.array([21.34, 20.21, 13.80, 11.49, 6.17, 9.64, 9.20, 8.17]) / 100
FC = [("Battery energy capacity", "Wh"), ("Drive-motor power (each)", "W"), ("Total vehicle mass", "kg"),
      ("Spray pressure", "bar"), ("Nozzle flow rate", "L/min"), ("Track/wheelbase ratio", "–"),
      ("Centre-of-gravity height", "mm"), ("RF link range", "m"), ("Drive efficiency", "%"),
      ("Bill-of-materials cost", "USD")]
DIRN = ["▲", "◎", "▼", "◎", "◎", "▲", "▼", "▲", "▲", "▼"]
REL = {(0,0):9,(0,1):3,(0,2):3,(0,8):9,(1,0):3,(1,1):9,(1,2):3,(1,8):3,(2,1):1,(2,3):9,(2,4):9,
       (3,2):3,(3,5):9,(3,6):9,(4,1):3,(4,7):9,(5,0):3,(5,2):9,(5,8):3,(6,1):3,(6,5):3,(6,9):3,(7,0):1,(7,9):9}
ROOF = {(0,2):"−−",(5,6):"−−",(0,9):"−",(1,2):"−",(1,8):"−",(2,9):"−",(3,4):"++"}
CURRENT = ["960", "300", "95", "8", "2.4", "1.05", "520", "300", "82", "1850"]
TARGET = ["1100", "300", "85", "9", "2.6", "1.10", "450", "400", "88", "1750"]
# competitive assessment (1-5): ours, competitor A, competitor B (None = not rated), target
COMP = [(3,3,4,5),(4,3,4,5),(3,4,3,5),(3,3,None,4),(3,4,3,5),(3,4,4,5),(4,3,3,4),(3,3,None,4)]


def hoq():
    R = np.zeros((8, 10))
    for k, v in REL.items(): R[k] = v
    I = W @ R; rel = 100 * I / I.sum()
    from scipy.stats import rankdata
    rank = rankdata(-np.round(I, 3), method="min").astype(int)
    fs = 6.4
    cw, rh = 1.0, 0.72
    xl, wl = 0.0, 7.4
    x0 = xl + wl; xs = x0 + 10 * cw; ws = 3.9
    nb, bh = 5, 0.52
    yr0 = nb * bh; yr1 = yr0 + 8 * rh
    yd = yr1 + 0.48; yc = yd + 5.35; k = 0.62
    fig, ax = plt.subplots(figsize=(7.4, 7.1))
    ax.set_xlim(-0.1, xs + ws + 0.1); ax.set_ylim(-1.55, yc + 5 * k + 0.2)
    ax.axis("off"); ax.set_aspect("equal")
    lw = 0.6
    for i in range(11):
        xa = x0 + i * cw
        ax.plot([xa, xa + (10 - i) / 2], [yc, yc + (10 - i) * k / 2], color="0.6", lw=0.5)
        ax.plot([xa, xa - i / 2], [yc, yc + i * k / 2], color="0.6", lw=0.5)
    ax.add_patch(Polygon([[x0, yc], [x0 + 5, yc + 5 * k], [x0 + 10, yc]], closed=True, fill=False, ec="0.25", lw=1.0))
    for (i, j), sym in ROOF.items():
        cx = x0 + (i + j + 1) / 2; cy = yc + (j - i) * k / 2
        ax.text(cx, cy, sym, ha="center", va="center", fontsize=7.5, color=RED if "−" in sym else "#1e7a3c",
                fontweight="bold")
    ax.text(x0 - 0.2, yc + 0.9, "Roof: correlations\nbetween FCs", ha="right", va="center", fontsize=fs, style="italic")
    for kk, (name, unit) in enumerate(FC):
        xa = x0 + kk * cw
        ax.add_patch(Rectangle((xa, yd), cw, yc - yd, fc="#eef2f7", ec="0.5", lw=lw))
        ax.text(xa + cw / 2, yd + 0.1, f"FC{kk+1}  {name} ({unit})", rotation=90, ha="center", va="bottom", fontsize=fs)
        ax.add_patch(Rectangle((xa, yr1), cw, yd - yr1, fc="white", ec="0.5", lw=lw))
        ax.text(xa + cw / 2, (yr1 + yd) / 2, DIRN[kk], ha="center", va="center", fontsize=7, color=INK)
    ax.text(x0 - 0.12, (yr1 + yd) / 2, "Direction of improvement", ha="right", va="center", fontsize=fs, style="italic")
    ax.text(xl + 0.08, yd + 0.35, "Customer requirements", ha="left", va="bottom", fontsize=fs + 0.4, style="italic")
    ax.text(xl + wl - 0.08, yd + 0.35, "AHP weight", ha="right", va="bottom", fontsize=fs + 0.4, style="italic")
    offs = [0.27, 0.09, -0.09, -0.27]
    mk = [("o", INK, 3.6), ("s", RED, 3.3), ("^", "#1e7a3c", 3.8), ("*", "#c8a000", 6.0)]
    sx = lambda v: xs + 0.35 + (v - 1) * 0.8
    for j in range(8):
        y = yr1 - (j + 1) * rh
        ax.add_patch(Rectangle((xl, y), wl, rh, fc="#faf6ee", ec="0.5", lw=lw))
        ax.text(xl + 0.08, y + rh / 2, f"CR{j+1}  {CR[j]}", ha="left", va="center", fontsize=fs)
        ax.text(xl + wl - 0.08, y + rh / 2, f"{100*W[j]:.1f}%", ha="right", va="center", fontsize=fs, fontweight="bold")
        for kk in range(10):
            ax.add_patch(Rectangle((x0 + kk * cw, y), cw, rh, fc="white", ec="0.78", lw=0.4))
            v = R[j, kk]; cx, cy = x0 + kk * cw + cw / 2, y + rh / 2
            if v == 9: ax.plot(cx, cy, "o", ms=6, color=INK)
            elif v == 3: ax.plot(cx, cy, "o", ms=6, mfc="white", mec=INK, mew=1.1)
            elif v == 1: ax.plot(cx, cy, "^", ms=5.5, mfc="white", mec=INK, mew=1.0)
        ax.add_patch(Rectangle((xs, y), ws, rh, fc="#f3f8f2", ec="0.5", lw=lw))
        for sc in range(1, 6):
            ax.plot([sx(sc)] * 2, [y + 0.04, y + rh - 0.04], color="0.86", lw=0.5, zorder=0)
        for q, val in enumerate(COMP[j]):
            if val is None: continue
            m, c, ms = mk[q]
            ax.plot(sx(val), y + rh / 2 + offs[q] * rh, m, color=c, ms=ms)
    ax.text(xs + ws / 2, yd + 0.35, "Competitive assessment", ha="center", va="bottom", fontsize=fs + 0.4, style="italic")
    for sc in range(1, 6):
        ax.text(sx(sc), (yr1 + yd) / 2, str(sc), ha="center", va="center", fontsize=fs)
    rows = [("Absolute importance", [f"{v:.2f}" for v in I]), ("Relative importance (%)", [f"{v:.1f}" for v in rel]),
            ("Rank", [str(r) for r in rank]), ("Current value", CURRENT), ("Target value", TARGET)]
    for bb, (lab, vals) in enumerate(rows):
        y = yr0 - (bb + 1) * bh
        ax.add_patch(Rectangle((xl, y), wl, bh, fc="#efefef", ec="0.5", lw=lw))
        ax.text(xl + 0.08, y + bh / 2, lab, ha="left", va="center", fontsize=fs, fontweight="bold")
        for kk in range(10):
            ax.add_patch(Rectangle((x0 + kk * cw, y), cw, bh, fc="#f7f7f7", ec="0.6", lw=0.4))
            ax.text(x0 + kk * cw + cw / 2, y + bh / 2, vals[kk], ha="center", va="center", fontsize=fs - 0.2,
                    fontweight="bold" if (bb == 2 and int(vals[kk]) <= 3) else "normal")
    # legend (two rows, fixed slots)
    def leg(x, y, m, kw, t):
        ax.plot(x, y, m, **kw); ax.text(x + 0.3, y, t, va="center", fontsize=fs)
    y1, y2 = -0.55, -1.15
    leg(0.2, y1, "o", dict(color=INK, ms=5.5), "Strong (9)")
    leg(2.6, y1, "o", dict(mfc="white", mec=INK, ms=5.5), "Medium (3)")
    leg(5.0, y1, "^", dict(mfc="white", mec=INK, ms=5.5), "Weak (1)")
    ax.text(7.4, y1, "Roof:  ++ strong positive   − negative   −− strong negative", va="center", fontsize=fs)
    leg(0.2, y2, "o", dict(color=INK, ms=3.6), "Current design")
    leg(3.4, y2, "s", dict(color=RED, ms=3.3), "Competitor A")
    leg(6.4, y2, "^", dict(color="#1e7a3c", ms=3.8), "Competitor B")
    leg(9.4, y2, "*", dict(color="#c8a000", ms=6.0), "Target")
    ax.text(12.0, y2, "▲ maximise   ▼ minimise   ◎ nominal target", va="center", fontsize=fs)
    fig.savefig(f"{OUT}/fig3_house_of_quality.png", dpi=400, bbox_inches="tight", pad_inches=0.05)
    plt.close(fig)
    return I, rel, rank


def box(ax, x, y, w, h, text, fc, fs=8, lh=0.2, ec=INK):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=fc, ec=ec, lw=1.0))
    lines = text.split("\n"); n = len(lines); cy = y + h / 2
    top = cy + n * lh / 2
    for i, ln in enumerate(lines):
        ax.text(x + w / 2, top - (i + 0.5) * lh, ln, ha="center", va="center",
                fontsize=fs if i == 0 else fs - 0.6, fontweight="bold" if (i == 0 and n > 1) else "normal")


def arrow(ax, p, q, color="0.25", lw=1.1, ls="-", style="-|>", conn="arc3"):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle=style, mutation_scale=9, color=color, lw=lw, linestyle=ls,
                                 connectionstyle=conn, shrinkA=0, shrinkB=0))


def framework():
    fig, ax = plt.subplots(figsize=(6.3, 7.8)); ax.axis("off")
    ax.set_xlim(0, 8.6); ax.set_ylim(0, 10.65)
    X, Wd, lh = 0.2, 5.6, 0.21
    steps = [
        (9.85, 0.62, "Voice of the customer\nInterviews with farmers, orchard operators, extension staff", "#f6e3e3"),
        (8.5, 0.86, "Step 1 – AHP\nPairwise comparison of CR1–CR8\nprincipal eigenvector · consistency check (CR ≤ 0.10)", "#e3ebf5"),
        (7.1, 0.86, "Step 2 – Phase-I QFD (House of Quality)\nRelationship matrix (9-3-1) · technical importance\ntargets · correlation roof", "#e3ebf5"),
        (5.7, 0.86, "Step 3 – TRIZ\nRoof conflicts → contradictions in the 39 parameters\ncontradiction matrix → inventive principles → concepts", "#e5f1df"),
        (4.3, 0.86, "Step 4 – Phase-II QFD\nFCs and TRIZ concepts → component parameters\nclassification into control and noise factors", "#e3ebf5"),
        (2.9, 0.86, "Step 5 – Taguchi robust design\nL18 array × compound noise · larger-the-better S/N\nANOVA · additive prediction", "#fdf0d9"),
        (1.55, 0.72, "Confirmation experiment\nMeasured S/N within the 95% confidence interval?", "#fdf0d9"),
        (0.25, 0.55, "Robust design specification", "#f6e3e3"),
    ]
    for y, h, t, c in steps:
        box(ax, X, y, Wd, h, t, c, fs=8.2, lh=lh)
    data = ["8 customer requirements", "weights $w_j$", "importance $I_k$, targets, conflicting FC pairs",
            "design concepts", "control factors A–G, noise factor N",
            "optimal levels, predicted η ± CI", "yes"]
    for i in range(len(steps) - 1):
        ytop = steps[i + 1][0] + steps[i + 1][1]; ybot = steps[i][0]
        arrow(ax, (X + Wd / 2, ybot), (X + Wd / 2, ytop))
        ax.text(X + Wd / 2 + 0.12, (ybot + ytop) / 2, data[i], ha="left", va="center", fontsize=6.9, style="italic", color="0.2")
    xr1 = X + Wd + 0.35
    y_ahp = steps[1][0] + steps[1][1] / 2
    ax.plot([X + Wd, xr1, xr1], [y_ahp - 0.22, y_ahp - 0.22, y_ahp + 0.22], color=RED, lw=1)
    arrow(ax, (xr1, y_ahp + 0.22), (X + Wd, y_ahp + 0.22), color=RED)
    ax.text(xr1 + 0.1, y_ahp, "CR > 0.10:\nrevise\njudgements", fontsize=6.6, color=RED, va="center")
    y_conf = steps[6][0] + steps[6][1] / 2; y_triz = steps[3][0] + steps[3][1] / 2
    xr = X + Wd + 1.5
    ax.plot([X + Wd, xr, xr], [y_conf, y_conf, y_triz], color=RED, lw=1)
    arrow(ax, (xr, y_triz), (X + Wd, y_triz), color=RED)
    ax.text(xr + 0.1, (y_conf + y_triz) / 2, "no: revisit\nconcepts,\nfactors or\nlevels", fontsize=6.6, color=RED, va="center")
    fig.savefig(f"{OUT}/fig1_framework.png", dpi=400, bbox_inches="tight", pad_inches=0.05); plt.close(fig)


def architecture():
    fig, ax = plt.subplots(figsize=(7.0, 3.9)); ax.axis("off")
    ax.set_xlim(0, 13.1); ax.set_ylim(0.2, 7.1)
    P = "#8b1a1a"; S = "0.15"; lh = 0.27
    def b(x, y, w, h, t, fc): box(ax, x, y, w, h, t, fc, fs=7.6, lh=lh)
    b(0.2, 5.6, 2.5, 1.1, "Transmitter\n2.4 GHz RF link", "#fbe3d3")
    b(3.6, 5.3, 3.2, 1.4, "Removable control board\nMCU · RF receiver\nlink-loss fail-safe", "#dce9f6")
    b(0.2, 0.4, 2.5, 1.2, "Li-ion battery pack\n48 V · 20 Ah (960 Wh)", "#fdf1c7")
    b(3.6, 0.4, 3.2, 1.2, "Power distribution\nfuses · DC–DC converter", "#fdf1c7")
    b(3.6, 2.6, 3.2, 1.6, "Spray subsystem\ntank → diaphragm pump\n→ pressure regulator\n→ nozzle boom", "#f4d9c6")
    b(8.0, 4.5, 2.2, 1.1, "Motor driver L\nPWM · current limit", "#dce9f6")
    b(8.0, 2.6, 2.2, 1.1, "Motor driver R\nPWM · current limit", "#dce9f6")
    b(10.75, 4.5, 2.15, 1.1, "In-wheel motor\nfront left · 300 W", "#d9eed2")
    b(10.75, 2.6, 2.15, 1.1, "In-wheel motor\nfront right · 300 W", "#d9eed2")
    b(10.75, 0.7, 2.15, 1.1, "Rear wheels\npassive, trailing", "#e6e6e6")
    # signals
    arrow(ax, (2.7, 6.35), (3.6, 6.35), color=S, ls="--")
    arrow(ax, (6.8, 6.3), (8.6, 5.6), color=S, ls="--")
    arrow(ax, (6.8, 5.6), (8.0, 3.5), color=S, ls="--")
    arrow(ax, (5.2, 5.3), (5.2, 4.2), color=S, ls="--")
    ax.text(5.3, 4.75, "pump PWM", fontsize=6.5, color=S)
    # power
    arrow(ax, (2.7, 1.0), (3.6, 1.0), color=P, lw=2.0)
    arrow(ax, (5.2, 1.6), (5.2, 2.6), color=P, lw=2.0)
    ax.plot([6.8, 7.55, 7.55], [1.0, 1.0, 5.05], color=P, lw=2.0)
    arrow(ax, (7.5, 5.05), (8.0, 5.05), color=P, lw=2.0)
    arrow(ax, (7.5, 3.15), (8.0, 3.15), color=P, lw=2.0)
    ax.plot([3.6, 3.3, 3.3], [1.4, 1.4, 5.65], color=P, lw=1.3)
    arrow(ax, (3.28, 5.65), (3.6, 5.65), color=P, lw=1.3)
    ax.text(3.2, 3.4, "logic supply", fontsize=6.3, color=P, rotation=90, ha="right", va="center")
    arrow(ax, (10.2, 5.05), (10.75, 5.05), color=P, lw=2.0)
    arrow(ax, (10.2, 3.15), (10.75, 3.15), color=P, lw=2.0)
    ax.add_patch(Rectangle((10.6, 0.5), 2.45, 5.35, fill=False, ec="0.5", ls=":", lw=1))
    ax.text(11.82, 5.95, "Chassis", fontsize=6.8, ha="center", color="0.35")
    ax.plot([0.3, 0.9], [3.6, 3.6], color=P, lw=2.0); ax.text(1.0, 3.6, "Electrical power", va="center", fontsize=7)
    ax.plot([0.3, 0.9], [3.1, 3.1], color=S, lw=1.1, ls="--"); ax.text(1.0, 3.1, "Control signal", va="center", fontsize=7)
    fig.savefig(f"{OUT}/fig2_architecture.png", dpi=400, bbox_inches="tight", pad_inches=0.05); plt.close(fig)


if __name__ == "__main__":
    I, rel, rank = hoq()
    print("abs", np.round(I, 3)); print("rel", np.round(rel, 2)); print("rank", rank)
    framework(); architecture()

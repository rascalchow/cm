#!/usr/bin/env python3
"""
Taguchi L18 (2^1 x 3^7) analysis for the sprayer robust-design study.

Reads l18_responses.csv (one row per run: factor levels A-G and the response
under each noise condition), and writes:
  - results/sn_and_means.csv      per-run mean and larger-the-better S/N ratio
  - results/response_table.csv    level means of S/N and of the raw response
  - results/anova_sn.csv          ANOVA of the S/N ratios (unpooled and pooled)
  - results/prediction.txt        optimum, additive prediction and 95% CI
  - figures (PNG): main effects of S/N and means, ANOVA contribution, prediction

Usage:
  python taguchi_l18_analysis.py [--csv l18_responses.csv] [--pool A]
                                 [--alpha 0.05] [--r-confirm 3] [--figdir ../figures]

--pool: factors to pool into the error term in addition to the unassigned
        column 8 (default: factors whose unpooled contribution is < 5 %).
Replace the y_* columns with measured values and re-run; every number in
the manuscript's Tables 8-11 and Figs 4-7 is regenerated from this file.
"""
import argparse, os
import numpy as np, pandas as pd
from scipy import stats

FACTORS = {
    "A": ("Battery configuration", "series cells", [13, 14]),
    "B": ("Motor current limit", "A", [12, 16, 20]),
    "C": ("Wheel track width", "mm", [480, 520, 560]),
    "D": ("Nozzle orifice diameter", "mm", [1.0, 1.2, 1.4]),
    "E": ("Spray pressure", "bar", [6, 8, 10]),
    "F": ("Travel speed", "m/s", [0.8, 1.0, 1.2]),
    "G": ("Boom height", "mm", [400, 500, 600]),
}
SHORT = {"A": "Battery", "B": "Current limit", "C": "Wheel track", "D": "Orifice",
         "E": "Pressure", "F": "Speed", "G": "Boom height"}
# Column 8 of the standard L18 array (unassigned -> error estimate)
COL8 = [1, 2, 3, 3, 1, 2, 3, 1, 2, 1, 2, 3, 2, 3, 1, 2, 3, 1]


def sn_ltb(y):
    y = np.asarray(y, float)
    return -10 * np.log10(np.mean(1.0 / y**2, axis=1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default="l18_responses.csv")
    ap.add_argument("--pool", nargs="*", default=None)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--r-confirm", type=int, default=3)
    ap.add_argument("--figdir", default="../figures")
    ap.add_argument("--outdir", default="results")
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True); os.makedirs(a.figdir, exist_ok=True)

    df = pd.read_csv(a.csv)
    ycols = [c for c in df.columns if c.startswith("y_")]
    Y = df[ycols].to_numpy(float)
    df["mean"] = Y.mean(1)
    df["SN"] = sn_ltb(Y)
    df["e8"] = COL8
    df[["run"] + list(FACTORS) + ycols + ["mean", "SN"]].round(3).to_csv(
        f"{a.outdir}/sn_and_means.csv", index=False)

    gm, gmy, N = df.SN.mean(), df["mean"].mean(), len(df)
    cols = list(FACTORS) + ["e8"]
    resp, respm, SS, DF = {}, {}, {}, {}
    for c in cols:
        lv = sorted(df[c].unique())
        resp[c] = [df.SN[df[c] == l].mean() for l in lv]
        respm[c] = [df["mean"][df[c] == l].mean() for l in lv]
        SS[c] = sum((df[c] == l).sum() * (m - gm) ** 2 for l, m in zip(lv, resp[c]))
        DF[c] = len(lv) - 1
    SST = ((df.SN - gm) ** 2).sum()

    # Response table
    rows = []
    for c in FACTORS:
        r = resp[c] + [np.nan] * (3 - len(resp[c]))
        rm = respm[c] + [np.nan] * (3 - len(respm[c]))
        rows.append([c, FACTORS[c][0], *r, max(resp[c]) - min(resp[c]), *rm,
                     max(respm[c]) - min(respm[c]), int(np.argmax(resp[c])) + 1])
    rt = pd.DataFrame(rows, columns=["code", "factor", "SN_L1", "SN_L2", "SN_L3", "SN_delta",
                                     "M_L1", "M_L2", "M_L3", "M_delta", "best_level"])
    rt["rank"] = rt.SN_delta.rank(ascending=False).astype(int)
    rt.round(3).to_csv(f"{a.outdir}/response_table.csv", index=False)

    # Pooling
    pool = a.pool if a.pool is not None else [c for c in FACTORS if 100 * SS[c] / SST < 5]
    pool_all = list(pool) + ["e8"]
    SSe = sum(SS[c] for c in pool_all); DFe = sum(DF[c] for c in pool_all); Ve = SSe / DFe
    an = []
    for c in FACTORS:
        if c in pool:
            an.append([c, FACTORS[c][0], DF[c], SS[c], SS[c] / DF[c], np.nan, np.nan, np.nan, "pooled"])
            continue
        F = (SS[c] / DF[c]) / Ve; p = 1 - stats.f.cdf(F, DF[c], DFe)
        rho = 100 * (SS[c] - DF[c] * Ve) / SST
        an.append([c, FACTORS[c][0], DF[c], SS[c], SS[c] / DF[c], F, p, rho, ""])
    an.append(["e", "Pooled error (" + "+".join(pool + ["col 8"]) + ")", DFe, SSe, Ve, np.nan, np.nan,
               100 - sum(x[7] for x in an if not np.isnan(x[7])), ""])
    an.append(["T", "Total", N - 1, SST, np.nan, np.nan, np.nan, 100.0, ""])
    anova = pd.DataFrame(an, columns=["code", "source", "DF", "SS", "MS", "F", "p", "rho_pct", "note"])
    anova.round(4).to_csv(f"{a.outdir}/anova_sn.csv", index=False)

    # Unpooled check against column 8 only
    Ve8 = SS["e8"] / DF["e8"]

    # Prediction (factors significant at alpha)
    best = {c: int(np.argmax(resp[c])) for c in FACTORS}
    sig = [r[0] for r in an if r[0] in FACTORS and not np.isnan(r[6]) and r[6] < a.alpha]
    eta = gm + sum(resp[c][best[c]] - gm for c in sig)
    mu = gmy + sum(respm[c][best[c]] - gmy for c in sig)
    nu = sum(DF[c] for c in sig); neff = N / (1 + nu)
    Fc = stats.f.ppf(1 - a.alpha, 1, DFe)
    ci_pop = np.sqrt(Fc * Ve / neff)
    ci_conf = np.sqrt(Fc * Ve * (1 / neff + 1 / a.r_confirm))
    base = df.iloc[0]
    ibest = int(df.SN.idxmax())
    with open(f"{a.outdir}/prediction.txt", "w") as f:
        f.write(f"Grand mean S/N = {gm:.3f} dB; grand mean response = {gmy:.2f}\n")
        f.write(f"SST = {SST:.4f}; SS(col 8) = {SS['e8']:.4f} (DF 2); unpooled Ve = {Ve8:.5f}\n")
        f.write(f"Pooled factors: {pool}; error DF = {DFe}; Ve = {Ve:.5f}\n")
        f.write("Optimal levels (max S/N): " + ", ".join(f"{c}{best[c]+1}" for c in FACTORS) + "\n")
        f.write(f"Significant factors (alpha={a.alpha}): {sig}\n")
        f.write(f"Predicted S/N = {eta:.3f} dB  -> equivalent response 10^(S/N/20) = {10**(eta/20):.2f}\n")
        f.write(f"Predicted mean response (additive model on means) = {mu:.2f}\n")
        f.write(f"n_eff = {neff:.3f}; F(1,{DFe}) = {Fc:.3f}\n")
        f.write(f"95% CI (population mean) = +/-{ci_pop:.3f} dB\n")
        f.write(f"95% CI (confirmation, r={a.r_confirm}) = +/-{ci_conf:.3f} dB -> "
                f"[{eta-ci_conf:.2f}, {eta+ci_conf:.2f}] dB\n")
        f.write(f"Reference run 1: S/N = {base.SN:.3f} dB, mean = {base['mean']:.2f}\n")
        f.write(f"Best L18 run {int(df.run[ibest])}: S/N = {df.SN[ibest]:.3f} dB, mean = {df['mean'][ibest]:.2f}\n")
    print(open(f"{a.outdir}/prediction.txt").read())
    print(rt.round(3).to_string(index=False)); print(anova.round(4).to_string(index=False))

    make_figures(a.figdir, resp, respm, gm, gmy, best, anova, pool, df, eta, ci_conf, ibest)


def make_figures(figdir, resp, respm, gm, gmy, best, anova, pool, df, eta, ci_conf, ibest):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    import glob
    for fp in glob.glob("/usr/share/fonts/truetype/liberation/LiberationSans-*.ttf"):
        font_manager.fontManager.addfont(fp)
    fam = "Liberation Sans" if any("Liberation Sans" == f.name for f in font_manager.fontManager.ttflist) else "DejaVu Sans"
    plt.rcParams.update({"font.family": fam, "font.size": 9,
                         "axes.spines.top": False, "axes.spines.right": False})
    ink, accent = "#1f3b57", "#b22222"

    def main_effects(data, gmean, ylabel, fname):
        allv = [v for c in FACTORS for v in data[c]]
        pad = 0.08 * (max(allv) - min(allv))
        lo, hi = min(allv) - pad, max(allv) + pad
        fig, axs = plt.subplots(1, 7, figsize=(7.2, 2.3), sharey=True)
        for ax, c in zip(axs, FACTORS):
            name, unit, lv = FACTORS[c]
            x = np.arange(len(data[c]))
            ax.plot(x, data[c], "-o", color=ink, ms=4, lw=1.2)
            ax.axhline(gmean, ls="--", lw=0.8, color="0.55")
            k = int(np.argmax(data[c]))
            ax.plot(k, data[c][k], "o", ms=9, mfc="none", mec=accent, mew=1.4)
            ax.set_xticks(x); ax.set_xticklabels([f"{v:g}" for v in lv], fontsize=7.5)
            ax.set_xlim(-0.4, len(x) - 0.6)
            ax.set_title(f"{c}: {SHORT[c]}", fontsize=8)
            ax.set_xlabel(unit, fontsize=7.5)
            ax.set_ylim(lo, hi)
        axs[0].set_ylabel(ylabel)
        fig.tight_layout(w_pad=0.4)
        fig.savefig(f"{figdir}/{fname}", dpi=400); plt.close(fig)

    main_effects(resp, gm, "Mean S/N ratio (dB)", "fig4_main_effects_SN.png")
    main_effects(respm, gmy, "Mean uniformity index", "fig5_main_effects_mean.png")

    # ANOVA contribution
    sub = anova[anova.code.isin(list(FACTORS) + ["e"])].copy()
    sub = sub[~sub.note.eq("pooled")]
    sub = sub.sort_values("rho_pct", ascending=False)
    labels = [(f"{r.code}: {FACTORS[r.code][0]}" if r.code in FACTORS else "Pooled error") for r in sub.itertuples()]
    fig, ax = plt.subplots(figsize=(5.2, 2.8))
    cols = [ink if (r.code in FACTORS and r.p < 0.05) else ("#7f99b2" if r.code in FACTORS else "0.7")
            for r in sub.itertuples()]
    ax.barh(labels[::-1], sub.rho_pct.to_numpy()[::-1], color=cols[::-1])
    for i, (v, r) in enumerate(zip(sub.rho_pct.to_numpy()[::-1], list(sub.itertuples())[::-1])):
        star = "" if r.code not in FACTORS else ("*" if r.p < 0.05 else (" (p<0.10)" if r.p < 0.10 else " n.s."))
        ax.text(v + 0.4, i, f"{v:.1f}%{star}", va="center", fontsize=8)
    ax.set_xlabel("Percentage contribution to S/N variation (%)")
    ax.set_xlim(0, max(sub.rho_pct) * 1.3)
    fig.tight_layout(); fig.savefig(f"{figdir}/fig6_anova_contribution.png", dpi=400); plt.close(fig)

    # Prediction comparison (dot plot; bars on a truncated axis would exaggerate differences)
    fig, ax = plt.subplots(figsize=(4.6, 2.6))
    names = ["Reference\n(run 1)", "L18 grand\nmean", f"Best L18 run\n(run {int(df.run[ibest])})", "Predicted\noptimum"]
    vals = [df.SN.iloc[0], gm, df.SN[ibest], eta]
    x = np.arange(4)
    ax.plot(x[:3], vals[:3], "o", color="0.45", ms=7)
    ax.errorbar(3, eta, yerr=ci_conf, fmt="o", color=ink, ecolor=accent, capsize=5, lw=1.4, ms=7)
    for i, v in enumerate(vals):
        ax.annotate(f"{v:.2f} dB", (i, v), xytext=(9, -3), textcoords="offset points", fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=8)
    ax.set_xlim(-0.5, 3.9)
    ax.set_ylim(min(vals) - 0.5, max(vals) + ci_conf + 0.3)
    ax.set_ylabel("S/N ratio (dB)")
    ax.grid(axis="y", color="0.9", lw=0.6)
    fig.tight_layout(); fig.savefig(f"{figdir}/fig7_prediction.png", dpi=400); plt.close(fig)

if __name__ == "__main__":
    main()
